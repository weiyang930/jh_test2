import torch

from ..utils import get_logger
from .cpu import CpuPlatform
from .cuda import CudaPlatform
from .npu import NpuPlatform
from .platform import Platform
from .rocm import RocmPlatform
from .unknown import UnknownPlatform


logger = get_logger(__name__)


def _init_platform() -> Platform:
    """
    Detect and initialize the appropriate platform based on available devices.

    Priority:
    1. CUDA (NVIDIA / AMD ROCm)
    2. NPU (if torch_npu is installed)
    3. CPU (fallback)

    Returns:
        An instance of a subclass of Platform corresponding to the detected hardware.
    """
    try:
        if hasattr(torch, "npu") and torch.npu.is_available():
            logger.debug("Detected NPU (torch_npu). Initializing NPU platform.")
            return NpuPlatform()
    except ImportError:
        pass

    if torch.cuda.is_available():
        device_name = torch.cuda.get_device_name().upper()
        logger.debug(f"Detected CUDA device: {device_name}")

        if "NVIDIA" in device_name:
            logger.debug("Initializing CUDA platform (NVIDIA).")
            return CudaPlatform()
        elif "AMD" in device_name:
            logger.debug("Initializing ROCm platform (AMD).")
            return RocmPlatform()

        logger.warning("Unrecognized CUDA device. Falling back to UnknownPlatform.")
        return UnknownPlatform()
    
    logger.debug("No supported accelerator detected. Initializing CPU platform.")
    return CpuPlatform()


# Global singleton representing the current platform in use.
current_platform: Platform = _init_platform()

__all__ = [
    "Platform",
    "current_platform",
]
