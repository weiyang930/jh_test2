import collections
import json

BASE = "/workspace/async-rlvr/artifacts/runs"
ARMS = [("a1 fifo/uniform", "e2_a1_fifo_uniform"), ("a2 joint/uniform", "e2_a2_joint_uniform"),
        ("a3 fifo/cost", "e2_a3_fifo_costaware"), ("a4 joint/cost", "e2_a4_joint_costaware")]

rows = {}
for arm, rid in ARMS:
    d = f"{BASE}/{rid}"
    mets = [json.loads(l[l.index("{"):]) for l in open(f"{d}/stdout.log", errors="ignore")
            if '"time/step_total"' in l]

    def sm(k):
        v = [m[k] for m in mets[1:] if k in m]
        return sum(v) / max(len(v), 1)

    wall = sum(m.get("time/step_total", 0) for m in mets)
    subs = collections.defaultdict(list); rets = collections.defaultdict(list)
    grew = collections.defaultdict(list); gstep = {}; gcost = collections.defaultdict(float)
    for l in open(f"{d}/output/events.jsonl", errors="ignore"):
        try: e = json.loads(l)
        except json.JSONDecodeError: continue
        if e.get("event") == "sample_done":
            pid = e["prompt_id"]; grew[pid].append(e.get("reward"))
            gstep[pid] = e.get("sampling_start_step", -1)
            gcost[pid] += e.get("verifier_execution_s", 0.0)
            subs[gstep[pid]].append(e["t_reward_submit"]); rets[pid].append(e["t_reward_return"])
    mk = collections.defaultdict(float); inf_n = 0; cost_tot = 0.0; grp_n = 0
    for pid, rs in grew.items():
        if len(rs) != 4: continue
        grp_n += 1; cost_tot += gcost[pid]
        if len(set(rs)) > 1:
            inf_n += 1; s = gstep[pid]
            mk[s] = max(mk[s], max(rets[pid]) - min(subs[s]))
    mks = sorted(v for k, v in mk.items() if k >= 0); n = len(mks)
    vq = [json.loads(l) for l in open(f"{d}/output/verify_queue_events.jsonl")]
    disp = [e for e in vq if e["event"] == "dispatch"]
    w = sorted(e["queue_wait_s"] for e in disp)
    expl = sum(1 for e in disp if e.get("explored"))
    kept = sum(m.get("compaction/groups_kept", 0) for m in mets)
    # admission audit: per-step ESS over selected candidates
    adm = [json.loads(l) for l in open(f"{d}/output/admission_events.jsonl")]
    sel = [e for e in adm if e.get("event") == "candidate" and e.get("selected") and e.get("pool_id") is not None]
    by_step = collections.defaultdict(list)
    for e in sel:
        by_step[e["step"]].append(1.0 / e["path_propensity"])
    esss = []; maxw = 0
    for s, ws in by_step.items():
        esss.append(sum(ws) ** 2 / sum(x * x for x in ws)); maxw = max(maxw, max(ws) / min(ws))
    esss.sort()
    rows[arm] = dict(steps=len(mets), wall=wall / 3600, step=sm("time/step_total"),
                     train=sm("time/step_train"), cost_grp=cost_tot / grp_n, cpu=cost_tot,
                     inf_rate=inf_n / grp_n, q50=w[len(w) // 2], q90=w[int(.9 * len(w))], qmax=w[-1],
                     mk_mean=sum(mks) / n, mk90=mks[int(.9 * n)], mkmax=mks[-1],
                     inf_step=kept / len(mets), inf_hour=kept / (wall / 3600),
                     score=sum(m.get("critic/score/mean", 0) for m in mets[-5:]) / 5,
                     expl=expl / len(disp), ess=sum(esss) / len(esss), rel_w=maxw)

hdr = ["steps", "wall", "step", "train", "cost_grp", "cpu", "inf_rate", "q50", "q90", "qmax",
       "mk_mean", "mk90", "mkmax", "inf_step", "inf_hour", "score", "expl", "ess"]
print(f"{'metric':10s}" + "".join(f"{a.split()[0]:>12s}" for a, _ in ARMS))
for k in hdr:
    print(f"{k:10s}" + "".join(f"{rows[a][k]:12.2f}" for a, _ in ARMS))
