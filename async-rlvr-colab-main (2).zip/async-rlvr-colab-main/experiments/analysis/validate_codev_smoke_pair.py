"""Verify completed smokes using measured updates and runtime configuration."""
import argparse
import json
import math
import re
from collections import Counter
from pathlib import Path

from analyze_codev_smoke import json_lines, summarize


def flatten(value, prefix=''):
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            result.update(flatten(item, f'{prefix}.{key}' if prefix else key))
        return result
    return {prefix: value}


def normalized_config(folder):
    path = folder / 'output/runtime_config.json'
    config = json.loads(path.read_text())
    # Backups reside elsewhere; infer the original remote run directory.
    remote_run = str(Path(config['output_dir']).parent)
    text = json.dumps(config).replace(remote_run, '<RUN>')
    return flatten(json.loads(re.sub(r'20260907-\d{6}', '<STAMP>', text)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('async_run', type=Path)
    parser.add_argument('sync_run', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    reports, checks = [], {}
    for label, folder in [('async', args.async_run), ('sync', args.sync_run)]:
        summary = summarize(folder)
        reports.append(summary)
        checks[f'{label}/completed'] = summary['status'] == 'completed'
        checks[f'{label}/two_updates'] = summary['learner_updates_completed'] == 2
        checks[f'{label}/two_batches'] = summary['sampler_batches_consumed'] == 2
        checks[f'{label}/512_rows_each'] = summary['training_rows_per_update'] == [512, 512]
        checks[f'{label}/two_optimizer_steps_each'] = summary['optimizer_updates_per_learner'] == [2, 2]
        changes = summary['parameter_probe_changed_elements']
        checks[f'{label}/parameters_changed'] = len(changes) == 2 and all(x is not None and x > 0 for x in changes)
        for metric in ('grad_norm_per_update', 'pg_loss_per_update'):
            values = summary[metric]
            checks[f'{label}/{metric}_finite'] = len(values) == 2 and all(x is not None and math.isfinite(x) for x in values)
        consumers = [r for r in json_lines(folder / 'output/scheduler_events.jsonl')
                     if r.get('event') == 'consume_batch']
        groups = Counter(item['prompt_id'] for r in consumers for item in r['consumed_items'])
        checks[f'{label}/64_distinct_complete_groups'] = len(groups) == 64 and set(groups.values()) == {16}
        samples = [r for r in json_lines(folder / 'output/events.jsonl')
                   if r.get('event') == 'sample_done' and r['prompt_id'] in groups]
        checks[f'{label}/1024_valid_unique_trajectories'] = (
            len(samples) == 1024 and all(r.get('reward_valid', True) for r in samples)
            and len({(r['prompt_id'], r['member_index']) for r in samples}) == 1024)
        checks[f'{label}/within_response_cap'] = bool(samples) and max(r['response_tokens'] for r in samples) <= 16384
        (folder / 'smoke_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    left, right = normalized_config(args.async_run), normalized_config(args.sync_run)
    differences = {key: [left.get(key), right.get(key)] for key in left.keys() | right.keys()
                   if left.get(key) != right.get(key)}
    checks['pair/same_training_source'] = reports[0]['source_commit'] == reports[1]['source_commit']
    checks['pair/intended_config_differences_only'] = differences == {
        'async_generation_ratio': [1, 0], 'prompt_admission_args.mode': ['value_cost', 'uniform']}
    checks['async/partial_resumption_exercised'] = reports[0]['resumed_consumed_trajectories'] > 0
    checks['sync/no_partial_resumptions'] = (reports[1]['status'] == 'completed'
                                             and reports[1]['resumed_finished_trajectories'] == 0)
    selection_training_path_exercised = (
        reports[0]['consumed_group_selection_slots'].get('exploit', 0) > 0)
    result = dict(passed=all(checks.values()),
                  pair_evaluation_status='completed' if all(r['status'] == 'completed' for r in reports) else 'incomplete',
                  checks=checks, config_differences=differences,
                  summaries=reports, quality_evaluated=False,
                  selection_training_path_exercised=selection_training_path_exercised,
                  interpretation='Hardware/control smoke only; selector consumption is reported separately. '
                  'A passing hardware result does not imply selected prompts were trained or quality improved.')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'passed': result['passed'], 'failed_checks': [k for k, v in checks.items() if not v],
                      'selection_training_path_exercised': selection_training_path_exercised,
                      'config_differences': differences}, indent=2))
