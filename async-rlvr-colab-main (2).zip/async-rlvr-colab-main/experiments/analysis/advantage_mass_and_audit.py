import collections
import json

import numpy as np

BASE = "artifacts/runs"
ARMS = {"a1 fifo/uni": "e2_a1_fifo_uniform", "a2 joint/uni": "e2_a2_joint_uniform",
        "a3 fifo/cost": "e2_a3_fifo_costaware", "a4 joint/cost": "e2_a4_joint_costaware"}


def adv_mass(rs):
    r = np.array(rs, dtype=float)
    if len(set(rs)) <= 1:
        return 0.0
    a = (r - r.mean()) / (r.std() + 1e-6)
    return float(np.abs(a).sum())


data = {}
for arm, rid in ARMS.items():
    d = f"{BASE}/{rid}"
    mets = [json.loads(l[l.index("{"):]) for l in open(f"{d}/stdout.log", errors="ignore")
            if '"time/step_total"' in l]
    step_wall = [m.get("time/step_total", 0) for m in mets]
    grew = collections.defaultdict(list); gstep = {}
    for l in open(f"{d}/output/events.jsonl", errors="ignore"):
        try: e = json.loads(l)
        except json.JSONDecodeError: continue
        if e.get("event") == "prompt_commit":
            grew[e["prompt_id"]] = e.get("rewards", [])
            gstep[e["prompt_id"]] = e.get("sampling_start_step", -1)
    mass_by_step = collections.defaultdict(float); inf_by_step = collections.defaultdict(int)
    for pid, rs in grew.items():
        s = gstep.get(pid, -1)
        if s >= 0:
            mass_by_step[s] += adv_mass(rs)
            inf_by_step[s] += int(len(set(rs)) > 1)
    data[arm] = dict(step_wall=step_wall, mass=mass_by_step, inf=inf_by_step, d=d)

print("=== 1c. advantage mass (|A| sum under GRPO group-norm) ===")
wall_min = min(sum(v["step_wall"]) for v in data.values())
print(f"{'arm':14s} {'mass_total':>11s} {'mass/hour':>10s} {'mass@equalWC':>13s} {'inf@equalWC':>12s}")
for arm, v in data.items():
    wall = sum(v["step_wall"]); mass_tot = sum(v["mass"].values())
    cum = np.cumsum(v["step_wall"])
    n_cut = int(np.searchsorted(cum, wall_min)) + 1
    mass_cut = sum(m for s, m in v["mass"].items() if s < n_cut)
    inf_cut = sum(m for s, m in v["inf"].items() if s < n_cut)
    print(f"{arm:14s} {mass_tot:11.0f} {mass_tot/(wall/3600):10.0f} {mass_cut:13.0f} {inf_cut:12d}")
print(f"(equal wall-clock cutoff = {wall_min/3600:.2f}h, the fastest arm's total)")

print("\n=== 2b/2c. audit-weighted vs unweighted + bootstrap CI (cost-aware arms) ===")
for arm in ("a3 fifo/cost", "a4 joint/cost"):
    d = data[arm]["d"]
    adm = [json.loads(l) for l in open(f"{d}/output/admission_events.jsonl")]
    rew = {}; 
    for l in open(f"{d}/output/events.jsonl", errors="ignore"):
        try: e = json.loads(l)
        except json.JSONDecodeError: continue
        if e.get("event") == "prompt_commit":
            rew[e.get("dataset_id")] = e.get("rewards", [])
    steps = collections.defaultdict(list)
    for e in adm:
        if e.get("event") == "candidate" and e.get("selected") and e.get("pool_id") is not None:
            rid_ = e["dataset_id"]
            if rid_ in rew:
                informative = int(len(set(rew[rid_])) > 1)
                steps[e["step"]].append((informative, 1.0 / e["stage2_prob"]))
    unw_steps, wt_steps = [], []
    for s, items in steps.items():
        inf = np.array([i for i, _ in items]); w = np.array([x for _, x in items])
        unw_steps.append(inf.mean()); wt_steps.append((inf * w).sum() / w.sum())
    unw_steps, wt_steps = np.array(unw_steps), np.array(wt_steps)
    rng = np.random.default_rng(0)
    boots = [wt_steps[rng.integers(0, len(wt_steps), len(wt_steps))].mean() for _ in range(2000)]
    lo, hi = np.percentile(boots, [2.5, 97.5])
    print(f"{arm}: unweighted(selected) informative={unw_steps.mean():.3f} | "
          f"HT-weighted(pool est)={wt_steps.mean():.3f} 95%CI[{lo:.3f},{hi:.3f}] | "
          f"per-step HT std={wt_steps.std():.3f} (ESS=13 -> wide)")
