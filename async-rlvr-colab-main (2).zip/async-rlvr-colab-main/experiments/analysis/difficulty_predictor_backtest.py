"""Offline backtest: is group zero-variance (zero GRPO signal) predictable BEFORE rollout?

Gate for the verification-aware curriculum direction: train on steps [0, split),
test on steps [split, 100). Features use only what the prompt sampler would have
at admission time: the dataset row (prompt text + reference solution).

Usage: python experiments/analysis/difficulty_predictor_backtest.py <run_dir> [split_step]
"""
import glob
import json
import re
import sys

import numpy as np
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score


def structural_features(prompt: str, gt: str) -> list:
    return [
        len(prompt), len(gt),
        gt.count("\n"),
        len(re.findall(r"\balways\b", gt)),
        len(re.findall(r"\bposedge\b|\bnegedge\b", gt)),
        len(re.findall(r"\binput\b|\boutput\b", gt)),
        len(re.findall(r"\bcase\b", gt)),
        len(re.findall(r"\bif\b", gt)),
        len(re.findall(r"\breg\b", gt)),
        len(re.findall(r"\bwire\b", gt)),
        len(re.findall(r"<=", gt)),
        int("state" in gt.lower() or "fsm" in prompt.lower()),
        int("counter" in prompt.lower()),
        int("shift" in prompt.lower()),
        int("memory" in prompt.lower() or "ram" in prompt.lower()),
    ]


def load_groups(run_dir: str):
    rows = []
    for path in sorted(glob.glob(f"{run_dir}/output/generations/rollout_dump_data.step_*.jsonl")):
        for line in open(path, errors="ignore"):
            d = json.loads(line)
            ids, msgs, gts, scores, steps = d["id"], d["messages"], d["ground_truth"], d["scores"], d["global_step"]
            # rows are flat lists of samples; group = consecutive rows sharing the dataset id
            i = 0
            while i < len(ids):
                j = i
                while j < len(ids) and ids[j] == ids[i]:
                    j += 1
                group_scores = scores[i:j]
                prompt = json.loads(msgs[i])[-1]["content"] if msgs[i].startswith("[") else msgs[i]
                rows.append({
                    "id": ids[i],
                    "step": steps[i],
                    "prompt": prompt,
                    "gt": gts[i],
                    "scores": group_scores,
                    "zero_var": int(len(set(group_scores)) == 1),
                    "all_pass": int(all(s == 1.0 for s in group_scores)),
                    "all_09": int(len(set(group_scores)) == 1 and abs(group_scores[0] - 0.9) < 0.01),
                })
                i = j
    return rows


def main(run_dir: str, split_step: int = 80):
    rows = load_groups(run_dir)
    print(f"groups: {len(rows)}  (samples ~{sum(len(r['scores']) for r in rows)})")
    train = [r for r in rows if r["step"] < split_step]
    train_ids = {r["id"] for r in train}
    test = [r for r in rows if r["step"] >= split_step and r["id"] not in train_ids]
    dropped = sum(1 for r in rows if r["step"] >= split_step) - len(test)
    print(f"train: {len(train)} groups (steps 0-{split_step-1})  test: {len(test)} groups "
          f"(steps {split_step}-99, {dropped} dropped for id overlap)")
    print(f"zero-var rate: train={np.mean([r['zero_var'] for r in train]):.3f} "
          f"test={np.mean([r['zero_var'] for r in test]):.3f}")

    text_tr = [r["prompt"] + "\n" + r["gt"] for r in train]
    text_te = [r["prompt"] + "\n" + r["gt"] for r in test]
    tfidf = TfidfVectorizer(max_features=20000, ngram_range=(1, 2), sublinear_tf=True, min_df=2)
    Xt_tr = tfidf.fit_transform(text_tr)
    Xt_te = tfidf.transform(text_te)
    Xs_tr = np.array([structural_features(r["prompt"], r["gt"]) for r in train], dtype=float)
    Xs_te = np.array([structural_features(r["prompt"], r["gt"]) for r in test], dtype=float)
    mu, sd = Xs_tr.mean(0), Xs_tr.std(0) + 1e-9
    X_tr = sparse.hstack([Xt_tr, sparse.csr_matrix((Xs_tr - mu) / sd)]).tocsr()
    X_te = sparse.hstack([Xt_te, sparse.csr_matrix((Xs_te - mu) / sd)]).tocsr()

    for label, name in [("zero_var", "P(zero-variance)  <-- gate metric"),
                        ("all_pass", "P(all-pass 1.0)"),
                        ("all_09", "P(all-0.9 plateau)")]:
        y_tr = np.array([r[label] for r in train])
        y_te = np.array([r[label] for r in test])
        if y_te.sum() in (0, len(y_te)):
            print(f"{name}: degenerate test labels, skipped")
            continue
        clf = LogisticRegression(max_iter=2000, C=1.0)
        clf.fit(X_tr, y_tr)
        p = clf.predict_proba(X_te)[:, 1]
        auc = roc_auc_score(y_te, p)
        # budget view: if we skip the predicted-worst 50% of prompts, what fraction
        # of informative (non-zero-var) groups do we keep? (only for the gate label)
        extra = ""
        if label == "zero_var":
            order = np.argsort(p)  # ascending predicted zero-var prob = keep first
            keep = order[: len(order) // 2]
            informative_kept = (1 - y_te[keep]).sum() / max((1 - y_te).sum(), 1)
            extra = f" | keep-best-50% retains {informative_kept:.1%} of informative groups"
        print(f"{name}: AUC={auc:.3f} (base rate {y_te.mean():.3f}){extra}")


def u_score_backtest(run_dir: str, split_step: int = 80):
    """The principled variant: per-sample multinomial p(r|x), then U(x)=1-sum_r p_r^n.

    A single binary head on zero-variance is structurally handicapped (the label is
    the union of too-easy and too-hard, which have opposite feature signatures);
    composing the class distribution recovers the non-monotone target."""
    rows = load_groups(run_dir)
    train = [r for r in rows if r["step"] < split_step]
    train_ids = {r["id"] for r in train}
    test = [r for r in rows if r["step"] >= split_step and r["id"] not in train_ids]

    def expand(rs):
        texts, labels = [], []
        for r in rs:
            for s in r["scores"]:
                texts.append(r["prompt"] + "\n" + r["gt"])
                labels.append(0 if s <= 0.6 else (1 if s < 0.95 else 2))  # 0.5 / 0.9 / 1.0
        return texts, np.array(labels)

    tx_tr, y_tr = expand(train)
    tfidf = TfidfVectorizer(max_features=20000, ngram_range=(1, 2), sublinear_tf=True, min_df=2)
    X_tr = tfidf.fit_transform(tx_tr)
    clf = LogisticRegression(max_iter=2000, C=1.0)
    clf.fit(X_tr, y_tr)

    X_te = tfidf.transform([r["prompt"] + "\n" + r["gt"] for r in test])
    P = clf.predict_proba(X_te)  # (n_groups, 3)
    n = 4
    U = 1.0 - (P ** n).sum(axis=1)
    y_zero = np.array([r["zero_var"] for r in test])
    auc = roc_auc_score(y_zero, 1.0 - U)
    order = np.argsort(-U)  # keep highest-U first
    keep = order[: len(order) // 2]
    informative_kept = (1 - y_zero[keep]).sum() / max((1 - y_zero).sum(), 1)
    print(f"U-score (1 - sum p_r^{n}) composed from multinomial p(r|x):")
    print(f"  zero-variance AUC={auc:.3f} | keep-top-50%-U retains {informative_kept:.1%} of informative groups")
    # verifier-cost proxy: p(0.9) predicts the expensive EQY/timeout class
    p09 = P[:, 1]
    y09 = np.array([r["all_09"] for r in test])
    print(f"  cost proxy: AUC(p_hat(0.9) vs all-0.9 group)={roc_auc_score(y09, p09):.3f}")


def _fit_two_heads(train):
    """Two binary heads (all-pass / too-hard) on TF-IDF + structural features.

    Beats single-model variants at the admission top-k because the U-shape's two
    ends have opposite feature signatures; returns a scoring closure."""
    tfidf = TfidfVectorizer(max_features=20000, ngram_range=(1, 2), sublinear_tf=True, min_df=2)
    Xt = tfidf.fit_transform([r["prompt"] + "\n" + r["gt"] for r in train])
    Xs = np.array([structural_features(r["prompt"], r["gt"]) for r in train], dtype=float)
    mu, sd = Xs.mean(0), Xs.std(0) + 1e-9
    X = sparse.hstack([Xt, sparse.csr_matrix((Xs - mu) / sd)]).tocsr()
    heads = {}
    for label in ("all_pass", "too_hard"):
        y = np.array([r[label] for r in train])
        heads[label] = LogisticRegression(max_iter=2000).fit(X, y)

    def score(rows):
        Xt_ = tfidf.transform([r["prompt"] + "\n" + r["gt"] for r in rows])
        Xs_ = np.array([structural_features(r["prompt"], r["gt"]) for r in rows], dtype=float)
        X_ = sparse.hstack([Xt_, sparse.csr_matrix((Xs_ - mu) / sd)]).tocsr()
        p_easy = heads["all_pass"].predict_proba(X_)[:, 1]
        p_hard = heads["too_hard"].predict_proba(X_)[:, 1]
        return 1.0 - (p_easy + p_hard)

    return score


# class-conditional mean verifier seconds measured on the 100-step run (events.jsonl);
# exact per-group costs are blocked until dataset ids are logged into events.
CLASS_MEAN_VERIFIER_S = {0.5: 0.02, 0.9: 1.02, 1.0: 1.05}


def walk_forward_gate(run_dir: str, splits=(50, 60, 70, 80, 90), pool_factor: int = 2, n_boot: int = 2000):
    """The deployment-faithful offline gate: expanding walk-forward splits, precision@64
    under pooled admission, paired bootstrap CI over step-pairs, ECE, and an
    informative-groups-per-verifier-second proxy (class-conditional mean costs)."""
    rows = load_groups(run_dir)
    for r in rows:
        r["too_hard"] = int(r["zero_var"] and not r["all_pass"])
        r["est_cost"] = sum(CLASS_MEAN_VERIFIER_S[round(s, 1)] for s in r["scores"])

    all_sel, all_uni, eces = [], [], []
    print(f"=== expanding walk-forward: train [0,T) -> test [T,T+10), pool {pool_factor}x ===")
    for T in splits:
        train = [r for r in rows if r["step"] < T]
        test = [r for r in rows if T <= r["step"] < T + 10]
        score = _fit_two_heads(train)
        prec_sel, prec_uni = [], []
        steps = sorted({r["step"] for r in test})
        for pair in zip(*[steps[i::pool_factor] for i in range(pool_factor)]):
            pool = [r for r in test if r["step"] in pair]
            s = score(pool)
            informative = np.array([1 - r["zero_var"] for r in pool])
            sel = np.argsort(-s)[:64]
            prec_sel.append(informative[sel].mean())
            prec_uni.append(informative.mean())
        all_sel += prec_sel
        all_uni += prec_uni
        s = np.clip(score(test), 0, 1)
        y = np.array([1 - r["zero_var"] for r in test])
        ece = 0.0
        for lo, hi in zip(np.linspace(0, 1, 11)[:-1], np.linspace(0, 1, 11)[1:]):
            m = (s >= lo) & (s < hi)
            if m.sum():
                ece += m.mean() * abs(s[m].mean() - y[m].mean())
        eces.append(ece)
        print(f"T={T}: precision@64 sel={np.mean(prec_sel):.3f} uniform={np.mean(prec_uni):.3f} "
              f"(+{(np.mean(prec_sel)/np.mean(prec_uni)-1)*100:.0f}%) ECE={ece:.3f}")

    ps, pu = np.array(all_sel), np.array(all_uni)
    rng = np.random.default_rng(0)
    boots = [(ps[idx] / pu[idx]).mean() for idx in
             (rng.integers(0, len(ps), len(ps)) for _ in range(n_boot))]
    lo, hi = np.percentile(boots, [2.5, 97.5])
    print(f"pooled: sel {ps.mean():.3f} vs uni {pu.mean():.3f}; uplift x{ps.mean()/pu.mean():.3f} "
          f"(paired bootstrap 95% CI [{lo:.3f}, {hi:.3f}]); mean ECE={np.mean(eces):.3f}")

    # cost-proxy metric on the final split
    T = splits[-1]
    score = _fit_two_heads([r for r in rows if r["step"] < T])
    test = [r for r in rows if r["step"] >= T]
    steps = sorted({r["step"] for r in test})
    ig_sel, ig_uni = [], []
    for pair in zip(steps[::2], steps[1::2]):
        pool = [r for r in test if r["step"] in pair]
        s = score(pool)
        informative = np.array([1 - r["zero_var"] for r in pool])
        cost = np.array([r["est_cost"] for r in pool])
        sel = np.argsort(-s)[:64]
        ig_sel.append(informative[sel].sum() / cost[sel].sum())
        ig_uni.append(informative.sum() / cost.sum())
    print(f"informative groups per est-verifier-second: sel={np.mean(ig_sel):.4f} "
          f"uniform={np.mean(ig_uni):.4f} (+{(np.mean(ig_sel)/np.mean(ig_uni)-1)*100:.0f}%) "
          f"[class-conditional mean-cost proxy]")


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 80)
    u_score_backtest(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 80)
    walk_forward_gate(sys.argv[1])
