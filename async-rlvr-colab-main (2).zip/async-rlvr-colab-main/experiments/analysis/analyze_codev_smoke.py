"""Summarize real CodeV smoke events, keeping generation, filtering and training separate."""
import argparse
import json
import statistics
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


def json_lines(path: Path) -> list:
    """Tolerate one unfinished line when inspecting an active run."""
    if not path.exists():
        return []
    rows = []
    for line in path.read_text(errors='replace').splitlines():
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return rows


def summarize(folder: Path) -> dict:
    """Read actual counters; missing measurements remain null, never estimated results."""
    manifest = json.loads((folder / 'manifest.json').read_text())
    completion_file = folder / 'completion.json'
    completion = json.loads(completion_file.read_text()) if completion_file.exists() else None
    interruption_file = folder / 'monitoring_interruption.json'
    interruption = json.loads(interruption_file.read_text()) if interruption_file.exists() else None
    out = folder / 'output'
    events = json_lines(out / 'events.jsonl')
    scheduler = json_lines(out / 'scheduler_events.jsonl')
    admission = json_lines(out / 'admission_events.jsonl')
    verifiers = [r for f in out.glob('verifier_events.*.jsonl') for r in json_lines(f)]
    metrics = {}
    for line in (folder / 'stdout.log').read_text(errors='replace').splitlines():
        if '"system/global_step"' in line and '{' in line:
            try:
                value = json.loads(line[line.index('{'):])
                metrics[value['system/global_step']] = value
            except (json.JSONDecodeError, KeyError):
                continue
    samples = [r for r in events if r.get('event') == 'sample_done']
    consumes = [r for r in scheduler if r.get('event') == 'consume_batch']
    consumed_ids = {item['prompt_id'] for r in consumes for item in r.get('consumed_items', [])}
    consumed_samples = [r for r in samples if r['prompt_id'] in consumed_ids]
    counts = Counter(r.get('event') for r in events)
    observed = [r for r in admission if r.get('event') == 'observed_group']
    observed_by_group = {r['group_id']: r for r in observed}
    def sample_disposition(sample):
        group = sample['prompt_id']
        if group in consumed_ids:
            return 'consumed'
        outcome = observed_by_group.get(group)
        if outcome is None:
            return 'group_incomplete_or_canceled'
        if not outcome['valid']:
            return 'invalid_group'
        return 'useful_group_not_consumed' if outcome['useful'] else 'zero_variance_group'
    dispositions = Counter(sample_disposition(r) for r in samples)
    tokens_by_disposition = Counter()
    cpu_by_disposition = Counter()
    for sample in samples:
        tokens_by_disposition[sample_disposition(sample)] += sample.get('response_tokens', 0)
        cpu_by_disposition[sample_disposition(sample)] += sample.get('verifier_cpu_core_seconds', 0)
    consumed_slots = Counter(observed_by_group.get(group, {}).get('slot', 'unknown')
                             for group in consumed_ids)
    valid = [r for r in observed if r['valid']]
    uniform = [r for r in valid if r['slot'] in {'uniform', 'explore'}]
    g4_events = [len(set(r['rewards'][i:i+4])) > 1 for r in uniform for i in range(0,16,4)]
    peaks = {}
    if (folder / 'gpu.csv').exists():
        for line in (folder / 'gpu.csv').read_text().splitlines():
            values = [x.strip() for x in line.split(',')]
            if len(values) == 4:
                try:
                    index, memory = int(values[1]), float(values[2])
                    peaks[index] = max(peaks.get(index, 0), memory)
                except ValueError:
                    pass
    def mean(values):
        return statistics.mean(values) if values else None
    begin = datetime.fromisoformat(manifest['start_time'])
    elapsed = (completion['wall_seconds'] if completion else None if interruption
               else (datetime.now(timezone.utc)-begin).total_seconds())
    status = completion['status'] if completion else 'unknown_connection_lost' if interruption else 'running'
    rows = list(metrics.values())
    return dict(
        run_id=manifest['run_id'], status=status, completion_record_available=completion is not None,
        monitoring_interruption=interruption,
        source_commit=manifest['commit'], wall_seconds=elapsed,
        allocated_gpu_hours=6*elapsed/3600 if elapsed is not None else None,
        learner_updates_completed=len(rows), sampler_batches_consumed=len(consumes),
        generated_answers_completed=len(samples), generated_response_tokens=sum(r.get('response_tokens',0) for r in samples),
        completed_answers_by_disposition=dict(dispositions),
        completed_response_tokens_by_disposition=dict(tokens_by_disposition),
        sample_event_verifier_cpu_by_disposition=dict(cpu_by_disposition),
        mean_generated_response_tokens=mean([r['response_tokens'] for r in samples if 'response_tokens' in r]),
        consumed_sample_events=len(consumed_samples),
        mean_consumed_response_tokens=mean([r['response_tokens'] for r in consumed_samples]),
        consumed_response_cap_fraction=mean([int(r['response_tokens'] == 16384) for r in consumed_samples]),
        consumed_groups=sum(r['num_prompt_groups'] for r in consumes),
        consumed_trajectories=sum(r['num_samples'] for r in consumes), event_counts=dict(counts),
        valid_observed_groups=len(valid), useful_observed_groups=sum(r['useful'] for r in valid),
        valid_group_useful_fraction=mean([int(r['useful']) for r in valid]),
        uniform_observed_groups=len(uniform), uniform_g16_useful_fraction=mean([int(r['useful']) for r in uniform]),
        uniform_g4_subgroup_useful_fraction=mean([int(x) for x in g4_events]),
        subgroup_note='G4 diagnostic uses four subsets of each observed G16 group, not a separate training run.',
        selector_fits=sum(r.get('event') == 'predictor_fit' for r in admission),
        selection_slots=dict(Counter(r['slot'] for r in admission if r.get('event') == 'selected')),
        consumed_group_selection_slots=dict(consumed_slots),
        consumed_slots_per_update=[dict(Counter(
            observed_by_group.get(group, {}).get('slot', 'unknown')
            for group in {item['prompt_id'] for item in r.get('consumed_items', [])}
        )) for r in consumes],
        consumed_start_step_lag_per_update=[dict(Counter(r.get('staleness_per_sample', [])))
                                            for r in consumes],
        selector_cpu_core_seconds=sum(r.get('cpu_s', 0) for r in admission
                                     if r.get('event') in {'predictor_fit', 'selection_round'}),
        resumed_finished_trajectories=sum(r.get('partial_rollout_resumptions', 0) > 0 for r in samples),
        resumed_consumed_trajectories=sum(r.get('partial_rollout_resumptions', 0) > 0 for r in consumed_samples),
        completed_verification_jobs=len(verifiers),
        completed_verifier_cpu_core_seconds=sum(r.get('cpu_core_seconds',0) for r in verifiers),
        verifier_stage_counts=dict(Counter(r.get('stage') for r in verifiers)),
        verifier_cpu_core_seconds_by_stage={stage: sum(r.get('cpu_core_seconds', 0) for r in verifiers
                                                      if r.get('stage') == stage)
                                            for stage in sorted({r.get('stage', 'unknown') for r in verifiers})},
        mean_completed_verifier_wall_seconds=mean([r['verifier_execution_s'] for r in verifiers]),
        mean_reward_queue_wait_seconds=mean([r['reward_queue_wait_s'] for r in samples]),
        reported_previous_step_seconds=[r.get('time/step_total') for r in rows],
        mean_train_seconds=mean([r['time/step_train'] for r in rows]),
        physical_compaction_removed_rows=sum(r.get('compaction/samples_before',0)-r.get('compaction/samples_after',0) for r in rows),
        training_rows_per_update=[r.get('system/batch_size') for r in rows],
        optimizer_updates_per_learner=[r.get('actor/backward_steps') for r in rows],
        grad_norm_per_update=[r.get('actor_train/grad_norm') for r in rows],
        pg_loss_per_update=[r.get('actor/pg_loss@sum') for r in rows],
        gpu_peak_used_mib=peaks,
        reported_train_peak_allocated_gib=max((r.get('codev/train_peak_allocated_gib@max',0) for r in rows),default=None),
        reported_train_peak_reserved_gib=max((r.get('codev/train_peak_reserved_gib@max',0) for r in rows),default=None),
        parameter_probe_changed_elements=[r.get('codev/probe_changed_elements@sum') for r in rows],
        parameter_probe_max_abs_update=[r.get('codev/probe_max_abs_update@max') for r in rows],
        phase_seconds=[{k: v for k,v in r.items() if (k.startswith('time/step_') and k != 'time/step_total')
                        or k == 'time/old_log_probs'} for r in rows],
        caveats=['Short hardware smoke, no benchmark or trained-quality claim.',
                 'An unreachable run has unknown final wall time; local partial-event counters are not its final totals.',
                 'Start-step lag refers to request admission, not every token policy in a resumed trajectory.',
                 'Complete verifier CPU counters exclude any killed job without a final event.',
                 'Completed response token counts exclude canceled partial outputs.',
                 'ROLL time/step_total is the previous step duration, not the current step.',
                 'Startup and final in-flight work are included in wall time; compare step phases separately.'],
    )


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('run_dir', type=Path)
    parser.add_argument('--write', action='store_true')
    args = parser.parse_args()
    result = summarize(args.run_dir)
    if args.write:
        (args.run_dir / 'smoke_summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
