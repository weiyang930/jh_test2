"""Drift curves: predictor trained on window [t-w, t), tested at t+k for growing k.
Data: E1 both arms + E2 a1 (uniform arms only, to avoid selection-induced label shift)."""
import collections
import glob
import json

import numpy as np
from scipy.stats import spearmanr
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import roc_auc_score

RUNS = ["artifacts/runs/e1_uniform_r1_100step", "artifacts/runs/e2_a1_fifo_uniform"]
texts, rows = {}, []
for rd in RUNS:
    for p in glob.glob(f"{rd}/output/generations/*.jsonl"):
        for l in open(p, errors="ignore"):
            d = json.loads(l)
            for i, pid in enumerate(d["id"]):
                if pid not in texts:
                    m = d["messages"][i]
                    pr = json.loads(m)[-1]["content"] if m.startswith("[") else m
                    texts[pid] = pr + "\n" + d["ground_truth"][i]
    cost = collections.defaultdict(float); rew = {}; st = {}
    for l in open(f"{rd}/output/events.jsonl", errors="ignore"):
        try: e = json.loads(l)
        except json.JSONDecodeError: continue
        if e.get("event") == "sample_done":
            cost[e.get("dataset_id")] += e.get("verifier_execution_s", 0.0)
            st[e.get("dataset_id")] = e.get("sampling_start_step", -1)
        elif e.get("event") == "prompt_commit":
            rs = e.get("rewards", [])
            rew[e.get("dataset_id")] = rs
    for i, rs in rew.items():
        if i in cost and i in texts and st.get(i, -1) >= 0:
            zv = len(set(rs)) == 1
            rows.append({"id": i, "run": rd, "step": st[i], "cost": cost[i],
                         "all_pass": int(zv and rs[0] == 1.0),
                         "too_hard": int(zv and rs[0] != 1.0),
                         "informative": int(not zv)})

# use e1_uniform steps 0-99 as epoch A; e2_a1 steps as "later" (different policy state after
# independent training) - within-run horizon curves are the cleaner test:
run = "artifacts/runs/e1_uniform_r1_100step"
R = [r for r in rows if r["run"] == run]
W = 40
print(f"within-run drift (train [t-{W},t), test [t+k, t+k+10)), run=e1_uniform, n={len(R)}")
print(f"{'t':>3s} {'k':>3s} {'cost_rho':>9s} {'exp_auc':>8s} {'inf_auc(U)':>10s}")
for t in (40, 60):
    train = [r for r in R if t - W <= r["step"] < t]
    tf = TfidfVectorizer(max_features=20000, ngram_range=(1, 2), sublinear_tf=True, min_df=2)
    Xtr = tf.fit_transform([texts[r["id"]] for r in train])
    creg = Ridge(alpha=1.0).fit(Xtr, np.log1p([r["cost"] for r in train]))
    thr = np.quantile([r["cost"] for r in train], 0.9)
    cexp = LogisticRegression(max_iter=2000).fit(Xtr, [int(r["cost"] >= thr) for r in train])
    ce = LogisticRegression(max_iter=2000).fit(Xtr, [r["all_pass"] for r in train])
    ch = LogisticRegression(max_iter=2000).fit(Xtr, [r["too_hard"] for r in train])
    for k in (0, 10, 20, 30):
        test = [r for r in R if t + k <= r["step"] < t + k + 10]
        if len(test) < 200: continue
        Xte = tf.transform([texts[r["id"]] for r in test])
        chat = creg.predict(Xte)
        rho = spearmanr(chat, [r["cost"] for r in test]).correlation
        yexp = [int(r["cost"] >= thr) for r in test]
        aexp = roc_auc_score(yexp, cexp.predict_proba(Xte)[:, 1]) if 0 < sum(yexp) < len(yexp) else float("nan")
        U = 1 - ce.predict_proba(Xte)[:, 1] - ch.predict_proba(Xte)[:, 1]
        ainf = roc_auc_score([r["informative"] for r in test], U)
        print(f"{t:3d} {k:3d} {rho:9.3f} {aexp:8.3f} {ainf:10.3f}")

# cross-run transfer: bundle trained on ALL of e1_uniform, tested on e2_a1 (weeks... days later,
# fresh training trajectory) - the harshest realistic transfer we have
trainR = [r for r in rows if r["run"] == RUNS[0]]
testR = [r for r in rows if r["run"] == RUNS[1] and r["id"] not in {x["id"] for x in trainR}]
tf = TfidfVectorizer(max_features=20000, ngram_range=(1, 2), sublinear_tf=True, min_df=2)
Xtr = tf.fit_transform([texts[r["id"]] for r in trainR])
creg = Ridge(alpha=1.0).fit(Xtr, np.log1p([r["cost"] for r in trainR]))
thr = np.quantile([r["cost"] for r in trainR], 0.9)
cexp = LogisticRegression(max_iter=2000).fit(Xtr, [int(r["cost"] >= thr) for r in trainR])
ce = LogisticRegression(max_iter=2000).fit(Xtr, [r["all_pass"] for r in trainR])
ch = LogisticRegression(max_iter=2000).fit(Xtr, [r["too_hard"] for r in trainR])
Xte = tf.transform([texts[r["id"]] for r in testR])
rho = spearmanr(creg.predict(Xte), [r["cost"] for r in testR]).correlation
aexp = roc_auc_score([int(r["cost"] >= thr) for r in testR], cexp.predict_proba(Xte)[:, 1])
U = 1 - ce.predict_proba(Xte)[:, 1] - ch.predict_proba(Xte)[:, 1]
ainf = roc_auc_score([r["informative"] for r in testR], U)
print(f"\ncross-run transfer (e1_uniform -> e2_a1, fresh 100-step trajectory, {len(testR)} groups):")
print(f"  cost rho={rho:.3f}  expensive AUC={aexp:.3f}  informative AUC={ainf:.3f}")
