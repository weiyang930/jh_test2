"""Offline allocator replay on the 100-step run: oracle bounds for the main experiment.

Replays each step's actual verification jobs (real submit offsets and service times)
through a simulated 16-server queue under different orderings, measuring the time by
which all eventually-informative groups are verified ("informative-ready makespan") —
the quantity the async step actually waits on.

Orderings (per design_verification_aware_rlvr.md, semantics-preserving unless noted):
  fifo              actual submit order (production behavior)
  sept_oracle       shortest service time first (oracle cost; realizable proxy = predicted cost)
  value_oracle      jobs of eventually-informative groups first (oracle value), FIFO within class
  joint_oracle      informative-first, SEPT within class
  cancel_oracle     zero-variance groups' jobs never run (budgeted variant upper bound)

Usage: python experiments/analysis/allocator_replay.py <run_dir>
"""
import collections
import heapq
import json
import sys

WORKERS = 16


def load_jobs(run_dir):
    """Per step: list of jobs (submit_offset, service_s, group, informative)."""
    samples, group_rewards = [], collections.defaultdict(list)
    for line in open(f"{run_dir}/output/events.jsonl", errors="ignore"):
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue
        if e.get("event") == "sample_done":
            samples.append(e)
            group_rewards[e["prompt_id"]].append(e.get("reward"))
    informative = {pid: len(set(rs)) > 1 for pid, rs in group_rewards.items()}
    by_step = collections.defaultdict(list)
    for s in samples:
        by_step[s.get("sampling_start_step", -1)].append(s)
    steps = {}
    for step, ss in by_step.items():
        t0 = min(x["t_reward_submit"] for x in ss)
        steps[step] = [
            {
                "submit": x["t_reward_submit"] - t0,
                "service": max(x.get("verifier_execution_s", 0.0), 1e-4),
                "group": x["prompt_id"],
                "informative": informative[x["prompt_id"]],
            }
            for x in ss
        ]
    return steps


def simulate(jobs, order_key, drop=None):
    """List scheduling on WORKERS servers honoring submit times; returns completion times."""
    jobs = [j for j in jobs if drop is None or not drop(j)]
    pending = sorted(jobs, key=lambda j: j["submit"])
    ready, done, t = [], [], 0.0
    servers = [0.0] * WORKERS  # next-free times
    heapq.heapify(servers)
    i = 0
    while i < len(pending) or ready:
        if not ready:
            t = max(pending[i]["submit"], heapq.nsmallest(1, servers)[0])
            while i < len(pending) and pending[i]["submit"] <= t:
                ready.append(pending[i]); i += 1
            continue
        free = heapq.heappop(servers)
        start = max(free, min(j["submit"] for j in ready))
        while i < len(pending) and pending[i]["submit"] <= start:
            ready.append(pending[i]); i += 1
        ready.sort(key=order_key)
        job = ready.pop(0)
        start = max(free, job["submit"])
        end = start + job["service"]
        heapq.heappush(servers, end)
        done.append((job, end))
    return done


def informative_ready_makespan(done):
    group_end = collections.defaultdict(float)
    group_informative = {}
    for job, end in done:
        group_end[job["group"]] = max(group_end[job["group"]], end)
        group_informative[job["group"]] = job["informative"]
    ends = [e for g, e in group_end.items() if group_informative[g]]
    return max(ends) if ends else 0.0


def main(run_dir):
    steps = load_jobs(run_dir)
    policies = {
        "fifo": lambda j: (j["submit"],),
        "sept_oracle": lambda j: (j["service"],),
        "value_oracle": lambda j: (not j["informative"], j["submit"]),
        "joint_oracle": lambda j: (not j["informative"], j["service"]),
    }
    results = collections.defaultdict(list)
    cpu_total = cpu_cancel = 0.0
    for step, jobs in sorted(steps.items()):
        if len(jobs) < WORKERS:
            continue
        for name, key in policies.items():
            results[name].append(informative_ready_makespan(simulate(jobs, key)))
        results["cancel_oracle"].append(
            informative_ready_makespan(simulate(jobs, policies["joint_oracle"],
                                                drop=lambda j: not j["informative"])))
        cpu_total += sum(j["service"] for j in jobs)
        cpu_cancel += sum(j["service"] for j in jobs if j["informative"])

    def stats(xs):
        xs = sorted(xs)
        return (sum(xs) / len(xs), xs[len(xs) // 2], xs[int(0.9 * len(xs))], xs[-1])

    base = stats(results["fifo"])[0]
    print(f"steps replayed: {len(results['fifo'])}   (16 servers, real submit offsets + service times)")
    print(f"{'policy':14s} {'mean':>8s} {'p50':>8s} {'p90':>8s} {'max':>8s} {'vs fifo':>9s}")
    for name in ["fifo", "sept_oracle", "value_oracle", "joint_oracle", "cancel_oracle"]:
        m, p50, p90, mx = stats(results[name])
        print(f"{name:14s} {m:8.1f} {p50:8.1f} {p90:8.1f} {mx:8.1f} {base / m:8.2f}x")
    print(f"cancel_oracle verifier-CPU: {cpu_cancel:.0f}/{cpu_total:.0f}s = saves {1 - cpu_cancel / cpu_total:.1%}")


if __name__ == "__main__":
    main(sys.argv[1])
