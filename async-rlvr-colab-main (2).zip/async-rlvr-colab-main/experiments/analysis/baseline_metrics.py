"""Live baseline metrics for a running RTL async run (read-only, non-interfering).

Covers task §16: throughput, verifier decomposition/utilization, staleness,
whole-group selection dynamics, useful-verifier-work fraction, and per-update
training metrics parsed from stdout.log.

Usage: python experiments/analysis/baseline_metrics.py artifacts/runs/<RUN_ID>
"""
import glob
import json
import re
import sys
import time
from collections import defaultdict


def load_jsonl(pattern):
    out = []
    for p in glob.glob(pattern):
        with open(p) as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        out.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
    return out


def pct(vals, q):
    if not vals:
        return float("nan")
    s = sorted(vals)
    return s[min(int(q * len(s)), len(s) - 1)]


def main(run_dir):
    ev = load_jsonl(f"{run_dir}/output/events.jsonl")
    sev = load_jsonl(f"{run_dir}/output/scheduler_events.jsonl")
    vev = load_jsonl(f"{run_dir}/output/verifier_events.*.jsonl")

    commits = [e for e in ev if e.get("event") == "prompt_commit"]
    samples = [e for e in ev if e.get("event") == "sample_done"]
    cancels = [e for e in ev if e.get("event") == "prompt_canceled"]
    filtered = [e for e in ev if e.get("event") == "prompt_filtered"]
    consume = [e for e in sev if e.get("event") == "consume_batch"]
    gc_aborts = [e for e in sev if e.get("event") == "gc_abort_prompt"]
    steps = sorted({e["step"] for e in sev if e.get("event") == "step_begin"})

    if not ev:
        print("no events yet")
        return

    t0 = min(e["ts"] for e in ev)
    t1 = max(e["ts"] for e in ev)
    hours = max((t1 - t0) / 3600, 1e-9)
    updates = len(consume)

    print(f"=== throughput (window {t1 - t0:.0f}s) ===")
    print(f"learner updates completed: {updates}  ({updates / hours:.1f}/h)")
    print(f"prompt groups committed: {len(commits)}  trajectories generated: {len(samples)} ({len(samples) / hours:.0f}/h)")
    print(f"verifier jobs completed: {len(vev)} ({len(vev) / hours:.0f}/h)")
    consumed_n = sum(c["num_samples"] for c in consume)
    consumed_groups = sum(c["num_prompt_groups"] for c in consume)
    print(f"consumed: {consumed_groups} groups / {consumed_n} trajectories ({consumed_n / hours:.0f}/h)")
    print(f"prompt-filtered groups: {len(filtered)}  canceled prompts: {len(cancels)}  stale-GC aborts: {len(gc_aborts)}")

    # useful verifier work fraction
    consumed_pids = set()
    for c in consume:
        for item in c.get("consumed_items", []):
            consumed_pids.add(item["prompt_id"])
    v_by_pid = defaultdict(float)
    for s in samples:
        v_by_pid[s["prompt_id"]] += s.get("verifier_execution_s", 0.0)
    v_total = sum(v_by_pid.values())
    v_used = sum(t for pid, t in v_by_pid.items() if pid in consumed_pids)
    if v_total > 0:
        print(f"verifier-seconds: total={v_total:.0f} consumed={v_used:.0f} unconsumed={v_total - v_used:.0f}")
        print(f"useful verifier work fraction: {v_used / v_total:.3f}")

    print(f"=== verifier decomposition (n={len(samples)}) ===")
    for key in ["gen_duration_s", "reward_queue_wait_s", "verifier_execution_s", "reward_return_overhead_s"]:
        vals = [s[key] for s in samples if key in s]
        if vals:
            print(f"{key}: mean={sum(vals)/len(vals):.2f} p50={pct(vals,0.5):.2f} p90={pct(vals,0.9):.2f} p99={pct(vals,0.99):.2f} max={max(vals):.2f}")

    # reward-worker utilization: busy time / (16 workers x window)
    busy = sum(e.get("verifier_execution_s", 0) for e in vev)
    if vev:
        vt0 = min(e["t_worker_start"] for e in vev)
        vt1 = max(e["t_worker_end"] for e in vev)
        print(f"reward-worker utilization: {busy / (16 * max(vt1 - vt0, 1e-9)):.3f} (16 workers)")

    print("=== staleness of consumed samples ===")
    stal = [s for c in consume for s in c.get("staleness_per_sample", [])]
    if stal:
        hist = defaultdict(int)
        for s in stal:
            hist[s] += 1
        print(f"n={len(stal)} mean={sum(stal)/len(stal):.3f} p50={pct(stal,0.5)} p90={pct(stal,0.9)} p99={pct(stal,0.99)} max={max(stal)} hist={dict(sorted(hist.items()))}")

    print("=== whole-group selection dynamics ===")
    # group completion latency (t_commit - t_admit) vs consumption
    lat_consumed, lat_uncons = [], []
    reward_consumed, reward_uncons = [], []
    for c in commits:
        if "t_admit" not in c or "t_commit" not in c:
            continue
        lat = c["t_commit"] - c["t_admit"]
        mean_r = sum(c["rewards"]) / len(c["rewards"])
        if c["prompt_id"] in consumed_pids:
            lat_consumed.append(lat)
            reward_consumed.append(mean_r)
        else:
            lat_uncons.append(lat)
            reward_uncons.append(mean_r)
    print(f"committed groups: consumed={len(lat_consumed)} not-(yet-)consumed={len(lat_uncons)} "
          f"canceled/censored={len(cancels)} (outcome unobserved)")
    if lat_consumed:
        print(f"group completion latency (consumed): p50={pct(lat_consumed,0.5):.1f}s p90={pct(lat_consumed,0.9):.1f}s max={max(lat_consumed):.1f}s")
        print(f"mean group reward: consumed={sum(reward_consumed)/len(reward_consumed):.3f}", end="")
        if reward_uncons:
            print(f" not-consumed={sum(reward_uncons)/len(reward_uncons):.3f}")
        else:
            print()
    # P(consumed | latency bucket)
    if lat_consumed or lat_uncons:
        buckets = [(0, 30), (30, 120), (120, 300), (300, 1e9)]
        print("P(consumed | group completion latency):")
        for lo, hi in buckets:
            n_c = sum(1 for x in lat_consumed if lo <= x < hi)
            n_u = sum(1 for x in lat_uncons if lo <= x < hi)
            n = n_c + n_u
            if n:
                print(f"  [{lo:>4.0f},{hi if hi < 1e9 else float('inf'):>5} s): {n_c}/{n} = {n_c/n:.2f}")

    print("=== per-update training metrics (stdout) ===")
    try:
        with open(f"{run_dir}/stdout.log", errors="ignore") as f:
            for line in f:
                if '"time/step_total"' in line:
                    m = json.loads(line[line.index("{"):])
                    print(f"step: score={m.get('critic/score/mean', float('nan')):.3f} "
                          f"pg={m.get('actor/pg_loss@sum', float('nan')):.3f} "
                          f"kl={m.get('actor/kl_loss@sum', float('nan')):.4f} "
                          f"ratio={m.get('actor/ratio_mean@sum', float('nan')):.4f} "
                          f"clipfrac={m.get('actor/ppo_ratio_clipfrac@sum', float('nan')):.4f} "
                          f"mask={m.get('rtl/actor/final_mask_ratio', float('nan')):.3f} "
                          f"off_policy={m.get('rtl/scheduler/off_policy_ratio', float('nan'))} "
                          f"t_gen={m.get('time/step_generate', float('nan')):.0f}s "
                          f"t_train={m.get('time/step_train', float('nan')):.0f}s")
    except FileNotFoundError:
        pass


if __name__ == "__main__":
    main(sys.argv[1])
