"""Prepare isolated random weights + fake rewards for scheduling tests only."""
from pathlib import Path

import torch
from omegaconf import OmegaConf
from transformers import AutoTokenizer, Qwen2Config, Qwen2ForCausalLM


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[2]
    tokenizer = AutoTokenizer.from_pretrained(root / "models/codev-sft")
    toy = root / "models/control-only-random-qwen"
    tokenizer.save_pretrained(toy)
    torch.manual_seed(42)
    model = Qwen2ForCausalLM(Qwen2Config(
        vocab_size=max(tokenizer.get_vocab().values()) + 1,
        hidden_size=64, intermediate_size=128,
        num_hidden_layers=2, num_attention_heads=2, num_key_value_heads=1,
        max_position_embeddings=32768, bos_token_id=tokenizer.bos_token_id,
        eos_token_id=tokenizer.eos_token_id, pad_token_id=tokenizer.pad_token_id,
    ))
    model.save_pretrained(toy)
    config = OmegaConf.load(root / "experiments/configs/codev_eqyv2_smoke.yaml")
    config.exp_name = "control_test_not_rtl_results"
    config.max_steps = 3
    config.rollout_batch_size = 2
    config.prompt_admission_args.batch = 2
    config.prompt_admission_args.mode = "uniform"
    config.pretrain = str(toy)
    config.reward_pretrain = str(toy)
    config.response_length = 1024
    config.sequence_length = 3072
    config.actor_train.training_args.gradient_accumulation_steps = 8
    config.actor_infer.strategy_args.strategy_config.max_num_seqs = 1
    config.actor_infer.strategy_args.strategy_config.max_model_len = 3072
    config.actor_infer.strategy_args.strategy_config.gpu_memory_utilization = 0.15
    # Force router credit waiters as well as engine queue waiters. The real
    # G16 workload can exceed the default 128 requests per routing worker.
    config.router_args = {"router_name": "PromptAffinityRouter", "max_running_requests": 4}
    config.rewards.rtl.worker_cls = "applications.rtl.control_reward_worker.ControlRewardWorker"
    config.rewards.rtl.world_size = 2
    OmegaConf.save(config, root / "experiments/configs/codev_control_regression.yaml")
    print("CONTROL_ONLY_ASSETS_READY")
