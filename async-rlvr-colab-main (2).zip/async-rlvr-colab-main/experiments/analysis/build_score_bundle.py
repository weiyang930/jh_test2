"""Build the pretrained score bundle (difficulty heads + cost head) from E1 run logs.

Outputs:
  <out>/score_bundle.pkl   {tfidf, clf_easy, clf_hard, cost_reg, cost_norm}
  <out>/e1_used_ids.json   dataset ids consumed by the source runs (E2 exclusion list)

Usage: python experiments/analysis/build_score_bundle.py <run_dir>... --out <dir>
"""
import argparse
import collections
import glob
import json
import pickle

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression, Ridge


def load_runs(run_dirs):
    texts, rows = {}, []
    for rd in run_dirs:
        for p in glob.glob(f"{rd}/output/generations/*.jsonl"):
            for l in open(p, errors="ignore"):
                d = json.loads(l)
                for i, pid in enumerate(d["id"]):
                    if pid not in texts:
                        m = d["messages"][i]
                        pr = json.loads(m)[-1]["content"] if m.startswith("[") else m
                        texts[pid] = pr + "\n" + d["ground_truth"][i]
        cost = collections.defaultdict(float)
        rew = {}
        for l in open(f"{rd}/output/events.jsonl", errors="ignore"):
            try:
                e = json.loads(l)
            except json.JSONDecodeError:
                continue
            if e.get("event") == "sample_done":
                cost[e.get("dataset_id")] += e.get("verifier_execution_s", 0.0)
            elif e.get("event") == "prompt_commit":
                rs = e.get("rewards", [])
                zv = len(set(rs)) == 1
                rew[e.get("dataset_id")] = (int(zv and rs[0] == 1.0), int(zv and rs[0] != 1.0))
        for i, (ap, th) in rew.items():
            if i in cost and i in texts:
                rows.append({"id": i, "all_pass": ap, "too_hard": th, "cost": cost[i]})
    return texts, rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run_dirs", nargs="+")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    texts, rows = load_runs(args.run_dirs)
    print(f"training bundle on {len(rows)} groups from {len(args.run_dirs)} runs")
    X_texts = [texts[r["id"]] for r in rows]
    tfidf = TfidfVectorizer(max_features=20000, ngram_range=(1, 2), sublinear_tf=True, min_df=2)
    X = tfidf.fit_transform(X_texts)
    clf_easy = LogisticRegression(max_iter=2000).fit(X, [r["all_pass"] for r in rows])
    clf_hard = LogisticRegression(max_iter=2000).fit(X, [r["too_hard"] for r in rows])
    log_cost = np.log1p([r["cost"] for r in rows])
    cost_reg = Ridge(alpha=1.0).fit(X, log_cost)
    raw_cost = np.expm1(cost_reg.predict(X))
    bundle = {"tfidf": tfidf, "clf_easy": clf_easy, "clf_hard": clf_hard,
              "cost_reg": cost_reg, "cost_norm": (float(raw_cost.mean()), float(raw_cost.std()))}
    import os
    os.makedirs(args.out, exist_ok=True)
    with open(f"{args.out}/score_bundle.pkl", "wb") as fh:
        pickle.dump(bundle, fh)
    with open(f"{args.out}/e1_used_ids.json", "w") as fh:
        json.dump(sorted({r["id"] for r in rows}), fh)
    print(f"saved {args.out}/score_bundle.pkl and e1_used_ids.json ({len({r['id'] for r in rows})} ids)")


if __name__ == "__main__":
    main()
