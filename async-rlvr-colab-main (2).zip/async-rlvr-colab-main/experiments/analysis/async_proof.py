"""Gate 4: timestamp proof of genuine native-async execution.

Reads a run's rollout-loop events (events.jsonl) and scheduler events
(scheduler_events.jsonl) and verifies, with timestamps:

  P1  cross-step consumption: samples consumed at learner step v with
      sampling_start_step < v (native buffer carries groups across updates);
  P2  generation/verification activity spans learner-step boundaries:
      some sample's [t_gen_start, t_gen_end] or [t_reward_submit,
      t_reward_return] interval contains a later step_begin timestamp
      (i.e. rollout/verify ran while the learner/model-update advanced);
  P3  admission continues ahead: step_begin shows running prompts from the
      previous step window still in flight (async_generation_ratio window).

Also prints staleness distribution, queue state per step and stale-GC events.

Usage: python experiments/analysis/async_proof.py artifacts/runs/<RUN_ID>
"""
import glob
import json
import sys
from collections import defaultdict


def load_jsonl(path):
    out = []
    for p in glob.glob(path):
        with open(p) as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        out.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
    return out


def pct(sorted_vals, q):
    if not sorted_vals:
        return None
    idx = min(int(q * len(sorted_vals)), len(sorted_vals) - 1)
    return sorted_vals[idx]


def main(run_dir):
    ev = load_jsonl(f"{run_dir}/output/events.jsonl")
    sev = load_jsonl(f"{run_dir}/output/scheduler_events.jsonl")

    step_begin = {e["step"]: e for e in sev if e.get("event") == "step_begin"}
    consume = [e for e in sev if e.get("event") == "consume_batch"]
    gc_groups = [e for e in sev if e.get("event") == "gc_group"]
    gc_aborts = [e for e in sev if e.get("event") == "gc_abort_prompt"]
    samples = [e for e in ev if e.get("event") == "sample_done"]
    commits = [e for e in ev if e.get("event") == "prompt_commit"]
    cancels = [e for e in ev if e.get("event") == "prompt_canceled"]

    print(f"events: {len(ev)} rollout-loop, {len(sev)} scheduler")
    print(f"steps observed: {sorted(step_begin)}")
    print(f"commits={len(commits)} samples={len(samples)} cancels={len(cancels)} "
          f"gc_groups={len(gc_groups)} gc_aborted_prompts={len(gc_aborts)}")

    # P1: cross-step consumption + staleness distribution
    stal_all = []
    p1 = False
    for c in consume:
        st = c.get("staleness_per_sample", [])
        stal_all.extend(st)
        if any(s > 0 for s in st):
            p1 = True
    stal_sorted = sorted(stal_all)
    if stal_all:
        mean = sum(stal_all) / len(stal_all)
        print(f"staleness(consumed): n={len(stal_all)} mean={mean:.3f} "
              f"p50={pct(stal_sorted,0.5)} p90={pct(stal_sorted,0.9)} "
              f"p99={pct(stal_sorted,0.99)} max={stal_sorted[-1]}")
        hist = defaultdict(int)
        for s in stal_all:
            hist[s] += 1
        print(f"staleness histogram: {dict(sorted(hist.items()))}")
    print(f"P1 cross-step consumption (staleness>0 consumed): {'PASS' if p1 else 'FAIL'}")

    # P2: activity interval spans a later step_begin timestamp
    boundaries = sorted((s, e["ts"]) for s, e in step_begin.items())
    p2_gen = p2_rew = 0
    for smp in samples:
        for step, ts in boundaries:
            if step <= smp["sampling_start_step"]:
                continue
            if smp["t_gen_start"] < ts < smp["t_gen_end"]:
                p2_gen += 1
            if smp["t_reward_submit"] < ts < smp["t_reward_return"]:
                p2_rew += 1
    print(f"P2 activity across learner-step boundary: generation={p2_gen} samples, "
          f"reward/verify={p2_rew} samples -> {'PASS' if (p2_gen + p2_rew) > 0 else 'FAIL'}")

    # P3: admission window carries running prompts across steps
    p3 = False
    for s, e in sorted(step_begin.items()):
        rp = e.get("running_prompts", 0)
        print(f"step {s}: admission_window={e.get('admission_window')} running={rp} "
              f"completed={e.get('completed_prompts')} inflight_gen={e.get('inflight_generation')} "
              f"groups={e.get('groups')}")
        if s > min(step_begin) and rp > 0:
            p3 = True
    print(f"P3 prompts in flight at step boundary: {'PASS' if p3 else 'FAIL'}")

    # resumptions (partial rollout across model updates)
    res = [s.get("partial_rollout_resumptions", 0) for s in samples]
    if res:
        print(f"partial-rollout resumptions: total={sum(res)} max={max(res)} "
              f"samples_with_resumption={sum(1 for r in res if r > 0)}")

    # verifier timing decomposition
    qw = sorted(s["reward_queue_wait_s"] for s in samples if "reward_queue_wait_s" in s)
    vx = sorted(s["verifier_execution_s"] for s in samples if "verifier_execution_s" in s)
    if qw:
        print(f"reward_queue_wait_s: mean={sum(qw)/len(qw):.2f} p50={pct(qw,0.5):.2f} "
              f"p90={pct(qw,0.9):.2f} max={qw[-1]:.2f}")
        print(f"verifier_execution_s: mean={sum(vx)/len(vx):.2f} p50={pct(vx,0.5):.2f} "
              f"p90={pct(vx,0.9):.2f} max={vx[-1]:.2f}")

    ok = p1 and (p2_gen + p2_rew) > 0 and p3
    print(f"Gate 4 (genuine async): {'PASS' if ok else 'FAIL'}")
    return ok


if __name__ == "__main__":
    sys.exit(0 if main(sys.argv[1]) else 1)
