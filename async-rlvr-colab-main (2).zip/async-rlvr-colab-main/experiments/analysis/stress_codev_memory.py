"""Isolated maximum-length FSDP memory probe; never saves or changes SFT weights.

Uses synthetic tokens and two Adam updates so the second backward includes
allocated optimizer states. This tests long-sequence memory, not RL quality or
end-to-end rollout throughput. Run only while the actual RL job is stopped.
"""
import json
import os
import time
from pathlib import Path

import torch
import torch.distributed as dist
from torch.distributed.device_mesh import init_device_mesh
from torch.distributed._composable.fsdp import fully_shard, MixedPrecisionPolicy
from transformers import AutoModelForCausalLM

from applications.rtl.codev_actor_worker import selected_log_probs


def main():
    rank = int(os.environ['LOCAL_RANK'])
    torch.cuda.set_device(rank)
    dist.init_process_group('nccl')
    mesh = init_device_mesh('cuda', (dist.get_world_size(),))
    torch.manual_seed(42)
    start = time.monotonic()
    model = AutoModelForCausalLM.from_pretrained(
        '/opt/codev-sixgpu-smoke-20260907/models/codev-sft', torch_dtype=torch.float32,
        attn_implementation='flash_attention_2', low_cpu_mem_usage=True)
    model.config.use_cache = False
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False})
    precision = MixedPrecisionPolicy(param_dtype=torch.bfloat16, reduce_dtype=torch.float32)
    for layer in model.model.layers:
        fully_shard(layer, mesh=mesh, mp_policy=precision, reshard_after_forward=True)
    fully_shard(model, mesh=mesh, mp_policy=precision, reshard_after_forward=True)
    assert {p.dtype for p in model.parameters()} == {torch.float32}
    model.train()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-6, betas=(.9, .999), weight_decay=0)
    ids = torch.randint(100, 140000, (1, 18432), device='cuda')
    attention = torch.ones_like(ids)
    records = []
    for step in range(2):
        torch.cuda.reset_peak_memory_stats()
        began = time.monotonic()
        with torch.autocast('cuda', dtype=torch.bfloat16):
            logits = model(input_ids=ids, attention_mask=attention).logits
            loss = -selected_log_probs(logits[:, :-1], ids[:, 1:]).mean()
        loss.backward()
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)
        torch.cuda.synchronize()
        states = {v.dtype for state in optimizer.state.values()
                  for k,v in state.items() if k in {'exp_avg', 'exp_avg_sq'}}
        assert states == {torch.float32}, states
        record = dict(rank=rank, step=step, loss=float(loss.detach()),
                      allocated_gib=torch.cuda.max_memory_allocated()/2**30,
                      reserved_gib=torch.cuda.max_memory_reserved()/2**30,
                      seconds=time.monotonic()-began)
        records.append(record)
        print(json.dumps(record), flush=True)
        del logits, loss
    Path(f'artifacts/setup/max_length_memory_rank{rank}.json').write_text(json.dumps(
        dict(records=records, total_seconds=time.monotonic()-start,
             sequence_length=18432, microbatch=1, fsdp_ranks=dist.get_world_size(),
             master_dtype='fp32', compute_dtype='bf16', optimizer_dtype='fp32'), indent=2))
    dist.destroy_process_group()


if __name__ == '__main__':
    main()
