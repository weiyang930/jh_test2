#!/usr/bin/env bash
# Launch one SALV blocking-cost arm on the 6-GPU pod.
# usage: launch_salv_arm.sh RUN_ID MAX_STEPS SAVE_STEPS BETA [WALLCLOCK_LIMIT_S]
# Calibrated constants are passed through the environment (RTL_COST_ETA, RTL_COST_SCALE).
set -euo pipefail
RUN_ID="$1"; MAX_STEPS="$2"; SAVE_STEPS="$3"; BETA="$4"; LIMIT="${5:-0}"
R=${ROOT:-/root/ec}
V="${VENV:-/opt/venvs/async-rlvr}/bin"
OSS="${OSS_CAD_DIR:-/opt/oss-cad-suite}"
OUT="$R/runs/$RUN_ID"
mkdir -p "$OUT/output" "$OUT/checkpoints"

export RUN_ID
export RTL_RUN_OUTPUT_DIR="$OUT/output"
export RTL_CKPT_DIR="${RTL_CKPT_DIR:-$OUT/checkpoints}"
export RTL_MAX_STEPS="$MAX_STEPS" RTL_SAVE_STEPS="$SAVE_STEPS" RTL_SAVE_LAST="${RTL_SAVE_LAST:-true}"
export RTL_COST_AUX_BETA="$BETA"
export RTL_COST_ETA="${RTL_COST_ETA:-1.0}" RTL_COST_SCALE="${RTL_COST_SCALE:-1.0}"
export RTL_COST_EPSILON="${RTL_COST_EPSILON:-0.1}" RTL_COST_CLASSES="${RTL_COST_CLASSES:-pass,eqy_counterexample}"
export RTL_WALLCLOCK_LIMIT_S="$LIMIT"
export RTL_WORKSPACE_ROOT="${RTL_TMP_ROOT:-/tmp}/rtl_verify_$RUN_ID"   # RTL_TMP_ROOT: put EQY workspaces on a big local disk
export RTL_VERIFY_WORKERS="${RTL_VERIFY_WORKERS:-4}"
export RTL_ASYNC_GENERATION_RATIO="${RTL_ASYNC_GENERATION_RATIO:-1}"
export SALV_MODEL_PATH="${SALV_MODEL_PATH:-$R/assets/salv-7b}"
export SALV_DATA_PATH="${SALV_DATA_PATH:-$R/assets/data/salv_direct/train.jsonl}"   # EARL-SFT start: assets/data/plain/train.jsonl
export RTL_SIM_META="${RTL_SIM_META:-$R/assets/data/salv_direct/sim_meta.json}" RTL_CODEV_TK="${RTL_CODEV_TK:-$R/env/codev_tk}"
export PYTHONPATH="$R/code"
export RTL_OSS_CAD_BIN="$OSS/bin"
export PATH="$OSS/bin:$PATH"
# short: Ray AF_UNIX socket paths are limited to 107 bytes. RTL_RAY_TMP_ROOT (<= 29 chars) keeps Ray off the root disk.
if [ -n "${RTL_RAY_TMP_ROOT:-}" ]; then export RAY_TMPDIR="$RTL_RAY_TMP_ROOT/$(printf %s "$RUN_ID" | md5sum | cut -c1-6)"
else export RAY_TMPDIR="/tmp/ray_$(printf %s "$RUN_ID" | md5sum | cut -c1-8)"; fi
export VLLM_USE_V1=1
mkdir -p "$RAY_TMPDIR" "$RTL_WORKSPACE_ROOT"

START_UTC=$(date -u +%FT%TZ)
env | grep -E '^(RUN_ID|RTL_|SALV_|RAY_TMPDIR)' | sort > "$OUT/launch_env.txt"
cat > "$OUT/manifest.json" <<EOF
{
  "run_id": "$RUN_ID",
  "start_utc": "$START_UTC",
  "code_commit": "$(cat $R/code/CODE_COMMIT 2>/dev/null || echo unknown)",
  "model": "TabCanNotTab/SALV-Qwen2.5-Coder-7B-Instruct@99de67c99a64a3faa06ea8c9dbaef995fc1bb9a0",
  "model_sha256_shard1": "0b85e5772f712f5af08f5bb44a0ff98bfcb0d0e702d94959e02d99c0d490fb02",
  "data": "zhuyaoyu/CodeV-R1-dataset@9ab06ff546c597b66e124839a6f60c5330083424 salv_direct train.jsonl (3033 rows)",
  "config": "experiments/configs/salv_blocking_cost.yaml",
  "max_steps": $MAX_STEPS, "save_steps": $SAVE_STEPS, "beta": $BETA,
  "eta": ${RTL_COST_ETA}, "cost_scale": ${RTL_COST_SCALE}, "epsilon": ${RTL_COST_EPSILON},
  "classes": "$RTL_COST_CLASSES", "wallclock_limit_s": $LIMIT,
  "verify_workers": $RTL_VERIFY_WORKERS, "async_generation_ratio": $RTL_ASYNC_GENERATION_RATIO, "eqy_timeout_s": ${RTL_EQY_TIMEOUT_S:-180}, "sim_fallback": ${RTL_SIM_FALLBACK:-0},
  "rollout_batch_size": ${RTL_ROLLOUT_B:-64}, "group_size": ${RTL_GROUP_G:-4},
  "gpus": "${RTL_GPU_DESC:-$(nvidia-smi --query-gpu=name --format=csv,noheader | sort | uniq -c | tr -s " " | tr "\n" ";")}", "cpu_cores": $(nproc),
  "status": "running", "pid": $$
}
EOF
cd "$R/code"
set +e
"$V/python" experiments/launch/run_blocking_cost.py --config_path ../experiments/configs \
  --config_name ${RTL_CONFIG_NAME:-salv_blocking_cost} > "$OUT/stdout.log" 2>&1
CODE=$?
set -e
END_UTC=$(date -u +%FT%TZ)
"$V/python" - "$OUT/manifest.json" "$CODE" "$END_UTC" <<'PY'
import json, sys
path, code, end = sys.argv[1:]
m = json.load(open(path))
m.update(status='completed' if code == '0' else f'exit_{code}', exit_code=int(code), end_utc=end)
json.dump(m, open(path, 'w'), indent=2)
PY
# keep the Ray system logs (raylet/gcs/dashboard/*.err) next to stdout.log: on Slurm nodes RAY_TMPDIR is on the node's /tmp
# and is gone with the job, which hid the raylet death behind "Failed to register worker to Raylet" (ORCD 2026-10-20)
# ray.init() puts the session under $RAY_TMPDIR/ray/, `ray start --temp-dir` directly under $RAY_TMPDIR/
RAY_SESSION_LOGS=""; for d in "$RAY_TMPDIR/session_latest/logs" "$RAY_TMPDIR/ray/session_latest/logs"; do [ -d "$d" ] && RAY_SESSION_LOGS="$d"; done
if [ -n "$RAY_SESSION_LOGS" ]; then
  mkdir -p "$OUT/ray_logs" && find -L "$RAY_SESSION_LOGS" -maxdepth 1 -type f \( -name "*.err" -o -name "raylet.out" -o -name "gcs_server.out" -o -name "dashboard*.log" -o -name "monitor.log" -o -name "log_monitor.log" \) -exec cp -p {} "$OUT/ray_logs/" \; 2>/dev/null || true
fi
rm -rf "$RAY_TMPDIR" 2>/dev/null || true
echo "ARM_DONE $RUN_ID exit=$CODE"
