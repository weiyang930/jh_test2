"""Run the standard RLVR entry point and terminate deterministically."""

import os
import signal
import sys
from types import FrameType

import ray

from examples.start_rlvr_pipeline import main


def handle_shutdown_timeout(_signum: int, _frame: FrameType | None) -> None:
    """Force a successful exit if Ray shutdown exceeds the grace period."""
    os._exit(0)


if __name__ == "__main__":
    main()
    sys.stdout.flush()
    sys.stderr.flush()
    signal.signal(signal.SIGALRM, handle_shutdown_timeout)
    signal.alarm(30)
    ray.shutdown()
    signal.alarm(0)
    os._exit(0)
