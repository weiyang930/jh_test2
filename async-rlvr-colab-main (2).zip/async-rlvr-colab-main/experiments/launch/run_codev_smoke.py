"""Run native RLVR with a bounded local Ray object store on this large-RAM pod."""
import os
import dataclasses
import json
from pathlib import Path

import ray

from examples import start_rlvr_pipeline as entry
from roll.platforms import current_platform
from roll.utils.constants import RAY_NAMESPACE


def initialize_smoke_ray() -> None:
    """Use the measured 81.6-core quota, reserving CPU headroom for the host."""
    ray.init(num_cpus=80, num_gpus=6, object_store_memory=8 * 2**30,
             include_dashboard=False, namespace=RAY_NAMESPACE,
             runtime_env={'env_vars': current_platform.get_custom_env_vars()})


if __name__ == '__main__':
    entry.init = initialize_smoke_ray
    original_run = entry.RLVRPipeline.run

    def run_with_config_snapshot(pipeline):
        # Include dataclass defaults and constructor-resolved worker settings,
        # in addition to the launcher's resolved user YAML.
        folder = Path(pipeline.pipeline_config.output_dir)
        folder.mkdir(parents=True, exist_ok=True)
        (folder / 'runtime_config.json').write_text(json.dumps(
            dataclasses.asdict(pipeline.pipeline_config), indent=2, default=str) + '\n')
        return original_run(pipeline)

    entry.RLVRPipeline.run = run_with_config_snapshot
    try:
        entry.main()
    finally:
        ray.shutdown()
