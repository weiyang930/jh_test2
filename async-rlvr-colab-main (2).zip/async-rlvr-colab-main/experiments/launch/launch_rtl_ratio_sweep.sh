#!/usr/bin/env bash
# Run the 15-step ratio sweep. Ratio 1 defaults to the preserved Run A result.
#
# Usage: launch_rtl_ratio_sweep.sh [RATIO ...]
set -uo pipefail

REPO="${REPO:-/workspace/async-rlvr}"
VENV="${VENV:-/opt/venvs/async-rlvr}"
SWEEP_ID="${SWEEP_ID:-rtl_ratio_sweep_$(date -u +%Y%m%d)}"
SWEEP_DIR="$REPO/artifacts/sweeps/$SWEEP_ID"
LAUNCHER="$REPO/experiments/launch/launch_rtl_ratio.sh"
STATUS="$SWEEP_DIR/status.json"
RATIOS=("$@")
if [ "${#RATIOS[@]}" -eq 0 ]; then
    RATIOS=(0 2 3)
fi

cd "$REPO"
mkdir -p "$SWEEP_DIR"
"$VENV/bin/python" - "$STATUS" "$SWEEP_ID" "${RATIOS[@]}" <<'PY'
import json
import sys
import time
from pathlib import Path

status_path = Path(sys.argv[1])
status = {
    "sweep_id": sys.argv[2],
    "ratios": [int(ratio) for ratio in sys.argv[3:]],
    "status": "running",
    "start_time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "runs": [],
}
status_path.write_text(json.dumps(status, indent=2))
PY

for ratio in "${RATIOS[@]}"; do
    if [ "$ratio" = "0" ]; then
        mode=sync_control
    else
        mode=async
    fi
    run_id="${SWEEP_ID}_${mode}_ratio${ratio}_15step"
    echo "SWEEP_RUN_START ratio=$ratio run_id=$run_id time=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    "$VENV/bin/python" - "$STATUS" "$run_id" "$ratio" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
status = json.loads(path.read_text())
status["current_run"] = sys.argv[2]
status["current_ratio"] = int(sys.argv[3])
status["runs"].append({"run_id": sys.argv[2], "ratio": int(sys.argv[3]), "status": "running"})
path.write_text(json.dumps(status, indent=2))
PY
    "$VENV/bin/ray" stop --force >/dev/null 2>&1 || true
    MAX_RUNTIME="${MAX_RUNTIME:-5h}" "$LAUNCHER" "$ratio" "$run_id" 15
    exit_code=$?
    "$VENV/bin/python" - "$STATUS" "$run_id" "$exit_code" <<'PY'
import json
import sys
import time
from pathlib import Path

path = Path(sys.argv[1])
status = json.loads(path.read_text())
run_id = sys.argv[2]
exit_code = int(sys.argv[3])
for run in status["runs"]:
    if run["run_id"] == run_id:
        run.update(
            {
                "status": "completed" if exit_code == 0 else "failed",
                "exit_code": exit_code,
                "end_time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            }
        )
path.write_text(json.dumps(status, indent=2))
PY
    "$VENV/bin/ray" stop --force >/dev/null 2>&1 || true
    echo "SWEEP_RUN_END ratio=$ratio run_id=$run_id rc=$exit_code time=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    if [ "$exit_code" -ne 0 ]; then
        "$VENV/bin/python" - "$STATUS" <<'PY'
import json
import sys
import time
from pathlib import Path

path = Path(sys.argv[1])
status = json.loads(path.read_text())
status.update({"status": "failed", "end_time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
path.write_text(json.dumps(status, indent=2))
PY
        exit "$exit_code"
    fi
done

"$VENV/bin/python" - "$STATUS" <<'PY'
import json
import sys
import time
from pathlib import Path

path = Path(sys.argv[1])
status = json.loads(path.read_text())
status.pop("current_run", None)
status.pop("current_ratio", None)
status.update({"status": "completed", "end_time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
path.write_text(json.dumps(status, indent=2))
PY
echo "SWEEP_COMPLETE time=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
