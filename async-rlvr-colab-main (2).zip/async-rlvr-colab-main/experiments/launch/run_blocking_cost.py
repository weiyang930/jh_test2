"""Launch the SALV blocking-cost RL arms: baseline (beta=0) or method (beta>0).

Instrumentation is installed on the pipeline instance and on two module-level
functions; ROLL core is not edited.  Both arms run exactly the same code path,
including D_local computation and logging; only ``RTL_COST_AUX_BETA`` differs.

Env knobs (all recorded in ``cost_aux_config.json``):
  RTL_COST_AUX_BETA      auxiliary loss coefficient (0 = baseline arm)
  RTL_COST_ETA           within-class tilt strength
  RTL_COST_SCALE         fixed cost scale in seconds (effective_cost / scale)
  RTL_COST_EPSILON       service-time shrink fraction for D_local (default 0.1)
  RTL_COST_CLASSES       comma list of verifier stages eligible (default pass,eqy_counterexample)
  RTL_WALLCLOCK_LIMIT_S  stop launching new steps after this many seconds
  RTL_RAY_NUM_CPUS       Ray CPU budget (default 120 on the 122.4-core quota)
"""
import dataclasses
import json
import os
import subprocess
import time
from pathlib import Path

import ray

from applications.rtl.blocking_cost_credit import BlockingCostCredit
from examples import start_rlvr_pipeline as entry
from roll.pipeline.rlvr import rlvr_pipeline as pipeline_module
from roll.platforms import current_platform
from roll.utils.constants import RAY_NAMESPACE


def initialize_ray() -> None:
    # RTL_RAY_SYSTEM_CONFIG: JSON of Ray system-config overrides, e.g. {"agent_register_timeout_ms": 300000} on ORCD
    system_config = json.loads(os.environ.get('RTL_RAY_SYSTEM_CONFIG', '{}')) or None
    ray.init(num_cpus=int(os.environ.get('RTL_RAY_NUM_CPUS', '120')), num_gpus=int(os.environ.get('RTL_NUM_GPUS', '6')),
             object_store_memory=8 * 2 ** 30, include_dashboard=False, namespace=RAY_NAMESPACE,
             runtime_env={'env_vars': current_platform.get_custom_env_vars()}, _system_config=system_config)


def cost_config() -> dict:
    return dict(
        beta=float(os.environ.get('RTL_COST_AUX_BETA', '0')),
        eta=float(os.environ.get('RTL_COST_ETA', '1.0')),
        cost_scale=float(os.environ.get('RTL_COST_SCALE', '1.0')),
        epsilon=float(os.environ.get('RTL_COST_EPSILON', '0.1')),
        classes=os.environ.get('RTL_COST_CLASSES', 'pass,eqy_counterexample').split(','),
        wallclock_limit_s=float(os.environ.get('RTL_WALLCLOCK_LIMIT_S', '0')),
        wallclock_min_steps=int(os.environ.get('RTL_WALLCLOCK_MIN_STEPS', '0')),  # the limit never stops before this many steps
    )


def git_commit() -> str:
    marker = Path(__file__).resolve().parents[2] / 'CODE_COMMIT'
    if marker.exists():
        return marker.read_text().strip()
    try:
        return subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    except Exception:  # noqa: BLE001
        return 'unknown'


def install_instrumentation(pipeline, credit: BlockingCostCredit, limit_s: float, t_launch: float, min_steps: int = 0) -> None:
    cfg = pipeline.pipeline_config

    original_load_states = pipeline.actor_infer.load_states

    def load_states(*args, **kwargs):
        result = original_load_states(*args, **kwargs)
        credit.mark('learner_request')
        return result

    pipeline.actor_infer.load_states = load_states

    original_model_update = pipeline.model_update

    def model_update(global_step):
        credit.current_step = global_step
        credit.mark('model_update_start')
        result = original_model_update(global_step)
        credit.mark('model_update_end')
        return result

    pipeline.model_update = model_update

    original_train_step = pipeline.actor_train.train_step

    def train_step(*args, **kwargs):
        credit.mark('train_start')
        return original_train_step(*args, **kwargs)

    pipeline.actor_train.train_step = train_step

    original_checkpoint = pipeline.do_checkpoint

    def do_checkpoint(global_step, is_last_step=None):
        elapsed = time.time() - t_launch
        over = limit_s > 0 and elapsed > limit_s and global_step + 1 >= min_steps
        credit.mark('step_end', elapsed_s=elapsed, wallclock_limit_reached=over)
        # At the wall-clock limit force a final checkpoint at this step, then stop.  ROLL's
        # do_checkpoint ignores is_last_step and tests global_step == max_steps - 1 directly,
        # so the limit is enforced by temporarily shrinking max_steps.
        saved_max_steps = cfg.max_steps
        if over:
            cfg.max_steps = global_step + 1
        try:
            result = original_checkpoint(global_step, is_last_step)
        finally:
            cfg.max_steps = saved_max_steps
        credit.mark('checkpoint_end', forced_final=over)
        if over:
            credit.mark('wallclock_limit_stop', elapsed_s=time.time() - t_launch, final_step=global_step)
            raise SystemExit(f'wall-clock limit {limit_s}s reached at step {global_step}; final checkpoint saved')
        return result

    pipeline.do_checkpoint = do_checkpoint

    original_dump = pipeline_module.dump_rollout_to_specific_path

    def dump_rollout(*args, **kwargs):
        credit.mark('batch_received')
        return original_dump(*args, **kwargs)

    pipeline_module.dump_rollout_to_specific_path = dump_rollout

    original_compaction = pipeline_module.physical_group_compaction

    def compaction(data, n_sample, alignment):
        metrics = credit.annotate(data, int(data.meta_info['global_step']))
        batch, compaction_metrics = original_compaction(data, n_sample, alignment)
        compaction_metrics.update(metrics)
        return batch, compaction_metrics

    pipeline_module.physical_group_compaction = compaction
    assert cfg.physical_compaction, 'cost credit hook requires physical_compaction=true'


if __name__ == '__main__':
    entry.init = initialize_ray
    original_run = entry.RLVRPipeline.run
    t_launch = time.time()

    def run_with_instrumentation(pipeline):
        cfg = pipeline.pipeline_config
        folder = Path(cfg.output_dir)
        folder.mkdir(parents=True, exist_ok=True)
        (folder / 'runtime_config.json').write_text(json.dumps(
            dataclasses.asdict(cfg), indent=2, default=str) + '\n')
        aux = cost_config()
        aux.update(git_commit=git_commit(), run_id=os.environ.get('RUN_ID', 'unset'), t_launch=t_launch,
                   group_size=cfg.actor_infer.generating_args.num_return_sequences)
        (folder / 'cost_aux_config.json').write_text(json.dumps(aux, indent=2) + '\n')
        credit = BlockingCostCredit(
            output_dir=cfg.output_dir, epsilon=aux['epsilon'], eta=aux['eta'], cost_scale=aux['cost_scale'],
            classes=aux['classes'], group_size=aux['group_size'])
        install_instrumentation(pipeline, credit, aux['wallclock_limit_s'], t_launch, aux['wallclock_min_steps'])
        credit.mark('run_start')
        return original_run(pipeline)

    entry.RLVRPipeline.run = run_with_instrumentation
    try:
        entry.main()
    finally:
        ray.shutdown()
