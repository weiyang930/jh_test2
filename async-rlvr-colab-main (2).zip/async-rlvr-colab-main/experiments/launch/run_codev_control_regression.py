"""Bounded control-only regression; never use these outputs as RTL evidence."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from omegaconf import OmegaConf


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[2]
    ratio = int(sys.argv[1])
    assert ratio in (0, 1)
    folder = root / "artifacts/control" / sys.argv[2]
    folder.mkdir(parents=True, exist_ok=False)
    config = OmegaConf.load(root / "experiments/configs/codev_control_regression.yaml")
    assert "control-only-random" in config.pretrain
    assert "ControlRewardWorker" in config.rewards.rtl.worker_cls
    env = dict(os.environ, RUN_ID=folder.name, RTL_RUN_OUTPUT_DIR=str(folder / "output"),
               RTL_ASYNC_GENERATION_RATIO=str(ratio), CODEV_ADMISSION_MODE="uniform",
               NCCL_NVLS_ENABLE="0", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
               OPENBLAS_NUM_THREADS="1", TOKENIZERS_PARALLELISM="false",
               PYTHONUNBUFFERED="1", RAY_USAGE_STATS_ENABLED="0", PYTHONPATH=str(root))
    command = [sys.executable, "experiments/launch/run_codev_smoke.py", "--config_path",
               "../experiments/configs", "--config_name", "codev_control_regression"]
    began = time.monotonic()
    with (folder / "stdout.log").open("w") as log:
        try:
            result = subprocess.run(command, cwd=root, env=env, stdout=log,
                                    stderr=subprocess.STDOUT, timeout=600)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
        finally:
            subprocess.run([str(Path(sys.executable).parent / "ray"), "stop", "--force"],
                           stdout=log, stderr=subprocess.STDOUT, timeout=60, check=False)
    (folder / "completion.json").write_text(json.dumps({
        "purpose": "control_only_random_weights_fake_rewards", "exit_code": code,
        "wall_seconds": time.monotonic() - began, "async_ratio": ratio,
    }, indent=2))
    raise SystemExit(code)
