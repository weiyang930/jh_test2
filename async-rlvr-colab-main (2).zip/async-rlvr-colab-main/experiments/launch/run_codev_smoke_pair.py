"""Execute just the two requested short smokes, with immutable launch manifests."""
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from omegaconf import OmegaConf


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def run_arm(root: Path, arm: str, ratio: int, mode: str) -> bool:
    """Keep logs from failures; never silently continue into a long training job."""
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
    run_id = f'{stamp}_codev_eqyv2_{arm}_smoke_b32'
    folder = root / 'artifacts/runs' / run_id
    folder.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, RUN_ID=run_id, RTL_RUN_OUTPUT_DIR=str(folder / 'output'),
               RTL_ASYNC_GENERATION_RATIO=str(ratio), CODEV_ADMISSION_MODE=mode,
               NCCL_NVLS_ENABLE='0', TOKENIZERS_PARALLELISM='false', PYTHONUNBUFFERED='1',
               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
               PYTHONPATH=str(root), PATH=f'/opt/oss-cad-suite/bin:{Path(sys.executable).parent}:' + os.environ['PATH'],
               RAY_USAGE_STATS_ENABLED='0')
    os.environ.update({k: env[k] for k in ['RTL_RUN_OUTPUT_DIR','RTL_ASYNC_GENERATION_RATIO','CODEV_ADMISSION_MODE']})
    config = OmegaConf.load(root / 'experiments/configs/codev_eqyv2_smoke.yaml')
    (folder / 'resolved_config.yaml').write_text(OmegaConf.to_yaml(config, resolve=True))
    command = [sys.executable, 'experiments/launch/run_codev_smoke.py',
               '--config_path', '../experiments/configs', '--config_name', 'codev_eqyv2_smoke']
    manifest = dict(run_id=run_id, status='launched', start_time=utc(), arm=arm,
                    commit=(root / 'SOURCE_COMMIT').read_text().strip(),
                    config_sha256=hashlib.sha256((folder / 'resolved_config.yaml').read_bytes()).hexdigest(),
                    command=command, learner_updates=int(config.max_steps), effective_prompt_batch=32, group_size=16,
                    actor_gpus=[0,1,2,3], rollout_gpus=[4,5], verifier_workers=16,
                    seed=42, cost_scope='measured_verifier_cpu_only',
                    checkpoint_saved=False, purpose='hardware_and_training_smoke_not_quality_comparison')
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(dict(event='launch', **manifest)), flush=True)
    began = time.monotonic()
    with (folder / 'gpu.csv').open('w') as gpu_log, (folder / 'stdout.log').open('w') as log:
        monitor = subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,index,memory.used,utilization.gpu',
                                    '--format=csv,noheader,nounits','-l','2'], stdout=gpu_log, stderr=subprocess.DEVNULL)
        process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        try:
            # Measured 16K runs spend ~22 min sampling + ~7 min learning per
            # update. Allow two updates and startup without a false timeout.
            code = process.wait(timeout=5400)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            code = 124
        finally:
            monitor.terminate()
            monitor.wait(timeout=10)
            subprocess.run([str(Path(sys.executable).parent/'ray'), 'stop','--force'],
                           env=env, stdout=log, stderr=subprocess.STDOUT, timeout=60, check=False)
    completion = dict(run_id=run_id, exit_code=code, status='completed' if code == 0 else 'failed',
                      end_time=utc(), wall_seconds=time.monotonic()-began)
    (folder / 'completion.json').write_text(json.dumps(completion, indent=2) + '\n')
    print(json.dumps(completion), flush=True)
    return code == 0


if __name__ == '__main__':
    root = Path(__file__).resolve().parents[2]
    for arguments in [('a10',1,'value_cost'), ('sync',0,'uniform')]:
        if not run_arm(root, *arguments):
            raise SystemExit(1)
