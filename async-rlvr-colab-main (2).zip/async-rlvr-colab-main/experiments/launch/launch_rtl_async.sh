#!/usr/bin/env bash
# Launch the RTL native async baseline (smoke or formal run).
#
# Usage:
#   RUN_ID=<id> [RTL_MAX_STEPS=n] [ALLOW_DIRTY=1] bash experiments/launch/launch_rtl_async.sh
#
# Creates artifacts/runs/$RUN_ID/{manifest.json,resolved_config.yaml,command.sh,output/}
# and runs the driver in the foreground with unbuffered, tee'd logs.
# For a formal run, invoke inside tmux:  tmux new -s run-<...> 'bash ...'
set -euo pipefail

REPO=/workspace/async-rlvr
cd "$REPO"

: "${RUN_ID:?set RUN_ID}"
RUN_DIR="$REPO/artifacts/runs/$RUN_ID"
if [ -e "$RUN_DIR" ]; then
    echo "FATAL: run dir $RUN_DIR already exists (never reuse a RUN_ID)" >&2
    exit 1
fi

GIT_STATUS=$(git status --porcelain)
if [ -n "$GIT_STATUS" ] && [ "${ALLOW_DIRTY:-0}" != "1" ]; then
    echo "FATAL: dirty git tree; commit first or set ALLOW_DIRTY=1 (smoke only)" >&2
    git status --short >&2
    exit 1
fi
GIT_COMMIT=$(git rev-parse HEAD)
GIT_BRANCH=$(git branch --show-current)

mkdir -p "$RUN_DIR/output"

export RUN_ID
export RTL_RUN_OUTPUT_DIR="$RUN_DIR/output"
export RTL_MAX_STEPS="${RTL_MAX_STEPS:-15}"
export PYTHONPATH="$REPO:${PYTHONPATH:-}"
export PATH="/opt/oss-cad-suite/bin:$PATH"
export PYTHONUNBUFFERED=1
export TOKENIZERS_PARALLELISM=false

CMD=(python examples/start_rlvr_pipeline.py
     --config_path ../experiments/configs
     --config_name rtl_async_baseline)

# resolved config + manifest + command, before launch
python - <<PY
import json, os, time
from hydra import compose
from hydra.experimental import initialize_config_dir
from omegaconf import OmegaConf
initialize_config_dir(config_dir="$REPO/experiments/configs", job_name="resolve")
cfg = compose(config_name="rtl_async_baseline")
resolved = OmegaConf.to_yaml(cfg, resolve=True)
open("$RUN_DIR/resolved_config.yaml", "w").write(resolved)
manifest = {
    "run_id": "$RUN_ID",
    "git_commit": "$GIT_COMMIT",
    "git_branch": "$GIT_BRANCH",
    "git_dirty": bool("""$GIT_STATUS""".strip()),
    "launch_time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "command": "${CMD[*]}",
    "tmux_session": os.environ.get("TMUX_SESSION", ""),
    "max_steps": int(os.environ["RTL_MAX_STEPS"]),
    "hardware": "6xA100-80GB; train GPUs 0-3 (fsdp2), infer GPUs 4-5 (vllm 0.8.4), 16 CPU RTL reward workers",
    "model": "Carolineshi/origen-deepseek7b-run-20250803_172955 (local copy models/)",
    "dataset": "data/rtl_filtered_train.jsonl (from reference filtered_dataset-train.parquet)",
}
json.dump(manifest, open("$RUN_DIR/manifest.json", "w"), indent=2)
PY
printf '%s\n' "#!/usr/bin/env bash" "# exact launch command for $RUN_ID (commit $GIT_COMMIT)" \
  "export RUN_ID=$RUN_ID RTL_RUN_OUTPUT_DIR=$RTL_RUN_OUTPUT_DIR RTL_MAX_STEPS=$RTL_MAX_STEPS" \
  "export PYTHONPATH=$REPO PATH=/opt/oss-cad-suite/bin:\$PATH PYTHONUNBUFFERED=1" \
  "cd $REPO && ${CMD[*]}" > "$RUN_DIR/command.sh"
chmod +x "$RUN_DIR/command.sh"

echo "=== launching $RUN_ID (commit $GIT_COMMIT, branch $GIT_BRANCH) ==="
"${CMD[@]}" > >(tee -a "$RUN_DIR/stdout.log") 2> >(tee -a "$RUN_DIR/stderr.log" >&2)
