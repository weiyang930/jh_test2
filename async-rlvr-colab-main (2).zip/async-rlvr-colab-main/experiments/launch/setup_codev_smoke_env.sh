#!/usr/bin/env bash
# Restore the tested FSDP2/vLLM environment without changing system Python.
set -euo pipefail
VENV=${VENV:-/opt/venvs/async-rlvr}
python3 -m venv "$VENV"
"$VENV/bin/pip" install --upgrade pip uv
UV="$VENV/bin/uv"
"$UV" pip install --python "$VENV/bin/python" torch==2.6.0 torchvision==0.21.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cu124
# Ray's optional default extra conflicts with vLLM's OpenTelemetry pin. The
# training path uses base Ray; dashboard dependencies are installed explicitly.
"$UV" pip install --python "$VENV/bin/python" vllm==0.8.4 transformers==4.51.3 ray==2.48.0 accelerate==0.34.2 datasets==3.1.0 'fsspec[http]==2024.9.0' numpy==1.26.4 tensordict==0.10.0 peft==0.12.0 tensorboard huggingface-hub==0.36.2 aiohttp-cors opencensus virtualenv
# Preserve the historical runtime pins rather than pulling Ray's conflicting
# optional OpenTelemetry extra via TransferQueue. Verify imports before launch.
"$UV" pip install --python "$VENV/bin/python" --no-deps TransferQueue==0.1.6
"$UV" pip install --python "$VENV/bin/python" 'https://github.com/Dao-AILab/flash-attention/releases/download/v2.7.4.post1/flash_attn-2.7.4.post1+cu12torch2.6cxx11abiFALSE-cp311-cp311-linux_x86_64.whl'
"$UV" pip install --python "$VENV/bin/python" codetiming dacite more_itertools pybase64 jsonlines deprecated loralib 'tyro>=0.5.7' latex2sympy2==1.5.4 latex2sympy2_extended==1.10.1 langdetect 'nltk>=3.8' imageio gymnasium mcp openai nvidia-ml-py scikit-learn pytest pandas 'pyzmq>=26' hydra-core==1.3.2 omegaconf==2.3.0 psutil
apt-get update -qq
apt-get install -y -qq tmux rsync iverilog
if [ ! -x /opt/oss-cad-suite/bin/eqy ]; then
  tar xzf /workspace/oss-cad-suite-linux-x64-20240403.tgz -C /opt
fi
"$VENV/bin/python" - <<'PY'
import torch
from flash_attn import flash_attn_func
q = torch.randn(1, 8, 2, 64, dtype=torch.bfloat16, device='cuda')
flash_attn_func(q, q.clone(), q.clone(), causal=True)
print('FLASH_ATTN_KERNEL_OK', torch.__version__)
print('NVML_OK', torch.cuda.device_memory_used(0))
PY
"$VENV/bin/pip" freeze
echo CODEV_SMOKE_ENV_READY
