#!/usr/bin/env bash
# Evaluate selected checkpoints of one arm on VerilogEval-v1 (full protocol), one GPU per checkpoint.
# usage: eval_arm_checkpoints.sh RUN_ID "STEP1 STEP2 ..." GPU_LIST   e.g.  eval_arm_checkpoints.sh async_baseline "20 final" "4 5"
set -euo pipefail
RUN_ID="$1"; STEPS="$2"; GPUS="$3"
R=${ROOT:-/workspace/rtl-blocking-cost-20260910}
CK_ROOT=$(ls -d "$R/runs/$RUN_ID"/checkpoints/*/ | head -1)
export PYTHONPATH="$R/code"
gpu_arr=($GPUS); i=0; pids=()
for step in $STEPS; do
  if [ "$step" = final ]; then
    ck=$(ls -d "$CK_ROOT"/checkpoint-* | sort -t- -k2 -n | tail -1)
  else
    ck="$CK_ROOT/checkpoint-$step"
  fi
  label="$RUN_ID-$(basename "$ck")"
  gpu=${gpu_arr[$((i % ${#gpu_arr[@]}))]}
  echo "eval $label on GPU $gpu"
  bash "$R/code/experiments/launch/run_verilogeval_v1.sh" "$ck" "$label" "$gpu" > "$R/logs/eval_$label.log" 2>&1 &
  pids+=($!); i=$((i + 1))
  if [ $((i % ${#gpu_arr[@]})) -eq 0 ]; then wait "${pids[@]}"; pids=(); fi
done
[ ${#pids[@]} -gt 0 ] && wait "${pids[@]}"
for step in $STEPS; do :; done
grep -h '"pass@1"' "$R"/eval/results/"$RUN_ID"-*/verilogeval-v1/machine/full/temp-0p2/summary.json || true
echo EVAL_ARM_DONE "$RUN_ID"
