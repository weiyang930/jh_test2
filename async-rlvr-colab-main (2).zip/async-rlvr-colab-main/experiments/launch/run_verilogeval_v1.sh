#!/usr/bin/env bash
# VerilogEval-v1 machine, full 143 problems, n=20, T=0.2, top_p=0.95, 2048 tokens, seed 42.
# Same faithful-reconstruction protocol as runpod-backups/sota-repro-2026-09-04 (24-problem
# shard), extended to the full split.  Usage: run_verilogeval_v1.sh MODEL_PATH LABEL GPU_ID
set -euo pipefail
MODEL_PATH="$1"; LABEL="$2"; GPU_ID="${3:-0}"
ROOT=${ROOT:-/workspace/rtl-blocking-cost-20260910}
VENV=${VENV:-/opt/venvs/async-rlvr}
CODEV_TEST="$ROOT/assets/codev-r1-repo/test"
PROTO="$ROOT/eval/protocol"
TEMPERATURE=${TEMPERATURE:-0.2}
N_SAMPLES=${N_SAMPLES:-20}
MAX_TOKENS=2048
SPLIT=machine
OUT="$ROOT/eval/results/$LABEL/verilogeval-v1/$SPLIT/full/temp-${TEMPERATURE/./p}"
mkdir -p "$OUT"

export PATH="/opt/oss-cad-suite/bin:$PATH"
export PYTHONPATH="$CODEV_TEST:$CODEV_TEST/testbench/VerilogEval_v1.0.0:${PYTHONPATH:-}"
export CUDA_VISIBLE_DEVICES="$GPU_ID"
export VLLM_USE_V1=1

PROBLEM_FILE="$CODEV_TEST/testbench/VerilogEval_v1.0.0/data/VerilogEval_Machine.jsonl"
DESCRIPTION_FILE="$CODEV_TEST/testbench/VerilogEval_v1.0.0/descriptions/VerilogDescription_Machine.jsonl"

# vLLM cannot load ROLL's FSDP checkpoint architecture name; patch a copy of config.json.
if grep -q "FSDPQwen2ForCausalLM" "$MODEL_PATH/config.json" 2>/dev/null; then
  sed -i 's/FSDPQwen2ForCausalLM/Qwen2ForCausalLM/' "$MODEL_PATH/config.json"
fi
if [ ! -f "$MODEL_PATH/tokenizer.json" ]; then
  cp "$ROOT/assets/salv-7b"/{tokenizer.json,tokenizer_config.json,vocab.json,merges.txt,special_tokens_map.json,added_tokens.json} "$MODEL_PATH/" 2>/dev/null || true
fi

START_TS=$(date +%s)
"$VENV/bin/python" "$PROTO/prepare_salv_verilogeval_v1.py" --problems "$PROBLEM_FILE" \
  --descriptions "$DESCRIPTION_FILE" --out "$OUT/prompts.jsonl"
"$VENV/bin/python" "$PROTO/sample_codev_single_gpu.py" --prompts "$OUT/prompts.jsonl" --out "$OUT/raw_samples.jsonl" \
  --model "$MODEL_PATH" --n-sample "$N_SAMPLES" --temperature "$TEMPERATURE" --top-p 0.95 --max-tokens "$MAX_TOKENS" \
  --gpu-id "$GPU_ID"
GEN_END_TS=$(date +%s)
"$VENV/bin/python" "$PROTO/extract_salv_verilog.py" --in-path "$OUT/raw_samples.jsonl" --out-path "$OUT/extracted_samples.jsonl"
cd "$CODEV_TEST/testbench/VerilogEval_v1.0.0"
"$VENV/bin/python" "$PROTO/verify_verilogeval_subset.py" "$OUT/extracted_samples.jsonl" \
  --problem-file="$PROBLEM_FILE" --out-file="$OUT/verification_results.jsonl" --n-workers 8
EVAL_END_TS=$(date +%s)

"$VENV/bin/python" - "$OUT" "$MODEL_PATH" "$LABEL" "$N_SAMPLES" "$TEMPERATURE" "$START_TS" "$GEN_END_TS" "$EVAL_END_TS" <<'PY'
import json, math, pathlib, sys
from collections import defaultdict
root, model_path, label, n_samples, temperature, start_ts, gen_end_ts, eval_end_ts = sys.argv[1:]
rows = [json.loads(l) for l in (pathlib.Path(root) / "verification_results.jsonl").open() if l.strip()]
by_task = defaultdict(list)
for row in rows:
    by_task[row["task_id"]].append(bool(row.get("passed")))
pass_at_k = {}
for k in (1, 5, 10):
    if by_task and all(len(v) >= k for v in by_task.values()):
        est = []
        for v in by_task.values():
            n, c = len(v), sum(v)
            miss = 0.0 if n - c < k else math.comb(n - c, k) / math.comb(n, k)
            est.append(1.0 - miss)
        pass_at_k[f"pass@{k}"] = sum(est) / len(est)
per_task = {t: sum(v) / len(v) for t, v in by_task.items()}
summary = dict(reproduction_class="faithful_reconstruction_not_exact", model_path=model_path, model_label=label,
               benchmark="VerilogEval-v1", split="machine", mode="full", n_samples_per_problem=int(n_samples),
               temperature=float(temperature), top_p=0.95, max_output_tokens=2048, seed=42,
               num_generations=len(rows), num_problems=len(by_task),
               passed_generations=sum(sum(v) for v in by_task.values()), pass_at_k=pass_at_k,
               empty_completion_count=sum(not r.get("completion", "") for r in rows),
               generation_seconds=int(gen_end_ts) - int(start_ts), verification_seconds=int(eval_end_ts) - int(gen_end_ts))
(pathlib.Path(root) / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
(pathlib.Path(root) / "per_task_pass_rate.json").write_text(json.dumps(per_task, indent=2, sort_keys=True) + "\n")
print(json.dumps(summary, indent=2))
PY
