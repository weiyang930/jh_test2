#!/usr/bin/env bash
# Launch one RTL async_generation_ratio experiment.
#
# Usage: launch_rtl_ratio.sh RATIO RUN_ID [STEPS]
set -euo pipefail
ulimit -c 0

REPO="${REPO:-/workspace/async-rlvr}"
VENV="${VENV:-/opt/venvs/async-rlvr}"
RATIO="${1:?async_generation_ratio is required}"
RUN_ID="${2:?run ID is required}"
STEPS="${3:-15}"
MAX_RUNTIME="${MAX_RUNTIME:-5h}"
RUN_DIR="$REPO/artifacts/runs/$RUN_ID"
CONFIG="$REPO/experiments/configs/rtl_async_baseline.yaml"

if ! [[ "$RATIO" =~ ^[0-9]+$ ]]; then
    echo "FATAL: ratio must be a non-negative integer: $RATIO" >&2
    exit 2
fi
if [ -e "$RUN_DIR" ]; then
    echo "FATAL: run directory already exists: $RUN_DIR" >&2
    exit 1
fi

cd "$REPO"
GIT_STATUS=$(git status --porcelain)
if [ -n "$GIT_STATUS" ]; then
    echo "FATAL: source worktree is dirty" >&2
    git status --short >&2
    exit 1
fi

mkdir -p "$RUN_DIR/output"
export RTL_ASYNC_GENERATION_RATIO="$RATIO"
export RTL_DATA_PATH="${RTL_DATA_PATH:-/opt/async-rlvr-assets/rtl_filtered_train.jsonl}"
export RTL_MAX_STEPS="$STEPS"
export RTL_MODEL_PATH="${RTL_MODEL_PATH:-/opt/async-rlvr-assets/origen-deepseek7b-run-20250803_172955}"
export RTL_RUN_OUTPUT_DIR="$RUN_DIR/output"
export PYTHONPATH="$REPO:${PYTHONPATH:-}"
export PATH="/opt/oss-cad-suite/bin:$VENV/bin:$PATH"
export NCCL_NVLS_ENABLE=0
export PYTHONUNBUFFERED=1
export TOKENIZERS_PARALLELISM=false

CMD=(
    "$VENV/bin/python"
    experiments/launch/run_rlvr_with_shutdown.py
    --config_path ../experiments/configs
    --config_name rtl_async_baseline
)

"$VENV/bin/python" - "$RUN_DIR" "$RUN_ID" "$RATIO" "$STEPS" "$MAX_RUNTIME" "$CONFIG" "${CMD[*]}" <<'PY'
import json
import subprocess
import sys
import time
from pathlib import Path

from omegaconf import OmegaConf

run_dir, run_id, ratio, steps, max_runtime, config_path, command = sys.argv[1:]
run_path = Path(run_dir)
config = OmegaConf.load(config_path)
(run_path / "resolved_config.yaml").write_text(OmegaConf.to_yaml(config, resolve=True))
manifest = {
    "run_id": run_id,
    "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "git_branch": subprocess.check_output(["git", "branch", "--show-current"], text=True).strip(),
    "git_dirty": False,
    "launch_time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "command": command,
    "max_steps": int(steps),
    "max_runtime": max_runtime,
    "async_generation_ratio": int(ratio),
    "mode": "sync_wait_all_control" if int(ratio) == 0 else "native_async",
    "hardware": "6xA100-SXM4-80GB; train/reference GPUs 0-3; inference GPUs 4-5; 16 RTL workers",
    "model": config.pretrain,
    "dataset": config.actor_train.data_args.file_name[0],
    "config": config_path,
    "status": "running",
}
(run_path / "manifest.json").write_text(json.dumps(manifest, indent=2))
PY

printf '%s\n' \
    '#!/usr/bin/env bash' \
    "export RTL_ASYNC_GENERATION_RATIO=$RATIO RTL_MAX_STEPS=$STEPS" \
    "export RTL_RUN_OUTPUT_DIR=$RTL_RUN_OUTPUT_DIR" \
    "export RTL_MODEL_PATH=$RTL_MODEL_PATH RTL_DATA_PATH=$RTL_DATA_PATH" \
    "export PYTHONPATH=$REPO PATH=/opt/oss-cad-suite/bin:$VENV/bin:\$PATH NCCL_NVLS_ENABLE=0" \
    "cd $REPO" \
    "${CMD[*]}" > "$RUN_DIR/command.sh"
chmod +x "$RUN_DIR/command.sh"

set +e
timeout --signal=INT --kill-after=5m "$MAX_RUNTIME" "${CMD[@]}" \
    > >(tee -a "$RUN_DIR/stdout.log") \
    2> >(tee -a "$RUN_DIR/stderr.log" >&2)
EXIT_CODE=$?
set -e

"$VENV/bin/python" experiments/analysis/baseline_metrics.py "$RUN_DIR" > "$RUN_DIR/analysis.txt" 2>&1 || true
"$VENV/bin/python" - "$RUN_DIR/manifest.json" "$EXIT_CODE" <<'PY'
import json
import sys
import time
from pathlib import Path

path = Path(sys.argv[1])
manifest = json.loads(path.read_text())
manifest.update(
    {
        "end_time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "exit_code": int(sys.argv[2]),
        "status": "completed" if int(sys.argv[2]) == 0 else "failed",
    }
)
path.write_text(json.dumps(manifest, indent=2))
PY
exit "$EXIT_CODE"
