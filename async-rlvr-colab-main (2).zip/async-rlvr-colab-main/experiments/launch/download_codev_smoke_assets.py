"""Fetch only the pinned public SFT weights and RL parquet data for the smoke."""
import os
from pathlib import Path

from huggingface_hub import snapshot_download, hf_hub_download


if __name__ == '__main__':
    root = Path(os.environ.get('CODEV_SMOKE_ROOT', '/opt/codev-sixgpu-smoke-20260907'))
    snapshot_download(
        'zhuyaoyu/CodeV-R1-Distill-Qwen-7B',
        revision='8fdb92e328cb2a98ef9a3f9dcd82995a2112bd9c',
        local_dir=str(root / 'models/codev-sft'),
        allow_patterns=['*.safetensors', '*.json', '*.txt'],
        max_workers=4,
    )
    for filename in ['codev_r1_rl_train.parquet', 'codev_r1_rl_val.parquet']:
        hf_hub_download(
            'zhuyaoyu/CodeV-R1-dataset', filename=filename, repo_type='dataset',
            revision='9ab06ff546c597b66e124839a6f60c5330083424',
            local_dir=str(root / 'data/codev'),
        )
    print('CODEV_PINNED_ASSETS_READY', flush=True)
