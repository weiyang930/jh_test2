#!/usr/bin/env python3
"""Zero-GPU replay for the dynamic-price (bid-price) coupling claim.

Reads the run directories produced by the async-RLVR pipeline (``<run>/output/events.jsonl``; schema identical to
the E-C runs) and writes ONLY aggregates: ``results.json`` plus a few PNGs. No prompts, generations or raw events
leave this script.

Questions answered, per target run:
  Q1  Does the verifier backlog (hence an opportunity price rho_t ~ queue depth / workers) vary over time, and is the
      variation sustained (between steps) or only bursty (within a step)?
  Q2  If the index controller used a dynamic price rho_t instead of a constant lambda with the SAME mean, how many
      continue/cancel decisions would flip, and how many verifier-seconds do those flips cover?
  Q3  Where does verifier time go: useful (informative group) vs wasted, and of the wasted time how much is visible
      in flight (posterior P(pass | age, siblings) < threshold) and/or knowable from a prior run's timeout history.

usage:
  python replay_rho.py --run <dir> --workers 32 --tau 180 --out <outdir> [--table-from <barrier run dir>]
                       [--history <prior run dir>] [--group-size 8] [--label "H100 decoupled eta2 tau180"]

Decision rule replayed (0930_method.md, index controller):  continue j  <=>  dV_j(t) - lambda * R(t) > 0, with
  dV_j = p*v(n+1,s+1) + (1-p)*v(n+1,s) - vbar(n,s),  v(n,s) = 1[0<s<n]*(n/G),  vbar = v if releasable else 0,
  p = P(pass | T>t, sibling state) and R(t) = E[min(T,tau)-t | T>t] from Kaplan-Meier-style tables.
Since the rule is  lambda < theta_j(t) := dV_j/R(t),  a decision flips between a constant lambda_bar and a dynamic
lambda(t) with the same mean iff theta lies between them.
"""
from __future__ import annotations

import argparse
import collections
import json
import math
import os
import statistics as st

import numpy as np

GRID = [0, 2, 5, 10, 20, 30, 45, 60, 90, 120, 180, 240]
STATES = ("none", "fail", "pass")


# ----------------------------------------------------------------------------- loading
def load_events(run_dir: str) -> list[dict]:
    path = os.path.join(run_dir, "output", "events.jsonl")
    if not os.path.exists(path):
        path = os.path.join(run_dir, "events.jsonl")
    out = []
    with open(path, errors="ignore") as f:
        for line in f:
            try:
                out.append(json.loads(line))
            except Exception:
                pass
    return out


def group_jobs(events: list[dict]) -> dict:
    """(prompt_id, step) -> list of jobs {start, end, dur, pass, timeout, cancelled}."""
    groups = collections.defaultdict(list)
    for e in events:
        k = (e.get("prompt_id"), e.get("sampling_start_step"))
        if e.get("event") == "sample_done" and e.get("verifier_execution_s") is not None:
            if not (e.get("t_worker_start") and e.get("t_worker_end")):
                continue
            groups[k].append({"submit": float(e.get("t_reward_submit") or e["t_worker_start"]),
                              "start": float(e["t_worker_start"]), "end": float(e["t_worker_end"]),
                              "dur": float(e["verifier_execution_s"]), "pass": e.get("verifier_stage") == "pass",
                              "timeout": e.get("verifier_stage") == "eqy_timeout", "cancelled": False,
                              "step": e.get("sampling_start_step")})
        elif e.get("event") == "sample_canceled" and e.get("phase") in ("verifying", "verify", None):
            dur = float(e.get("elapsed_s") or 0.0)
            end = float(e["ts"])
            groups[k].append({"submit": end - dur, "start": end - dur, "end": end, "dur": dur, "pass": False,
                              "timeout": False, "cancelled": True, "step": e.get("sampling_start_step")})
    return groups


# ----------------------------------------------------------------------------- tables
def sib_state(jobs, j, t_age):
    """Sibling state of job j at its own age t_age, from realised sibling finish times (relative to j's start)."""
    t_abs = jobs[j]["start"] + t_age
    done = [x["pass"] for k, x in enumerate(jobs) if k != j and x["end"] <= t_abs and not x["cancelled"]]
    if not done:
        return "none"
    return "pass" if any(done) else "fail"


def fit_tables(groups: dict, tau: float, min_count: int = 20):
    """P(pass | T>t, S) and R(t) = E[min(T,tau)-t | T>t] on GRID. Cancelled jobs are right-censored for R."""
    num = collections.Counter()
    den = collections.Counter()
    rem = collections.defaultdict(list)
    for jobs in groups.values():
        for j, x in enumerate(jobs):
            for t in GRID:
                if x["dur"] > t:
                    s = sib_state(jobs, j, t)
                    if not x["cancelled"]:
                        den[(t, s)] += 1
                        num[(t, s)] += x["pass"]
                        rem[t].append(min(x["dur"], tau) - t)
    pooled_num = collections.Counter()
    pooled_den = collections.Counter()
    for (t, s), d in den.items():
        pooled_den[t] += d
        pooled_num[t] += num[(t, s)]
    p = {}
    for t in GRID:
        for s in STATES:
            if den[(t, s)] >= min_count:
                p[(t, s)] = num[(t, s)] / den[(t, s)]
            elif pooled_den[t] >= min_count:
                p[(t, s)] = pooled_num[t] / pooled_den[t]
    R = {t: float(np.mean(v)) for t, v in rem.items() if len(v) >= min_count}
    counts = {f"{t}|{s}": den[(t, s)] for (t, s) in den}
    return p, R, counts


def v_of(n, s, G):
    return (n / G) if 0 < s < n else 0.0


def releasable(n, s, G):
    return 0 < s < n and n >= math.ceil(0.75 * G)


# ----------------------------------------------------------------------------- Q1 backlog / price
def backlog_series(groups: dict, workers: int):
    """1-second grid: queued (submitted, not started), running, and rho = queued/workers."""
    jobs = [x for js in groups.values() for x in js]
    t0 = min(x["submit"] for x in jobs)
    t1 = max(x["end"] for x in jobs)
    n = int(t1 - t0) + 2
    queued = np.zeros(n)
    running = np.zeros(n)
    for x in jobs:
        a, b, c = int(x["submit"] - t0), int(x["start"] - t0), int(x["end"] - t0)
        if b > a:
            queued[a:b] += 1
        if c > b:
            running[b:c] += 1
    rho = queued / workers
    return t0, queued, running, rho


def ema(x: np.ndarray, half_life_s: float) -> np.ndarray:
    a = 1 - 0.5 ** (1.0 / max(half_life_s, 1e-9))
    y = np.empty_like(x)
    acc = 0.0
    for i, v in enumerate(x):
        acc = a * v + (1 - a) * acc
        y[i] = acc
    return y


def q1_summary(groups, workers, step_bounds):
    t0, queued, running, rho = backlog_series(groups, workers)
    out = {"seconds": int(len(rho)), "rho_mean": float(rho.mean()), "rho_cv": float(rho.std() / max(rho.mean(), 1e-9)),
           "frac_time_queue_nonempty": float((queued > 0).mean()),
           "occupancy_mean": float((running / workers).mean()),
           "frac_time_pool_saturated": float((running >= workers - 0.5).mean()),
           "corr_queue_vs_running": float(np.corrcoef(queued, running)[0, 1]) if queued.std() > 0 and running.std() > 0 else None}
    for hl in (10, 30, 120):
        s = ema(rho, hl)
        out[f"rho_ema{hl}_cv"] = float(s.std() / max(s.mean(), 1e-9))
    # between-step vs within-step variance of rho (steps = sampling_start_step boundaries via first submit per step)
    if step_bounds:
        per_step = []
        for a, b in step_bounds:
            seg = rho[max(0, int(a - t0)):max(0, int(b - t0))]
            if len(seg) > 5:
                per_step.append(float(seg.mean()))
        if len(per_step) >= 3:
            tot = float(rho.var())
            between = float(np.var(per_step))
            out["rho_between_step_var_share"] = between / tot if tot > 0 else None
            out["rho_per_step_means_first10"] = [round(v, 3) for v in per_step[:10]]
    return out, (t0, queued, running, rho)


# ----------------------------------------------------------------------------- Q2 decision flips
def theta_series(groups, p_tab, R_tab, G, tau):
    """For every (job, grid age) where the job is still running: theta = dV/R and the absolute time."""
    rows = []
    for jobs in groups.values():
        for j, x in enumerate(jobs):
            for t in GRID:
                if t <= 0 or x["dur"] <= t or t >= tau:
                    continue
                s_state = sib_state(jobs, j, t)
                p = p_tab.get((t, s_state))
                R = R_tab.get(t)
                if p is None or R is None or R <= 0:
                    continue
                t_abs = x["start"] + t
                done = [y for k, y in enumerate(jobs) if k != j and y["end"] <= t_abs and not y["cancelled"]]
                n, s = len(done), sum(y["pass"] for y in done)
                vbar = v_of(n, s, G) if releasable(n, s, G) else 0.0
                dV = p * v_of(n + 1, s + 1, G) + (1 - p) * v_of(n + 1, s, G) - vbar
                # seconds this decision governs: until the next grid point or the job's end
                nxt = min([g for g in GRID if g > t] + [tau])
                sec = min(x["dur"], nxt) - t
                rows.append((t_abs, dV / R, sec))
    return rows


def q2_flips(rows, t0, rho, theta_quantiles=(0.5, 0.6, 0.7, 0.8, 0.9, 0.95)):
    """Flip rate between a constant lambda and a dynamic lambda(t) with the same mean.

    theta = dV/R is in informative-groups per verifier-second and is tiny (1e-4..1e-2), while rho = queued/N is
    O(1), so the price scale kappa is set so that lambda_const = kappa * mean(rho) sits at a chosen quantile of
    theta (i.e. the constant controller cancels that share of running checks). Dynamic: lambda(t) = kappa *
    EMA_30s(rho)(t), same kappa hence the same mean price. A decision flips iff theta lies between the two prices.
    """
    rho_s = ema(rho, 30)
    mean_rho = float(rho.mean())
    out = []
    thetas = np.array([r[1] for r in rows])
    secs = np.array([r[2] for r in rows])
    idx = np.array([min(len(rho_s) - 1, max(0, int(r[0] - t0))) for r in rows])
    lam_dyn_unit = rho_s[idx]
    pos = thetas[thetas > 0]
    for q in theta_quantiles:
        lam_c = float(np.quantile(pos, q)) if len(pos) else 0.0
        k = lam_c / mean_rho if mean_rho > 0 else 0.0
        lam_d = k * lam_dyn_unit
        cont_c = lam_c < thetas
        cont_d = lam_d < thetas
        flip = cont_c != cont_d
        out.append({"theta_quantile": q, "lambda_const": lam_c, "kappa": k,
                    "continue_rate_const": float(cont_c.mean()), "continue_rate_dynamic": float(cont_d.mean()),
                    "flip_rate_decisions": float(flip.mean()), "flip_share_verifier_seconds": float(secs[flip].sum() / secs.sum()),
                    "flips_to_continue": float((flip & cont_d).mean()), "flips_to_cancel": float((flip & ~cont_d).mean())})
    return {"n_decisions": int(len(rows)), "share_theta_zero": float((thetas <= 0).mean()),
            "theta_quantiles_positive": {q: float(np.quantile(pos, q)) for q in (0.1, 0.25, 0.5, 0.75, 0.9)} if len(pos) else {},
            "rho_mean": mean_rho, "sweep": out}


# ----------------------------------------------------------------------------- Q3 overlap cross-tab
def q3_crosstab(groups, p_tab, G, history_groups=None, thr=0.10):
    hist_to = set()
    if history_groups:
        hist_to = {pid for (pid, _), js in history_groups.items() if any(x["timeout"] for x in js)}
    tot = 0.0
    cell = collections.Counter()
    probs = set()
    for (pid, _), jobs in groups.items():
        n = len(jobs)
        npass = sum(x["pass"] for x in jobs)
        inform = 0 < npass < n
        hflag = pid in hist_to
        for j, x in enumerate(jobs):
            tot += x["dur"]
            if inform:
                cell["useful"] += x["dur"]
                continue
            vis_from = None
            for t in GRID:
                if x["dur"] <= t:
                    break
                pr = p_tab.get((t, sib_state(jobs, j, t)))
                if pr is not None and pr < thr:
                    vis_from = t
                    break
            if vis_from is None:
                cell[(hflag, "never_visible")] += x["dur"]
            else:
                cell[(hflag, "pre")] += vis_from
                cell[(hflag, "post")] += x["dur"] - vis_from
            if hflag:
                probs.add(pid)
    f = lambda k: cell[k] / tot if tot else None
    res = {"total_verifier_s": tot, "useful": f("useful"),
           "hist_pre": f((True, "pre")), "hist_post": f((True, "post")), "hist_never": f((True, "never_visible")),
           "nohist_pre": f((False, "pre")), "nohist_post": f((False, "post")), "nohist_never": f((False, "never_visible")),
           "n_groups": len(groups), "n_prior_timeout_problems_with_waste": len(probs), "history_available": bool(history_groups)}
    res["reclaimable_selector_only"] = (res["hist_pre"] or 0) + (res["hist_post"] or 0) + (res["hist_never"] or 0)
    res["reclaimable_scheduler_only"] = (res["hist_post"] or 0) + (res["nohist_post"] or 0)
    res["reclaimable_both"] = res["reclaimable_selector_only"] + (res["nohist_post"] or 0)
    return res


# ----------------------------------------------------------------------------- main
def step_bounds_from(groups):
    first = collections.defaultdict(lambda: float("inf"))
    last = collections.defaultdict(lambda: 0.0)
    for (pid, step), jobs in groups.items():
        for x in jobs:
            first[step] = min(first[step], x["submit"])
            last[step] = max(last[step], x["end"])
    steps = sorted(k for k in first if k is not None)
    return [(first[s], last[s]) for s in steps]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--workers", type=int, required=True)
    ap.add_argument("--tau", type=float, default=180.0)
    ap.add_argument("--group-size", type=int, default=None)
    ap.add_argument("--table-from", default=None, help="barrier run to fit p(t|S), R(t); default = the run itself")
    ap.add_argument("--history", default=None, help="independent prior run for the history flag in Q3")
    ap.add_argument("--label", default="")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    groups = group_jobs(load_events(a.run))
    G = a.group_size or int(round(st.median(len(js) for js in groups.values())))
    tab_groups = group_jobs(load_events(a.table_from)) if a.table_from else groups
    p_tab, R_tab, counts = fit_tables(tab_groups, a.tau)
    hist_groups = group_jobs(load_events(a.history)) if a.history else None

    q1, (t0, queued, running, rho) = q1_summary(groups, a.workers, step_bounds_from(groups))
    rows = theta_series(groups, p_tab, R_tab, G, a.tau)
    q2 = q2_flips(rows, t0, rho)
    q3 = q3_crosstab(groups, p_tab, G, hist_groups)

    results = {"label": a.label, "run": os.path.basename(os.path.normpath(a.run)), "workers": a.workers, "tau": a.tau,
               "group_size": G, "n_groups": len(groups), "n_jobs": sum(len(j) for j in groups.values()),
               "n_cancelled_jobs": sum(x["cancelled"] for j in groups.values() for x in j),
               "p_table": {f"{t}|{s}": round(v, 3) for (t, s), v in sorted(p_tab.items())},
               "p_table_counts": counts, "R_table": {str(t): round(v, 1) for t, v in sorted(R_tab.items())},
               "Q1_backlog_price": q1, "Q2_decision_flips": q2, "Q3_overlap_crosstab": q3}
    with open(os.path.join(a.out, "results.json"), "w") as f:
        json.dump(results, f, indent=1)
    print(json.dumps({k: results[k] for k in ("label", "run", "workers", "group_size", "n_groups", "n_jobs", "n_cancelled_jobs")}))
    print("Q1", json.dumps(q1, indent=1))
    print("Q2", json.dumps({k: q2[k] for k in ("n_decisions", "share_theta_zero", "theta_quantiles_positive", "rho_mean")}, indent=1))
    for r in q2["sweep"]:
        print("   ", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()})
    print("Q3", json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in q3.items()}, indent=1))

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(2, 1, figsize=(11, 6), sharex=False)
        tt = np.arange(len(rho))
        ax[0].plot(tt, running / a.workers, lw=0.6, color="#777", label="occupancy (running / N)")
        ax[0].plot(tt, rho, lw=0.6, color="#C62828", label="rho = queued / N")
        ax[0].plot(tt, ema(rho, 30), lw=1.2, color="#2b6cd4", label="rho, EMA 30 s")
        ax[0].set_ylabel("per worker")
        ax[0].legend(frameon=False, fontsize=9)
        ax[0].set_title(f"{a.label}  N={a.workers}  tau={a.tau}", loc="left")
        w = min(len(rho), 600)
        mid = len(rho) // 2
        ax[1].plot(tt[mid:mid + w], (running / a.workers)[mid:mid + w], lw=0.8, color="#777")
        ax[1].plot(tt[mid:mid + w], rho[mid:mid + w], lw=0.8, color="#C62828")
        ax[1].plot(tt[mid:mid + w], ema(rho, 30)[mid:mid + w], lw=1.4, color="#2b6cd4")
        ax[1].set_xlabel("seconds since first submit (zoom: 10 min mid-run)")
        fig.tight_layout()
        fig.savefig(os.path.join(a.out, "rho_timeseries.png"), dpi=150)
        plt.close(fig)
        fig, ax = plt.subplots(figsize=(6, 3.6))
        ks = [r["theta_quantile"] for r in q2["sweep"]]
        ax.plot(ks, [r["flip_rate_decisions"] for r in q2["sweep"]], marker="o", label="share of decisions that flip")
        ax.plot(ks, [r["flip_share_verifier_seconds"] for r in q2["sweep"]], marker="s", label="share of verifier-seconds governed by a flip")
        ax.plot(ks, [r["continue_rate_const"] for r in q2["sweep"]], marker="^", color="#999", label="continue rate, constant lambda")
        ax.set_xlabel("quantile of theta = dV/R at which the constant lambda sits (dynamic price has the same mean)")
        ax.set_title("constant vs dynamic price: how often the decision differs", loc="left", fontsize=10)
        ax.legend(frameon=False, fontsize=9)
        fig.tight_layout()
        fig.savefig(os.path.join(a.out, "flip_rate.png"), dpi=150)
        plt.close(fig)
    except Exception as e:  # figures are optional
        print("figures skipped:", e)


if __name__ == "__main__":
    main()
