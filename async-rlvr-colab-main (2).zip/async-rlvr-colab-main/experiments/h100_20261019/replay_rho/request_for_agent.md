# Analysis request: verifier backlog, dynamic price, and decision flips on the H100 E-C runs

Please run the attached `replay_rho.py` on the 2026-10-10 H100 runs and send back **only** the outputs it writes
(`results.json` and two PNGs per run). It reads `<run>/output/events.jsonl` (the same schema as the A100 E-C runs;
if the file sits directly in `<run>/events.jsonl` that also works) and writes aggregates only — no prompts, generations
or raw events are copied anywhere.

## Environment

Python 3.10+ with `numpy` and `matplotlib` (figures are skipped automatically if matplotlib is missing). No GPU.
Each run takes well under a minute.

## Runs and commands

Replace `$R` with the directory that holds the synced runs (`/home/wei/jiahe/ec_results/synced_runs/` or the
unpacked `ec_h100_results.tgz`). Workers = 32 EQY workers, group size = 8, tau = 180 s for the main arms and 60 s for
the `_t60` arms. Tables p(t | S) and R(t) are fitted on the barrier r1 arm; the "history" flag uses barrier r1 as the
independent prior run (for barrier r1 itself use r2 as history).

```bash
python replay_rho.py --run $R/ec_barrier_r1       --table-from $R/ec_barrier_r2 --history $R/ec_barrier_r2 --workers 32 --tau 180 --group-size 8 --label "H100 barrier r1 tau180"       --out out/barrier_r1
python replay_rho.py --run $R/ec_barrier_r2       --table-from $R/ec_barrier_r1 --history $R/ec_barrier_r1 --workers 32 --tau 180 --group-size 8 --label "H100 barrier r2 tau180"       --out out/barrier_r2
python replay_rho.py --run $R/ec_barrier_r4       --table-from $R/ec_barrier_r1 --history $R/ec_barrier_r1 --workers 32 --tau 180 --group-size 8 --label "H100 barrier r4 tau180"       --out out/barrier_r4
python replay_rho.py --run $R/ec_decoupled_eta2   --table-from $R/ec_barrier_r1 --history $R/ec_barrier_r1 --workers 32 --tau 180 --group-size 8 --label "H100 decoupled eta2 tau180"   --out out/decoupled_eta2
python replay_rho.py --run $R/ec_barrier_r2_t60   --table-from $R/ec_barrier_r2_t60 --history $R/ec_barrier_r1 --workers 32 --tau 60 --group-size 8 --label "H100 barrier r2 tau60"    --out out/barrier_r2_t60
python replay_rho.py --run $R/ec_decoupled_t60    --table-from $R/ec_barrier_r2_t60 --history $R/ec_barrier_r1 --workers 32 --tau 60 --group-size 8 --label "H100 decoupled eta2 tau60" --out out/decoupled_t60
```

If an arm directory is named differently, use the actual name; if the `_t60` arms are missing, skip them.

## What each output means (so you can sanity-check before sending)

- `Q1_backlog_price`: the verifier queue reconstructed per second from `t_reward_submit` / `t_worker_start` /
  `t_worker_end` (cancelled jobs count as running for their `elapsed_s`). `rho = queued / workers`. Key fields:
  `frac_time_queue_nonempty`, `frac_time_pool_saturated`, `rho_ema30_cv` (how much the price moves after 30 s
  smoothing), `rho_between_step_var_share` (sustained between-step variation vs within-step bursts).
- `Q2_decision_flips`: for every running check at ages 2…120 s, the index controller's threshold
  `theta = dV / R` (tables from the barrier arm). A constant price placed at a quantile of theta is compared with a
  dynamic price `kappa * EMA30(rho)` of the same mean; `flip_rate_decisions` and `flip_share_verifier_seconds` say
  how many decisions, and how much verifier time, the two prices disagree on.
- `Q3_overlap_crosstab`: verifier-seconds split into useful (informative group) vs wasted, and wasted into
  "visible in flight" (posterior < 0.1) and "problem timed out in the independent prior run".

Sanity checks: `n_jobs` ≈ 30 steps × 32 prompts × 8 (≈ 7,700 plus cancellations for the decoupled arm);
`occupancy_mean` for `barrier_r2` should be close to the busy fraction already reported for that arm.

## Please send back

`out/*/results.json`, `out/*/rho_timeseries.png`, `out/*/flip_rate.png`, and the exact command lines used.
Nothing else is needed.
