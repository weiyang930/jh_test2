#!/usr/bin/env python3
"""Machine-checkable smoke gate: decides whether Stage 1 may start, no human in the loop.

usage: python experiments/h100_20261019/smoke_gate.py <ROOT> [--runs h100_rtl_barrier_r2_smoke h100_lean_barrier_r2_smoke]
Exit 0 and prints SMOKE_GATE_PASS when every check passes; otherwise exit 1 with SMOKE_GATE_FAIL and the reasons.
Checks (per smoke run, 2 training steps, B=32 G=8 unless the manifest says otherwise):
  setup    logs/setup_1018.log contains LEAN_REPL_OK, VE2_JUDGE ('pass' and H100_SETUP_DONE
  train    manifest status == completed, exit_code 0, stdout reaches global_step=1
  reward   >= 2*B*0.75 groups committed, every committed group has G rewards, >= 1 informative group,
           invalid-reward fraction < 10%, no 'OutOfMemory' / 'Traceback' in the last 400 lines of stdout
  eval     eval/eval_curve.json has 2 rows (step0 + checkpoint-2) and each row has the expected benchmarks with pass@1
  pack     outbox/<run>.tgz exists and is > 200 KB
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


def check(root: Path, run_id: str, reasons: list) -> None:
    r = root / "runs" / run_id
    train = (r / "train").resolve() if (r / "train").exists() else None
    if train is None or not (train / "manifest.json").exists():
        reasons.append(f"{run_id}: no train/manifest.json"); return
    m = json.load(open(train / "manifest.json"))
    if m.get("status") != "completed" or m.get("exit_code") != 0:
        reasons.append(f"{run_id}: manifest status={m.get('status')} exit={m.get('exit_code')}")
    B, G = int(m.get("rollout_batch_size", 32)), int(m.get("group_size", 8))
    stdout = (train / "stdout.log").read_text(errors="ignore") if (train / "stdout.log").exists() else ""
    if "global_step=1" not in stdout:
        reasons.append(f"{run_id}: stdout never reached global_step=1")
    tail = "\n".join(stdout.splitlines()[-400:])
    for bad in ("OutOfMemoryError", "Traceback (most recent call last)"):
        if bad in tail:
            reasons.append(f"{run_id}: '{bad}' in the last 400 stdout lines")
    ev = train / "output" / "events.jsonl"
    commits, inform, invalid, done = 0, 0, 0, 0
    if ev.exists():
        for line in open(ev, errors="ignore"):
            try:
                e = json.loads(line)
            except Exception:
                continue
            if e.get("event") == "prompt_commit":
                rw = e.get("rewards") or []
                commits += 1
                inform += len(set(rw)) > 1
                if len(rw) != G:
                    reasons.append(f"{run_id}: committed group with {len(rw)} rewards (G={G})")
            elif e.get("event") == "sample_done":
                done += 1
                invalid += (e.get("reward_valid") is False)
    else:
        reasons.append(f"{run_id}: no output/events.jsonl")
    if commits < int(2 * B * 0.75):
        reasons.append(f"{run_id}: only {commits} groups committed (expected >= {int(2 * B * 0.75)} for 2 steps)")
    if inform < 1:
        reasons.append(f"{run_id}: no informative group among {commits} commits")
    if done and invalid / done >= 0.10:
        reasons.append(f"{run_id}: invalid reward fraction {invalid / done:.2f}")
    curve = r / "eval" / "eval_curve.json"
    want = {"minif2f_test_n32"} if "lean" in run_id else {"ve2_n20", "cvdp_cid003_n10", "cvdp_cid002_n10"}
    if not curve.exists():
        reasons.append(f"{run_id}: no eval/eval_curve.json")
    else:
        rows = json.load(open(curve))
        if len(rows) < 2:
            reasons.append(f"{run_id}: eval_curve has {len(rows)} rows, expected step0 + checkpoint-2")
        for row in rows:
            missing = [b for b in want if b not in row or not any(k.startswith("pass@") for k in row[b])]
            if missing:
                reasons.append(f"{run_id}: eval row {row.get('tag')} missing {missing}")
    tgz = root / "outbox" / f"{run_id}.tgz"
    # a 2-step smoke packs ~0.9 MB of gzip-compressed JSONL (ORCD 2026-10-20); the check only guards against an empty pack
    if not tgz.exists() or tgz.stat().st_size < 200_000:
        reasons.append(f"{run_id}: outbox tgz missing or < 200 KB")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("root", type=Path)
    ap.add_argument("--runs", nargs="+", default=["h100_rtl_barrier_r2_smoke", "h100_lean_barrier_r2_smoke"])
    ap.add_argument("--setup-log", default="logs/setup_1018.log")
    a = ap.parse_args()
    reasons: list = []
    sl = a.root / a.setup_log
    txt = sl.read_text(errors="ignore") if sl.exists() else ""
    for marker in ("LEAN_REPL_OK", "VE2_JUDGE ('pass'", "H100_SETUP_DONE"):
        if marker not in txt:
            reasons.append(f"setup: '{marker}' not in {sl}")
    for run in a.runs:
        check(a.root, run, reasons)
    if reasons:
        print("SMOKE_GATE_FAIL"); [print(" -", x) for x in reasons]; sys.exit(1)
    print("SMOKE_GATE_PASS: setup markers present; both smoke runs trained 2 steps, committed full groups with informative "
          "rewards, evaluated step0 + checkpoint-2 on every benchmark, and packed their outbox tarballs.")


if __name__ == "__main__":
    main()
