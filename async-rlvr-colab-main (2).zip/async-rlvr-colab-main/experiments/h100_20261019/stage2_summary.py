#!/usr/bin/env python3
"""Stage-2 arm summary (zero GPU): what the controller and the selector did in one run, from the event logs.

usage: stage2_summary.py <ROOT>/runs/<run_id>        (reads train/output/{events,verify_queue_events,admission_events}.jsonl)

Prints, per 50 learner steps and overall:
  price      mean / p10 / p90 of the price the controller used (dynamic: kappa * EMA(queued / workers); const: lambda)
  controller decisions, abandoned groups, partial releases, shadow abandons on the audit lane
  loss       two online estimates of the label loss (informative groups the controller gave up):
             model-based  = sum of p_inform at abandon time / (informative consumed + that sum)
             audit-based  = among audit-lane groups the controller WOULD have abandoned, the share that ended informative,
                            times the abandon rate of the controlled lane (model-free; needs audit groups, i.e. a selector arm)
  selector   admits by slot (exploit / audit / replacement), unique problems admitted, informative share by lane
"""
from __future__ import annotations

import collections
import json
import statistics as st
import sys
from pathlib import Path


def events(path: Path) -> list:
    """Parseable JSON lines of a jsonl file (empty if missing)."""
    if not path.exists():
        return []
    out = []
    for line in open(path, errors="ignore"):
        try:
            out.append(json.loads(line))
        except Exception:
            pass
    return out


def informative(rewards: list) -> bool:
    """The learner's definition: reward variance > 0 (graded failures count)."""
    return len({round(float(r), 6) for r in rewards}) > 1


def pct(x: float) -> str:
    return f"{100 * x:5.1f}%"


def main() -> None:
    run = Path(sys.argv[1]); out = run / "train" / "output" if (run / "train" / "output").exists() else run / "output"
    ev = events(out / "events.jsonl"); vq = events(out / "verify_queue_events.jsonl"); adm = events(out / "admission_events.jsonl")
    print(f"# {run.name}   events {len(ev)}  governor {len(vq)}  admission {len(adm)}")
    init = next((e for e in vq if e.get("event") == "governor_init"), {})
    print("governor:", {k: init.get(k) for k in ("controller", "ctrl_lambda", "ctrl_kappa", "ctrl_release", "ctrl_tables", "workers")})
    pinit = next((e for e in adm if e.get("event") == "policy_init"), {})
    if pinit:
        print("admission:", {k: pinit.get(k) for k in ("mode", "batch", "pool_size", "audit", "visit_budget", "budget_window", "price", "rho")})

    # groups: prompt_id -> dict(step, audit, rewards, released, committed)
    groups: dict = {}
    for e in ev:
        k = e.get("event"); pid = e.get("prompt_id")
        if k == "prompt_begin":
            groups[pid] = dict(step=e.get("sampling_start_step", 0), audit=bool(e.get("audit")), dataset_id=e.get("dataset_id"),
                               rewards=None, released=0, committed=False, abandoned=False)
        elif k == "prompt_commit" and pid in groups:
            groups[pid].update(rewards=e.get("rewards") or [], released=int(e.get("released") or 0), committed=True)
    ctrl = collections.defaultdict(list)
    for e in vq:
        k = e.get("event")
        if k in ("controller_abandon", "controller_release", "controller_shadow_abandon", "controller_continue_sample"):
            ctrl[k].append(e)
        if k == "controller_abandon" and e.get("prompt_id") in groups:
            groups[e["prompt_id"]]["abandoned"] = True
    shadow = {e["prompt_id"] for e in ctrl["controller_shadow_abandon"]}

    # per-50-step table
    by_bin = collections.defaultdict(lambda: dict(n=0, inf=0, ab=0, ab_p=0.0, rel=0, audit_n=0, audit_inf=0, shadow=0, shadow_inf=0, prices=[], rew=[], audit_rew=[]))
    step_of = {pid: g["step"] for pid, g in groups.items()}
    for pid, g in groups.items():
        b = by_bin[(g["step"] // 50) * 50]
        lane_audit = g["audit"]
        if g["committed"]:
            inf = informative(g["rewards"]) if g["rewards"] else False
            if lane_audit:
                b["audit_n"] += 1; b["audit_inf"] += inf; b["audit_rew"].extend(float(r) for r in g["rewards"])
                if pid in shadow:
                    b["shadow"] += 1; b["shadow_inf"] += inf
            else:
                b["n"] += 1; b["inf"] += inf; b["rel"] += g["released"] > 0; b["rew"].extend(float(r) for r in g["rewards"])
        elif g["abandoned"]:
            b["n"] += 1; b["ab"] += 1
    for e in ctrl["controller_abandon"]:
        pid = e.get("prompt_id")
        if pid in step_of:
            by_bin[(step_of[pid] // 50) * 50]["ab_p"] += float(e.get("p_inform") or 0.0)
    for k in ("controller_abandon", "controller_release", "controller_continue_sample", "controller_shadow_abandon"):
        for e in ctrl[k]:
            pid = e.get("prompt_id")
            if pid in step_of and e.get("price") is not None:
                by_bin[(step_of[pid] // 50) * 50]["prices"].append(float(e["price"]))

    print("\n## per 50 steps: controlled lane (groups | informative | abandoned | released) | audit lane (groups | informative | shadow-abandon -> informative) | price mean [p10, p90] | loss model / audit | mean reward selected / audit")
    tot = dict(n=0, inf=0, ab=0, ab_p=0.0, audit_n=0, audit_inf=0, shadow=0, shadow_inf=0, rel=0)
    for b0 in sorted(by_bin):
        b = by_bin[b0]
        for k in tot:
            tot[k] += b[k]
        pr = b["prices"]
        price = f"{st.mean(pr):.2e} [{sorted(pr)[len(pr) // 10]:.1e}, {sorted(pr)[9 * len(pr) // 10]:.1e}]" if len(pr) >= 10 else "n/a"
        loss_model = b["ab_p"] / max(b["inf"] + b["ab_p"], 1e-9)
        ab_rate = b["ab"] / max(b["n"], 1)
        loss_audit = (b["shadow_inf"] / b["shadow"]) * (b["shadow"] / b["audit_n"]) / max(b["audit_inf"] / b["audit_n"], 1e-9) if b["audit_n"] and b["shadow"] else float("nan")
        rew = f"{st.mean(b['rew']):.3f}" if b["rew"] else "  n/a"; arew = f"{st.mean(b['audit_rew']):.3f}" if b["audit_rew"] else "  n/a"
        print(f"  {b0:4d}-{b0 + 49:4d}: {b['n']:5d} | {b['inf']:5d} | {b['ab']:4d} | {b['rel']:4d} || {b['audit_n']:4d} | {b['audit_inf']:4d} | {b['shadow']:3d} -> {b['shadow_inf']:3d} || {price:28s} | {pct(loss_model)} / {pct(loss_audit) if loss_audit == loss_audit else '  n/a'} | {rew} / {arew}   (abandon rate {pct(ab_rate)})")
    loss_model = tot["ab_p"] / max(tot["inf"] + tot["ab_p"], 1e-9)
    loss_audit = (tot["shadow_inf"] / tot["audit_n"]) / max(tot["audit_inf"] / tot["audit_n"], 1e-9) if tot["audit_n"] and tot["shadow"] else float("nan")
    print(f"\noverall: controlled lane {tot['n']} groups, informative {tot['inf']} ({pct(tot['inf'] / max(tot['n'], 1))}), abandoned {tot['ab']}, "
          f"released {tot['rel']}; audit lane {tot['audit_n']} groups, informative {pct(tot['audit_inf'] / max(tot['audit_n'], 1))}, "
          f"shadow abandons {tot['shadow']} of which informative {tot['shadow_inf']}")
    print(f"label loss estimate: model-based {pct(loss_model)}; audit-based {pct(loss_audit) if loss_audit == loss_audit else 'n/a (no audit lane or no shadow abandons)'}")
    print("  audit-based = (informative audit groups the controller would have abandoned) / (informative audit groups): the loss the rule")
    print("  would incur on uniformly admitted groups; model-based uses the controller's own p_inform at abandon time.")
    print("  mean reward: the selected lane's reward is NOT comparable across arms (a selector admits mixed problems, so it is lower by")
    print("  construction); the audit lane is uniformly admitted and is the training-reward curve to compare with the Stage-1 arms.")

    if adm:
        admits = [e for e in adm if e.get("event") == "admit"]
        slots = collections.Counter(e.get("slot") for e in admits)
        uniq = len({e.get("dataset_id") for e in admits})
        obs = collections.Counter(e.get("kind") for e in adm if e.get("event") == "observe")
        print(f"\nselector: admits by slot {dict(slots)}; unique problems admitted {uniq}; observe kinds {dict(obs)}")
        sq = [e for e in adm if e.get("event") == "step_queue" and e.get("price") is not None]
        if sq:
            ps = [float(e["price"]) for e in sq]
            print(f"selector price seen at admission: mean {st.mean(ps):.2e}, min {min(ps):.1e}, max {max(ps):.1e} (shared with the controller when price=shared)")
    print("\nfiles:", out)


if __name__ == "__main__":
    main()
