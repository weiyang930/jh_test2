# Run request: async-RLVR Stage 1 on the 8xH100 (2026-10-19)

Repository `Coone21/async-rlvr-colab` (the collaboration package shared on 2026-10-03; `git pull`), directory
`experiments/h100_20261019/`; Chinese step-by-step version in `RUN_1018.md` at the repo root. Same conventions as the
E-C rerun (2026-10-10): `ROOT/code` = this repo, `ROOT/assets`, `ROOT/runs`, `ROOT/logs`; the ROLL venv and
oss-cad-suite from that rerun are reused. Please send back only the per-run tarballs written to `ROOT/outbox/`
(event logs, manifests, eval summaries; no checkpoints, no generations).

## 0. Setup (once, ~30-60 min, mostly Mathlib cache download)

```bash
export ROOT=/path/to/root VENV=/path/to/roll-venv OSS_CAD_DIR=/path/to/oss-cad-suite   # as in the E-C rerun
cd $ROOT/code && git pull
bash experiments/h100_20261019/setup_h100.sh            # add WITH_EARL=1 HF_TOKEN=... only if Stage 3 is requested
```
It installs Lean 4.9.0-rc1 + Goedel-Prover-V2's Mathlib workspace (`lake exe cache get`, REPL built from the lake
dependency), DeepSeek-Prover-V1.5-SFT, the Lean prompt sets, a cocotb venv (CVDP harness runs on the host, no Docker),
CVDP v1.1.0 and VerilogEval-v2 files. It ends with `LEAN_REPL_OK` and `VE2_JUDGE ('pass', ...)`; if either is missing,
stop and send the log.

## 1. Runs (Stage 1: 4 runs, ~22-26 h sequential on one node; two can share the node only if 16 GPUs are available)

Each run = train 300 steps at the fixed operating point -> evaluate every checkpoint (step 0/100/200/300, one GPU per
checkpoint in parallel) -> pack `ROOT/outbox/<run>.tgz`. Expected step times: RTL barrier_r2 ~75 s, decoupled ~45 s;
Lean ~68 s / ~42 s. Trainability (reward curve, eval moving) is visible by step 100-200; the 300 steps also give the
steady-state throughput and staleness numbers.

```bash
cd $ROOT/code
bash experiments/h100_20261019/run_arm.sh rtl  barrier_r2     300   # SALV-7B + CodeV-R1, EQY tau 180, N=32   (~7.5 h incl. eval)
bash experiments/h100_20261019/run_arm.sh rtl  decoupled_eta2 300   # same, AReaL-style consumption, eta=2       (~5 h)
bash experiments/h100_20261019/run_arm.sh lean barrier_r2     300   # DSP-V1.5-SFT + Pset/V1 pool, REPL tau 300, N=8 (~7 h)
bash experiments/h100_20261019/run_arm.sh lean decoupled_eta2 300   #                                            (~5 h)
```
Order matters only in that the two barrier runs are the baselines; if time is short, run `rtl barrier_r2` and
`lean barrier_r2` first. Each run prints `H100_ARM_DONE <run_id>` and `SYNC_READY <tarball>`. Smoke first: `SMOKE=1 run_arm.sh rtl barrier_r2 2 _smoke`
(and the same for `lean`), which evaluates only 8 problems per benchmark.

Fixed settings baked into `run_arm.sh` (do not change unless something fails): 8 GPUs = 4 train (FSDP 4, no offload)
+ 4 vLLM; B=32 prompts x G=8 = 256 samples/step; 2 optimizer updates per step (128 samples each, `RTL_GRAD_ACCUM=32`);
lr 1e-6 (RTL) / 2e-6 (Lean); clip 0.2/0.28, KL 0, T=1.0; checkpoints every 100 steps; `RTL_VERIFY_WORKERS=32` EQY
processes, `LEAN_VERIFY_WORKERS=8` REPLs (each REPL capped at 32 GB RLIMIT_AS, recycled every 100 checks).

## 2. What comes back (text through the agent; files stay on disk)

Run `python experiments/h100_20261019/summarize_run.py ROOT/runs/<run_id>` and paste its output plus `eval/eval_curve.json`;
keep `output/`, `eval/`, the final checkpoint and `outbox/*.tgz` on disk for later transfer.

`ROOT/outbox/h100_<domain>_<arm>.tgz` per run, containing `eval/eval_curve.json` (pass@k per checkpoint: VerilogEval-v2
spec-to-rtl n=20, CVDP cid003/cid002 n=10 for RTL; miniF2F-test n=32 for Lean), the training `output/` directory
(events.jsonl, learner/scheduler/verifier events, admission and governor logs, tensorboard), `manifest.json`,
`launch_env.txt`, `stdout.log`. Typically 50-200 MB. Checkpoints: all but the final one are deleted after evaluation
(`KEEP_CKPTS=1` keeps them); please keep the final checkpoints on your side for now.

## 3. Sanity checks you can do before sending

- `manifest.json` has `"status": "completed"`; `stdout.log` shows `global_step=299`.
- `eval/eval_curve.json` has four rows (step0, checkpoint-100/200/300); RTL step0 should match the SALV baselines measured
  on 2026-10-19 with these exact scripts (VerilogEval-v2 spec-to-rtl pass@1 0.53 / pass@5 0.65 / pass@20 0.72 at T=1.0;
  CVDP cid003 pass@1 0.25 / pass@5 0.37; cid002 0.16 / 0.26); Lean step0 miniF2F
  attempt pass ~0.30.
- Verifier busy fraction for barrier_r2 (from events) in the same range as the E-C rerun at N=32 (~0.7).

## 4. Not in this package (later stages)

- Controller (state-based cancel + partial release) and selector arms: the online implementations are being finished;
  they will come as the same `run_arm.sh` with two more arm names.
- Stage 3: second RTL start EARL-SFT (`run_arm.sh rtl_earl ...`, needs `WITH_EARL=1` in setup) and longer runs if the
  300-step curves have not plateaued.

## 5. If something breaks

Send `ROOT/logs/<run_id>.launch.log` and the last 200 lines of `ROOT/runs/<train_run>/stdout.log`. Known pitfalls:
`lake exe cache get` needs network and ~5 GB; the CVDP harness must use local disk for its scratch (`ROOT/tmp`);
datasets caches must be on local disk (`HF_DATASETS_CACHE`, set by the runners).
