#!/usr/bin/env bash
# Evaluate every saved checkpoint of a handoff run, one checkpoint per GPU in parallel, then delete all but the final one.
# usage: eval_ckpt.sh DOMAIN RUN_ID        (KEEP_CKPTS=1 keeps every checkpoint)
# RTL: VerilogEval-v2 spec-to-rtl n=20 T=1.0 (CodeV-R1 protocol) + CVDP cid003 and cid002 n=10 T=1.0 (ChipMATE protocol).
# Lean: miniF2F-test and ProofNet-test, n=32 T=1.0 (pass@1 = attempt pass rate, pass@32), REPL tau 300 s.
# Re-evaluate an already evaluated run on a benchmark added later: BENCH_ONLY=proofnet_test eval_ckpt.sh lean RUN_ID
# (evaluates step0 + every checkpoint still on disk, skips benchmarks that already have a summary.json, regenerates eval_curve.json).
set -uo pipefail
DOMAIN="$1"; RUN_ID="$2"
SM=""; [ "${SMOKE:-0}" = 1 ] && SM="--limit 8"   # SMOKE=1: 8 problems per benchmark, n unchanged (path check only)
ROOT="${ROOT:-/root/ec}"; VENV="${VENV:-/opt/venvs/async-rlvr}"
PY="$VENV/bin/python"; export PYTHONPATH="$ROOT/code" VLLM_USE_V1=1 HF_HOME="${HF_HOME:-$ROOT/hf}"
OSS_BIN="${OSS_CAD_DIR:-/opt/oss-cad-suite}/bin"; export PATH="$OSS_BIN:$HOME/.elan/bin:$PATH"
CK_DIR="$ROOT/runs/$RUN_ID/checkpoints"; EV="$ROOT/runs/$RUN_ID/eval"; mkdir -p "$EV"
mapfile -t CKS < <(find -L "$CK_DIR" -maxdepth 3 -type d -name 'checkpoint-*' -exec test -f {}/config.json \; -print | awk -F'checkpoint-' '{print $NF "\t" $0}' | sort -n | cut -f2-)   # -L: CKPT_ROOT symlink; numeric by step (10-30: '-t- -k2' keyed on the timestamp dir and kept checkpoint-50 instead of the last one)
if [ "$DOMAIN" = lean ]; then BASE="${LEAN_MODEL_PATH:-$ROOT/assets/dsp15-sft}"
elif [ "$DOMAIN" = rtl_earl ]; then BASE="${EARL_MODEL_PATH:-$ROOT/assets/earl-sft-deepseek7b}"
else BASE="${SALV_MODEL_PATH:-$ROOT/assets/salv-7b}"; fi
# checkpoints saved by older code carry torch FSDP's wrapper class name (FSDPQwen2ForCausalLM) in config.json; vLLM refuses it
for c in "${CKS[@]}"; do $PY - "$c/config.json" <<'PYEOF'
import json, sys
p = sys.argv[1]; cfg = json.load(open(p)); archs = cfg.get("architectures") or []
fixed = [a[4:] if a.startswith("FSDP") else a for a in archs]
if fixed != archs:
    cfg["architectures"] = fixed; json.dump(cfg, open(p, "w"), indent=2); print(f"architectures {archs} -> {fixed} in {p}")
PYEOF
done
TARGETS=("step0:$BASE"); for c in "${CKS[@]}"; do TARGETS+=("$(basename "$c"):$c"); done
echo "evaluating ${#TARGETS[@]} models: ${TARGETS[*]}"
NGPU="${EVAL_PAR:-${RTL_NUM_GPUS:-8}}"; i=0; pids=()  # EVAL_PAR / EVAL_STAGGER_S / EVAL_BENCH_TIMEOUT_S: set on the 8xA100-40GB pod (10-29: 8 simultaneous vLLM starts hung 3 of 8); defaults unchanged
for t in "${TARGETS[@]}"; do
  tag="${t%%:*}"; model="${t#*:}"; gpu=$((i % NGPU)); out="$EV/$tag"; mkdir -p "$out"
  tok=""; [ -f "$model/tokenizer_config.json" ] || tok="--tokenizer $BASE"
  (
    if [ "$DOMAIN" = lean ]; then
      for bench in ${BENCH_ONLY:-minif2f_test proofnet_test}; do
        [ -s "$out/${bench}_n32/summary.json" ] && { echo "$tag $bench already evaluated"; continue; }
        [ -s "$ROOT/assets/data/lean/$bench.jsonl" ] || { echo "missing $ROOT/assets/data/lean/$bench.jsonl (run setup_h100.sh)"; continue; }
        $PY applications/lean/probe_and_eval.py --model "$model" $tok --data "$ROOT/assets/data/lean/$bench.jsonl" --out "$out/${bench}_n32" $SM \
          --n 32 --workers 16 --timeout 300 --gpu "$gpu" --mem-limit-gb 16 --recycle 100 --workspace "${LEAN_WORKSPACE:-$ROOT/lean/Goedel-Prover-V2/mathlib4}"
      done
    else
      sleep $((gpu * ${EVAL_STAGGER_S:-0}))
      [ -s "$out/ve2_n20/summary.json" ] && echo "$tag ve2 already evaluated" || \
      timeout "${EVAL_BENCH_TIMEOUT_S:-0}" $PY applications/rtl/ve2_eval.py --model "$model" $tok --dataset "$ROOT/assets/bench/VerilogEval_v2.0.0/dataset_spec-to-rtl" --out "$out/ve2_n20" $SM --n 20 --workers 16 --gpu "$gpu" --work "$ROOT/tmp/ve2_$RUN_ID" --oss-bin "$OSS_BIN"
      for cid in cid003 cid002; do
        [ -s "$out/cvdp_${cid}_n10/summary.json" ] && { echo "$tag cvdp $cid already evaluated"; continue; }
        timeout "${EVAL_BENCH_TIMEOUT_S:-0}" $PY applications/rtl/cvdp_eval.py --model "$model" $tok --data "$ROOT/assets/bench/cvdp/cvdp_v1.1.0_nonagentic_code_generation_no_commercial.jsonl" \
          --out "$out/cvdp_${cid}_n10" $SM --categories "$cid" --n 10 --workers 16 --gpu "$gpu" --python "$ROOT/env/cvdp-venv/bin/python" --oss-bin "$OSS_BIN" --issues-root "$ROOT/tmp/cvdp_issues"
      done
    fi
  ) > "$EV/$tag.log" 2>&1 &
  pids+=($!); i=$((i + 1))
  if [ $((i % NGPU)) -eq 0 ]; then wait "${pids[@]}"; pids=(); fi
done
[ ${#pids[@]} -gt 0 ] && wait "${pids[@]}"
cd "$ROOT/code" && $PY - "$EV" <<'PY'
import json, sys, glob, os
ev = sys.argv[1]; rows = []
def order(p):
    b = os.path.basename(p)
    return 0 if b == "step0" else (int(b.split("-", 1)[1]) if b.startswith("checkpoint-") and b.split("-", 1)[1].isdigit() else 10**9)
for d in sorted([p for p in glob.glob(os.path.join(ev, "*")) if os.path.isdir(p)], key=order):
    r = {"tag": os.path.basename(d)}
    for s in glob.glob(os.path.join(d, "*", "summary.json")):
        j = json.load(open(s)); name = os.path.basename(os.path.dirname(s))
        r[name] = {k: round(v, 4) for k, v in j.items() if k.startswith("pass@") or k == "attempt_pass_rate"}
    rows.append(r)
json.dump(rows, open(os.path.join(ev, "eval_curve.json"), "w"), indent=1); print(json.dumps(rows, indent=1))
PY
if [ "${KEEP_CKPTS:-0}" != 1 ] && [ ${#CKS[@]} -gt 1 ]; then
  for c in "${CKS[@]::${#CKS[@]}-1}"; do
    t=$(basename "$c"); n=$(ls "$EV/$t"/*/summary.json 2>/dev/null | wc -l)
    if [ "$n" -ge 3 ]; then rm -rf "$c"; echo "deleted $t (evaluated)"; else echo "KEPT $t: only $n/3 eval summaries"; fi
  done
fi
echo "EVAL_DONE $RUN_ID"
