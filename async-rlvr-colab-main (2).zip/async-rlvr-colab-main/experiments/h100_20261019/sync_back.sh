#!/usr/bin/env bash
# Pack what we need back (aggregates and event logs only; no checkpoints, no generations): events.jsonl, learner/scheduler/
# verifier events, admission/governor logs, manifests, stdout, tensorboard, eval summaries + attempts. ~50-200 MB per run.
# usage: sync_back.sh RUN_ID   -> <ROOT>/outbox/<RUN_ID>.tgz
set -euo pipefail
RUN_ID="$1"; ROOT="${ROOT:-/root/ec}"; R="$ROOT/runs/$RUN_ID"; OUT="$ROOT/outbox"; mkdir -p "$OUT"
T="$R/train"
tar -czf "$OUT/$RUN_ID.tgz" -C "$ROOT/runs" \
  --exclude='*/generations*' --exclude='*/checkpoints/*' --exclude='*/issues/*' --exclude='*.safetensors' --exclude='*.bin' \
  "$RUN_ID/eval" "$(basename "$(readlink -f "$T")")/output" "$(basename "$(readlink -f "$T")")/manifest.json" "$(basename "$(readlink -f "$T")")/launch_env.txt" "$(basename "$(readlink -f "$T")")/stdout.log" 2>/dev/null || true
ls -la "$OUT/$RUN_ID.tgz"; echo "SYNC_READY $OUT/$RUN_ID.tgz"
