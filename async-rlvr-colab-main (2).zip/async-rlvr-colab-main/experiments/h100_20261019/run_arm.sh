#!/usr/bin/env bash
# H100 handoff runner (2026-10-19). One arm = train (fixed operating point) -> evaluate every saved checkpoint -> pack aggregates.
# usage: run_arm.sh DOMAIN ARM STEPS [SUFFIX]
#   DOMAIN: rtl (SALV-7B + CodeV-R1 salv_direct) | rtl_earl (EARL-SFT + CodeV-R1 plain) | lean (DSP-V1.5-SFT + Pset/V1 pool)
#   ARM:    barrier_r2 | decoupled_eta2 | decoupled_eta2_ctrl[_dyn|_post|_rel] | decoupled_eta2_hsel[_skip] | decoupled_eta2_full[_rel]
#           | decoupled_eta2_sel (top-k selector, visit budget, const price) | decoupled_eta2_full2 (dynamic price shared by
#           selector and controller, partial release, no min_obs guard)  -- the 2026-10-25 Stage-2 design
#           ctrl = group-level verification controller (const / dynamic price / posterior rule), hsel = history selector
#           (weighted / skip), full = ctrl(const) + hsel(skip). Controller arms read RTL_CTRL_TABLES (default
#           <ROOT>/assets/ctrl_tables/<domain>.json, fit with applications/rtl/fit_controller_tables.py).
# Fixed operating point (operating-point-selection-logic 2026-10-18): B=32 x G=8 = 256 samples/step, 2 updates/step
# (128 samples each), tau fixed by the verifier (EQY 180 s / Lean 300 s), N = 32 EQY workers / 8 Lean REPLs,
# lr 1e-6 (RTL) / 2e-6 (Lean), clip 0.2/0.28, KL 0, T=1.0. Checkpoints every 100 steps (HF format), kept until evaluated.
set -euo pipefail
DOMAIN="$1"; ARM="$2"; STEPS="$3"; SUFFIX="${4:-}"
HERE="$(cd "$(dirname "$0")" && pwd)"
export ROOT="${ROOT:-/root/ec}"                      # <ROOT>/code = this repo, <ROOT>/assets, <ROOT>/runs, <ROOT>/logs
export VENV="${VENV:-/opt/venvs/async-rlvr}"
export OSS_CAD_DIR="${OSS_CAD_DIR:-/opt/oss-cad-suite}"
export RTL_NUM_GPUS="${RTL_NUM_GPUS:-8}" RTL_TRAIN_GPUS="${RTL_TRAIN_GPUS:-4}" RTL_FSDP_SIZE="${RTL_FSDP_SIZE:-4}" RTL_OFFLOAD="${RTL_OFFLOAD:-false}"
export RTL_ROLLOUT_B="${RTL_ROLLOUT_B:-32}" RTL_GROUP_G="${RTL_GROUP_G:-8}" RTL_GRAD_ACCUM="${RTL_GRAD_ACCUM:-32}"
export RTL_SAVE_STEPS="${RTL_SAVE_STEPS:-100}" RTL_SAVE_LAST=true RTL_TRAIN_OMP_THREADS="${RTL_TRAIN_OMP_THREADS:-32}"
export HF_HOME="${HF_HOME:-$ROOT/hf}" HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-$ROOT/env/hf_datasets}"
# metrics: Weights & Biases by default (ROLL's WandbTracker, same metrics as tensorboard, which is still written under
# output/). The key below is the author's (2026-10-25); RTL_TRACK_WITH=tensorboard turns wandb off. If api.wandb.ai is
# unreachable from this node the run goes WANDB_MODE=offline automatically (synced later from output/wandb/).
export RTL_TRACK_WITH="${RTL_TRACK_WITH:-wandb}" WANDB_PROJECT="${WANDB_PROJECT:-async-rlvr-stage2}"
export WANDB_API_KEY="${WANDB_API_KEY:-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}"
if [ -z "${WANDB_MODE:-}" ] && [ "$RTL_TRACK_WITH" = wandb ]; then
  if curl -sS -m 10 -o /dev/null https://api.wandb.ai/ 2>/dev/null; then export WANDB_MODE=online; else export WANDB_MODE=offline; echo "wandb: api.wandb.ai unreachable, WANDB_MODE=offline"; fi
fi
export WANDB_MODE="${WANDB_MODE:-online}"
# never let the tracker take a run down: if wandb (or what its install dragged in) does not import, use tensorboard
if [ "$RTL_TRACK_WITH" = wandb ] && ! "$VENV/bin/python" -c "import wandb, vllm, roll" >/dev/null 2>&1; then
  echo "WANDB_IMPORT_FAIL: tracking with tensorboard"; export RTL_TRACK_WITH=tensorboard
fi
# EQY work dirs and Ray tmp under ROOT (NVMe), not /tmp: the Stage-1 node's 97 GB system disk filled up at step 49 (2026-10-23)
export RTL_TMP_ROOT="${RTL_TMP_ROOT:-$ROOT/tmp}"; mkdir -p "$RTL_TMP_ROOT"
# Ray's AF_UNIX socket paths are limited to 107 bytes: the Ray tmp root must stay short (<= 29 chars), so it only moves off
# /tmp when ROOT itself is short; otherwise Ray keeps /tmp (small, cleaned per run by the launcher).
if [ -z "${RTL_RAY_TMP_ROOT:-}" ] && [ "${#ROOT}" -le 25 ]; then export RTL_RAY_TMP_ROOT="$ROOT/tmp"; fi
[ -n "${RTL_RAY_TMP_ROOT:-}" ] && mkdir -p "$RTL_RAY_TMP_ROOT"
export RTL_GPU_DESC="${RTL_GPU_DESC:-$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | sort | uniq -c | tr -s " " | tr "\n" ";")}"
case "$ARM" in barrier_r2|barrier_dapo|decoupled_eta2|decoupled_eta2_ctrl|decoupled_eta2_ctrl_dyn|decoupled_eta2_ctrl_post|decoupled_eta2_hsel|decoupled_eta2_hsel_skip|decoupled_eta2_hsel_prior|decoupled_eta2_full|decoupled_eta2_sel|decoupled_eta2_full2|decoupled_eta2_ctrl_rel|decoupled_eta2_full_rel) ;; *) echo "arm $ARM not in this package" >&2; exit 2 ;; esac
RUN_ID="h100_${DOMAIN}_${ARM}${SUFFIX}"
# checkpoints: local by default; CKPT_ROOT=<other fs> (e.g. a large network volume) when the local disk cannot hold
# the fp32 checkpoint twice (the trainer writes it under output/ first, the uploader copies it to RTL_CKPT_DIR).
export RTL_CKPT_DIR="${CKPT_ROOT:-$ROOT/runs}/$RUN_ID/checkpoints"
mkdir -p "$ROOT/runs/$RUN_ID" "$ROOT/logs" "$RTL_CKPT_DIR"
[ -n "${CKPT_ROOT:-}" ] && ln -sfn "$RTL_CKPT_DIR" "$ROOT/runs/$RUN_ID/checkpoints"
# never start on GPUs still held by the previous run's evaluation (10-26: a leftover vLLM held 74 GB on GPU 0 and the next
# run died at start-up): wait until every GPU is below 2 GB, up to 20 min, then kill what is left and go on
for i in $(seq 1 120); do
  busy=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits 2>/dev/null | awk '$1 > 2000 {n++} END {print n+0}')
  [ "$busy" -eq 0 ] && break
  [ "$i" -eq 1 ] && echo "GPUS_BUSY $busy GPU(s) still hold memory, waiting"
  sleep 10
done
[ "${busy:-0}" -ne 0 ] && { echo "GPUS_STILL_BUSY after 20 min: killing leftover python/vllm processes"; pkill -9 -f "vllm|ray::|roll\." 2>/dev/null || true; sleep 15; }
case "$DOMAIN" in
  rtl|rtl_earl)
    export RTL_VERIFY_WORKERS="${RTL_VERIFY_WORKERS:-32}" RTL_EQY_TIMEOUT_S="${RTL_EQY_TIMEOUT_S:-180}" RTL_LR="${RTL_LR:-1.0e-06}"
    export RTL_CONFIG_NAME=salv_2gpu
    if [ "$DOMAIN" = rtl_earl ]; then
      export SALV_MODEL_PATH="${EARL_MODEL_PATH:-$ROOT/assets/earl-sft-deepseek7b}" SALV_DATA_PATH="$ROOT/assets/data/plain/train.jsonl"
    else
      export SALV_MODEL_PATH="${SALV_MODEL_PATH:-$ROOT/assets/salv-7b}" SALV_DATA_PATH="$ROOT/assets/data/salv_direct/train.jsonl"
    fi
    bash "$ROOT/code/experiments/ec/run_ec_arm.sh" "$ARM" "$STEPS" "${SUFFIX}" 2>&1 | tee "$ROOT/logs/$RUN_ID.launch.log"
    TRAIN_RUN="ec_${ARM}${SUFFIX}" ;;
  lean)
    export LEAN_VERIFY_WORKERS="${LEAN_VERIFY_WORKERS:-8}" LEAN_TIMEOUT_S=300 LEAN_MEM_LIMIT_GB=32 LEAN_REPL_RECYCLE=100 RTL_LR="${RTL_LR:-2.0e-06}"
    export LEAN_MODEL_PATH="${LEAN_MODEL_PATH:-$ROOT/assets/dsp15-sft}" LEAN_DATA_PATH="${LEAN_DATA_PATH:-$ROOT/assets/data/lean/train_pset_v1_mixed.jsonl}"
    export LEAN_WORKSPACE="${LEAN_WORKSPACE:-$ROOT/lean/Goedel-Prover-V2/mathlib4}"
    bash "$ROOT/code/experiments/lean/run_lean_arm.sh" "$ARM" "$STEPS" "${SUFFIX}" 2>&1 | tee "$ROOT/logs/$RUN_ID.launch.log"
    TRAIN_RUN="lean_${ARM}${SUFFIX}" ;;
  *) echo "unknown domain $DOMAIN" >&2; exit 2 ;;
esac
# the underlying runners write runs/<TRAIN_RUN>; link it under the handoff id so sync_back finds everything in one place
ln -sfn "$ROOT/runs/$TRAIN_RUN" "$ROOT/runs/$RUN_ID/train"
bash "$HERE/eval_ckpt.sh" "$DOMAIN" "$RUN_ID" 2>&1 | tee -a "$ROOT/logs/$RUN_ID.launch.log"
bash "$HERE/sync_back.sh" "$RUN_ID" 2>&1 | tee -a "$ROOT/logs/$RUN_ID.launch.log"
echo "H100_ARM_DONE $RUN_ID"
