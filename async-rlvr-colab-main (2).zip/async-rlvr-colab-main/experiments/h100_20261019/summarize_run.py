#!/usr/bin/env python3
"""Compact text report for one handoff run, meant to be pasted back through an agent (no file transfer needed).

usage: python experiments/h100_20261019/summarize_run.py <ROOT>/runs/<run_id> [--workers N]
Prints: manifest status + steps, the E-C steady-state metrics table (experiments/ec/analyze_ec.py: step_s,
informative groups/h, staleness, verifier busy, verification-time percentiles, cancellations), the evaluation curve
(pass@k per checkpoint) and the reward/informative-fraction trajectory per 50 steps. Everything stays on disk.
"""
from __future__ import annotations

import argparse
import collections
import json
import os
import subprocess
import sys
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("run", type=Path)
    ap.add_argument("--workers", type=int, default=None)
    a = ap.parse_args()
    run = a.run
    train = (run / "train").resolve() if (run / "train").exists() else run
    print(f"# {run.name}")
    man = train / "manifest.json"
    if man.exists():
        m = json.load(open(man))
        print("manifest:", {k: m.get(k) for k in ("status", "exit_code", "max_steps", "consumption_mode", "async_generation_ratio",
                                                  "verify_workers", "rollout_batch_size", "group_size", "start_utc", "end_utc")})
    env = {}
    le = train / "launch_env.txt"
    if le.exists():
        env = dict(l.rstrip("\n").split("=", 1) for l in open(le) if "=" in l)
    workers = a.workers or int(env.get("RTL_VERIFY_WORKERS") or env.get("LEAN_VERIFY_WORKERS") or 0) or None
    code = Path(__file__).resolve().parents[2]
    cmd = [sys.executable, str(code / "experiments/ec/analyze_ec.py"), str(train)] + (["--workers", str(workers)] if workers else [])
    print("\n## steady-state metrics (analyze_ec.py, warmup 5)")
    try:
        print(subprocess.run(cmd, capture_output=True, text=True, timeout=600, cwd=code).stdout.strip())
    except Exception as e:  # noqa: BLE001
        print("analyze_ec failed:", e)
    ev = train / "output" / "events.jsonl"
    if ev.exists():
        per = collections.defaultdict(lambda: [0, 0, 0.0])
        for line in open(ev, errors="ignore"):
            try:
                e = json.loads(line)
            except Exception:
                continue
            if e.get("event") == "prompt_commit" and e.get("rewards"):
                b = int(e.get("sampling_start_step", 0)) // 50 * 50
                per[b][0] += 1
                per[b][1] += len(set(e["rewards"])) > 1
                per[b][2] += sum(e["rewards"]) / len(e["rewards"])
        print("\n## training trajectory per 50 steps: groups committed | informative fraction | mean reward")
        for b in sorted(per):
            n, inf, r = per[b]
            print(f"  steps {b:4d}-{b + 49:4d}: {n:5d} | {inf / n:.2f} | {r / n:.3f}")
    curve = run / "eval" / "eval_curve.json"
    if curve.exists():
        print("\n## evaluation curve (eval/eval_curve.json)")
        for row in json.load(open(curve)):
            print(" ", json.dumps(row))
    else:
        print("\n(no eval_curve.json yet)")
    print("\nfiles kept on disk:", train / "output", "|", run / "eval", "|", run / "checkpoints")


if __name__ == "__main__":
    main()
