#!/usr/bin/env bash
# One-time setup on the 8xH100 node for the 2026-10-19 handoff. Idempotent. Assumes the E-C rerun environment exists:
# the repo at <ROOT>/code (this branch), the ROLL venv at $VENV, oss-cad-suite (EQY) at $OSS_CAD_DIR, SALV-7B and the
# CodeV-R1 salv_direct data under <ROOT>/assets (from experiments/ec/pod_assets.sh). Adds: Lean toolchain + Mathlib REPL,
# DeepSeek-Prover-V1.5-SFT, Lean prompts, cocotb venv + CVDP + VerilogEval-v2 benchmark files, EARL-SFT (optional).
set -euo pipefail
export ROOT="${ROOT:-/root/ec}" VENV="${VENV:-/opt/venvs/async-rlvr}" HF_HOME="${HF_HOME:-$ROOT/hf}"
export PATH="$HOME/.elan/bin:$HOME/.local/bin:$PATH"
PY="$VENV/bin/python"; A="$ROOT/assets"; mkdir -p "$A/data/lean" "$A/bench/cvdp" "$ROOT/env" "$ROOT/lean" "$ROOT/tmp" "$ROOT/outbox" "$HF_HOME"
command -v uv >/dev/null || curl -LsSf https://astral.sh/uv/install.sh | sh
uv pip install --python "$PY" "pyarrow==19.0.1" >/dev/null                      # datasets needs pyarrow built for NumPy 2
# ---- Lean 4.9.0-rc1 + Goedel-Prover-V2's Mathlib workspace (REPL is a lake dependency: xinhjBrant/repl @ deepseek)
[ -x "$HOME/.elan/bin/elan" ] || { curl -fsSL https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh -o /tmp/elan-init.sh && sh /tmp/elan-init.sh -y --default-toolchain none; }
elan toolchain install leanprover/lean4:v4.9.0-rc1 2>&1 | tail -1
if [ ! -d "$ROOT/lean/Goedel-Prover-V2" ]; then git clone -q https://github.com/Goedel-LM/Goedel-Prover-V2.git "$ROOT/lean/Goedel-Prover-V2"; fi
git -C "$ROOT/lean/Goedel-Prover-V2" checkout -q 2e9036e
# mathlib4 is a submodule (xinhjBrant fork @2f65ba7f). The fork is not in the upstream olean cache (cache get downloads
# 0 files), so Mathlib is built from source: tens of minutes on a large CPU node, a no-op once built.
git -C "$ROOT/lean/Goedel-Prover-V2" submodule update --init -q mathlib4
( cd "$ROOT/lean/Goedel-Prover-V2/mathlib4" && { lake exe cache get 2>&1 | tail -2; lake build 2>&1 | tail -2; lake build REPL 2>&1 | tail -2; lake exe repl < /dev/null >/dev/null 2>&1; } || true )
export LEAN_WORKSPACE="$ROOT/lean/Goedel-Prover-V2/mathlib4"
# ---- models + Lean data
[ -d "$ROOT/lean/dsp15" ] || git clone -q --depth 1 https://github.com/deepseek-ai/DeepSeek-Prover-V1.5.git "$ROOT/lean/dsp15"
"$PY" - <<'PYEOF'
import os, json
from huggingface_hub import snapshot_download
A = os.environ["ROOT"] + "/assets"
d = A + "/dsp15-sft"
snapshot_download('deepseek-ai/DeepSeek-Prover-V1.5-SFT', local_dir=d, allow_patterns=['*.safetensors', '*.json', '*.txt', '*.py'], max_workers=8)
p = d + "/tokenizer_config.json"; tc = json.load(open(p))
if not tc.get("pad_token"):
    eos = tc["eos_token"]["content"] if isinstance(tc["eos_token"], dict) else tc["eos_token"]
    tc["pad_token"] = eos; json.dump(tc, open(p, "w"), indent=2, ensure_ascii=False); print("pad_token set to eos")
if os.environ.get("WITH_EARL") == "1":   # second RTL start (private HF repo: needs HF_TOKEN)
    snapshot_download('Carolineshi/origen-deepseek7b-run-20250803_172955', local_dir=A + "/earl-sft-deepseek7b", allow_patterns=['*.safetensors', '*.json', '*.txt', '*.py'], max_workers=8)
print("MODELS_OK")
PYEOF
cp "$ROOT/code/experiments/h100_20261019/data/train_pset_v1_mixed.jsonl" "$A/data/lean/"
( cd "$ROOT/code" && PYTHONPATH="$ROOT/code" "$PY" applications/lean/prepare_lean_dataset.py --source minif2f --src "$ROOT/lean/dsp15/datasets/minif2f.jsonl" --split test --dst "$A/data/lean/minif2f_test.jsonl" )
# ProofNet-test (186 undergraduate statements; the second eval set of the DeepSeek-Prover-V1.5 paper), same jsonl schema as miniF2F
PN="$ROOT/lean/dsp15/datasets/proofnet.jsonl"; [ -s "$PN" ] || PN="$ROOT/code/experiments/h100_20261019/data/proofnet.jsonl"
( cd "$ROOT/code" && PYTHONPATH="$ROOT/code" "$PY" applications/lean/prepare_lean_dataset.py --source minif2f --src "$PN" --split test --dst "$A/data/lean/proofnet_test.jsonl" )
# ---- RTL: EARL-SFT prompts (plain protocol) if the second start is wanted; SALV data already exists from E-C
if [ "${WITH_EARL:-0}" = 1 ] && [ ! -s "$A/data/plain/train.jsonl" ]; then
  ( cd "$ROOT/code" && PYTHONPATH="$ROOT/code" "$PY" applications/rtl/prepare_codev_dataset.py --src "$A/codev-r1-dataset/codev_r1_rl_train.parquet" --protocol plain --dst "$A/data/plain/train.jsonl" ) || echo "plain-protocol prep failed; see applications/rtl/prepare_codev_dataset.py --help"
fi
# ---- evaluation: cocotb venv (CVDP harness, no Docker) + CVDP v1.1.0 + VerilogEval v2 spec-to-rtl
[ -x "$ROOT/env/cvdp-venv/bin/python" ] || uv venv --python 3.11 "$ROOT/env/cvdp-venv"
uv pip install --python "$ROOT/env/cvdp-venv/bin/python" "cocotb==2.0.1" pytest pyyaml >/dev/null
# cocotb's VPI library dlopens this venv's libpython inside oss-cad-suite's own loader (bundled glibc 2.35, --library-path
# restricted to its lib/). A python-build-standalone libpython also NEEDs librt.so.1 / libutil.so.1, which glibc >= 2.34
# folded into libc and the bundle does not ship -> every CVDP test dies with "librt.so.1: cannot open shared object file"
# (ORCD Rocky 8 + uv python 3.11, 2026-10-20). Empty stubs with the right soname satisfy the loader.
OSS="${OSS_CAD_DIR:-/opt/oss-cad-suite}"
LIBPY="$("$ROOT/env/cvdp-venv/bin/python" -c 'import os, sysconfig; print(os.path.join(sysconfig.get_config_var("LIBDIR"), sysconfig.get_config_var("INSTSONAME")))')"
if [ -f "$LIBPY" ] && [ -d "$OSS/lib" ] && command -v readelf >/dev/null && command -v gcc >/dev/null; then
  for n in $(readelf -d "$LIBPY" | awk '/NEEDED/{gsub(/[][]/,"",$5); print $5}'); do
    if [ ! -e "$OSS/lib/$n" ]; then echo "" | gcc -shared -o "$OSS/lib/$n" -Wl,-soname,"$n" -x c - && echo "oss-cad-suite: stub $OSS/lib/$n for cocotb"; fi
  done
fi
f=cvdp_v1.1.0_nonagentic_code_generation_no_commercial.jsonl
[ -s "$A/bench/cvdp/$f" ] || curl -sL -o "$A/bench/cvdp/$f" "https://huggingface.co/datasets/nvidia/cvdp-benchmark-dataset/resolve/main/$f"
if [ ! -d "$A/bench/VerilogEval_v2.0.0/dataset_spec-to-rtl" ]; then
  git clone -q --depth 1 https://github.com/NVlabs/verilog-eval.git "$ROOT/tmp/verilog-eval" && mkdir -p "$A/bench/VerilogEval_v2.0.0" && cp -r "$ROOT/tmp/verilog-eval/dataset_spec-to-rtl" "$A/bench/VerilogEval_v2.0.0/"
fi
# ---- checks
( cd "$ROOT/code" && PYTHONPATH="$ROOT/code" "$PY" - <<'PYEOF'
import os
from pathlib import Path
from applications.lean.lean_repl import LeanRepl
r = LeanRepl(os.environ["LEAN_WORKSPACE"], mem_limit_gb=16); s = r.start(); ok = s.is_pass and r.run("theorem t1 : (2:ℕ) + 2 = 4 := by norm_num", 120).is_pass; r.kill()
print("LEAN_REPL_OK" if ok else f"LEAN_REPL_FAIL {s.detail[:200]}")
from applications.rtl.ve2_eval import judge_sample
ds = Path(os.environ["ROOT"] + "/assets/bench/VerilogEval_v2.0.0/dataset_spec-to-rtl")
ref = (ds / "Prob001_zero_ref.sv").read_text().replace("module RefModule", "module TopModule")
print("VE2_JUDGE", judge_sample(Path(os.environ["ROOT"] + "/tmp/ve2_check"), "Prob001_zero", ds, ref, os.environ.get("OSS_CAD_DIR", "/opt/oss-cad-suite") + "/bin"))
PYEOF
)
# wandb into the venv WITHOUT letting it upgrade protobuf / opentelemetry (vLLM 0.8.4's otlp exporter needs 1.26.0; an
# unpinned install broke ROLL at import on the 10-27 pod). uv venvs have no pip module: use uv when pip is absent.
if "$PY" -m pip --version >/dev/null 2>&1; then PIPI="$PY -m pip install -q"; else PIPI="uv pip install -q --python $PY"; fi
$PIPI "wandb==0.28.0" "protobuf==4.25.9" opentelemetry-api==1.26.0 opentelemetry-sdk==1.26.0 opentelemetry-proto==1.26.0 \
  opentelemetry-exporter-otlp==1.26.0 opentelemetry-exporter-otlp-proto-grpc==1.26.0 opentelemetry-exporter-otlp-proto-http==1.26.0 \
  opentelemetry-exporter-otlp-proto-common==1.26.0 2>&1 | tail -n 2
"$PY" -c "import wandb, vllm, roll; print('WANDB_OK', wandb.__version__)" || echo "WANDB_IMPORT_FAIL (run_arm.sh will fall back to tensorboard)"
# controller tables fitted on the Stage-1 H100 runs (research/h100_replay_20261024, early window, tau 180 / 300)
mkdir -p "$ROOT/assets/ctrl_tables"
cp "$ROOT/code/experiments/h100_20261019/tables/rtl_h100_tau180.json" "$ROOT/assets/ctrl_tables/rtl.json"
cp "$ROOT/code/experiments/h100_20261019/tables/lean_h100_tau300.json" "$ROOT/assets/ctrl_tables/lean.json"
echo "CTRL_TABLES_OK $(ls "$ROOT/assets/ctrl_tables")"
echo "H100_SETUP_DONE  (ROOT=$ROOT  LEAN_WORKSPACE=$LEAN_WORKSPACE)"
