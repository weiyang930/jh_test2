# Shared environment for ORCD Engaging (sourced by setup_orcd.sh and the *.sbatch files in this directory).
# ROOT holds code/ (this repo), assets/, env/ (venv, oss-cad-suite, caches), runs/, logs/, outbox/; scratch quota is 1 TB.
export ROOT="${ROOT:-$HOME/orcd/scratch/ec}"
export VENV="${VENV:-$ROOT/env/venv}" OSS_CAD_DIR="${OSS_CAD_DIR:-$ROOT/env/oss-cad-suite}" HF_HOME="${HF_HOME:-$ROOT/hf}"
# big caches (uv wheels, Mathlib oleans) on scratch next to the venv, not in the 200 GB home
export UV_CACHE_DIR="${UV_CACHE_DIR:-$ROOT/env/uv-cache}" XDG_CACHE_HOME="${XDG_CACHE_HOME:-$ROOT/env/xdg-cache}"
export PATH="$HOME/.local/bin:$HOME/.elan/bin:$PATH"
# 4xH100: 2 train (FSDP 2) + 2 vLLM; grad accum 64 keeps 128 samples per update = 2 updates per 256-sample step
export RTL_NUM_GPUS=4 RTL_TRAIN_GPUS="${RTL_TRAIN_GPUS:-2}" RTL_FSDP_SIZE="${RTL_FSDP_SIZE:-2}" RTL_GRAD_ACCUM="${RTL_GRAD_ACCUM:-64}"
export RTL_TRAIN_OMP_THREADS="${RTL_TRAIN_OMP_THREADS:-16}"   # only the CPU-offloaded Adam step uses these; EQY needs the rest
# preemptable nodes can also run other users' jobs: give Ray job-unique GCS / dashboard ports instead of 6379 / 8265
if [ -n "${SLURM_JOB_ID:-}" ]; then
  export MASTER_PORT=$((30000 + SLURM_JOB_ID % 10000)) DASHBOARD_PORT=$((40000 + SLURM_JOB_ID % 10000))
  # Ray must see the Slurm allocation, not the node: os.cpu_count() is 240 on the H100x8 nodes and the raylet then
  # prestarts 240 workers (ORCD diag 2026-10-20). RTL's run_blocking_cost.py reads RTL_RAY_NUM_CPUS; Lean's
  # `ray start --head` (roll initialize.py) appends ROLL_RAY_START_ARGS.
  export RTL_RAY_NUM_CPUS="${RTL_RAY_NUM_CPUS:-${SLURM_CPUS_PER_TASK:-64}}"
  # The raylet kills itself if its runtime-env agent (a Python process importing ray.dashboard from the venv on the network
  # scratch FS) is not up within agent_register_timeout_ms (30 s). On a loaded shared node with a cold file cache the agent
  # needs longer -> "Failed to register worker to Raylet" 30 s after ray.init (ORCD 2026-10-20, raylet.err). RAY_<config>
  # env vars set raylet system config.
  export RAY_agent_register_timeout_ms="${RAY_agent_register_timeout_ms:-300000}"
  export ROLL_RAY_START_ARGS="${ROLL_RAY_START_ARGS:---num-cpus=${SLURM_CPUS_PER_TASK:-64}}"
  # worker processes importing torch/vLLM from the network FS can also exceed Ray's 60 s worker_register_timeout_seconds
  # ("Some workers of the worker process have not registered within the timeout", raylet.out, smoke3 2026-10-20)
  export RAY_worker_register_timeout_seconds="${RAY_worker_register_timeout_seconds:-600}"
  [ -n "${RTL_RAY_SYSTEM_CONFIG:-}" ] || RTL_RAY_SYSTEM_CONFIG="{\"agent_register_timeout_ms\": $RAY_agent_register_timeout_ms, \"worker_register_timeout_seconds\": $RAY_worker_register_timeout_seconds}"
  export RTL_RAY_SYSTEM_CONFIG
  export ROLL_RAY_START_ARGS="$ROLL_RAY_START_ARGS --system-config='$RTL_RAY_SYSTEM_CONFIG'"
fi
