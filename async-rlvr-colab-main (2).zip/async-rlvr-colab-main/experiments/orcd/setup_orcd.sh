#!/usr/bin/env bash
# ORCD Engaging install for the h100_20261019 package (2026-10-20), run on a login node: no GPU and a per-user cgroup of
# 4 cores / 10 GB, so this only downloads and installs. Order: uv -> ROLL venv + oss-cad-suite (ec/pod_setup.sh) in
# parallel with SALV-7B + CodeV-R1 (ec/pod_assets.sh) -> Lean toolchain, Mathlib, DSP-V1.5-SFT, eval benchmarks
# (h100_20261019/setup_h100.sh). The GPU kernel / Lean REPL / VerilogEval judge checks at the end of those scripts need
# a compute node and may fail here; smoke_4xh100.sbatch reruns them on the GPU node.
# usage: nohup bash experiments/orcd/setup_orcd.sh > ~/orcd/scratch/ec/logs/setup_orcd.log 2>&1 &
set -uo pipefail
source "$(cd "$(dirname "$0")" && pwd)/orcd_env.sh"
C="$ROOT/code"; L="$ROOT/logs"; mkdir -p "$L" "$ROOT/env" "$UV_CACHE_DIR" "$XDG_CACHE_HOME"
command -v uv >/dev/null || curl -LsSf https://astral.sh/uv/install.sh | sh
uv --version || { echo "ORCD_SETUP_FAIL uv"; exit 1; }

echo "== venv + assets $(date -u +%T)"
bash "$C/experiments/ec/pod_setup.sh" > "$L/setup_orcd_venv.log" 2>&1 &
P1=$!
bash "$C/experiments/ec/pod_assets.sh" > "$L/setup_orcd_assets.log" 2>&1 &
P2=$!
wait $P1; wait $P2
# pod_setup.sh ends with a CUDA kernel check that cannot pass without a GPU; everything before it must have run
grep -q CODEV_TK_OK "$L/setup_orcd_venv.log" || { echo "ORCD_SETUP_FAIL venv"; tail -20 "$L/setup_orcd_venv.log"; exit 1; }
grep -q ASSETS_DONE "$L/setup_orcd_assets.log" || { echo "ORCD_SETUP_FAIL assets"; tail -20 "$L/setup_orcd_assets.log"; exit 1; }
grep -E "SALV_SHA_OK|DATA_SHA_OK" "$L/setup_orcd_assets.log"

echo "== lean + eval $(date -u +%T)"
bash "$C/experiments/h100_20261019/setup_h100.sh" > "$L/setup_orcd_h100.log" 2>&1
grep -q MODELS_OK "$L/setup_orcd_h100.log" || { echo "ORCD_SETUP_FAIL lean/eval"; tail -20 "$L/setup_orcd_h100.log"; exit 1; }
grep -E "LEAN_REPL_|VE2_JUDGE|H100_SETUP_DONE" "$L/setup_orcd_h100.log"
"$VENV/bin/python" -c "import torch, vllm, ray, flash_attn; print('IMPORT_OK torch', torch.__version__, 'vllm', vllm.__version__, 'flash_attn', flash_attn.__version__)"
du -sh "$ROOT/env" "$ROOT/assets" "$ROOT/lean" 2>/dev/null
echo "ORCD_SETUP_DONE $(date -u +%FT%TZ)"
