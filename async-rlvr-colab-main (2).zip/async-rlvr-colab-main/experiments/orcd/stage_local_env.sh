# Stage the ROLL venv on the compute node's local disk (ORCD 2026-10-20): the venv lives on the network scratch FS
# (47k files, 8 GB) and under node load `import torch` alone took minutes, so Ray killed worker processes at its
# registration timeouts. Sourced by the *.sbatch files after orcd_env.sh. Needs the tarballs made on the login node:
#   cd $ROOT/env && tar -cf venv.tar venv && tar -C $HOME/.local/share/uv -cf uvpython.tar python
# A copy already present on the node (same tarball mtime) is reused. Set ORCD_LOCAL_ENV=0 to keep the network venv.
if [ "${ORCD_LOCAL_ENV:-1}" = 1 ] && [ -f "$ROOT/env/venv.tar" ] && [ -f "$ROOT/env/uvpython.tar" ]; then
  LOCAL_ENV="${ORCD_LOCAL_ENV_DIR:-/tmp/$USER/ec_env}"
  STAMP="$(stat -c %Y "$ROOT/env/venv.tar")_$(stat -c %Y "$ROOT/env/uvpython.tar")"
  if [ ! -f "$LOCAL_ENV/.ready_$STAMP" ]; then
    echo "staging venv to $LOCAL_ENV ($(date -u +%T))"
    rm -rf "$LOCAL_ENV"; mkdir -p "$LOCAL_ENV"
    tar -xf "$ROOT/env/venv.tar" -C "$LOCAL_ENV" && tar -xf "$ROOT/env/uvpython.tar" -C "$LOCAL_ENV" || { echo "staging failed, keeping $VENV"; LOCAL_ENV=""; }
    if [ -n "$LOCAL_ENV" ]; then
      # relocate: interpreter symlinks, pyvenv.cfg home, console-script shebangs
      UV_PY_DIR="$(ls -d "$LOCAL_ENV"/python/cpython-3.11.*-linux-x86_64-gnu 2>/dev/null | head -1)"   # the real dir, not the unversioned symlink
      for b in python python3 python3.11; do ln -sfn "$UV_PY_DIR/bin/python3.11" "$LOCAL_ENV/venv/bin/$b"; done
      sed -i "s|^home = .*|home = $UV_PY_DIR/bin|" "$LOCAL_ENV/venv/pyvenv.cfg"
      OLD_VENV="$(sed -n 's|^command = .*\(/[^ ]*/venv\)$|\1|p' "$LOCAL_ENV/venv/pyvenv.cfg" | head -1)"; [ -n "$OLD_VENV" ] || OLD_VENV="$VENV"
      grep -l "^#!$OLD_VENV/bin/python" "$LOCAL_ENV"/venv/bin/* 2>/dev/null | xargs -r sed -i "1s|^#!$OLD_VENV/bin/python.*|#!$LOCAL_ENV/venv/bin/python|"
      touch "$LOCAL_ENV/.ready_$STAMP"; echo "staged ($(date -u +%T))"
    fi
  else
    echo "local venv already staged at $LOCAL_ENV"
  fi
  if [ -n "${LOCAL_ENV:-}" ] && [ -x "$LOCAL_ENV/venv/bin/python" ]; then
    export VENV="$LOCAL_ENV/venv" PATH="$LOCAL_ENV/venv/bin:$PATH"
    "$VENV/bin/python" -c "import sys; print('local venv ok', sys.executable, sys.version.split()[0])"
  fi
fi
