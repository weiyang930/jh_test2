#!/usr/bin/env bash
# Lean RL arm runner (2026-10-18). Same arm vocabulary as experiments/ec/run_ec_arm.sh, on the Lean REPL reward.
# usage: run_lean_arm.sh ARM MAX_STEPS [SUFFIX]      ARM in: barrier_r1 | barrier_r2 | barrier_r4 | decoupled_eta2 | decoupled_eta8
# Defaults are the 2-GPU smoke layout (1 train GPU with CPU offload + 1 vLLM GPU); on a larger node set
# RTL_NUM_GPUS / RTL_TRAIN_GPUS / RTL_FSDP_SIZE / RTL_OFFLOAD. Model, data and the Lean workspace come from LEAN_*.
set -euo pipefail
ARM="$1"; MAX_STEPS="$2"; SUFFIX="${3:-}"
export ROOT="${ROOT:-/root/ec}"
export RTL_NUM_GPUS="${RTL_NUM_GPUS:-2}" RTL_TRAIN_GPUS="${RTL_TRAIN_GPUS:-1}"
export RTL_FSDP_SIZE="${RTL_FSDP_SIZE:-$RTL_TRAIN_GPUS}" RTL_OFFLOAD="${RTL_OFFLOAD:-true}"
export RTL_ROLLOUT_B="${RTL_ROLLOUT_B:-16}" RTL_GROUP_G="${RTL_GROUP_G:-8}"
export LEAN_VERIFY_WORKERS="${LEAN_VERIFY_WORKERS:-32}" LEAN_TIMEOUT_S="${LEAN_TIMEOUT_S:-300}" LEAN_MEM_LIMIT_GB="${LEAN_MEM_LIMIT_GB:-32}"   # RLIMIT_AS; 8 GB gave std::bad_alloc at import inside Ray workers; a runaway REPL reached 14.7 GB RSS
export LEAN_MODEL_PATH="${LEAN_MODEL_PATH:-/workspace/lean_rl/assets/dsp15-sft}"
export LEAN_DATA_PATH="${LEAN_DATA_PATH:-/workspace/lean_rl/data/train.jsonl}"
export LEAN_WORKSPACE="${LEAN_WORKSPACE:-/root/lean/goedel/mathlib4}"
export RTL_SAVE_LAST="${RTL_SAVE_LAST:-false}"
export RTL_CTRL_TABLES="${RTL_CTRL_TABLES:-$ROOT/assets/ctrl_tables/lean.json}"
case "$ARM" in
  barrier_r1)     export RTL_ASYNC_GENERATION_RATIO=1 RTL_CONSUMPTION_MODE=barrier   RTL_VERIFY_MAX_CONCURRENCY=1 ;;
  barrier_r2)     export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=barrier   RTL_VERIFY_MAX_CONCURRENCY=1 ;;
  barrier_dapo)    export RTL_ASYNC_GENERATION_RATIO=0 RTL_CONSUMPTION_MODE=barrier  RTL_VERIFY_MAX_CONCURRENCY=1 RTL_DAPO=true RTL_DAPO_EXTRA="${RTL_DAPO_EXTRA:-32}" RTL_QUERY_FILTER=std_filter RTL_QUERY_FILTER_STD="${RTL_QUERY_FILTER_STD:-1e-4}" ;;
    # ratio 0 = ROLL's native synchronous dynamic sampling: generate until B groups pass the std filter, pause, train. With ratio 2 the
    # extra-prompt lane never pauses and runs unbounded during training (pod 10-28); std of 8 equal float32 rewards is ~6e-8, hence 1e-4.
  barrier_r4)     export RTL_ASYNC_GENERATION_RATIO=4 RTL_CONSUMPTION_MODE=barrier   RTL_VERIFY_MAX_CONCURRENCY=1 ;;
  decoupled_eta2) export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 ;;
  # ---- Stage 2 arms (2026-10-19): group-level controller and/or history selector on top of decoupled eta2
  decoupled_eta2_ctrl)      export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE=const RTL_CTRL_LAMBDA="${RTL_CTRL_LAMBDA:-3.0e-03}" ;;
  decoupled_eta2_ctrl_dyn)  export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE=dynamic RTL_CTRL_KAPPA="${RTL_CTRL_KAPPA:-6e-5}" ;;
  decoupled_eta2_ctrl_post) export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE=posterior ;;
  decoupled_eta2_hsel)      export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE="${RTL_HSEL_MODE:-skip}" ;;
  decoupled_eta2_hsel_skip) export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE=skip ;;
  decoupled_eta2_hsel_prior) export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE=prior ;;   # needs RTL_ADMISSION_PRIOR=<probe summary.json>
  decoupled_eta2_full)      export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE="${RTL_CTRL_MODE:-const}"
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE="${RTL_HSEL_MODE:-skip}" ;;
  # ---- partial release (2026-10-21): controller also releases informative groups at >= 3/4 verified (RTL_CTRL_RELEASE slow|index)
  decoupled_eta2_ctrl_rel)  export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE="${RTL_CTRL_MODE:-const}"
    export RTL_CTRL_RELEASE="${RTL_CTRL_RELEASE:-index}" ;;
  # ---- 2026-10-25 Stage-2 design (research/h100_replay_20261024): top-k selector with a visit budget and one price
  decoupled_eta2_sel)       export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE=topk RTL_ADMISSION_AUDIT="${RTL_ADMISSION_AUDIT:-4}"
    export RTL_ADMISSION_POOL="${RTL_ADMISSION_POOL:-256}" RTL_ADMISSION_BUDGET="${RTL_ADMISSION_BUDGET:-2}" RTL_ADMISSION_WINDOW="${RTL_ADMISSION_WINDOW:-50}" RTL_ADMISSION_TEXT="${RTL_ADMISSION_TEXT:-true}" RTL_ADMISSION_PRICE=shared RTL_ADMISSION_RHO="${RTL_ADMISSION_RHO:-3.0e-03}"
    export RTL_PRICE_TRACKER=true RTL_CTRL_KAPPA="${RTL_CTRL_KAPPA:-6e-5}" ;;   # dynamic price without a controller (rho is only the fallback)
  decoupled_eta2_full2)     export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2
    export RTL_CTRL_MODE="${RTL_CTRL_MODE:-dynamic}" RTL_CTRL_RELEASE="${RTL_CTRL_RELEASE:-expiry}" RTL_CTRL_MIN_OBS="${RTL_CTRL_MIN_OBS:-0}" RTL_CTRL_KAPPA="${RTL_CTRL_KAPPA:-6e-5}" RTL_CTRL_LAMBDA="${RTL_CTRL_LAMBDA:-3.0e-03}"
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE=topk RTL_ADMISSION_AUDIT="${RTL_ADMISSION_AUDIT:-4}"
    export RTL_ADMISSION_POOL="${RTL_ADMISSION_POOL:-256}" RTL_ADMISSION_BUDGET="${RTL_ADMISSION_BUDGET:-2}" RTL_ADMISSION_WINDOW="${RTL_ADMISSION_WINDOW:-50}" RTL_ADMISSION_TEXT="${RTL_ADMISSION_TEXT:-true}" RTL_ADMISSION_PRICE=shared RTL_ADMISSION_RHO="${RTL_ADMISSION_RHO:-3.0e-03}" ;;
  decoupled_eta2_full_rel)  export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE="${RTL_CTRL_MODE:-const}"
    export RTL_CTRL_RELEASE="${RTL_CTRL_RELEASE:-index}"
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE="${RTL_HSEL_MODE:-skip}" ;;
  decoupled_eta8) export RTL_ASYNC_GENERATION_RATIO=8 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 ;;
  *) echo "unknown arm $ARM" >&2; exit 2 ;;
esac
RUN_ID="lean_${ARM}${SUFFIX}"
OUT="$ROOT/runs/$RUN_ID"; mkdir -p "$OUT/output" "$ROOT/logs"
export RUN_ID RTL_RUN_OUTPUT_DIR="$OUT/output" RTL_CKPT_DIR="${RTL_CKPT_DIR:-/workspace/lean_rl/checkpoints/$RUN_ID}"
export RTL_MAX_STEPS="$MAX_STEPS" RTL_SAVE_STEPS="${RTL_SAVE_STEPS:-100000}"
# short: Ray AF_UNIX socket paths are limited to 107 bytes. RTL_RAY_TMP_ROOT (<= 29 chars) keeps Ray off the root disk.
if [ -n "${RTL_RAY_TMP_ROOT:-}" ]; then export RAY_TMPDIR="$RTL_RAY_TMP_ROOT/$(printf %s "$RUN_ID" | md5sum | cut -c1-6)"
else export RAY_TMPDIR="/tmp/ray_$(printf %s "$RUN_ID" | md5sum | cut -c1-8)"; fi
export PYTHONPATH="$ROOT/code"
export VLLM_USE_V1=1 HF_HOME="${HF_HOME:-/workspace/hf}"   # (was swallowed by a trailing comment until 2026-10-25)
export HF_DATASETS_CACHE="${HF_DATASETS_CACHE:-$ROOT/env/hf_datasets}"   # datasets.map chmods its cache files; geesefs volumes refuse chmod
mkdir -p "$HF_DATASETS_CACHE"
export PATH="${VENV:-/opt/venvs/async-rlvr}/bin:$HOME/.elan/bin:/root/.elan/bin:$PATH"   # roll.distributed.scheduler.initialize shells out to `ray start`
mkdir -p "$RAY_TMPDIR" "$RTL_CKPT_DIR"
env | grep -E '^(RUN_ID|RTL_|LEAN_|RAY_TMPDIR)' | sort > "$OUT/launch_env.txt"
cat > "$OUT/manifest.json" <<JSON
{"run_id": "$RUN_ID", "start_utc": "$(date -u +%FT%TZ)", "arm": "$ARM", "model": "$LEAN_MODEL_PATH", "data": "$LEAN_DATA_PATH",
 "config": "experiments/configs/lean_async_2gpu.yaml", "max_steps": $MAX_STEPS, "consumption_mode": "$RTL_CONSUMPTION_MODE",
 "async_generation_ratio": $RTL_ASYNC_GENERATION_RATIO, "verify_workers": $LEAN_VERIFY_WORKERS, "lean_timeout_s": $LEAN_TIMEOUT_S,
 "rollout_batch_size": $RTL_ROLLOUT_B, "group_size": $RTL_GROUP_G, "gpus": "$(nvidia-smi --query-gpu=name --format=csv,noheader | sort | uniq -c | tr -s ' ' | tr '\n' ';')",
 "status": "running"}
JSON
cd "$ROOT/code"
set +e
"${VENV:-/opt/venvs/async-rlvr}/bin/python" examples/start_rlvr_pipeline.py --config_path ../experiments/configs --config_name lean_async_2gpu > "$OUT/stdout.log" 2>&1
CODE=$?
set -e
python3 - "$OUT/manifest.json" "$CODE" <<'PY'
import json, sys, datetime
p, code = sys.argv[1:]
m = json.load(open(p)); m.update(status='completed' if code == '0' else f'exit_{code}', exit_code=int(code), end_utc=datetime.datetime.utcnow().isoformat() + 'Z')
json.dump(m, open(p, 'w'), indent=2)
PY
# keep the Ray system logs (raylet/gcs/dashboard/*.err) next to stdout.log: on Slurm nodes RAY_TMPDIR is on the node's /tmp
# and is gone with the job, which hid the raylet death behind "Failed to register worker to Raylet" (ORCD 2026-10-20)
# ray.init() puts the session under $RAY_TMPDIR/ray/, `ray start --temp-dir` directly under $RAY_TMPDIR/
RAY_SESSION_LOGS=""; for d in "$RAY_TMPDIR/session_latest/logs" "$RAY_TMPDIR/ray/session_latest/logs"; do [ -d "$d" ] && RAY_SESSION_LOGS="$d"; done
if [ -n "$RAY_SESSION_LOGS" ]; then
  mkdir -p "$OUT/ray_logs" && find -L "$RAY_SESSION_LOGS" -maxdepth 1 -type f \( -name "*.err" -o -name "raylet.out" -o -name "gcs_server.out" -o -name "dashboard*.log" -o -name "monitor.log" -o -name "log_monitor.log" \) -exec cp -p {} "$OUT/ray_logs/" \; 2>/dev/null || true
fi
pkill -9 -f "lake exe repl" 2>/dev/null || true; pkill -9 -x repl 2>/dev/null || true
rm -rf "$RAY_TMPDIR" 2>/dev/null || true
echo "LEAN_ARM_DONE $RUN_ID exit=$CODE"
