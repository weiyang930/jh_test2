#!/usr/bin/env bash
# Lean-side pod bootstrap (2026-10-18), idempotent. Run AFTER experiments/ec/pod_setup.sh (python env) with the repo at
# $ROOT/code. Installs elan + Lean 4.9.0-rc1, downloads DeepSeek-Prover-V1.5-SFT into $LEAN_ASSETS, sets its missing
# pad token (= eos), and expects the Goedel Mathlib snapshot at $LEAN_WORKSPACE/.. (rsync/tar it from the Mac backup
# runpod-backups/sota-repro-2026-09-04/methods/lean_goedel-prover-v2: that Mathlib commit is not rebuildable).
set -euo pipefail
ROOT="${ROOT:-/root/ec}"; export LEAN_ASSETS="${LEAN_ASSETS:-/workspace/lean_rl/assets}"; T="${TOOLS_VENV:-$ROOT/env/tools-venv}"
export PATH="/root/.local/bin:/root/.elan/bin:$PATH" HF_HOME="${HF_HOME:-/workspace/hf}"
mkdir -p "$LEAN_ASSETS" /workspace/lean_rl/data /workspace/lean_rl/probe /workspace/lean_rl/checkpoints /root/lean "$HF_HOME"
# python deps shared with the main env: pyarrow must stay on NumPy 1
uv pip install --python "${VENV:-/opt/venvs/async-rlvr}/bin/python" "pyarrow==19.0.1" >/dev/null 2>&1 || true
[ -x "$T/bin/python" ] || { uv venv --python 3.11 "$T"; uv pip install --python "$T/bin/python" huggingface-hub==0.36.2 pandas pyarrow==19.0.1; }
# Lean toolchain
if [ ! -x /root/.elan/bin/elan ]; then
  curl -fsSL https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh -o /root/lean/elan-init.sh && sh /root/lean/elan-init.sh -y --default-toolchain none
fi
elan toolchain install leanprover/lean4:v4.9.0-rc1 2>&1 | tail -1
# DeepSeek-Prover repo (miniF2F file, reference verifier) and model
[ -d /root/lean/dsp15 ] || git clone -q --depth 1 https://github.com/deepseek-ai/DeepSeek-Prover-V1.5.git /root/lean/dsp15
"$T/bin/python" - <<'PY'
import os, json
from huggingface_hub import snapshot_download
d = os.environ["LEAN_ASSETS"] + "/dsp15-sft"
snapshot_download('deepseek-ai/DeepSeek-Prover-V1.5-SFT', local_dir=d, allow_patterns=['*.safetensors', '*.json', '*.txt', '*.py'], max_workers=8)
p = d + "/tokenizer_config.json"; tc = json.load(open(p))
if not tc.get("pad_token"):   # DeepSeek-Prover has only bos/eos; ROLL's collator needs a pad id
    eos = tc["eos_token"]["content"] if isinstance(tc["eos_token"], dict) else tc["eos_token"]
    tc["pad_token"] = eos; json.dump(tc, open(p, "w"), indent=2, ensure_ascii=False); print("pad_token set to eos")
print("DSP_SFT_OK", d)
PY
echo "LEAN_POD_SETUP_DONE (Mathlib snapshot expected at ${LEAN_WORKSPACE:-/root/lean/goedel/mathlib4}; prompts at /workspace/lean_rl/data)"
