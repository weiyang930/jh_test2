#!/usr/bin/env bash
# Local-side orchestrator for E-C (run on the Mac, not the pod).
# Per arm: launch on the pod (or re-attach if already launched), wait for EC_ARM_DONE, stage the final checkpoint on the
# pod's network volume (fast, local DC), delete the pod-local copies so the 100 GB disk is free, launch the NEXT arm
# immediately, and pull the staged checkpoint to the Mac in the background (the Mac link is ~10 MB/s, ~50 min per 29 GB).
# The volume copy is deleted only after the Mac copy holds every shard with matching sizes (ARCHIVED marker written).
# Resumable: arms with runs/<id>/ARCHIVED are skipped; arms whose pod log exists are not relaunched.
# usage: ec_orchestrate.sh MAX_STEPS ARM [ARM ...]
set -uo pipefail
MAX_STEPS="$1"; shift
POD_HOST="${POD_HOST:-154.54.102.47}"; POD_PORT="${POD_PORT:-12827}"
POD_SSH=(ssh -o ServerAliveInterval=30 -p "$POD_PORT" -i "$HOME/.ssh/id_ed25519" "root@$POD_HOST")
RSYNC_SSH="ssh -p $POD_PORT -i $HOME/.ssh/id_ed25519"
LOCAL="${LOCAL_ARCHIVE:-$HOME/Desktop/MIT/async-rlvr/runpod-backups/ec-20260930}"
VOLROOT=/workspace/ec-20260930/checkpoints
mkdir -p "$LOCAL/runs" "$LOCAL/logs"
log() { echo "[$(date -u +%FT%TZ)] $*"; }

pull_in_background() {  # volume -> Mac, verify shard list (size + name), then delete the volume copy
  local RUN_ID="$1" VOL="$VOLROOT/$1" DST="$LOCAL/runs/$1/checkpoints"
  (
    for attempt in 1 2 3 4 5; do
      rsync -az -e "$RSYNC_SSH" "root@$POD_HOST:$VOL/" "$DST/" && break
      log "pull $RUN_ID attempt $attempt failed; retrying in 60 s"; sleep 60
    done
    REMOTE_LIST=$("${POD_SSH[@]}" "cd $VOL && find . -name '*.safetensors' -printf '%s %f\n' | sort")
    LOCAL_LIST=$(cd "$DST" && find . -name '*.safetensors' -exec stat -f '%z %N' {} \; | sed 's#.*/##' | sort)
    N=$(echo "$REMOTE_LIST" | grep -c safetensors)
    if [ "$N" -ge 7 ] && [ "$REMOTE_LIST" = "$LOCAL_LIST" ]; then
      "${POD_SSH[@]}" "rm -rf $VOL"
      date -u +%FT%TZ > "$LOCAL/runs/$RUN_ID/ARCHIVED"
      log "ARCHIVED $RUN_ID: $N shards on the Mac match the volume; volume copy deleted"
    else
      log "WARNING: $RUN_ID shard mismatch (remote $N); volume copy kept. remote=[$REMOTE_LIST] local=[$LOCAL_LIST]"
    fi
  ) > "$LOCAL/logs/pull_$RUN_ID.log" 2>&1 &
  log "background pull of $RUN_ID started (log: logs/pull_$RUN_ID.log)"
}

for ARM in "$@"; do
  RUN_ID="ec_${ARM}"
  if [ -f "$LOCAL/runs/$RUN_ID/ARCHIVED" ]; then log "$RUN_ID already archived; skipping"; continue; fi
  if "${POD_SSH[@]}" "test -f /root/ec/logs/$RUN_ID.log"; then
    log "$RUN_ID already launched on the pod; resuming wait"
  else
    log "launching $RUN_ID ($MAX_STEPS steps)"
    "${POD_SSH[@]}" "cd /root/ec/code && (setsid nohup bash experiments/ec/run_ec_arm.sh $ARM $MAX_STEPS > /root/ec/logs/$RUN_ID.log 2>&1 < /dev/null &)"
  fi
  until "${POD_SSH[@]}" "grep -q EC_ARM_DONE /root/ec/logs/$RUN_ID.log 2>/dev/null"; do
    sleep 120
    "${POD_SSH[@]}" "grep -c step_end /root/ec/runs/$RUN_ID/output/learner_events.jsonl 2>/dev/null || true" \
      | sed "s/^/[$(date -u +%H:%M)] $RUN_ID steps done: /"
  done
  log "$RUN_ID finished; staging checkpoint on the volume"
  # The uploader copies output/actor_train-0-G0/checkpoint-N to RTL_CKPT_DIR (the volume) and removes the local copy.
  # If the copy failed (ENOSPC etc.) the complete local copy is still under output/: move it to the volume ourselves.
  "${POD_SSH[@]}" "set -u; VOL=$VOLROOT/$RUN_ID; mkdir -p \$VOL
    for HF in /root/ec/runs/$RUN_ID/output/actor_train-*/checkpoint-*; do
      [ -d \"\$HF\" ] || continue
      echo \"moving \$HF -> \$VOL/\$(basename \$HF)\"; rsync -a --remove-source-files \"\$HF/\" \"\$VOL/\$(basename \$HF)/\" && rm -rf \"\$HF\"
    done
    rm -rf /root/ec/runs/$RUN_ID/checkpoints
    echo \"volume shards: \$(find \$VOL -name 'model-*.safetensors' | wc -l) ; \$(du -sh \$VOL | cut -f1)\"; df -h / | tail -1"
  rsync -az -e "$RSYNC_SSH" "root@$POD_HOST:/root/ec/runs/$RUN_ID/" "$LOCAL/runs/$RUN_ID/"
  rsync -az -e "$RSYNC_SSH" "root@$POD_HOST:/root/ec/logs/$RUN_ID.log" "root@$POD_HOST:/root/ec/logs/$RUN_ID.launcher.log" "$LOCAL/logs/"
  log "$RUN_ID run dir archived ($(du -sh "$LOCAL/runs/$RUN_ID" | cut -f1))"
  pull_in_background "$RUN_ID"
done
log "all arms finished; waiting for background pulls"
wait
log "ALL_ARMS_DONE"
