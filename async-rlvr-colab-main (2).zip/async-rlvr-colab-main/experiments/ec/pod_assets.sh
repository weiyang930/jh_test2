#!/usr/bin/env bash
# E-C assets: SALV-7B weights, CodeV-R1 RL parquet (pinned revision), salv_direct train.jsonl. Uses a small tools venv
# so it can run concurrently with the main environment build. Verifies the shard-1 sha256 and the converted-file sha256
# against the 2026-09-30 pod (0b85e577..., 9cfeb764...). Logs to /root/ec/logs/assets.log.
set -euo pipefail
ROOT="${ROOT:-/root/ec}"; T="${TOOLS_VENV:-$ROOT/env/tools-venv}"
[ -x "$T/bin/python" ] || { uv venv --python 3.11 "$T"; uv pip install --python "$T/bin/python" huggingface-hub==0.36.2 pandas pyarrow; }
export ROOT
"$T/bin/python" - <<'PY'
import os
from huggingface_hub import snapshot_download, hf_hub_download
snapshot_download('TabCanNotTab/SALV-Qwen2.5-Coder-7B-Instruct', revision='99de67c99a64a3faa06ea8c9dbaef995fc1bb9a0', local_dir=os.environ['ROOT'] + '/assets/salv-7b',
                  allow_patterns=['*.safetensors', '*.json', '*.txt'], max_workers=8)
print('SALV_OK', flush=True)
hf_hub_download('zhuyaoyu/CodeV-R1-dataset', filename='codev_r1_rl_train.parquet', repo_type='dataset',
                revision='9ab06ff546c597b66e124839a6f60c5330083424', local_dir=os.environ['ROOT'] + '/assets/codev-r1-dataset')
print('DATA_OK', flush=True)
PY
mkdir -p "$ROOT/assets/data/salv_direct"
cd "$ROOT/code" && "$T/bin/python" applications/rtl/prepare_codev_dataset.py --src "$ROOT/assets/codev-r1-dataset/codev_r1_rl_train.parquet" \
  --dst "$ROOT/assets/data/salv_direct/train.jsonl" --protocol salv_direct \
  --sim-meta-out "$ROOT/assets/data/salv_direct/sim_meta.json"   # port info for the simulation fallback
wc -l "$ROOT/assets/data/salv_direct/train.jsonl"
sha256sum "$ROOT/assets/salv-7b/model-00001-of-00004.safetensors" "$ROOT/assets/data/salv_direct/train.jsonl"
grep -q 0b85e5772f712f5af08f5bb44a0ff98bfcb0d0e702d94959e02d99c0d490fb02 <(sha256sum "$ROOT/assets/salv-7b/model-00001-of-00004.safetensors") && echo SALV_SHA_OK
grep -q 9cfeb764b5fdf46aa9d8974cb240b1ce8ff076965fbc1f1f15fd0c52518da3f7 <(sha256sum "$ROOT/assets/data/salv_direct/train.jsonl") && echo DATA_SHA_OK
echo ASSETS_DONE
