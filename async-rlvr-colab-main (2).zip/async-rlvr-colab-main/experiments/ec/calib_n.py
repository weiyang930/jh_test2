"""Pick the number of CPU verifier workers N that puts a run in the verifier-bound regime, from a short smoke run.

rho = verifier work per learner step / (N x learner compute per step). rho > 1 means verification, not the learner, is
the binding stage. We target rho = 2 by default:  N = ceil(w * B * G / (rho * L)), capped by the CPU budget.
  w  mean verifier seconds per sample (completed samples, timeouts included at their capped time)
  L  learner compute per step = model-update time + (step_end - batch_received), median over steps >= 1
Usage: python calib_n.py <smoke_run_dir> [--rho 2] [--reserve-cores 16]
"""
from __future__ import annotations

import argparse
import json
import math
import os
import statistics as st
from pathlib import Path


def read(path: Path) -> list[dict]:
    rows = []
    for line in open(path, errors="ignore"):
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return rows


def learner_compute_s(learner: list[dict]) -> float:
    by_step: dict[int, dict[str, float]] = {}
    for e in learner:
        if "step" in e and "ts" in e:
            by_step.setdefault(e["step"], {})[e["event"]] = e["ts"]
    per = []
    for step, ev in sorted(by_step.items()):
        if step < 1 or not {"model_update_start", "model_update_end", "batch_received", "step_end"} <= ev.keys():
            continue
        per.append((ev["model_update_end"] - ev["model_update_start"]) + (ev["step_end"] - ev["batch_received"]))
    if not per:
        raise SystemExit("no complete learner step >= 1 in learner_events.jsonl; run the smoke for at least 2 steps")
    return st.median(per)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("run", type=Path)
    ap.add_argument("--rho", type=float, default=2.0)
    ap.add_argument("--reserve-cores", type=int, default=16, help="cores left for Ray, vLLM and the trainer")
    ap.add_argument("--n-only", action="store_true", help="print only N (for shell substitution)")
    args = ap.parse_args()
    out = args.run / "output"
    manifest = json.load(open(args.run / "manifest.json"))
    B, G = int(manifest.get("rollout_batch_size", 32)), int(manifest.get("group_size", 8))
    done = [e for e in read(out / "events.jsonl") if e.get("event") == "sample_done" and e.get("verifier_execution_s") is not None]
    if not done:
        raise SystemExit("no sample_done events with verifier_execution_s")
    # cancelled verifications (decoupled expiry, shutdown) also consumed worker time; count them, but a decoupled run
    # still under-counts the tail because expiry cuts timeouts short -> calibrate from a barrier smoke
    vq = read(out / "verify_queue_events.jsonl")
    cancelled = [float(e.get("running_s") or 0.0) for e in vq if e.get("event") == "cancel" and e.get("state") == "running"]
    w = (sum(float(e["verifier_execution_s"]) for e in done) + sum(cancelled)) / (len(done) + len(cancelled))
    if manifest.get("consumption_mode", "barrier") != "barrier":
        print("WARNING: decoupled run; expiry truncates the verification tail, so w is biased low. Use a barrier smoke.",
              file=__import__("sys").stderr)
    timeout_frac = st.mean(e.get("verifier_stage") in ("eqy_timeout", "sim_pass", "sim_fail") for e in done)
    L = learner_compute_s(read(out / "learner_events.jsonl"))
    cores = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else os.cpu_count()
    n_target = math.ceil(w * B * G / (args.rho * L))
    n_cap = max(1, cores - args.reserve_cores)
    n = min(n_target, n_cap)
    rho_at_n = w * B * G / (n * L)
    if args.n_only:
        print(n)
        return
    print(json.dumps(dict(samples=len(done), w_s=round(w, 2), timeout_frac=round(timeout_frac, 4), B=B, G=G,
                          learner_compute_s=round(L, 1), verifier_work_per_step_s=round(w * B * G),
                          cores=cores, target_rho=args.rho, n_target=n_target, n_cap=n_cap,
                          RTL_VERIFY_WORKERS=n, rho_at_N=round(rho_at_n, 2)), indent=1))


if __name__ == "__main__":
    main()
