#!/usr/bin/env bash
# Environment bootstrap: uv-managed Python 3.11 venv with the tested pins (torch 2.6 cu124, vLLM 0.8.4, flash-attn cp311)
# plus oss-cad-suite 2024-04-03 (yosys/eqy/sby/iverilog). Idempotent; no root needed if VENV/OSS_CAD_DIR are writable.
# env: ROOT (default /root/ec), VENV (default /opt/venvs/async-rlvr), OSS_CAD_DIR (default /opt/oss-cad-suite). Needs `uv`.
set -euo pipefail
ROOT="${ROOT:-/root/ec}"; VENV="${VENV:-/opt/venvs/async-rlvr}"; OSS="${OSS_CAD_DIR:-/opt/oss-cad-suite}"
mkdir -p "$ROOT"/{code,assets,runs,logs,env}
# apt is optional (tmux/rsync conveniences); the EDA tools and iverilog come from oss-cad-suite below
if [ "$(id -u)" = 0 ] && command -v apt-get >/dev/null; then apt-get update -qq >/dev/null && apt-get install -y -qq tmux rsync >/dev/null && echo APT_OK; fi
if [ ! -x "$OSS/bin/eqy" ]; then
  TGZ=/workspace/oss-cad-suite-linux-x64-20240403.tgz
  [ -f "$TGZ" ] || { TGZ="$ROOT/env/oss-cad-suite-linux-x64-20240403.tgz"; curl -L -o "$TGZ" https://github.com/YosysHQ/oss-cad-suite-build/releases/download/2024-04-03/oss-cad-suite-linux-x64-20240403.tgz; }
  mkdir -p "$(dirname "$OSS")"; tar xzf "$TGZ" -C "$(dirname "$OSS")"
  [ "$(basename "$OSS")" = oss-cad-suite ] || mv "$(dirname "$OSS")/oss-cad-suite" "$OSS"
fi
"$OSS/bin/yosys" -V && echo TOOLS_OK
if [ ! -x "$VENV/bin/python" ]; then uv venv --python 3.11 "$VENV"; fi
U="uv pip install --python $VENV/bin/python"
$U torch==2.6.0 torchvision==0.21.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cu124
$U vllm==0.8.4 transformers==4.51.3 ray==2.48.0 accelerate==0.34.2 datasets==3.1.0 'fsspec[http]==2024.9.0' numpy==1.26.4 \
   tensordict==0.10.0 peft==0.12.0 tensorboard huggingface-hub==0.36.2 aiohttp-cors opencensus virtualenv
$U --no-deps TransferQueue==0.1.6
$U 'https://github.com/Dao-AILab/flash-attention/releases/download/v2.7.4.post1/flash_attn-2.7.4.post1+cu12torch2.6cxx11abiFALSE-cp311-cp311-linux_x86_64.whl'
$U codetiming dacite more_itertools pybase64 jsonlines deprecated loralib 'tyro>=0.5.7' latex2sympy2==1.5.4 \
   latex2sympy2_extended==1.10.1 langdetect 'nltk>=3.8' imageio gymnasium mcp openai nvidia-ml-py pytest \
   'pyzmq>=26' hydra-core==1.3.2 omegaconf==2.3.0 psutil pyarrow==19.0.1 networkx \
   pandas==2.2.3 scikit-learn==1.6.1 scipy==1.15.2   # numpy 1.26 pins: latest pyarrow/pandas/scipy need NumPy 2
# CodeV-R1 simulation checker for the EQY-timeout fallback, fetched verbatim at the pinned commit (not vendored)
mkdir -p "$ROOT/env/codev_tk"
curl -fsSL -o "$ROOT/env/codev_tk/verify.py" \
  https://raw.githubusercontent.com/IPRC-DIP/CodeV-R1/277ac46e/verl/verl/utils/reward_score/codev_eval_toolkit/verify.py
echo "CODEV_TK_OK $(sha256sum "$ROOT/env/codev_tk/verify.py" | cut -c1-16)"
"$VENV/bin/python" - <<'PY'
import torch, vllm, ray
from flash_attn import flash_attn_func
q = torch.randn(1, 8, 2, 64, dtype=torch.bfloat16, device='cuda')
flash_attn_func(q, q.clone(), q.clone(), causal=True)
print('ENV_OK torch', torch.__version__, 'vllm', vllm.__version__, 'ray', ray.__version__, 'flash-attn kernel ok')
PY
echo SETUP_DONE
