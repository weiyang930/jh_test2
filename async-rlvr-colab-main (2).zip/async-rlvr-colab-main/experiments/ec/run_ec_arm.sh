#!/usr/bin/env bash
# E-C arm runner (2026-09-30). Wraps experiments/launch/launch_salv_arm.sh with the four locked arms.
# usage: run_ec_arm.sh ARM MAX_STEPS [SUFFIX]
#   ARM in: barrier_r1 | barrier_r2 | barrier_r4 | decoupled_eta8
# Locked settings: SALV-7B, CodeV-R1 salv_direct, EQY tau=180 (yaml), 48 verifier workers, beta=0 (no cost aux),
# no intermediate checkpoints (throughput experiment). The final HF checkpoint (fp32, 29 GB) is first written under
# $ROOT/runs/<id>/output/actor_train-0-G0/checkpoint-N on the local disk and then COPIED by the checkpoint uploader to
# RTL_CKPT_DIR (the local copy is removed after a successful copy). Two local copies (34 GB base + 29 + 29 + run outputs)
# overflow the 100 GB disk (ec_decoupled_eta8 hit ENOSPC in the copy), so RTL_CKPT_DIR points at the network volume.
# ROOT defaults to /root/ec (local NVMe), not the mfs volume.
set -euo pipefail
ARM="$1"; MAX_STEPS="$2"; SUFFIX="${3:-}"
export ROOT="${ROOT:-/root/ec}"
export RTL_VERIFY_WORKERS="${RTL_VERIFY_WORKERS:-48}"   # 64 saturated the 81.6-core cgroup quota (958 s throttled in a 5-min smoke)
# E-C v2 group setting: G=8 (standard GRPO range, 2.8x informative samples per prompt vs G=4 on this model/data),
# B=32 keeps 256 samples per step so the learner floor and the N calibration carry over. E-C v1 (2026-10-01) was B=64 x G=4.
export RTL_GROUP_G="${RTL_GROUP_G:-8}" RTL_ROLLOUT_B="${RTL_ROLLOUT_B:-32}"
export RTL_ADMISSION_EXPLOIT="${RTL_ADMISSION_EXPLOIT:-$((RTL_ROLLOUT_B - RTL_ROLLOUT_B / 8))}" RTL_ADMISSION_AUDIT="${RTL_ADMISSION_AUDIT:-$((RTL_ROLLOUT_B / 8))}"
export RTL_SAVE_LAST="${RTL_SAVE_LAST:-true}"    # keep the final checkpoint; the orchestrator archives it locally, then deletes it on the pod
# optional suffixes on the arm name, in this order: _fb = EQY + CodeV-R1 simulation fallback (EQY budget 30 s unless a
# _tNN suffix follows); _tNN = EQY timeout NN s (default 180). e.g. barrier_r2_t60, decoupled_eta2_fb, barrier_r2_fb_t60
BASE_ARM="$ARM"; export RTL_SIM_FALLBACK=0
if [[ "$BASE_ARM" =~ ^(.+)_t([0-9]+)$ ]]; then BASE_ARM="${BASH_REMATCH[1]}"; export RTL_EQY_TIMEOUT_S="${BASH_REMATCH[2]}"; fi
if [[ "$BASE_ARM" =~ ^(.+)_fb$ ]]; then BASE_ARM="${BASH_REMATCH[1]}"; export RTL_SIM_FALLBACK=1 RTL_EQY_TIMEOUT_S="${RTL_EQY_TIMEOUT_S:-30}"; fi
export RTL_EQY_TIMEOUT_S="${RTL_EQY_TIMEOUT_S:-180}"
export RTL_CTRL_TABLES="${RTL_CTRL_TABLES:-$ROOT/assets/ctrl_tables/rtl.json}"   # fit_controller_tables.py output (controller arms)
case "$BASE_ARM" in
  barrier_r1)     export RTL_ASYNC_GENERATION_RATIO=1 RTL_CONSUMPTION_MODE=barrier   RTL_VERIFY_MAX_CONCURRENCY=1 ;;
  barrier_r2)     export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=barrier   RTL_VERIFY_MAX_CONCURRENCY=1 ;;
  # DAPO baseline (2026-10-28): synchronous (ratio 0) + dynamic sampling, zero-std groups filtered and replaced by extra prompts
  barrier_dapo)    export RTL_ASYNC_GENERATION_RATIO=0 RTL_CONSUMPTION_MODE=barrier  RTL_VERIFY_MAX_CONCURRENCY=1 RTL_DAPO=true RTL_DAPO_EXTRA="${RTL_DAPO_EXTRA:-32}" RTL_QUERY_FILTER=std_filter RTL_QUERY_FILTER_STD="${RTL_QUERY_FILTER_STD:-1e-4}" ;;
    # ratio 0 = ROLL's native synchronous dynamic sampling: generate until B groups pass the std filter, pause, train. With ratio 2 the
    # extra-prompt lane never pauses and runs unbounded during training (pod 10-28); std of 8 equal float32 rewards is ~6e-8, hence 1e-4.
  barrier_r4)     export RTL_ASYNC_GENERATION_RATIO=4 RTL_CONSUMPTION_MODE=barrier   RTL_VERIFY_MAX_CONCURRENCY=1 ;;
  decoupled_eta8) export RTL_ASYNC_GENERATION_RATIO=8 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 ;;
  decoupled_eta2) export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 ;;  # matched-staleness arm vs barrier_r2
  # ---- Stage 2 arms (2026-10-19): group-level controller and/or history selector on top of decoupled eta2
  decoupled_eta2_ctrl)      export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE=const ;;
  decoupled_eta2_ctrl_dyn)  export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE=dynamic RTL_CTRL_KAPPA="${RTL_CTRL_KAPPA:-1e-4}" ;;
  decoupled_eta2_ctrl_post) export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE=posterior ;;
  decoupled_eta2_hsel)      export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE="${RTL_HSEL_MODE:-skip}" ;;
  decoupled_eta2_hsel_skip) export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE=skip ;;
  decoupled_eta2_hsel_prior) export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE=prior ;;   # needs RTL_ADMISSION_PRIOR=<probe summary.json>
  decoupled_eta2_full)      export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE="${RTL_CTRL_MODE:-const}"
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE="${RTL_HSEL_MODE:-skip}" ;;
  # ---- partial release (2026-10-21): controller also releases informative groups at >= 3/4 verified (RTL_CTRL_RELEASE slow|index)
  decoupled_eta2_ctrl_rel)  export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE="${RTL_CTRL_MODE:-const}"
    export RTL_CTRL_RELEASE="${RTL_CTRL_RELEASE:-index}" ;;
  # ---- 2026-10-25 Stage-2 design (research/h100_replay_20261024): top-k selector with a visit budget and one price
  decoupled_eta2_sel)       export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE=topk
    export RTL_ADMISSION_POOL="${RTL_ADMISSION_POOL:-256}" RTL_ADMISSION_BUDGET="${RTL_ADMISSION_BUDGET:-2}" RTL_ADMISSION_WINDOW="${RTL_ADMISSION_WINDOW:-50}" RTL_ADMISSION_TEXT="${RTL_ADMISSION_TEXT:-true}" RTL_ADMISSION_PRICE=shared RTL_ADMISSION_RHO="${RTL_ADMISSION_RHO:-1.0e-03}"
    export RTL_PRICE_TRACKER=true RTL_CTRL_KAPPA="${RTL_CTRL_KAPPA:-1e-4}" ;;   # dynamic price without a controller (rho is only the fallback)
  decoupled_eta2_full2)     export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2
    export RTL_CTRL_MODE="${RTL_CTRL_MODE:-dynamic}" RTL_CTRL_RELEASE="${RTL_CTRL_RELEASE:-expiry}" RTL_CTRL_MIN_OBS="${RTL_CTRL_MIN_OBS:-0}" RTL_CTRL_KAPPA="${RTL_CTRL_KAPPA:-1e-4}"
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE=topk
    export RTL_ADMISSION_POOL="${RTL_ADMISSION_POOL:-256}" RTL_ADMISSION_BUDGET="${RTL_ADMISSION_BUDGET:-2}" RTL_ADMISSION_WINDOW="${RTL_ADMISSION_WINDOW:-50}" RTL_ADMISSION_TEXT="${RTL_ADMISSION_TEXT:-true}" RTL_ADMISSION_PRICE=shared RTL_ADMISSION_RHO="${RTL_ADMISSION_RHO:-1.0e-03}" ;;
  decoupled_eta2_full_rel)  export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2 RTL_CTRL_MODE="${RTL_CTRL_MODE:-const}"
    export RTL_CTRL_RELEASE="${RTL_CTRL_RELEASE:-index}"
    export RTL_ADMISSION_CLS=applications.rtl.history_admission.HistoryAdmissionPolicy RTL_ADMISSION_MODE="${RTL_HSEL_MODE:-skip}" ;;
  decoupled_eta2_sel)  # decoupled eta=2 + E2 cost-aware admission selector (E1-pretrained bundle; off-distribution probe)
    export RTL_ASYNC_GENERATION_RATIO=2 RTL_CONSUMPTION_MODE=decoupled RTL_VERIFY_MAX_CONCURRENCY=2
    export RTL_ADMISSION_CLS=applications.rtl.admission.PooledAdmissionPolicy RTL_ADMISSION_MODE=cost_aware RTL_ADMISSION_MU=0.1
    export RTL_SCORE_BUNDLE="$ROOT/code/artifacts/score_bundle_e1/score_bundle.pkl" ;;
  *) echo "unknown arm $ARM" >&2; exit 2 ;;
esac
RUN_ID="ec_${ARM}${SUFFIX}"
mkdir -p "$ROOT/logs"
export RTL_CKPT_DIR="${RTL_CKPT_DIR:-$ROOT/runs/$RUN_ID/checkpoints}"
mkdir -p "$RTL_CKPT_DIR"
# save_steps: RTL_SAVE_STEPS when the caller sets it (h100_20261019/run_arm.sh: every 100 steps, evaluated then pruned by
# eval_ckpt.sh); otherwise larger than max_steps = no intermediate checkpoints (E-C throughput runs), final one still forced.
cd "$ROOT/code"
bash experiments/launch/launch_salv_arm.sh "$RUN_ID" "$MAX_STEPS" "${RTL_SAVE_STEPS:-100000}" 0.0 "${RTL_WALLCLOCK_LIMIT_S:-0}" 2>"${RTL_SAVE_STEPS:-100000}" 0.0 0 2>&11 | tee "$ROOT/logs/$RUN_ID.launcher.log"
# record the consumption mode in the manifest for analyze_ec.py
"${VENV:-/opt/venvs/async-rlvr}/bin/python" - "$ROOT/runs/$RUN_ID/manifest.json" "$RTL_CONSUMPTION_MODE" <<'PY'
import json, os, sys
path, mode = sys.argv[1:]
m = json.load(open(path)); m["consumption_mode"] = mode; m["gpus"] = os.environ.get("RTL_GPU_DESC", m.get("gpus", "unknown"))
json.dump(m, open(path, "w"), indent=2)
PY
# a crashed run leaves EQY children behind (they run in their own sessions); sweep this run's workspace token
pkill -9 -f "rtl_verify_$RUN_ID" 2>/dev/null || true
rm -rf "${RTL_TMP_ROOT:-/tmp}/rtl_verify_$RUN_ID" 2>/dev/null || true
echo "EC_ARM_DONE $RUN_ID"
