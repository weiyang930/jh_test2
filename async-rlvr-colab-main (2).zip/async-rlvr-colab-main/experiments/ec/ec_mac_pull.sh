#!/usr/bin/env bash
# Mac-side mirror for E-C: every 5 min rsync the pod's run dirs (no checkpoints) + logs to the local archive until the
# pod sequencer logs ALL_ARMS_DONE (then one final sync). Survives laptop sleep (each iteration reconnects).
# usage: ec_mac_pull.sh            env: POD_HOST POD_PORT LOCAL_ARCHIVE
set -uo pipefail
POD_HOST="${POD_HOST:-154.54.102.44}"; POD_PORT="${POD_PORT:-10354}"
S="ssh -o ConnectTimeout=30 -p $POD_PORT -i $HOME/.ssh/id_ed25519"
LOCAL="${LOCAL_ARCHIVE:-$HOME/Desktop/MIT/async-rlvr/runpod-backups/ec-20261001}"
mkdir -p "$LOCAL/runs" "$LOCAL/logs"
while true; do
  rsync -az --exclude 'checkpoints/' --exclude 'checkpoint-*/' -e "$S" "root@$POD_HOST:/root/ec/runs/" "$LOCAL/runs/" 2>/dev/null
  rsync -az -e "$S" "root@$POD_HOST:/root/ec/logs/" "$LOCAL/logs/" 2>/dev/null
  echo "[$(date -u +%FT%TZ)] synced; $(grep -h "steps done" "$LOCAL/logs/sequence.log" 2>/dev/null | tail -1 | cut -c1-80)"
  grep -q ALL_ARMS_DONE "$LOCAL/logs/sequence.log" 2>/dev/null && { echo "ALL_ARMS_DONE mirrored"; break; }
  sleep 300
done
