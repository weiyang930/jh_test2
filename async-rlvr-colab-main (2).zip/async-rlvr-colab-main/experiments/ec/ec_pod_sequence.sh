#!/usr/bin/env bash
# Pod-side arm sequencer (runs on the pod under setsid nohup, so the Mac can be closed).
# For each arm: skip if EC_ARM_DONE already logged; re-attach if its log exists; else launch with no final checkpoint
# (RTL_SAVE_LAST=false). After an arm, keep any checkpoint it did write only while >= MIN_FREE_GB stays free on the
# 100 GB disk; otherwise delete it (checkpoints are not being kept in this phase; the network volume is over quota).
# usage: ec_pod_sequence.sh MAX_STEPS ARM [ARM ...]      log: $ROOT/logs/sequence.log
set -uo pipefail
MAX_STEPS="$1"; shift
ROOT="${ROOT:-/root/ec}"; export ROOT
MIN_FREE_GB="${MIN_FREE_GB:-35}"
VOL_RUNS="${VOL_RUNS:-$ROOT/synced_runs}"   # a shared/persistent filesystem path: results are copied here as each arm ends
log() { echo "[$(date -u +%FT%TZ)] $*"; }
free_gb() { df -BG --output=avail "$ROOT" | tail -1 | tr -dc '0-9'; }
for ARM in "$@"; do
  RUN_ID="ec_${ARM}"; L="$ROOT/logs/$RUN_ID.log"
  if [ -f "$L" ] && grep -q EC_ARM_DONE "$L"; then log "$RUN_ID already done; skipping"; continue; fi
  if [ -f "$L" ]; then
    log "$RUN_ID already running; waiting"
  else
    log "launching $RUN_ID ($MAX_STEPS steps, no final checkpoint); free $(free_gb) GB"
    (cd $ROOT/code && RTL_SAVE_LAST=false setsid nohup bash experiments/ec/run_ec_arm.sh "$ARM" "$MAX_STEPS" > "$L" 2>&1 < /dev/null &)
  fi
  until grep -q EC_ARM_DONE "$L" 2>/dev/null; do
    sleep 120
    log "$RUN_ID steps done: $(grep -c step_end $ROOT/runs/$RUN_ID/output/learner_events.jsonl 2>/dev/null || echo 0); free $(free_gb) GB"
  done
  log "$RUN_ID finished; free $(free_gb) GB"
  # RESULTS LEAVE THE CONTAINER DISK IMMEDIATELY: events/logs (tens of MB, no checkpoints) go to the network volume now;
  # the Mac puller (ec_mac_pull.sh) mirrors the same files when it is awake. Lesson from 2026-10-01 (pod vanished).
  mkdir -p "$VOL_RUNS/$RUN_ID"
  rsync -a --exclude 'checkpoints/' --exclude 'checkpoint-*/' $ROOT/runs/$RUN_ID/ "$VOL_RUNS/$RUN_ID/" \
    && cp $ROOT/logs/$RUN_ID.log $ROOT/logs/$RUN_ID.launcher.log "$VOL_RUNS/" 2>/dev/null \
    && log "$RUN_ID events synced to $VOL_RUNS ($(du -sh "$VOL_RUNS/$RUN_ID" | cut -f1))" \
    || log "WARNING: volume sync of $RUN_ID failed"
  if [ "$(free_gb)" -lt "$MIN_FREE_GB" ]; then
    for C in $ROOT/runs/$RUN_ID/output/actor_train-*/checkpoint-* $ROOT/runs/$RUN_ID/checkpoints; do
      [ -e "$C" ] || continue
      log "disk below ${MIN_FREE_GB} GB: deleting $C"; rm -rf "$C"
    done
    log "after cleanup free $(free_gb) GB"
  fi
done
cp $ROOT/logs/sequence.log "$VOL_RUNS/" 2>/dev/null; log "ALL_ARMS_DONE"
