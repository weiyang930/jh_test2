"""Post-smoke checks for one E-C arm (run on the pod after a 2-step run). Prints PASS/WARN/FAIL lines.

Checks: (1) no leftover EQY/sby/yosys processes; (2) learner steps completed; (3) verification-time distribution close to
the E007 reference (CPU contention guard: p50 0.67 s, p90 4.0 s, timeout 3.9 % at tau=180 on 4 workers);
(4) decoupled arm: cancel events present when groups were discarded, staleness within [1, eta+1]; barrier arm: no cancels,
staleness == ratio; (5) no verifier tool errors / invalid payload spikes.
Usage: python smoke_check.py <run_dir> [--ref-p50 0.67 --ref-p90 4.0 --ref-timeout 0.039]
"""
from __future__ import annotations

import argparse
import json
import statistics as st
import subprocess
from pathlib import Path


def load(path: Path) -> list:
    if not path.exists():
        return []
    rows = []
    for line in open(path, errors="ignore"):
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return rows


def q(xs: list, p: float) -> float:
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(p * len(xs)))] if xs else float("nan")


def report(level: str, msg: str) -> None:
    print(f"[{level}] {msg}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("run", type=Path)
    ap.add_argument("--ref-p50", type=float, default=0.67)
    ap.add_argument("--ref-p90", type=float, default=4.0)
    ap.add_argument("--ref-timeout", type=float, default=0.039)
    args = ap.parse_args()
    out = args.run / "output"
    manifest = json.load(open(args.run / "manifest.json"))
    mode, ratio = manifest.get("consumption_mode", "barrier"), int(manifest.get("async_generation_ratio", 1))

    ps = subprocess.run(["bash", "-c", "ps -eo pid,etimes,comm,args | grep -E 'sby|yosys|eqy|smtbmc|yosys-abc' | grep -v grep"],
                        capture_output=True, text=True).stdout.strip()
    report("PASS" if not ps else "FAIL", f"leftover EDA processes: {len(ps.splitlines())}")

    sched = load(out / "scheduler_events.jsonl")
    steps = sorted({e["step"] for e in sched if e.get("event") == "step_begin"})
    consumed = [e for e in sched if e.get("event") == "consume_batch"]
    report("PASS" if len(consumed) >= 2 else "FAIL", f"steps begun {steps}, batches consumed {len(consumed)}")

    events = load(out / "events.jsonl")
    done = [e for e in events if e.get("event") == "sample_done"]
    exec_s = [float(e["verifier_execution_s"]) for e in done if e.get("verifier_execution_s") is not None]
    if exec_s:
        p50, p90 = q(exec_s, .5), q(exec_s, .9)
        to = sum(e.get("verifier_stage") in ("eqy_timeout", "sim_pass", "sim_fail") for e in done) / len(done)
        fb = [e for e in done if e.get("verifier_stage") in ("sim_pass", "sim_fail")]
        if manifest.get("sim_fallback"):
            report("PASS" if fb or not to else "FAIL",
                   f"simulation fallback decided {len(fb)} EQY timeouts ({sum(e['verifier_stage'] == 'sim_pass' for e in fb)} pass); "
                   "FAIL => toolkit/port info missing, see sim_detail in verifier events")
        lvl = "PASS" if p50 <= 1.2 * args.ref_p50 and p90 <= 1.3 * args.ref_p90 else "WARN"
        report(lvl, f"EQY exec p50 {p50:.2f} s (ref {args.ref_p50}), p90 {p90:.2f} s (ref {args.ref_p90}), "
                    f"timeout {to:.1%} (ref {args.ref_timeout:.1%}), n={len(done)}; WARN => CPU contention, lower workers")
        stages = {}
        for e in done:
            stages[e.get("verifier_stage")] = stages.get(e.get("verifier_stage"), 0) + 1
        err = sum(v for k, v in stages.items() if k in ("eqy_tool_error", "syntax_tool_error"))
        report("PASS" if err / len(done) < 0.02 else "WARN", f"stage mix {stages}")
    else:
        report("FAIL", "no sample_done events")

    stale = []
    for e in consumed:
        s = e.get("consume_step")
        for it in e.get("consumed_items", []):
            stale.append(s - it.get("sampling_start_step", s))
    cancels = [e for e in events if e.get("event") == "sample_canceled"]
    gc_abort = [e for e in sched if e.get("event") == "gc_abort_prompt"]
    if stale:
        hist = {k: stale.count(k) for k in sorted(set(stale))}
        if mode == "decoupled":
            ok = min(stale) >= 0 and max(stale) <= ratio + 1
            report("PASS" if ok else "FAIL", f"decoupled staleness histogram {hist} (expect within [0, {ratio + 1}])")
            report("PASS" if (not gc_abort or cancels) else "WARN",
                   f"gc-aborted prompts {len(gc_abort)}, verifier cancels {len(cancels)} (cancels expected iff gc aborted running prompts)")
        else:
            ok = all(v in (ratio, ratio - 1, ratio + 1) for v in hist)
            report("PASS" if ok else "WARN", f"barrier staleness histogram {hist} (expect ~{ratio})")
            report("PASS" if not cancels else "WARN", f"cancels in barrier mode: {len(cancels)}")
    else:
        report("FAIL", "no consumed items recorded")

    vq = load(out / "verify_queue_events.jsonl")
    if vq:
        kinds = {}
        for e in vq:
            kinds[e.get("event")] = kinds.get(e.get("event"), 0) + 1
        report("INFO", f"verify_queue_events {kinds}")
    learner = load(out / "learner_events.jsonl")
    ends = [e for e in learner if e.get("event") == "step_end"]
    if ends:
        report("INFO", "step elapsed s: " + ", ".join(f"{e.get('elapsed_s', 0):.0f}" for e in ends))


if __name__ == "__main__":
    main()
