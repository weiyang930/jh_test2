"""Per-arm metrics for experiment E-C from a run's output directory (no GPU, no network).

Inputs (all under <run>/output/): scheduler_events.jsonl (step_begin, consume_batch), events.jsonl (prompt_commit,
sample_done, sample_canceled), verify_queue_events.jsonl (optional), learner_events.jsonl (optional).
Metrics per arm (steady state = steps >= --warmup):
  step_s            mean wall-clock between consecutive step_begin events
  inform_per_h      informative groups consumed per hour (group informative = committed rewards not all equal)
  consumed_per_h    all consumed groups per hour
  stale_mean/p90    consume_step - sampling_start_step over consumed prompts
  verifier_busy     (completed exec time + running time of cancelled jobs) / (wall-clock * N workers); cancelled
                    jobs come from verify_queue_events (state=running, running_s). busy_done counts completed jobs only.
  eqy_p50/p90/timeout_frac   verification time distribution (to compare against E007 for CPU contention)
  cancelled         sample_canceled events
Usage: python analyze_ec.py <run_dir> [<run_dir> ...] [--warmup 5] [--workers 64] [--json out.json]
"""
from __future__ import annotations

import argparse
import collections
import json
import statistics as st
from pathlib import Path


def load(path: Path) -> list:
    if not path.exists():
        return []
    rows = []
    for line in open(path, errors="ignore"):
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return rows


def quantile(xs: list, q: float) -> float:
    if not xs:
        return float("nan")
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(q * len(xs)))]


def analyze(run: Path, warmup: int, workers: int | None) -> dict:
    out = run / "output"
    sched = load(out / "scheduler_events.jsonl")
    events = load(out / "events.jsonl")
    manifest = json.load(open(run / "manifest.json")) if (run / "manifest.json").exists() else {}
    n_workers = workers or int(manifest.get("verify_workers", 0)) or None

    step_begin = {e["step"]: e["ts"] for e in sched if e.get("event") == "step_begin"}
    steps = sorted(step_begin)
    steady = [s for s in steps if s >= warmup]
    if len(steady) < 2:
        return {"run": run.name, "error": f"only {len(steady)} steady steps"}
    t0, t1 = step_begin[steady[0]], step_begin[steady[-1]]
    span_h = (t1 - t0) / 3600.0
    step_s = (t1 - t0) / (len(steady) - 1)

    rewards = {e["prompt_id"]: e.get("rewards") for e in events if e.get("event") == "prompt_commit"}
    consumed, stale = 0, []
    informative = 0
    for e in sched:
        if e.get("event") != "consume_batch":
            continue
        s = e.get("consume_step")
        if s is None or s < steady[0] or s >= steady[-1]:
            continue
        for item in e.get("consumed_items", []):
            pid = item.get("prompt_id")
            consumed += 1
            stale.append(s - item.get("sampling_start_step", s))
            r = rewards.get(pid)
            if r and len({round(float(x), 3) for x in r}) > 1:
                informative += 1

    done = [e for e in events if e.get("event") == "sample_done" and t0 <= e.get("ts", 0) < t1]
    exec_s = [float(e["verifier_execution_s"]) for e in done if e.get("verifier_execution_s") is not None]
    timeouts = sum(e.get("verifier_stage") in ("eqy_timeout", "sim_pass", "sim_fail") for e in done)  # EQY timed out
    fallback_pass = sum(e.get("verifier_stage") == "sim_pass" for e in done)
    cancelled = sum(1 for e in events if e.get("event") == "sample_canceled" and t0 <= e.get("ts", 0) < t1)
    vq = load(out / "verify_queue_events.jsonl")
    cancel_run_s = sum(float(e.get("running_s") or 0.0) for e in vq
                       if e.get("event") == "cancel" and e.get("state") == "running" and t0 <= e.get("ts", 0) < t1)
    cap = (t1 - t0) * n_workers if n_workers else None
    busy_done = (sum(exec_s) / cap) if cap and exec_s else float("nan")
    busy = ((sum(exec_s) + cancel_run_s) / cap) if cap and exec_s else float("nan")

    return {
        "run": run.name, "mode": manifest.get("consumption_mode", "?"),
        "ratio": manifest.get("async_generation_ratio", "?"), "workers": n_workers,
        "steady_steps": len(steady), "step_s": step_s,
        "inform_per_h": informative / span_h, "consumed_per_h": consumed / span_h,
        "inform_frac": informative / consumed if consumed else float("nan"),
        "stale_mean": st.mean(stale) if stale else float("nan"), "stale_p90": quantile(stale, 0.9),
        "verifier_busy": busy, "busy_done": busy_done, "cancel_run_s": cancel_run_s, "eqy_p50": quantile(exec_s, 0.5), "eqy_p90": quantile(exec_s, 0.9),
        "timeout_frac": timeouts / len(done) if done else float("nan"), "cancelled": cancelled,
        "sim_pass_frac": fallback_pass / len(done) if done else float("nan"),
        "samples_done": len(done),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("runs", nargs="+", type=Path)
    ap.add_argument("--warmup", type=int, default=5)
    ap.add_argument("--workers", type=int)
    ap.add_argument("--json", type=Path)
    args = ap.parse_args()
    rows = [analyze(r, args.warmup, args.workers) for r in args.runs]
    cols = ["run", "mode", "ratio", "step_s", "inform_per_h", "consumed_per_h", "inform_frac", "stale_mean",
            "stale_p90", "verifier_busy", "busy_done", "eqy_p50", "eqy_p90", "timeout_frac", "cancelled", "steady_steps"]
    print(" ".join(f"{c:>13s}" for c in cols))
    for r in rows:
        if "error" in r:
            print(f"{r['run']:>13s} {r['error']}")
            continue
        cells = []
        for c in cols:
            v = r[c]
            cells.append(f"{v:13.3f}" if isinstance(v, float) else f"{str(v):>13s}")
        print(" ".join(cells))
    if args.json:
        args.json.write_text(json.dumps(rows, indent=1))


if __name__ == "__main__":
    main()
