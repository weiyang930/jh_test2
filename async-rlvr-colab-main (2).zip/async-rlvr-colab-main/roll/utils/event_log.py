"""Minimal JSONL event logging for scheduler-level observability.

Zero-overhead unless the process has ``ROLL_SCHED_EVENT_FILE`` set (the RTL
async baseline sets it inside the DynamicSamplingScheduler actor from
``pipeline_config.output_dir``).  Used only for instrumentation; never changes
scheduling behavior.
"""
import json
import os
import time
from typing import Optional, TextIO

_fh: Optional[TextIO] = None
_path: Optional[str] = None


def sched_event(**event) -> None:
    """Append one event line to $ROLL_SCHED_EVENT_FILE (flushed), if configured."""
    global _fh, _path
    path = os.environ.get("ROLL_SCHED_EVENT_FILE")
    if not path:
        return
    if _fh is None or _path != path:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        _fh = open(path, "a", encoding="utf-8")
        _path = path
    event["ts"] = time.time()
    _fh.write(json.dumps(event, ensure_ascii=False, default=str) + "\n")
    _fh.flush()
