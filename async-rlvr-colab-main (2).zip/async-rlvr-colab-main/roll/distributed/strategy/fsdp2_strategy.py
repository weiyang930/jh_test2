import contextlib
import json
import os
import random
from collections import defaultdict
from contextlib import nullcontext
from typing import Callable, Dict, Optional, Tuple
from abc import abstractmethod, ABC

import accelerate
import numpy as np
import ray
import transformers
from transformers import AutoConfig, get_scheduler, set_seed
from codetiming import Timer
from packaging import version
import torch
from torch import optim
from torch import Tensor
import torch.distributed as dist
import torch.distributed.checkpoint as dcp
from torch.distributed.checkpoint.state_dict import StateDictOptions, get_model_state_dict
from torch.distributed.device_mesh import init_device_mesh, DeviceMesh
from torch.distributed.fsdp import CPUOffloadPolicy, MixedPrecisionPolicy
from torch.distributed.tensor import DTensor, distribute_tensor, distribute_module, Shard
from torch.distributed.tensor.parallel import parallelize_module, ParallelStyle
from torch.distributed._functional_collectives import (
    all_to_all_single,
    all_to_all_single_autograd,
)
from torch.nn.utils import clip_grad_norm_
from torch.nn.utils.clip_grad import _clip_grads_with_norm_, _get_total_norm

from roll.datasets.collator import collate_fn_to_dict_list
from roll.distributed.executor.worker import Worker
from roll.distributed.scheduler.protocol import DataProto
from roll.distributed.strategy.strategy import InferenceStrategy, TrainStrategy
from roll.models.model_providers import (
    clear_fsdp2_init_context,
    default_processor_provider,
    default_tokenizer_provider,
    set_fsdp2_init_context,
)
from roll.platforms import current_platform
from roll.third_party.fsdp2.model_update import FSDP2WeightUpdater
from roll.utils.checkpoint_manager import CheckpointManager, download_model
from roll.utils.collective import collective
from roll.utils.context_parallel import get_ulysses_group, set_upg_manager
from roll.utils.context_parallel.autograd_gather import ulysses_gather
from roll.utils.fsdp_utils import (
    apply_fsdp2,
    fsdp2_load_full_state_dict,
    get_init_weight_context_manager,
    get_shard_placement_fn,
    get_shard_placement_fn_ep,
    _permute,
    _unpermute,
    register_experts_forward_in_ExpertsInterface,
    set_use_grouped_mm,
)
from roll.utils.functionals import append_to_dict, log_probs_from_logits
from roll.utils.logging import get_logger
from roll.utils.offload_states import OffloadStateType
from roll.utils.constants import IGNORE_INDEX

logger = get_logger()


def _parse_dtype(dtype):
    if dtype is None:
        return None

    if isinstance(dtype, torch.dtype):
        return dtype

    if isinstance(dtype, str):
        dtype_lower = dtype.lower()
        dtype_map = {
            "bf16": torch.bfloat16,
            "bfloat16": torch.bfloat16,
            "fp16": torch.float16,
            "float16": torch.float16,
            "half": torch.float16,
            "fp32": torch.float32,
            "float32": torch.float32,
            "float": torch.float32,
            "fp64": torch.float64,
            "float64": torch.float64,
        }

        if dtype_lower in dtype_map:
            return dtype_map[dtype_lower]
        else:
            if hasattr(torch, dtype):
                return getattr(torch, dtype)
            else:
                raise ValueError(
                    f"Unsupported dtype string: '{dtype}'. " f"Supported values: {list(dtype_map.keys())}"
                )

    return dtype


def create_device_mesh_with_ep(world_size: int, fsdp_size: int, efsdp_size: int, ep_size: int):
    """
    Create device mesh for FSDP.
    """

    # Default to global sharding (1D mesh) if fsdp_size is not explicitly set for HSDP
    if fsdp_size <= 1 or fsdp_size >= world_size:
        mesh_shape = (world_size,)
        mesh_dim_names = ["fsdp"]
    else:
        # HSDP Case: Shard within fsdp_size group, Replicate across the rest
        # PyTorch fully_shard shards on the LAST dimension (inner) and replicates on outer dimensions.
        # Example: world=8, fsdp=4. We want 2 replicas of 4-way sharding.
        # Mesh: (2, 4). Replicate on dim 0 (2), Shard on dim 1 (4).
        ddp_size = world_size // fsdp_size
        mesh_shape = (ddp_size, fsdp_size)
        mesh_dim_names = ["ddp", "fsdp"]

    device_mesh = init_device_mesh(
        current_platform.device_type,
        mesh_shape=mesh_shape,
        mesh_dim_names=mesh_dim_names,
    )

    # Create device mesh for MoE
    if ep_size > 1:
        moe_model_size = efsdp_size * ep_size
        if moe_model_size == world_size:
            moe_mesh_shape = (efsdp_size, ep_size)
            moe_mesh_dim_names = ("efsdp", "ep")
        else:
            eddp_size = world_size // moe_model_size
            moe_mesh_shape = (eddp_size, efsdp_size, ep_size)
            moe_mesh_dim_names = ["eddp", "efsdp", "ep"]

        moe_device_mesh = init_device_mesh(
            current_platform.device_type,
            mesh_shape=moe_mesh_shape,
            mesh_dim_names=moe_mesh_dim_names,
        )
    else:
        moe_device_mesh = None

    return device_mesh, moe_device_mesh


def strip_fsdp_architecture_prefix(save_dir: str) -> None:
    """torch's fully_shard subclasses the model as FSDP<Name> and save_pretrained records that class name in
    config.json "architectures"; vLLM then refuses the checkpoint. Rewrite it to the original architecture."""
    cfg_path = os.path.join(save_dir, "config.json")
    if not os.path.exists(cfg_path):
        return
    with open(cfg_path) as fh:
        cfg = json.load(fh)
    archs = cfg.get("architectures") or []
    fixed = [a[4:] if a.startswith("FSDP") else a for a in archs]
    if fixed == archs:
        return
    cfg["architectures"] = fixed
    with open(cfg_path, "w") as fh:
        json.dump(cfg, fh, indent=2)


class BaseExpertParallel(ParallelStyle, ABC):
    """
    Mirror torchtitan's BaseExpertParallel.
    Reference: https://github.com/pytorch/torchtitan/blob/main/torchtitan/distributed/expert_parallel.py #L30 #v0.2.2
    """
    @abstractmethod
    def _partition_fn(self, name: str, mod: torch.nn.Module, device_mesh: DeviceMesh) -> None:
        ...

    @abstractmethod
    def _token_dispatch(
        self, mod: torch.nn.Module, inputs: tuple, device_mesh: DeviceMesh
    ) -> tuple[Tensor, Tensor]:
        ...

    @abstractmethod
    def _token_combine(
        self, mod: torch.nn.Module, routed_output: Tensor, device_mesh: DeviceMesh
    ) -> Tensor:
        ...


class ExpertParallel(BaseExpertParallel):
    """
    Mirror torchtitan's BaseExpertParallel.
    Reference: https://github.com/pytorch/torchtitan/blob/main/torchtitan/distributed/expert_parallel.py #L89 #v0.2.2
    """
    def __init__(self, num_experts: int):
        super().__init__()
        self.input_splits = None
        self.output_splits = None
        self.input_shape = None
        self.permuted_indices = None
        self.num_experts = num_experts

    def _partition_fn(self, name: str, mod: torch.nn.Module, device_mesh: DeviceMesh) -> None:
        for param_name, param in mod.named_parameters(recurse=False):
            dist_param = torch.nn.Parameter(distribute_tensor(param, device_mesh, [Shard(0)]))
            mod.register_parameter(param_name, dist_param)

    def _token_dispatch(
        self, mod: torch.nn.Module, inputs: tuple, device_mesh: DeviceMesh
    ) -> tuple[Tensor, Tensor]:
        # Preprocess
        x, selected_experts_indices, top_scores = inputs
        self.x = x
        self.top_scores = top_scores
        self.bs_slen, self.dim = x.shape
        self.top_k = top_scores.shape[-1]
        num_tokens_per_expert = torch.histc(
            selected_experts_indices.view(-1),
            bins=self.num_experts,
            min=0,
            max=self.num_experts,
        )
        self.token_indices_experts_sorted = token_indices_experts_sorted = torch.argsort(
            selected_experts_indices.view(-1), stable=True
        )
        top_scores_experts_sorted = top_scores.view(-1)[token_indices_experts_sorted]
        # shape (bs*slen*top_k, dim)
        routed_input = x[token_indices_experts_sorted // self.top_k]

        # annotate module input placements/sharding with input_layouts
        ep_degree = device_mesh.shape[0]
        num_local_experts = num_tokens_per_expert.shape[0] // ep_degree

        # generate the input splits and output splits for all-to-all
        with torch.no_grad():
            num_tokens_per_expert_group = all_to_all_single(
                num_tokens_per_expert,
                None,
                None,
                group=device_mesh.get_group(),
            )
            # Need to wait explicitly because it is used by a triton kernel later
            # which doesn't realize that AsyncCollectiveTensor needs unwrapping
            num_tokens_per_expert_group = torch.ops._c10d_functional.wait_tensor(
                num_tokens_per_expert_group
            )
            input_splits = (
                num_tokens_per_expert.view(ep_degree, -1)
                .sum(dim=1)
                .to(torch.device("cpu"), non_blocking=True)
            )
            # NOTE: this would incur a device-to-host sync
            output_splits = (
                num_tokens_per_expert_group.view(ep_degree, -1)
                .sum(dim=1)
                .to(torch.device("cpu"), non_blocking=False)
            )
            self.input_splits = input_splits.tolist()
            self.output_splits = output_splits.tolist()

        # perform all-to-all
        routed_input = all_to_all_single_autograd(
            routed_input,
            self.output_splits,
            self.input_splits,
            device_mesh.get_group(),
        )

        # NOTE: After this all-to-all, the routed input is put on proper EP rank.
        # However, the num_tokens_per_expert_group is not of the final target format
        # [#tokens for local expert 0, #tokens for local expert 1, ...]
        # Rather, it is of the format
        # [#tokens for local expert 0 from EP rank 0, #tokens for local expert 1 from EP rank 0, ...,
        #  #tokens for local expert 0 from EP rank 1, #tokens for local expert 1 from EP rank 1, ...]
        # We need to perform another shuffle to get the correct layout, via the _permute function
        # below, which also does padding to make sure the number of tokens each expert gets locally
        # is a multiple of TOKEN_GROUP_ALIGN_SIZE_M.
        # Note that this will create side effects when wrapping the for-loop implementation
        # of GroupedExperts, as it does not need padding.

        (
            self.input_shape,
            routed_input,
            self.permuted_indices,
            num_tokens_per_expert_group,
        ) = _permute(
            routed_input, num_tokens_per_expert_group, ep_degree, num_local_experts
        )

        return routed_input, num_tokens_per_expert_group

    def _token_combine(
        self, mod: torch.nn.Module, routed_output: Tensor, device_mesh: DeviceMesh
    ) -> Tensor:
        routed_output = _unpermute(
            routed_output, self.input_shape, self.permuted_indices
        )

        routed_output = all_to_all_single_autograd(
            routed_output,
            self.input_splits,
            self.output_splits,
            device_mesh.get_group(),
        )

        # Postprocess
        routed_output_unsorted = torch.zeros(
            (self.bs_slen * self.top_k, self.dim),
            dtype=routed_output.dtype,
            device=routed_output.device,
        )
        routed_output_unsorted[self.token_indices_experts_sorted] = routed_output
        routed_output_unsorted = routed_output_unsorted.reshape(
            -1, self.top_k, self.dim
        )
        out_experts = (
            torch.bmm(
                self.top_scores.reshape(-1, 1, self.top_k),
                routed_output_unsorted.to(self.top_scores.dtype),
            )
            .to(self.x.dtype)
            .squeeze(1)
        )

        # Do cloning here to ensure that experts return a not-view tensor.
        # View tensor + in-place modification later can break pre-backward hook of fsdp.
        # For example, in qwen3.5, in-place modification is applied to the output of experts: expert_output += shared_expert_output
        return out_experts.clone()

    def _apply(self, module: torch.nn.Module, device_mesh: DeviceMesh) -> torch.nn.Module:
        return distribute_module(
            module,
            device_mesh,
            partition_fn=self._partition_fn,
            # pyrefly: ignore [bad-argument-type]
            input_fn=self._token_dispatch,
            # pyrefly: ignore [bad-argument-type]
            output_fn=self._token_combine,
        )


class FSDP2StrategyBase(InferenceStrategy):
    def __init__(self, worker: Worker):
        super().__init__(worker)
        self.cpu_offload_enabled: bool = False
        if not hasattr(self, "checkpoint_manager") or self.checkpoint_manager is None:
            checkpoint_config = getattr(self.worker_config, "checkpoint_config", None)
            self.checkpoint_manager = CheckpointManager(checkpoint_config=checkpoint_config)
        self._model_update_device_buffer: Optional[torch.Tensor] = None
        self.weight_updaters = {}
        self._dcp_process_group: Optional[dist.ProcessGroup] = None

    def _get_dcp_process_group(self) -> Optional[dist.ProcessGroup]:
        if self._dcp_process_group is None:
            self._dcp_process_group = dist.new_group(backend="gloo", group_desc="roll_dcp_checkpoint_pg")
        return self._dcp_process_group

    def _get_dp_rank(self) -> int:
        rank_info = getattr(self.worker, "rank_info", None)
        if rank_info is not None and getattr(rank_info, "dp_rank", None) is not None:
            return rank_info.dp_rank
        return dist.get_rank()

    def _build_checkpoint_paths(
        self,
        base_dir: str,
        world_size: Optional[int] = None,
        dp_rank: Optional[int] = None,
    ):
        world_size = world_size or dist.get_world_size()
        dp_rank = dp_rank if dp_rank is not None else self._get_dp_rank()
        suffix = f"world_size_{world_size}_rank_{dp_rank}.pt"
        model_path = os.path.join(base_dir, f"model_{suffix}")
        optim_path = os.path.join(base_dir, f"optim_{suffix}")
        extra_path = os.path.join(base_dir, f"extra_state_{suffix}")
        return model_path, optim_path, extra_path

    @staticmethod
    def _get_dcp_checkpoint_dir(base_dir: str) -> str:
        return os.path.join(base_dir, "dcp")

    def _get_dcp_state_dict_options(self, full_state_dict: bool = False) -> StateDictOptions:
        # Always use cpu_offload=True for DCP to avoid OOM during load/save
        # independent of training offload configuration.
        return StateDictOptions(
            full_state_dict=full_state_dict,
            cpu_offload=True,
        )

    def _save_checkpoint_with_dcp(self, checkpoint_dir: str, is_last_step: bool):
        state_dict = {
            **self.model.state_dict(),
        }

        optimizer = getattr(self, "optimizer", None)
        if optimizer is not None:
            state_dict["optimizer"] = optimizer

        scheduler = getattr(self, "scheduler", None)
        if scheduler is not None:
            state_dict["scheduler"] = scheduler

        rng_state = self.get_rng_state()
        state_dict["rng_state"] = rng_state
        dcp_process_group = self._get_dcp_process_group()

        if not self.async_save_strategy or is_last_step:
            if self.checkpoint_future is not None:
                self.checkpoint_future.result()
                self.checkpoint_future = None
            dcp.save(
                state_dict=state_dict,
                checkpoint_id=checkpoint_dir,
                process_group=dcp_process_group,
            )
        else:
            if self.checkpoint_future is not None:
                self.checkpoint_future.result()
            self.checkpoint_future = dcp.async_save(
                state_dict=state_dict,
                checkpoint_id=checkpoint_dir,
                process_group=dcp_process_group,
            )

    def _load_checkpoint_with_dcp(self, checkpoint_dir: str):
        state_dict = {
            **self.model.state_dict(),
        }

        optimizer = getattr(self, "optimizer", None)
        if optimizer is not None:
            state_dict["optimizer"] = optimizer

        scheduler = getattr(self, "scheduler", None)
        if scheduler is not None:
            state_dict["scheduler"] = scheduler

        state_dict["rng_state"] = {}
        dcp_process_group = self._get_dcp_process_group()

        dcp.load(
            state_dict=state_dict,
            checkpoint_id=checkpoint_dir,
            process_group=dcp_process_group,
        )

        if "rng_state" in state_dict and state_dict["rng_state"]:
            self.load_rng_state(state_dict["rng_state"])

        info = self.model.load_state_dict(state_dict, strict=False)
        missing_keys = info.missing_keys
        unexpected_keys = info.unexpected_keys

        filtered_unexpected_keys = [
            key for key in unexpected_keys if key not in ("optimizer", "scheduler", "rng_state")
        ]

        if missing_keys:
            logger.warning(f"Missing keys: {missing_keys}")
        if filtered_unexpected_keys:
            logger.warning(f"Unexpected keys: {filtered_unexpected_keys}")

    def _load_checkpoint_from_legacy_shards(
        self,
        load_dir: str,
        world_size: int,
        dp_rank: int,
        optimizer,
    ):
        model_path, optim_path, _ = self._build_checkpoint_paths(
            load_dir,
            world_size=world_size,
            dp_rank=dp_rank,
        )

        model_state_dict = self._load_torch_file(model_path, required=True)
        optimizer_state_dict = self._load_torch_file(optim_path, required=optimizer is not None)

        if not model_state_dict:
            logger.warning("Empty model state dict loaded from %s, skipping model restore", model_path)
            return

        first_param = next(iter(model_state_dict.values()))
        if isinstance(first_param, DTensor):
            self.model.load_state_dict(model_state_dict, assign=True)
        else:
            meta_sharded_sd = self.model.state_dict()
            sharded_sd = {}
            for param_name, full_tensor in model_state_dict.items():
                if param_name in meta_sharded_sd:
                    sharded_meta_param = meta_sharded_sd[param_name]
                    if isinstance(sharded_meta_param, DTensor):
                        # Respect the DTensor's device (CPU for offload_policy=True)
                        target_device = sharded_meta_param.device
                        sharded_tensor = distribute_tensor(
                            full_tensor.to(target_device),
                            sharded_meta_param.device_mesh,
                            sharded_meta_param.placements,
                        )
                        sharded_sd[param_name] = torch.nn.Parameter(sharded_tensor)
                    else:
                        sharded_sd[param_name] = torch.nn.Parameter(full_tensor)
                else:
                    sharded_sd[param_name] = torch.nn.Parameter(full_tensor)
            self.model.load_state_dict(sharded_sd, assign=True)

        if optimizer_state_dict is not None and optimizer is not None:
            optimizer.load_state_dict(optimizer_state_dict)

    def _load_extra_state_dict(self, base_dir: str, world_size: int, dp_rank: int):
        _, _, extra_state_path = self._build_checkpoint_paths(
            base_dir,
            world_size=world_size,
            dp_rank=dp_rank,
        )

        if os.path.exists(extra_state_path):
            return torch.load(extra_state_path, map_location="cpu", weights_only=False)

        return {}

    def save_checkpoint(self, save_dir, global_step, ckpt_id, tag="checkpoint", local_state_path=None, **kwargs):
        """
        Save the sharded (DTensor) checkpoint as well as HF-compatible full weights.
        In FSDP, all ranks should coordinate:
        1. All ranks save their sharded checkpoints (model/optim/extra state) to the same directory
        2. Only rank 0 saves the full HuggingFace-compatible model
        """
        logger.info(f"save_dir: {save_dir}")
        if local_state_path is None:
            local_state_path = save_dir

        is_last_step = kwargs.get("is_last_step", None)

        if is_last_step is None:
            if self.worker_config.training_args.max_steps is not None:
                is_last_step = global_step == self.worker_config.training_args.max_steps - 1
            else:
                # If max_steps is not set, we consider all steps as the last step in case of hang for async saving
                is_last_step = True

        # PumpkinComment:
        # Why we need to wait here and also in save_dcp? Because if not, easy to hang in LoRA
        # Not sure why, but keep the logic here for now.
        if self.async_save_strategy and self.checkpoint_future is not None:
            logger.info("Waiting for previous async checkpoint to complete...")
            self.checkpoint_future.result()
            self.checkpoint_future = None

        os.makedirs(save_dir, exist_ok=True)

        with Timer("load", logger=None) as load_timer:
            self.load_states()

        with Timer("hf_save", logger=None) as hf_timer:
            full_state_options = self._get_dcp_state_dict_options(full_state_dict=True)
            full_model_state = get_model_state_dict(
                model=self.model,
                options=full_state_options,
            )

            if dist.get_rank() == 0:
                underlying_model = self.unwrap_model()
                underlying_model.save_pretrained(
                    save_dir,
                    state_dict=full_model_state,
                    safe_serialization=True,
                )
                strip_fsdp_architecture_prefix(save_dir)
                self.tokenizer.save_pretrained(save_dir)
                if getattr(self, "processor", None):
                    self.processor.save_pretrained(save_dir)

        if self.save_only_model and dist.is_initialized():
            dist.barrier()

        dcp_save_time = 0
        dcp_save_future = None
        if not self.save_only_model:
            dcp_checkpoint_dir = self._get_dcp_checkpoint_dir(save_dir)
            os.makedirs(dcp_checkpoint_dir, exist_ok=True)

            with Timer("dcp_save", logger=None) as dcp_timer:
                self._save_checkpoint_with_dcp(checkpoint_dir=dcp_checkpoint_dir, is_last_step=is_last_step)
            dcp_save_time = dcp_timer.last

            # PumpkinComment:
            # If DCP save is async, uploading (which may copy+delete the local dir) must not start
            # until the async save has fully finished writing checkpoint shards.
            dcp_save_future = self.checkpoint_future if (self.async_save_strategy and not is_last_step) else None

        checkpoint_config = getattr(self.worker_config, "checkpoint_config", None) or {}
        # the last checkpoint must be copied synchronously: the pipeline exits right after do_checkpoint and Ray kills this
        # actor with the upload thread mid-copy (ORCD 2026-10-20: 13 of 30 GB arrived, shard 3 truncated)
        async_upload = checkpoint_config.get("async_upload", True) and not is_last_step
        keep_local_file = checkpoint_config.get("keep_local_file", False)
        if dcp_save_future is not None and async_upload:

            def _on_dcp_done(fut):
                print("[DEBUG] Enter Callback for DCP save")
                try:
                    fut.result()
                except Exception:
                    logger.error(f"Async DCP save failed for ckpt_id={ckpt_id}, skip upload.")
                    return

                self.thread_executor.submit(
                    self.checkpoint_manager.upload,
                    ckpt_id=ckpt_id,
                    local_state_path=local_state_path,
                    keep_local_file=keep_local_file,
                )

            dcp_save_future.add_done_callback(_on_dcp_done)
        else:
            # If async_upload=False, block until DCP async save completes, then upload.
            if dcp_save_future is not None:
                dcp_save_future.result()

            if async_upload:
                self.thread_executor.submit(
                    self.checkpoint_manager.upload,
                    ckpt_id=ckpt_id,
                    local_state_path=local_state_path,
                    keep_local_file=keep_local_file,
                )
            else:
                self.checkpoint_manager.upload(
                    ckpt_id=ckpt_id,
                    local_state_path=local_state_path,
                    keep_local_file=keep_local_file,
                )

        # When cpu_offload is enabled, restore optimizer states back to CPU after saving.
        # Without this, optimizer.step() will fail due to device mismatch (optimizer on GPU, grads on CPU).
        with Timer("offload", logger=None) as offload_timer:
            if self.cpu_offload_enabled:
                self.offload_states()

        return {
            "load": load_timer.last,
            "offload": offload_timer.last,
            "dcp_save": dcp_save_time,
            "hf_save": hf_timer.last,
        }

    def _load_torch_file(self, path: str, required: bool = True):
        if os.path.exists(path):
            return torch.load(path, map_location="cpu", weights_only=False)
        if required:
            raise FileNotFoundError(f"Missing checkpoint shard: {path}")
        logger.warning(f"Optional checkpoint shard missing, skipping: {path}")
        return None

    def load_checkpoint(self, load_dir, tag="checkpoint", **kwargs):
        """
        Load checkpoint from a shared directory where all ranks' sharded checkpoints are stored.

        In FSDP, synchronize the load_dir across all ranks to ensure they load from the same location.
        """
        logger.info(f"load_dir: {load_dir}")

        dcp_checkpoint_dir = self._get_dcp_checkpoint_dir(load_dir)
        used_dcp = False
        if os.path.isdir(dcp_checkpoint_dir):
            if dist.is_initialized():
                dist.barrier()

            self._load_checkpoint_with_dcp(
                checkpoint_dir=dcp_checkpoint_dir,
            )
            used_dcp = True
            logger.info(f"Loaded DCP checkpoint from {dcp_checkpoint_dir}")
            if dist.is_initialized():
                dist.barrier()
            return

    @staticmethod
    def get_rng_state():
        rng_state = {
            "cpu": torch.get_rng_state(),
            "device": current_platform.get_rng_state(),
            "numpy": np.random.get_state(),
            "random": random.getstate(),
        }
        return rng_state

    @staticmethod
    def load_rng_state(rng_state):
        torch.set_rng_state(rng_state["cpu"])
        current_platform.set_rng_state(rng_state["device"])
        np.random.set_state(rng_state["numpy"])
        random.setstate(rng_state["random"])

    def _copy_weight_to_param(self, param: torch.nn.Parameter, weight: torch.Tensor):
        """
        Copy a full (replicated) tensor onto a possibly-sharded FSDP2 parameter.
        Handles DTensor placement to keep shards consistent across ranks.
        """

        target = param.data if hasattr(param, "data") else param
        source = weight.data if hasattr(weight, "data") else weight
        source = source.detach()

        if isinstance(source, DTensor):
            if isinstance(target, DTensor):
                same_mesh = source.device_mesh == target.device_mesh
                same_place = source.placements == target.placements
                if same_mesh and same_place:
                    target.copy_(source)
                    return
            source = source.full_tensor()

        if isinstance(target, DTensor):
            sharded = distribute_tensor(
                source.to(target.device),
                target.device_mesh,
                target.placements,
            )
            target.copy_(sharded)
        else:
            target.copy_(source.to(target.device))

    def _gather_full_tensor(self, param: torch.nn.Parameter) -> torch.Tensor:
        tensor = param.data if hasattr(param, "data") else param
        if isinstance(tensor, DTensor):
            original_device = tensor.device
            if original_device.type == "cpu" and current_platform.device_type != "cpu":
                tensor = tensor.to(current_platform.device_type)
            tensor = tensor.full_tensor()
            if original_device.type == "cpu":
                tensor = tensor.cpu()
            # full_tensor() already returns a new tensor from all-gather
            return tensor.detach()
        # For non-DTensor (e.g., LoRA params that aren't sharded), we need to clone
        # to avoid modifying the original parameter during bucket packing
        return tensor.detach().clone()

    def _move_optimizer_states(self, device: torch.device, non_blocking: bool = False):
        optimizer = getattr(self, "optimizer", None)
        if optimizer is None:
            return
        for state in optimizer.state.values():
            for key, value in state.items():
                if torch.is_tensor(value):
                    state[key] = value.to(device, non_blocking=non_blocking)

    def _get_broadcast_tensor(self, weight_cpu: torch.Tensor) -> torch.Tensor:
        """
        Reuse buffer to avoid allocating new memory.
        """
        if current_platform.device_type == "cpu":
            return weight_cpu
        numel = weight_cpu.numel()
        dtype = weight_cpu.dtype
        buffer = self._model_update_device_buffer
        if buffer is None or buffer.numel() < numel or buffer.dtype != dtype:
            buffer = torch.empty(numel, dtype=dtype, device=current_platform.device_type)
            self._model_update_device_buffer = buffer
        device_view = buffer[:numel].view(weight_cpu.shape)
        device_view.copy_(weight_cpu, non_blocking=True)
        return device_view

    def get_data_input(self, batch: DataProto):
        """Ensure Ulysses/context-parallel ranks receive identical data."""

        def broadcast_obj(obj, group):
            obj_list = [obj if dist.get_rank(group) == 0 else None]
            src_rank = dist.get_process_group_ranks(group)[0]
            dist.broadcast_object_list(obj_list, src=src_rank, group=group)
            return obj_list[0]

        if getattr(self.worker.rank_info, "cp_size", 1) <= 1:
            return batch

        broadcast_non_tensor_batch = batch.meta_info.get("_broadcast_non_tensor_batch", False)
        if broadcast_non_tensor_batch:
            tmp_batch = broadcast_obj(batch, get_ulysses_group())
            batch.batch = tmp_batch.batch
            batch.non_tensor_batch = tmp_batch.non_tensor_batch
        else:
            batch.batch = broadcast_obj(batch.batch, get_ulysses_group())
        return batch

    def _prepare_fsdp2_model(
        self,
        model_provider,
        *,
        is_trainable: bool,
        default_model_dtype: torch.dtype,
        warmup_collective: bool = False,
    ):

        set_seed(seed=self.worker.pipeline_config.seed)

        if not torch.distributed.is_initialized():
            if current_platform.device_type != "cpu":
                backends_str = f"cpu:gloo,{current_platform.device_type}:{current_platform.communication_backend}"
            else:
                backends_str = current_platform.communication_backend
            torch.distributed.init_process_group(backend=backends_str)

        if warmup_collective:
            dist.all_reduce(torch.zeros(1).to(current_platform.device_type))

        if self.worker_config.strategy_args.strategy_config.get("apply_tiled_mlp", False):
            from roll.third_party.fsdp2.tiled_mlp import apply_tiled_mlp_monkey_patch

            apply_tiled_mlp_monkey_patch(
                num_shards=self.worker_config.strategy_args.strategy_config.get("tiled_num_shards", 4),
                model_type=self.worker_config.strategy_args.strategy_config.get("model_type", None),
            )

        world_size = torch.distributed.get_world_size()
        global_rank = torch.distributed.get_rank()

        cp_size = self.worker_config.model_args.ulysses_size
        if cp_size > 1:
            if current_platform.apply_ulysses_patch() is not None:
                set_upg_manager(
                    ulysses_size=cp_size,
                    rank=global_rank,
                    world_size=world_size,
                )
            else:
                cp_size = 1

        if self.worker_config.model_args.ulysses_size != cp_size:
            # PumpkinComment: Fallback if something goes wrong with CP
            logger.warning(
                f"ulysses_size in config ({self.worker_config.model_args.ulysses_size}) is not equal to cp_size ({cp_size}), using cp_size instead"
            )
            self.worker_config.strategy_args.strategy_config["fsdp_size"] = (
                self.worker_config.strategy_args.strategy_config["fsdp_size"]
                * self.worker_config.model_args.ulysses_size
            )
            self.worker_config.model_args.ulysses_size = cp_size

        self.worker.rank_info.dp_rank = global_rank // cp_size
        self.worker.rank_info.dp_size = world_size // cp_size
        self.worker.rank_info.cp_rank = global_rank % cp_size
        self.worker.rank_info.cp_size = cp_size

        if cp_size > 1 and global_rank == 0:
            logger.debug(f"FSDP2 CP(Ulysses) enabled: cp_size={cp_size}, dp_size={self.worker.rank_info.dp_size}")

        self.tokenizer = default_tokenizer_provider(model_args=self.worker_config.model_args)
        self.processor = default_processor_provider(model_args=self.worker_config.model_args)

        # Stored trainable parameters/Adam states need not use the low-precision
        # forward dtype. Keep historical defaults unless model_dtype is explicit.
        torch_dtype = self.worker_config.strategy_args.strategy_config.get(
            "model_dtype", self.worker_config.strategy_args.strategy_config.get("param_dtype", default_model_dtype))
        torch_dtype = _parse_dtype(torch_dtype)
        self.worker_config.model_args.compute_dtype = torch_dtype

        fsdp_size = self.worker_config.strategy_args.strategy_config.get("fsdp_size", 1)
        assert fsdp_size >= cp_size, "fsdp size should be greater than cp size."

        # Get expert parallel config
        efsdp_size = self.worker_config.strategy_args.strategy_config.get("efsdp_size", 1)
        ep_size = self.worker_config.strategy_args.strategy_config.get("ep_size", 1)
        moe_use_grouped_mm = self.worker_config.strategy_args.strategy_config.get("moe_use_grouped_mm", False)
        self.ep_enabled = ep_size > 1

        # Check efsdp, ep size
        if self.ep_enabled:
            assert version.parse(transformers.__version__) >= version.parse("5.2.0")

            moe_model_size = efsdp_size * ep_size
            assert moe_model_size > 0 and moe_model_size <= world_size and world_size % moe_model_size == 0, \
                f"efsdp_size * ep_size {moe_model_size} must be in [1, world_size({world_size})], and divisible by world_size {world_size}"

        if moe_use_grouped_mm and self.ep_enabled:
            set_use_grouped_mm(True)

        # Patch ExpertsInterface to offer more options of forward function in transformers's MoeExperts
        if self.ep_enabled:
            register_experts_forward_in_ExpertsInterface()

        # Create device mesh
        self.device_mesh, self.moe_device_mesh = create_device_mesh_with_ep(world_size=world_size, fsdp_size=fsdp_size, efsdp_size=efsdp_size, ep_size=ep_size)

        model_name_or_path = download_model(self.worker_config.model_args.model_name_or_path)
        config = AutoConfig.from_pretrained(
            model_name_or_path,
            trust_remote_code=True,
            **self.worker_config.model_args.model_config_kwargs,
        )

        self._validate_ulysses_compat(config, cp_size)

        use_meta_tensor = not getattr(config, "tie_word_embeddings", False) and not self.ep_enabled
        # accelerate v1.7.0 don't support _is_hf_initialized which is needed by use_meta_tensor
        if version.parse(accelerate.__version__) == version.parse("1.7.0"):
            use_meta_tensor = False
        init_context = get_init_weight_context_manager(
            use_meta_tensor=use_meta_tensor,
            mesh=self.device_mesh,
        )

        set_fsdp2_init_context(init_context)
        try:
            model = model_provider(
                tokenizer=self.tokenizer,
                model_args=self.worker_config.model_args,
                is_trainable=is_trainable,
            )
        finally:
            clear_fsdp2_init_context()

        self.is_lora = self.worker_config.model_args.lora_target is not None

        # Set _experts_implementation
        layers = self._get_layers(model)

        if self.ep_enabled:
            layers[0].mlp.experts.config._experts_implementation = "ep"
        elif moe_use_grouped_mm:
            assert version.parse(transformers.__version__) >= version.parse("5.2.0"), "moe_use_grouped_mm requires transformers>=5.2.0"
            layers[0].mlp.experts.config._experts_implementation = "grouped_mm"

        return model, torch_dtype, cp_size

    def _get_layers(self, model):
        if self.is_lora: # PeftModel
            base_model = model.base_model.model.model
        else:
            base_model = model.model
        
        if hasattr(base_model, "layers"):
            return base_model.layers
        else: # multi-modal model
            return base_model.language_model.layers

    @staticmethod
    def _validate_ulysses_compat(config, cp_size: int):
        try:
            num_attention_heads, num_key_value_heads = (
                config.num_attention_heads,
                config.num_key_value_heads,
            )
        except AttributeError:
            num_attention_heads, num_key_value_heads = (
                config.text_config.num_attention_heads,
                config.text_config.num_key_value_heads,
            )

        assert (
            num_attention_heads % cp_size == 0
        ), f"num_attention_heads {num_attention_heads} must be divisible by ulysses_size {cp_size}"
        assert num_key_value_heads % cp_size == 0 or cp_size % num_key_value_heads == 0, (
            f"num_key_value_heads {num_key_value_heads} must be divisible by ulysses_size "
            f"{cp_size}or vise versa. Upon ulysses_size % num_key_value_heads == 0,"
            f"kv heads are repeated to ensure correctness."
        )

    def load_states(self, include=None, non_blocking=False):
        if not self.cpu_offload_enabled:
            if include is None or OffloadStateType.model_params in include:
                device = current_platform.current_device()
                self.model.to(device, non_blocking=non_blocking)
            # When cpu_offload is disabled, always keep optimizer states on GPU
            self._move_optimizer_states(current_platform.current_device(), non_blocking=non_blocking)
        else:
            # When cpu_offload is enabled, only load optimizer states if requested
            if include is None or OffloadStateType.optimizer_states in include:
                self._move_optimizer_states(
                    current_platform.current_device(),
                    non_blocking=non_blocking,
                )

    def offload_states(self, include=None, non_blocking=False):
        """ "
        PumpkinComment:

        If CPUOFFloadPolicy is True: Every thing about offload /load model param is built from FSDP2.
        If CPUOFFloadPolicy is False: The model param in on GPU, we need to mvoe the optimizer to GPU as well.

        Therefore, we actually could leave model param. offload/onload logic to FSDP2 during training
        But here, I maintain mannual support and compatible with FSDP2 CPUOFFloadPolicy for other offload logic.
        """
        if not self.cpu_offload_enabled:
            if include is None or OffloadStateType.model_params in include:
                self.model.to("cpu", non_blocking=non_blocking)
                current_platform.empty_cache()
            # When cpu_offload is disabled, optimizer states should stay on GPU
            # Only offload optimizer states if cpu_offload is enabled
        else:
            # When cpu_offload is enabled, offload optimizer states
            if include is None or OffloadStateType.optimizer_states in include:
                self._move_optimizer_states(torch.device("cpu"), non_blocking=non_blocking)


class FSDP2InferStrategy(FSDP2StrategyBase):
    strategy_name = "fsdp2_infer"

    def __init__(self, worker: Worker):
        super().__init__(worker)
        self.device_mesh = None
        self.fsdp_config = None

    def initialize(self, model_provider):
        model, torch_dtype, _ = self._prepare_fsdp2_model(
            model_provider,
            is_trainable=False,
            default_model_dtype=torch.bfloat16,
        )

        # Initialize expert parallel model (must be before FSDP2 wrapping)
        if self.ep_enabled:
            self.apply_moe_ep(model)

        self.setup_fsdp2_configuration()
        self.initialize_fsdp2_model(model)

        dist.barrier()

    def setup_fsdp2_configuration(self):
        """Setup FSDP-2 configuration"""
        # ckpt strategy
        async_save_strategy = self.worker_config.strategy_args.strategy_config.get("async_save_ckpt", True)
        self.async_save_strategy = async_save_strategy
        if self.async_save_strategy:
            self.checkpoint_future = None
        self.save_only_model = self.worker_config.strategy_args.strategy_config.get("save_only_model", False)

        # Get mixed precision settings from config
        param_dtype = self.worker_config.strategy_args.strategy_config.get("param_dtype", torch.bfloat16)
        reduce_dtype = self.worker_config.strategy_args.strategy_config.get("reduce_dtype", torch.float32)

        # Convert string dtype specifications to torch.dtype
        param_dtype = _parse_dtype(param_dtype)
        reduce_dtype = _parse_dtype(reduce_dtype)
        self.param_dtype = param_dtype
        self.reduce_dtype = reduce_dtype

        mixed_precision = MixedPrecisionPolicy(
            param_dtype=param_dtype,
            reduce_dtype=reduce_dtype,
            cast_forward_inputs=True,
        )

        # Reshard after forward setting (FSDP2 uses this instead of sharding_strategy)
        # FULL_SHARD: reshard_after_forward=True
        # SHARD_GRAD_OP: reshard_after_forward=False
        # HYBRID_SHARD: reshard_after_forward=True with a 2D device mesh
        # HYBRID_SHARD_ZERO2: reshard_after_forward=False with a 2D device mesh
        # If None, True for submodules, False for root module
        reshard_after_forward = self.worker_config.strategy_args.strategy_config.get("reshard_after_forward", None)

        offload_policy_cfg = self.worker_config.strategy_args.strategy_config.get("offload_policy", False)
        self.cpu_offload_enabled = bool(offload_policy_cfg)

        # Perform reduce scatter during gradient accumulation.
        # Default to True, because it decrease cuda memory usage and increase training speed according to tests.
        self.reduce_scatter_during_grad_accumulation = bool(
            self.worker_config.strategy_args.strategy_config.get("reduce_scatter_during_grad_accumulation", True)
        )
        if self.reduce_scatter_during_grad_accumulation:
            logger.info("[FSDP2] reduce_scatter_during_grad_accumulation is ENABLED")

        offload_policy = None
        if self.cpu_offload_enabled:
            offload_policy = CPUOffloadPolicy(
                pin_memory=True,
            )

        # Store configuration for fully_shard()
        print(f"[DEBUG] fsdp_config: {self.worker_config.strategy_args.strategy_config.get('fsdp_size', 1)}")
        self.fsdp_config = {
            "mesh": self.device_mesh,
            "reshard_after_forward": reshard_after_forward,
            "mp_policy": mixed_precision,
            "offload_policy": offload_policy,
            "shard_placement_fn": get_shard_placement_fn(
                fsdp_size=self.worker_config.strategy_args.strategy_config.get("fsdp_size", 1)
            ),
        }
        self.moe_fsdp_config = self.fsdp_config.copy()
        if self.ep_enabled:
            self.moe_fsdp_config["mesh"] = self.moe_device_mesh["eddp", "efsdp"] if "eddp" in self.moe_device_mesh.mesh_dim_names else self.moe_device_mesh["efsdp"]
            self.moe_fsdp_config["shard_placement_fn"] = get_shard_placement_fn_ep(
                efsdp_size=self.worker_config.strategy_args.strategy_config.get("efsdp_size", 1),
            )

    def apply_moe_ep(self, model):
        layers = self._get_layers(model)

        num_experts = layers[0].mlp.experts.num_experts
        experts_plan = ExpertParallel(num_experts=num_experts)
        experts_mesh = self.moe_device_mesh["ep"]
        for layer in layers:
            if hasattr(layer.mlp, "experts"):
                parallelize_module(
                    module=layer.mlp.experts,
                    device_mesh=experts_mesh,
                    parallelize_plan=experts_plan,
                )

    def initialize_fsdp2_model(self, model):
        offload_policy = self.fsdp_config["offload_policy"]

        # Use nn.Module.state_dict() instead of model.state_dict() to get standard FQN keys
        # (e.g. 'pretrained_model.model.layers.0...') that match what PyTorch's
        # _iterate_valid_model_state() returns internally. Custom state_dict() methods
        # (like AutoModelForCausalLMWithValueHead's) may strip prefixes, causing key
        # mismatches in _broadcast_state_dict during FSDP2 initialization.
        full_state = torch.nn.Module.state_dict(model)
        apply_fsdp2(
            model,
            self.fsdp_config,
            self.moe_fsdp_config,
            self.worker_config.strategy_args.strategy_config,
            self.is_lora,
        )

        fsdp2_load_full_state_dict(
            model,
            full_state,
            self.device_mesh,
            offload_policy,
            self.ep_enabled,
        )

        self.model = model

    # Add torch.no_grad() to disable gradient calculation.
    # torch.no_grad() in pipeline cannot work because pipeline and worker are in different processes.
    @torch.no_grad()
    def forward_step(
        self,
        batch: DataProto,
        forward_func: Callable[
            [DataProto, torch.Tensor],
            Tuple[torch.Tensor, Dict[str, torch.Tensor]],
        ],
    ) -> Dict[str, torch.Tensor]:
        self.model.eval()
        batch_size = batch.batch.batch_size[0]
        micro_batch_size = batch.meta_info["micro_batch_size"]
        num_microbatches = max(batch_size // micro_batch_size, 1)
        micro_batches = batch.chunk(chunks=num_microbatches)

        cp_size = self.worker.rank_info.cp_size
        batch_num_tokens = self._get_batch_num_tokens(batch)
        batch.meta_info["batch_num_tokens"] = {k: v // cp_size for k, v in batch_num_tokens.items()}
        global_valid_tokens = self._get_global_valid_samples(batch)
        batch.meta_info["global_valid_samples"] = {k: v // cp_size for k, v in global_valid_tokens.items()}

        loss_scale = num_microbatches * self.worker.rank_info.dp_size

        disable_adapter = batch.meta_info.get("disable_adapter", False)
        adapter_context = self.unwrap_model().disable_adapter() if disable_adapter else nullcontext()
        losses_reduced = []

        with adapter_context:
            for data in micro_batches:
                with torch.autocast(
                    device_type=current_platform.device_type,
                    dtype=self.param_dtype,
                ):
                    input_ids = data.batch["input_ids"]
                    attention_mask = data.batch["attention_mask"]
                    position_ids = data.batch["position_ids"]
                    forward_args = data.meta_info.get("forward_args", {})
                    if position_ids.dim() == 3:
                        # qwen-vl mrope-style 3D position_ids stored in DataProto as (bsz, C, seqlen)
                        # transpose to (C, bsz, seqlen) for model forward.
                        position_ids = position_ids.transpose(0, 1)  # (bsz, C, seqlen) -> (C, bsz, seqlen)
                    if "multi_modal_inputs" in data.non_tensor_batch:
                        multi_modal_inputs = data.non_tensor_batch["multi_modal_inputs"]
                        multi_modal_data = defaultdict(list)
                        # mm inputs of some samples would be empty to allow text and mm mixed data
                        for sample_mm_inputs in multi_modal_inputs:
                            for key in sample_mm_inputs.keys():
                                multi_modal_data[key].append(sample_mm_inputs[key])
                        for key in multi_modal_data.keys():
                            assert key not in forward_args
                            mm_data = multi_modal_data[key]
                            # All mm fields are not padded in collator currently and some should be padded first
                            # pixel_values/pixel_values_videos for images/videos are concated for packing
                            # input_features for audios with shape `(bs, freqs, frames)` should be padded before concat
                            need_padding = any(t.shape[-1] != mm_data[0].shape[-1] for t in mm_data[1:])
                            if need_padding:  # input_features/feature_attention_mask
                                max_mm_len = max(t.shape[-1] for t in mm_data)
                                for i, t in enumerate(mm_data):
                                    mm_data[i] = torch.nn.functional.pad(t, (0, max_mm_len - t.shape[-1]), "constant", 0)
                            # DataProto.to('cuda') in upper frame not work for non_tensor_batch
                            forward_args[key] = torch.concat(multi_modal_data[key], dim=0).to(input_ids.device)
                        forward_args.update({"force_vit_image": True})

                    logits = self._fsdp2_forward(
                        input_ids=input_ids,
                        attention_mask=attention_mask,
                        position_ids=position_ids,
                        forward_args=forward_args,
                    )

                    loss, loss_reduced = forward_func(data, logits)
                    if self.worker_config.apply_loss_scale:
                        loss *= loss_scale
                losses_reduced.append(loss_reduced)

        results = collate_fn_to_dict_list(losses_reduced)
        return results

    def get_feature_on_cp_rank(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor = None,
        position_ids: torch.Tensor = None,
    ):
        """Get features for specific context parallel rank"""
        seqlens_in_batch = input_ids.size(1)
        assert (
            seqlens_in_batch % self.worker.rank_info.cp_size == 0
        ), f"input_length={seqlens_in_batch} not divisible by cp_size={self.worker.rank_info.cp_size}"
        cp_middle_rank_len = seqlens_in_batch // self.worker.rank_info.cp_size
        padded_input_ids = input_ids
        result = {}
        start_index = cp_middle_rank_len * self.worker.rank_info.cp_rank
        end_index = cp_middle_rank_len * (self.worker.rank_info.cp_rank + 1)
        result["input_ids"] = padded_input_ids[:, start_index:end_index]
        if attention_mask is not None:
            result["attention_mask"] = attention_mask[:, start_index:end_index]
        if position_ids is not None:
            if position_ids.dim() == 3:
                result["position_ids"] = position_ids[:, :, start_index:end_index]
            else:
                result["position_ids"] = position_ids[:, start_index:end_index]
        return result

    def _fsdp2_forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        position_ids: torch.Tensor,
        forward_args: Dict[str, torch.Tensor],
    ) -> torch.Tensor:
        cp_size = self.worker.rank_info.cp_size
        cp_rank = self.worker.rank_info.cp_rank

        # PumpkinComment:
        # - do NOT slice padded tensors first (would reintroduce imbalance)
        # - unpad to token stream, pad-to-multiple-of-cp, slice equally, run model with attn_mask=None
        # - gather outputs and unpad, then pad back to original (bs, seqlen) so downstream remains unchanged
        if cp_size > 1:
            underlying = self.unwrap_model()
            model_type = getattr(getattr(underlying, "config", None), "model_type", "") or ""
            is_vlm = getattr(getattr(underlying, "config", None), "vision_config", None) is not None
            is_supported_vlm = is_vlm and model_type in ("qwen2_5_vl", "qwen3_vl")

            if not is_supported_vlm:
                features = self.get_feature_on_cp_rank(input_ids, attention_mask, position_ids)
                input_ids = features["input_ids"]
                attention_mask = features["attention_mask"]
                position_ids = features["position_ids"]

        # Ensure use_cache is False if not specified (matches HF strategy)
        if "use_cache" not in forward_args:
            forward_args["use_cache"] = False

        return self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            **forward_args,
        ).logits

    def generate(self, batch: DataProto, generation_config):
        if self.worker.rank_info.cp_size > 1:
            raise RuntimeError("FSDP2 generate() is not supported with CP(Ulysses) enabled yet. ")
        input_ids = batch.batch["input_ids"]  # (bs, prompt_length)
        attention_mask = batch.batch["attention_mask"]  # left-padded attention_mask

        output = self.model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            use_cache=True,
            **generation_config,
        )

        return output

    def unwrap_model(self):
        if hasattr(self.model, "module"):
            return self.model.module
        return self.model

    def broadcast_parameter(
        self,
        model_update_name,
        src_pp_rank,
        dtype,
        shape,
        parameter_name,
        is_lora=False,
    ):
        if model_update_name not in self.model_update_comm_plan:
            self.model_update_comm_plan[model_update_name] = {}
        if src_pp_rank not in self.model_update_comm_plan[model_update_name]:
            self._setup_collective_group_impl(
                model_update_name=model_update_name,
                comm_plan=None,
                backend=None,
                mode="receiver",
            )
        comm_plan = self.model_update_comm_plan[model_update_name][src_pp_rank]
        weight = torch.empty(shape, dtype=dtype, device=current_platform.device_type)
        collective.broadcast(tensor=weight, src_rank=0, group_name=comm_plan["group_name"])
        param = self.model.get_parameter(parameter_name)
        self._copy_weight_to_param(param, weight)
        del weight

    def update_parameter(
        self,
        model_update_name,
        parameter_name,
        weight,
        ranks_in_worker,
        is_lora: bool = False,
    ):
        # TODO: Update in bucket
        param = self.model.get_parameter(parameter_name)
        self._copy_weight_to_param(param, weight)
        del weight

    def op_compute_log_probs(
        self,
        logits: torch.Tensor,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
    ):
        """
        input_ids [[p, p, r, r, r, 0, 0]] p: prompt, r: response, 0: pad
        response_mask [[0, 0, 1, 1, 1, 0, 0]]
        """
        # Create labels from FULL input_ids (shifted by 1)
        labels: torch.Tensor = input_ids[:, 1:].clone()
        labels[attention_mask[:, 1:] == 0] = 0  # avoid invalid token id

        if self.worker.rank_info.cp_size > 1:
            # For CP: slice the shifted labels to match the sharded logits
            # logits are sharded across sequence dimension by Ulysses
            labels = torch.cat([labels, torch.zeros_like(labels[:, :1])], dim=1)
            labels = self.get_feature_on_cp_rank(labels)["input_ids"]

            # Compute log_probs for this CP rank
            log_probs = log_probs_from_logits(logits, labels)

            log_probs = ulysses_gather(
                log_probs,
                gather_dim=1,
                group=get_ulysses_group(),
                grad_scaler=True,
            )

            # Apply mask using FULL attention_mask and handle the shift
            log_probs = log_probs[:, :-1] * attention_mask[:, 1:]
        else:
            # Non-CP path: original logic
            labels = torch.cat([labels, torch.zeros_like(labels[:, :1])], dim=1)
            log_probs = log_probs_from_logits(logits, labels)
            log_probs = log_probs[:, :-1] * attention_mask[:, 1:]

        return log_probs

    def op_compute_entropy(self, logits: torch.Tensor, attention_mask: torch.Tensor):
        from roll.utils.functionals import entropy_from_logits

        entropy = entropy_from_logits(logits)
        if self.worker.rank_info.cp_size > 1:
            entropy = ulysses_gather(
                entropy,
                gather_dim=1,
                group=get_ulysses_group(),
                grad_scaler=True,
            )
        entropy = entropy[:, :-1] * attention_mask[:, 1:]
        return entropy


class FSDP2TrainStrategy(FSDP2InferStrategy, TrainStrategy):
    strategy_name = "fsdp2_train"

    def initialize(self, model_provider):
        model, torch_dtype, _ = self._prepare_fsdp2_model(
            model_provider,
            is_trainable=True,
            default_model_dtype=torch.float32,
            warmup_collective=True,
        )

        logger.info(f"max steps pipeline {self.worker_config.training_args.max_steps}")
        self.worker_config.training_args.max_steps = (
            self.worker_config.training_args.max_steps // self.worker.rank_info.dp_size
        )
        logger.info(f"max steps worker train {self.worker_config.training_args.max_steps}")

        # Initialize expert parallel model
        if self.ep_enabled:
            self.apply_moe_ep(model)

        # Setup FSDP-2 configuration
        self.setup_fsdp2_configuration()

        if self.param_dtype == torch.float16:
            from torch.distributed.fsdp.sharded_grad_scaler import ShardedGradScaler

            self.scaler = ShardedGradScaler(growth_interval=400)
        else:
            self.scaler = None

        # Initialize FSDP-2 model
        self.initialize_fsdp2_model(model)

        # In-case of LoRA
        trainable_params = (param for param in self.model.parameters() if param.requires_grad)
        self.optimizer = optim.AdamW(
            trainable_params,
            lr=self.worker_config.training_args.learning_rate,
            betas=(
                self.worker_config.training_args.adam_beta1,
                self.worker_config.training_args.adam_beta2,
            ),
            weight_decay=self.worker_config.training_args.weight_decay,
        )

        self.scheduler = get_scheduler(
            self.worker_config.training_args.lr_scheduler_type,
            self.optimizer,
            num_warmup_steps=self.worker_config.training_args.get_warmup_steps(
                self.worker_config.training_args.max_steps
            ),
            num_training_steps=self.worker_config.training_args.max_steps,
        )

        dist.barrier()

    def _grad_accumulation_context(self):
        set_sync_fn = getattr(self.model, "set_requires_gradient_sync", None)
        if callable(set_sync_fn):
            return self._requires_grad_sync_context(set_sync_fn)

        no_sync_method = getattr(self.model, "no_sync", None)
        if callable(no_sync_method):
            return no_sync_method()

        return contextlib.nullcontext()

    @contextlib.contextmanager
    def _requires_grad_sync_context(self, set_sync_fn):
        set_sync_fn(False)
        try:
            yield
        finally:
            set_sync_fn(True)

    def _clip_grad_norm(self, max_norm: float):
        if not self.cpu_offload_enabled and not self.ep_enabled:
            grad_norm = clip_grad_norm_(
                self.model.parameters(),
                max_norm=max_norm,
            )
        elif not self.cpu_offload_enabled:
            grad_norm = self._clip_grad_norm_with_ep(max_norm)
        elif not self.ep_enabled:
            grad_norm = self._clip_grad_norm_cpu_offload(max_norm)
        else:
            grad_norm = self._clip_grad_norm_with_ep(max_norm, cpu_offload_enabled=True)

        if isinstance(grad_norm, DTensor):
            grad_norm = grad_norm.full_tensor()

        return grad_norm
    
    @torch.no_grad()
    def _clip_grad_norm_with_ep(self, max_norm: float, cpu_offload_enabled: bool = False):
        """
        Reference to torchtitan's _clip_grad_norm_with_ep:
        Reference: https://github.com/pytorch/torchtitan/blob/main/torchtitan/distributed/utils.py #L479 #v0.2.2
        """
        parameters = list(self.model.parameters())
        ep_params = []
        non_ep_params = []
        ep_grads = []
        non_ep_grads = []

        for p in parameters:
            if p.grad is None:
                continue
            assert isinstance(p, DTensor) and isinstance(p.grad, DTensor)
            mesh_dim_names = p.device_mesh.mesh_dim_names
            assert mesh_dim_names is not None
            if "efsdp" in mesh_dim_names:
                # Divide the gradient of the moe parameter by ep to ensure that the gradient is calculated from data on a single rank,
                # keeping it aligned with fsdp.
                ep_size = self.worker_config.strategy_args.strategy_config.get("ep_size", 1)
                p.grad.div_(ep_size)
                ep_params.append(p)
                ep_grads.append(p.grad)
            else:
                non_ep_params.append(p)
                non_ep_grads.append(p.grad)

        # Either list can be empty depending on the parallelization strategy:
        # - In torchtitan with separate dense/sparse meshes, both lists are typically non-empty
        # - In autoparallel, all params may live on a single sparse mesh with "ep" dimension,
        #   so non_ep_grads would be empty
        # - In PP + EP setups, certain PP ranks may only own EP or non-EP layers
        ep_grads_total_norm = _get_total_norm(
            ep_grads,
            norm_type=2.0,
            error_if_nonfinite=False,
            foreach=None,
        )
        # get_total_norm returns tensor(0.) for empty list, which is a non-DTensor
        if isinstance(ep_grads_total_norm, DTensor):
            ep_grads_total_norm = ep_grads_total_norm.full_tensor()

        non_ep_grads_total_norm = _get_total_norm(
            non_ep_grads,
            norm_type=2.0,
            error_if_nonfinite=False,
            foreach=None,
        )
        # get_total_norm returns tensor(0.) for empty list, which is a non-DTensor
        if isinstance(non_ep_grads_total_norm, DTensor):
            non_ep_grads_total_norm = non_ep_grads_total_norm.full_tensor()

        # move norm scalar to GPU
        if cpu_offload_enabled:
            ep_grads_total_norm = ep_grads_total_norm.to(current_platform.current_device(), non_blocking=True)
            non_ep_grads_total_norm = non_ep_grads_total_norm.to(current_platform.current_device(), non_blocking=True)

        # Calculate total norm
        norm_type = 2.0
        total_norm = (
            ep_grads_total_norm**norm_type + non_ep_grads_total_norm**norm_type
        )
        total_norm **= 1.0 / norm_type

        # Do clipping
        _clip_grads_with_norm_(
            ep_params,
            max_norm=max_norm,
            total_norm=total_norm,
            foreach=None,
        )
        _clip_grads_with_norm_(
            non_ep_params,
            max_norm=max_norm,
            total_norm=total_norm,
            foreach=None,
        )

        return total_norm

    def _clip_grad_norm_cpu_offload(self, max_norm: float):
        """
        Mirror VERL's fsdp2_clip_grad_norm_:
        1. operate on local gradients
        2. move norm scalar to GPU (avoid CPU DTensor collectives)

        Reference: https://github.com/volcengine/verl/blob/main/verl/utils/fsdp_utils.py#L566
        Related discussion: https://github.com/volcengine/verl/pull/1026#discussion_r2064879123
        """
        parameters = list(self.model.parameters())
        grads = [p.grad for p in parameters if getattr(p, "grad", None) is not None]
        if not grads:
            device = current_platform.current_device()
            return torch.zeros(1, device=device)

        total_norm = _get_total_norm(
            grads,
            norm_type=2.0,
            error_if_nonfinite=False,
            foreach=None,
        )
        total_norm = total_norm.to(current_platform.current_device(), non_blocking=True)
        _clip_grads_with_norm_(
            parameters,
            max_norm=max_norm,
            total_norm=total_norm,
            foreach=None,
        )
        return total_norm

    def train_step(
        self,
        batch: DataProto,
        loss_func: Callable[
            [DataProto, torch.Tensor],
            Tuple[torch.Tensor, Dict[str, torch.Tensor]],
        ],
        no_sync: bool = False,
    ):
        """
        Comment:
        no_sync: Usually, the inner step already handle no-sync, but leave this option for user if want other accumulation logic
        """
        self.model.train()
        mini_batch_size = self.worker_config.training_args.per_device_train_batch_size
        data_iter = batch.make_iterator(mini_batch_size=mini_batch_size, epochs=1)
        mini_steps = batch.batch.batch_size[0] // self.worker_config.training_args.per_device_train_batch_size

        cp_size = self.worker.rank_info.cp_size
        batch_num_tokens = self._get_batch_num_tokens(batch)
        batch.meta_info["batch_num_tokens"] = {k: v // cp_size for k, v in batch_num_tokens.items()}
        global_valid_tokens = self._get_global_valid_samples(batch)
        batch.meta_info["global_valid_samples"] = {k: v // cp_size for k, v in global_valid_tokens.items()}
        loss_scale = mini_steps * self.worker.rank_info.dp_size
        batch.meta_info["micro_batch_size"] = mini_batch_size

        gradient_accumulation_steps = self.worker_config.training_args.gradient_accumulation_steps

        metrics = {}
        cp_size = max(self.worker.rank_info.cp_size, 1)

        for step in range(mini_steps):
            data: DataProto = next(data_iter)
            input_ids = data.batch["input_ids"]
            attention_mask = data.batch["attention_mask"]
            position_ids = data.batch["position_ids"]
            forward_args = data.meta_info.get("forward_args", {})
            if position_ids.dim() == 3:
                position_ids = position_ids.transpose(0, 1)  # (bsz, C, seqlen) -> (C, bsz, seqlen)
            if "multi_modal_inputs" in data.non_tensor_batch:
                multi_modal_inputs = data.non_tensor_batch["multi_modal_inputs"]
                multi_modal_data = defaultdict(list)
                for sample_mm_inputs in multi_modal_inputs:
                    for key in sample_mm_inputs.keys():
                        multi_modal_data[key].append(sample_mm_inputs[key])
                for key in multi_modal_data.keys():
                    assert key not in forward_args
                    forward_args[key] = torch.concat(multi_modal_data[key], dim=0).to(input_ids.device)
                forward_args.update({"force_vit_image": True})

            sync_boundary = ((step + 1) % gradient_accumulation_steps == 0 or (step + 1 == mini_steps)) and not no_sync

            # PumpkinComment:
            # model.no_sync is replaced by model.set_requires_gradient_sync(False) in FSDP2
            # but also add support for model.no_sync for compatibility
            #
            # When reduce_scatter_during_grad_accumulation is enabled, sync every step to decrease cuda memory usage.
            # Reference: https://docs.pytorch.org/docs/stable/fsdp.html#torch.distributed.fsdp.FullyShardedDataParallel.no_sync
            if self.reduce_scatter_during_grad_accumulation:
                sync_context = contextlib.nullcontext()
            else:
                sync_context = (
                    self._grad_accumulation_context() if not sync_boundary and not no_sync else contextlib.nullcontext()
                )

            with (
                sync_context,
                torch.autocast(
                    device_type=current_platform.device_type,
                    dtype=self.param_dtype,
                ),
            ):
                logits = self._fsdp2_forward(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    position_ids=position_ids,
                    forward_args=forward_args,
                )

                loss, loss_reduced = loss_func(data, logits)
                append_to_dict(metrics, loss_reduced)

                if self.worker_config.apply_loss_scale:
                    loss *= loss_scale

                loss = loss / gradient_accumulation_steps

                if self.scaler is not None:
                    self.scaler.scale(loss).backward()
                else:
                    loss.backward()

            if sync_boundary:
                if self.scaler is not None:
                    self.scaler.unscale_(self.optimizer)
                grad_norm = self._clip_grad_norm(
                    max_norm=self.worker.pipeline_config.max_grad_norm,
                )
                metrics[f"{self.worker_config.name}/grad_norm"] = grad_norm.item()

                if self.scaler is not None:
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                else:
                    if not torch.isfinite(grad_norm):
                        logger.warning(f"WARN: rank {dist.get_rank()} grad_norm is not finite: {grad_norm}")
                    else:
                        self.optimizer.step()
                    self.scheduler.step()
                    self.optimizer.zero_grad(set_to_none=True)


        # Log cuda memory
        max_memory_allocated = torch.cuda.memory.max_memory_allocated() / (1024 ** 3)
        max_memory_reserved = torch.cuda.memory.max_memory_reserved() / (1024 ** 3)
        metrics[f"system/max_memory_allocated@max"] = max_memory_allocated
        metrics[f"system/max_memory_reserved@max"] = max_memory_reserved
        return metrics

    def setup_model_update(self, infer_cluster, model_update_name: str):
        assert model_update_name not in self.weight_updaters
        is_lora = self.worker_config.model_args.lora_target is not None
        self.weight_updaters[model_update_name] = FSDP2WeightUpdater(
            pipeline_config=self.worker.pipeline_config,
            infer_cluster=infer_cluster,
            worker_config=self.worker_config,
            model_update_name=model_update_name,
            model=self.unwrap_model(),
            is_lora=is_lora,
        )

    def model_update(self, model_update_name: str):
        return self.weight_updaters[model_update_name].model_update()
    
    def get_labels_on_cp_rank(
        self,
        labels: torch.Tensor,
    ):
        """Get labels for specific context parallel rank"""
        seqlens_in_batch = labels.size(1)
        assert (
            seqlens_in_batch % self.worker.rank_info.cp_size == 0
        ), f"input_length={seqlens_in_batch} not divisible by cp_size={self.worker.rank_info.cp_size}"
        cp_middle_rank_len = seqlens_in_batch // self.worker.rank_info.cp_size
        padded_labels = labels
        start_index = cp_middle_rank_len * self.worker.rank_info.cp_rank
        end_index = cp_middle_rank_len * (self.worker.rank_info.cp_rank + 1)
        labels_this_cp_rank = padded_labels[:, start_index:end_index]
        return labels_this_cp_rank

    def op_compute_language_loss(self, logits: torch.Tensor, labels: torch.Tensor, batch_num_tokens: int):
        """
        Override for FSDP2 strategy: compute language loss from logits.

        In FSDP2 strategy with HuggingFace models, the model returns logits
        (not per-token loss like in Megatron strategy where labels are passed to the model).

        Note: DataCollatorForSFT already shifts labels (shift_feature=True by default),
        so logits and labels are already aligned. Do NOT shift again here.

        Args:
            logits: Model output logits [batch_size, seq_len, vocab_size]
            labels: Pre-shifted labels [batch_size, seq_len], already aligned with logits
            batch_num_tokens: Number of valid tokens for loss normalization

        Returns:
            loss: Scalar loss tensor
            metrics: Dict
        """
        cp_size = self.worker.rank_info.cp_size
        # Slice labels to match the sharded logits
        if cp_size > 1:
            labels = self.get_labels_on_cp_rank(labels)
            labels = labels.contiguous()
        
        # Compute per-token loss mask
        loss_mask = (labels != IGNORE_INDEX).float()
        loss_mask = loss_mask.view(-1).float()
        
        # Compute cross entropy loss per token (reduction='none' to get per-token losses)
        per_token_losses = torch.nn.functional.cross_entropy(
            logits.view(-1, logits.size(-1)),
            labels.view(-1),
            ignore_index=IGNORE_INDEX,
            reduction='none',  # Get per-token loss
        )
        
        # Apply loss mask and sum
        losses_sum = torch.sum(per_token_losses.view(-1) * loss_mask)
        
        # All-reduce across CP ranks
        if cp_size > 1:
            loss_info = torch.cat([losses_sum.view(1)])
            dist.all_reduce(
                loss_info, op=dist.ReduceOp.SUM, group=get_ulysses_group()
            )
            losses_sum = loss_info[0]
        
        # Normalize by batch_num_tokens
        loss = losses_sum.clone() / batch_num_tokens  # clone to make sure loss is not a view
        
        metrics = {f"{self.worker_config.name}/loss@sum": loss.clone().detach().item()}

        return loss, metrics
