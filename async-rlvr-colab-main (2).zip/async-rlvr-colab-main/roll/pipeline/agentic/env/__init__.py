"""
base agentic codes reference: https://github.com/RAGEN-AI/RAGEN
"""
import gem

from roll.utils.logging import get_logger
logger = get_logger()

gem.register("sokoban", entry_point="roll.pipeline.agentic.env.sokoban:SokobanEnv")
gem.register("frozen_lake", entry_point="roll.pipeline.agentic.env.frozen_lake:FrozenLakeEnv")
gem.register("sokoban_mcp", entry_point="roll.pipeline.agentic.env.mcp:SokobanMCPEnv")
gem.register("roll_math", entry_point="roll.pipeline.agentic.env.gem.math_env:MathEnv")
gem.register("roll_code", entry_point="roll.pipeline.agentic.env.gem.code_env:CodeEnv")
gem.register("roll_qa", entry_point="roll.pipeline.agentic.env.gem.qa_env:QaEnv")
gem.register("sokoban_sandbox", entry_point="roll.pipeline.agentic.env.sandbox:SokobanSandboxEnv")
gem.register("sokoban_native_env", entry_point="roll.pipeline.agentic.env.sokoban.native_env:SokobanNativeEnv")
gem.register("sokoban_tool_call", entry_point="roll.pipeline.agentic.env.sokoban.tool_call_env:SokobanToolCallEnv")
gem.register("deepeyes", entry_point="roll.pipeline.agentic.env.deepeyes:DeepEyesEnv")
gem.register("rock_tb_native_env", entry_point="roll.pipeline.agentic.env.sandbox.rock_tb_native_env:RockTBNativeEnv")

try:
    gem.register("openreward_env", entry_point="roll.pipeline.agentic.env.openreward:OpenRewardEnv")
except Exception as e:
    logger.info(f"Failed to register openreward_env: {e}")

try:
    gem.register("atropos_env", entry_point="roll.pipeline.agentic.env.atropos:AtroposEnv")
except Exception as e:
    logger.info(f"Failed to register atropos_env: {e}")

try:
    # add webshop-minimal to PYTHONPATH
    import os
    import sys

    current_dir = os.path.dirname(os.path.abspath(__file__))
    relative_path = "../../../../third_party/webshop-minimal"
    module_path = os.path.join(current_dir, relative_path)
    sys.path.append(module_path)
    gem.register("webshop", entry_point="roll.pipeline.agentic.env.webshop.env:WebShopEnv")

except Exception as e:
    logger.info(f"Failed to import webshop: {e}")
