import dataclasses
from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional

from roll.configs.base_config import PPOConfig, RouterArguments
from roll.configs.worker_config import WorkerConfig
from roll.utils.logging import get_logger


logger = get_logger()


@dataclass
class DatasetFilterConfig:
    source: Optional[str] = None
    min_difficulty: Optional[float] = None
    max_difficulty: Optional[float] = None
    num_samples: int = 0

@dataclass
class RewardFilterConfig:
    type: Literal["no_filter", "mean_filter", "std_filter"] = field(
        default="no_filter",
        metadata={"help": "Type of filter to apply to rewards."},
    )
    filter_args: Dict[str, Any] = field(
        default_factory=dict,
        metadata={"help": "Arguments used in `filter_fn`"},
    )


@dataclass
class RewardConfig(WorkerConfig):
    code_url: str = field(
        default=None,
        metadata={"help": "The url of the code."}
    )
    use_local: bool = field(
        default=True,
        metadata={"help": "Whether to use local code instead of downloading from URL."}
    )
    judge_prompt: str = field(
        default=None,
        metadata={"help": "The prompt for judge."}
    )
    judge_model_type: str = field(
        default=None,
        metadata={"help": "api or inference"}
    )
    judge_model_name: str = field(
        default=None,
        metadata={"help": "judge_model_name."}
    )
    judge_api_url: str = field(
        default=None,
        metadata={"help": "judge_api_url."}
    )
    judge_api_key: str = field(
        default=None,
        metadata={"help": "judge_api_key."}
    )
    format_pattern: str = field(
        default=None,
        metadata={"help": "The pattern of the answer format."}
    )
    reward_type: str = field(default=None, metadata={"help": "The type of the reward."})
    response_length_penalty_coef: float = field(default=0.0, metadata={"help": "The coefficient of the response length penalty."})

    tag_included: List[str] = field(default_factory=list, metadata={"help": "The tags of the domain."})
    query_filter_config: RewardFilterConfig = field(
        default_factory=RewardFilterConfig,
        metadata={"help": "Arguments passed to reward query filtering"},)
    response_filter_config: RewardFilterConfig = field(
        default_factory=RewardFilterConfig,
        metadata={"help": "Arguments passed to reward response filtering"},
    )
    
    reward_manager_config: List[Dict[str, Any]] = field(default_factory=list, metadata={"help": "The reward system plugin config."})


@dataclass
class RLVRConfig(PPOConfig):
    # global
    global_template: str = field(
        default=None,
        metadata={"help": "The template of the global."})
    tag_to_template: Dict[str, str] = field(
        default_factory=dict,
        metadata={"help": "Mapping from tag to template name. Tags not in this dict fall back to global_template."}
    )
    dataset_filter: DatasetFilterConfig = field(
        default_factory=DatasetFilterConfig,
        metadata={"help": "Configuration for filtering dataset by source and difficulty"},
    )
    num_return_sequences_in_group: int = field(
        default=1,
        metadata={"help": "The number of return sequences in one group, used in generation_args."}
    )

    save_logging_board_dir: str = field(
        default=None, metadata={"help": "saving directory of logging board_metrics"}
    )

    # role related
    validation: WorkerConfig = field(
        default=None,
        metadata={"help": "Configuration for the validation."}
    )
    rewards: Optional[Dict[str, RewardConfig]] = field(
        default_factory=dict,
        metadata={"help": "Configuration for the multi domain rewards."}
    )
    reward_model: Optional[WorkerConfig] = field(
        default=None,
        metadata={"help": "Configuration for the shared reward model cluster (InferWorker + vLLM)."}
    )

    # PPO related
    difficulty_loss_weight: bool = field(default=False, metadata={"help": "Use difficulty_loss_weight"})
    length_loss_weight: bool = field(default=False, metadata={"help": "Use length_loss_weight"})
    postive_loss_coef: float = field(
        default=0,
        metadata={"help": "Loss coefficient for SFT loss, used for positive samples"}
    )
    use_topr_neg_loss_coef: float = field(
        default=0.0,
        metadata={"help": "Loss coefficient for TOPR Neg loss"}
    )
    use_policy_loss_type: Literal["PPO", "PG"] = field(
        default="PPO",
        metadata={"help": "whether to use PPO/PG loss"}
    )
    use_topr_loss: bool = field(
        default=False,
        metadata={"help": "whether to use TPRO loss, http://arxiv.org/abs/2503.14286"}
    )
    rl_loss_coef: float = field(
        default=1.0,
        metadata={"help": "Loss coefficient for RL loss"}
    )
    importance_sampling: Literal["token", "seq"] = (
        field(default="token", metadata={"help": "policy importance sampling"})
    )

    val_greedy: bool = field(default=False, metadata={"help": "Use greedy for validation"})
    val_n_sample: int = field(default=1, metadata={"help": "Number of samples for validation"})
    max_len_mask: bool = field(default=False)
    mask_type: Literal["all", "loss"] = field(default="loss", metadata={"help": "Mask type: 'all' or 'loss'"})
    difficulty_mask: bool = field(default=False)
    balance_length: bool = field(default=False)
    minibatch_data_iter_num: int = field(default=1)
    difficulty_low_threshold: float = field(default=0.0)
    difficulty_high_threshold: float = field(default=1.0)
    error_max_len_clip: bool = field(default=False)
    error_max_len_threshold: int = field(default=9999999999)
    prompt_admission_policy_cls: Optional[str] = field(
        default=None,
        metadata={
            "help": "Optional class path for a prompt-admission policy owning per-step candidate "
            "pools, selection and propensity logging (e.g. applications.rtl.admission.PooledAdmissionPolicy). "
            "Training schedulers only; None keeps the stock shuffled-epoch iterator."
        },
    )
    prompt_admission_args: Dict[str, Any] = field(
        default_factory=dict,
        metadata={"help": "Kwargs passed to prompt_admission_policy_cls (mode/pool_size/exploit/audit/...)."},
    )
    verify_governor_cls: Optional[str] = field(
        default=None,
        metadata={
            "help": "Optional class path for a verification-queue governor (central pending queue over "
            "reward workers with dispatch-ordering policies and decision propensity logging, e.g. "
            "applications.rtl.verify_governor.VerifyQueueGovernor). None keeps direct round-robin dispatch."
        },
    )
    verify_governor_args: Dict[str, Any] = field(
        default_factory=dict,
        metadata={"help": "Kwargs passed to verify_governor_cls (policy/epsilon/lam/bundle_path/...)."},
    )
    physical_compaction: bool = field(
        default=False,
        metadata={
            "help": "Physically remove reward-zero-variance groups (zero advantage under group-normalized "
            "estimators) right after generation, so ref/old-logprob/actor-train forward passes skip them "
            "instead of computing and masking them. The kept batch is padded to a DP/micro-batch-aligned "
            "size with inert filler groups whose final_response_mask is zeroed."
        },
    )

    consumption_mode: Literal["barrier", "decoupled"] = field(
        default="barrier",
        metadata={
            "help": "Learner consumption mode of the async ReplayBuffer. 'barrier' (ROLL default): step s waits "
            "for every prompt admitted at step s - ceil(async_generation_ratio). 'decoupled' (AReaL-style at "
            "GRPO-group granularity): consume any finished prompt groups whose age <= eta, oldest first, "
            "where eta = ceil(async_generation_ratio); older groups are discarded and their generation and "
            "verification cancelled. Requires is_use_additional_prompts=False."
        },
    )

    def __post_init__(self):
        self._validate_consumption_mode()
        # Handle OPD mapping FIRST before any access to actor_train/actor_infer/reference
        # This ensures student_train/student_infer/teacher are mapped correctly
        self._handle_opd_mapping()

        # Now safe to access actor_infer (may have been mapped from student_infer)
        self.actor_infer.generating_args.num_return_sequences = self.num_return_sequences_in_group
        super().__post_init__()

        # default worker_cls
        if self.actor_train.worker_cls is None:
            self.actor_train.worker_cls = "roll.pipeline.rlvr.actor_worker.ActorWorker"
        if self.actor_infer.worker_cls is None:
            self.actor_infer.worker_cls = "roll.pipeline.base_worker.InferWorker"
        if self.reference.worker_cls is None:
            self.reference.worker_cls = "roll.pipeline.rlvr.actor_worker.ActorWorker"
        if self.critic.worker_cls is None:
            self.critic.worker_cls = "roll.pipeline.base_worker.CriticWorker"
        if self.reward_model is not None and self.reward_model.worker_cls is None:
            self.reward_model.worker_cls = "roll.pipeline.base_worker.InferWorker"
        # Multi-teacher: set worker_cls for each _reference_configs entry
        if hasattr(self, '_reference_configs'):
            for ref_cfg in self._reference_configs.values():
                if ref_cfg.worker_cls is None:
                    ref_cfg.worker_cls = "roll.pipeline.rlvr.actor_worker.ActorWorker"

        if self.router_args is None:
            self.router_args = RouterArguments(router_name="PromptAffinityRouter", router_config=dict())
            self.router_args.max_running_requests = self.max_running_requests

        logger.info(f"actor_train.worker_cls: {self.actor_train.worker_cls}")

        self.domain_2_tag = None
        self.tag_2_domain = None
        if self.rewards is not None:
            self.domain_2_tag = {key: set(worker_config.tag_included) for key, worker_config in self.rewards.items()}
            self.tag_2_domain = {
                tag: key for key, worker_config in self.rewards.items() for tag in worker_config.tag_included
            }

        # OPD mode: include teacher tag_included in tag_2_domain mapping
        # so that teacher tags are also mapped to domains for routing
        if self.is_pure_opd or self.use_opd:
            if self.tag_2_domain is None:
                self.tag_2_domain = {}
                self.domain_2_tag = {}
            for name, ref_cfg in self._reference_configs.items():
                for tag in ref_cfg.tag_included:
                    if tag not in self.tag_2_domain:
                        # If no reward covers this tag, map tag to itself as domain
                        self.tag_2_domain[tag] = tag
                        if tag not in self.domain_2_tag:
                            self.domain_2_tag[tag] = {tag}

        # Validate tag_to_template entries
        if self.tag_to_template:
            from roll.datasets.chat_template import chat_templates
            for tag, tmpl_name in self.tag_to_template.items():
                if tmpl_name not in chat_templates:
                    raise ValueError(
                        f"Template '{tmpl_name}' for tag '{tag}' in tag_to_template not found. "
                        f"Available templates: {list(chat_templates.keys())}"
                    )

        if self.async_pipeline:
            assert self.async_generation_ratio >= 1.0, "async_generation_ratio must be >= 1.0"
            infer_devices = self.actor_infer.device_mapping
            other_worker_devices = set()
            for worker_config in [
                self.actor_train,
                self.critic,
                self.rewards,
                self.reference,
            ]:
                if worker_config is None:
                    continue
                if isinstance(worker_config, dict):
                    for config in worker_config.values():
                        other_worker_devices.update(config.device_mapping or set())
                else:
                    other_worker_devices.update(worker_config.device_mapping or set())

            if infer_devices is not None and len(set(infer_devices).intersection(other_worker_devices)) != 0:
                logger.warning("infer worker are sharing devices with other workers, which may cause performance issue")

            assert self.generate_opt_level == 1, "AsyncRLVRPipeline only support generate_opt_level 1"
            if self.num_return_sequences_in_group > 1 and not self.is_num_return_sequences_expand:
                self.is_num_return_sequences_expand = True
                logger.warning("Async Pipeline must is_num_return_sequences_expand is True when num_return_sequences_in_group > 1")

        if self.actor_infer:
            self.actor_infer.generating_args.max_new_tokens = self.sequence_length - self.prompt_length
            logger.warning(f"rewrite actor_infer max_new_tokens: {self.actor_infer.generating_args.max_new_tokens}")
        if self.validation:
            self.validation.generating_args.max_new_tokens = self.val_sequence_length - self.val_prompt_length
            logger.warning(f"rewrite validation max_new_tokens: {self.validation.generating_args.max_new_tokens}")

        # infer the required num nodes
        total_devices = []
        for attribute_name in dir(self):
            attribute = getattr(self, attribute_name)
            if isinstance(attribute, WorkerConfig):
                if attribute.device_mapping is not None:
                    total_devices.extend(attribute.device_mapping)
        for worker_config in self.rewards.values():
            if worker_config.device_mapping is not None:
                total_devices.extend(worker_config.device_mapping)
        # Also include _reference_configs device_mappings for multi-teacher
        if hasattr(self, '_reference_configs'):
            for ref_cfg in self._reference_configs.values():
                if isinstance(ref_cfg, WorkerConfig) and ref_cfg.device_mapping is not None:
                    total_devices.extend(ref_cfg.device_mapping)
        if len(total_devices) > 0:
            max_gpu_num = max(total_devices) + 1
            if max_gpu_num <= self.num_gpus_per_node:
                self.num_nodes = 1
            else:
                self.num_nodes = (max_gpu_num + self.num_gpus_per_node - 1) // self.num_gpus_per_node

        # Apply OPD configuration at the end (handles student_train/student_infer/teacher mapping)
        self._apply_opd_config()

    def _validate_consumption_mode(self) -> None:
        """Reject invalid modes; warn when decoupled cancellation cannot reach a busy verifier actor."""
        assert self.consumption_mode in ("barrier", "decoupled"), f"invalid {self.consumption_mode=!r}"
        assert self.consumption_mode == "barrier" or not self.is_use_additional_prompts, (
            "consumption_mode=decoupled requires is_use_additional_prompts=False"
        )
        if self.consumption_mode != "decoupled" or not self.verify_governor_cls:
            return
        for domain, reward_config in (self.rewards or {}).items():
            if reward_config.max_concurrency < 2:
                logger.warning(
                    f"consumption_mode=decoupled: rewards.{domain}.max_concurrency={reward_config.max_concurrency}; "
                    "cancel_verification can only interrupt a running verifier child when max_concurrency >= 2"
                )

    def to_dict(self):
        return dataclasses.asdict(self)
