# 怎么跑（2026-10-29 版）：主实验收尾 + RTL 消融

承接 `RERUN_1027.md`，环境、`ROOT`、代码目录都不变，没有新代码（`git pull` 应当无改动）。新东西只有两个：
**热启动**（把上一轮的最后一个 checkpoint 当作起始模型再训 200 步）和 **环境变量覆盖**（同一个 arm 换参数）。
所有 run 都带后缀，不会写进已有目录。时间含评测，8 卡顺序跑。

| 顺序 | run | 命令里的 arm / 后缀 | 步数 | 估时 |
|---|---|---|---|---|
| 1 | RTL full2 终版代码，从头 | `rtl decoupled_eta2_full2 600 _v2` | 600 | 9 h |
| 2 | RTL sel 热启动（接 10-27 的第 400 步） | `rtl decoupled_eta2_sel 200 _c600` + `SALV_MODEL_PATH=<ckpt>` | +200 | 3.5 h |
| 3 | Lean full2 κ 提高，从头 | `lean decoupled_eta2_full2 600 _k16` + `RTL_CTRL_KAPPA=1.6e-4` | 600 | 5.7 h |
| 4 | Lean sel 热启动（接第 400 步） | `lean decoupled_eta2_sel 200 _c600` + `LEAN_MODEL_PATH=<ckpt>` | +200 | 2 h |
| 5 | RTL ctrl-only（控制器 + 释放，无选题器） | `rtl decoupled_eta2_ctrl_dyn 150 _rel` + `RTL_CTRL_RELEASE=expiry` | 150 | 3.5 h |
| 6 | RTL release-off（选题器 + 控制器，无释放） | `rtl decoupled_eta2_full2 150 _norel` + `RTL_CTRL_RELEASE=none` | 150 | 2.5 h |

合计约 26 小时。DAPO 基线、小模型、验证器数量扫描放下一轮。

## 一、热启动是怎么做的（先读，再跑冒烟）

ROLL 的 `resume_from_checkpoint` 只认带优化器的 `dcp/` 目录，我们的 checkpoint 只存了权重，所以**不用它**。
做法是把上一轮最后的 checkpoint（HF 格式，评测时就是当模型加载的）当作起始模型，开一个新 run 跑 200 步：
优化器从零、选题器前 50 步重新暖机、步数从 0 计（分析时我加 400）。10-27 的 checkpoint 在
`$ROOT/runs/<run>/checkpoints/<时间戳>/checkpoint-399`。

```bash
export ROOT=/opt/dlami/nvme/weicyang_ec VENV=$ROOT/env/venv OSS_CAD_DIR=$ROOT/env/oss-cad-suite
cd $ROOT/code && git pull --no-rebase && git log --oneline -1
CK_RTL=$(ls -d $ROOT/runs/h100_rtl_decoupled_eta2_sel/checkpoints/*/checkpoint-399 | head -1)
CK_LEAN=$(ls -d $ROOT/runs/h100_lean_decoupled_eta2_sel/checkpoints/*/checkpoint-399 | head -1)
ls $CK_RTL/config.json $CK_RTL/tokenizer_config.json $CK_LEAN/config.json $CK_LEAN/tokenizer_config.json; ls $CK_RTL/*.safetensors | wc -l
```

四个文件都在、safetensors 数量 ≥ 1 就可以。冒烟 2 步（约 15 分钟，评测只跑 8 题）：

```bash
export RTL_NUM_GPUS=8 RTL_TRAIN_GPUS=4 RTL_TRACK_WITH=tensorboard WANDB_MODE=disabled
SMOKE=1 SALV_MODEL_PATH=$CK_RTL bash experiments/h100_20261019/run_arm.sh rtl decoupled_eta2_sel 2 _warm_smoke > $ROOT/logs/smoke_warm.log 2>&1
grep -m2 -n "model_name_or_path\|checkpoint-399" $ROOT/runs/h100_rtl_decoupled_eta2_sel_warm_smoke/train/stdout.log
$VENV/bin/python experiments/h100_20261019/stage2_summary.py $ROOT/runs/h100_rtl_decoupled_eta2_sel_warm_smoke | head -5
```

stdout 里加载的模型路径应当是 `checkpoint-399`，不是 `assets/salv-7b`；第一步选中组的 mean reward 应在 0.9 以上（接着训的模型），不是 0.9 以下的起始水平。两条都对就进第二节。

## 二、主实验（1 到 4，约 20 小时）

```bash
cd $ROOT/code
export ROOT VENV OSS_CAD_DIR RTL_NUM_GPUS=8 RTL_TRAIN_GPUS=4 RTL_TRACK_WITH=tensorboard WANDB_MODE=disabled
CK_RTL=$(ls -d $ROOT/runs/h100_rtl_decoupled_eta2_sel/checkpoints/*/checkpoint-399 | head -1)
CK_LEAN=$(ls -d $ROOT/runs/h100_lean_decoupled_eta2_sel/checkpoints/*/checkpoint-399 | head -1)
nohup bash -c "
  bash experiments/h100_20261019/run_arm.sh rtl  decoupled_eta2_full2 600 _v2 &&
  SALV_MODEL_PATH=$CK_RTL  bash experiments/h100_20261019/run_arm.sh rtl  decoupled_eta2_sel   200 _c600 &&
  RTL_CTRL_KAPPA=1.6e-4    bash experiments/h100_20261019/run_arm.sh lean decoupled_eta2_full2 600 _k16 &&
  LEAN_MODEL_PATH=$CK_LEAN bash experiments/h100_20261019/run_arm.sh lean decoupled_eta2_sel   200 _c600
  echo STAGE2C_MAIN_EXIT=\$?
" > $ROOT/logs/stage2c_main.log 2>&1 &
```

说明：
- `_v2` 的 full2 和 10-27 的 sel 只差控制器，是论文的主对比；10-26 那 419 步的 full2 是旧选题器，保留作消融点。
- 两条 `_c600` 的评测会评它自己的第 0 步（= 上一轮第 400 步的模型，重复评一次，正好给出评测噪声）、第 100 步（= 500）、第 199 步（= 600）。
- Lean `_k16`：κ 从 6e-5 提到 1.6e-4，目标是价格均值到 3e-3 附近。**第一小时检查**（约第 100 步）：
  `stage2_summary.py` 的 `50-99` 行 price mean 应在 2e-3 到 5e-3，abandon rate 低于 15%。超出就告诉我，不用停。

## 三、RTL 消融（5、6，约 6 小时）

```bash
nohup bash -c "
  RTL_CTRL_RELEASE=expiry RTL_CTRL_MIN_OBS=0 bash experiments/h100_20261019/run_arm.sh rtl decoupled_eta2_ctrl_dyn 150 _rel &&
  RTL_CTRL_RELEASE=none                       bash experiments/h100_20261019/run_arm.sh rtl decoupled_eta2_full2   150 _norel
  echo STAGE2C_ABL_EXIT=\$?
" > $ROOT/logs/stage2c_abl.log 2>&1 &
```

- `ctrl_dyn _rel` = 控制器（动态价）+ 到期释放，均匀进题，没有选题器。
- `full2 _norel` = 选题器 + 控制器，释放关掉（到期的组按原样被 staleness 丢弃）。
- 两条只进吞吐表（每步时长、informative 组/小时、放弃和释放数、audit 损失），和其它 arm 的前 150 步比，不出精度曲线。

## 四、回传（和 10-27 一样）

每个 run 结束后贴 `summarize_run.py`、`stage2_summary.py` 的打印和 `eval/eval_curve.json`；全部结束后发各 run 的 `$ROOT/outbox/*.tgz`
和一份过程记录 MD（冒烟结果、每个 run 的 manifest 状态、Lean 第一小时检查的数字）。
两条 `_c600` 请把 stdout 里加载模型路径的那行也贴上。盘上保留：`runs/*/train/output/`、`eval/`、每个 run 最后一个 checkpoint、`outbox/*.tgz`。

## 五、什么情况找我

checkpoint 目录缺 `config.json` 或 safetensors；冒烟加载的不是 `checkpoint-399`；Lean `_k16` 第一小时 price 超出区间或 abandon rate 超过 15%；任何 manifest 不是 `completed`。
