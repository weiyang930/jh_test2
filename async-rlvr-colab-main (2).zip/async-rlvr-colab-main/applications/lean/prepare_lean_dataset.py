"""Build ROLL jsonl prompts for Lean RL from Goedel-Pset-v1, Lean-Workbook or DeepSeek-Prover's miniF2F file.

Rows: id, data_source, prompt (raw DeepSeek-Prover completion prompt; no chat template), ground_truth (header-free
statement ending in ':= by', prepended to the model's continuation before checking), question, tag=lean.
Usage:
  prepare_lean_dataset.py --source pset --src train-00000-of-00004.parquet --dst pset_20k.jsonl --limit 20000 --seed 0
  prepare_lean_dataset.py --source workbook --src wkbk_1009.parquet --dst workbook.jsonl
  prepare_lean_dataset.py --source minif2f --src minif2f.jsonl --split test --dst minif2f_test.jsonl
  prepare_lean_dataset.py --source select --src probe_summary.json --dst train.jsonl --from pset_20k.jsonl --lo 1 --hi 7
"""
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

from applications.lean.lean_repl import DEFAULT_HEADER
from applications.lean.lean_verifier import PROMPT_TEMPLATE, normalize_statement, strip_header


def row(identifier: str, source: str, statement: str, informal: str, header: str = DEFAULT_HEADER) -> dict:
    stmt = normalize_statement(statement)
    informal = (informal or "").strip()
    docstring = "" if (not informal or stmt.lstrip().startswith("/--")) else f"/-- {informal} -/\n"
    body = docstring + stmt
    return dict(id=str(identifier), data_source=source, prompt=PROMPT_TEMPLATE.format(header=header, statement=body),
                ground_truth=body, question=informal, tag="lean", difficulty="")


def load_pset(src: Path, limit: int, seed: int, max_chars: int):
    import pandas as pd
    df = pd.read_parquet(src)
    df = df[df.formal_statement.str.len() <= max_chars]
    if limit and len(df) > limit:
        df = df.sample(n=limit, random_state=seed)
    for r in df.itertuples():
        yield row(r.problem_id, "goedel_pset_v1", r.formal_statement, "")   # docstring already inside the statement


def load_workbook(src: Path, limit: int, seed: int, max_chars: int):
    import pandas as pd
    df = pd.read_parquet(src)
    df = df[df.formal_statement.str.len() <= max_chars]
    if limit and len(df) > limit:
        df = df.sample(n=limit, random_state=seed)
    for r in df.itertuples():
        yield row(r.id, "lean_workbook", r.formal_statement, getattr(r, "natural_language_statement", ""))


def load_dsp_v1(src: Path, limit: int, seed: int, max_chars: int):
    """DeepSeek-Prover-V1 synthetic set (dataset.jsonl: name, formal_statement, header, formal_proof); dedup by statement."""
    import random
    seen, rows = set(), []
    for line in open(src, encoding="utf-8"):
        d = json.loads(line)
        stmt = d["formal_statement"]
        if len(stmt) > max_chars or stmt in seen:
            continue
        seen.add(stmt)
        rows.append(row(d["name"], "dsp_v1_synthetic", stmt, "", header=d.get("header") or DEFAULT_HEADER))
    if limit and len(rows) > limit:
        rows = random.Random(seed).sample(rows, limit)
    return rows


def load_minif2f(src: Path, split: str):
    for line in open(src, encoding="utf-8"):
        d = json.loads(line)
        if split and d.get("split") != split:
            continue
        stmt = (d.get("informal_prefix", "") or "") + d["formal_statement"]
        yield dict(id=d["name"], data_source=f"minif2f_{d['split']}", prompt=PROMPT_TEMPLATE.format(header=d["header"], statement=stmt),
                   ground_truth=strip_header(stmt), question=d.get("informal_prefix", ""), tag="lean", difficulty="")


def select(summary: Path, source_jsonl: Path, lo: int, hi: int):
    """Keep prompts whose probe pass count is in [lo, hi] (mixed groups at the probe's n)."""
    s = json.load(open(summary))
    keep = {pid for pid, rec in s["problems"].items() if lo <= rec["passes"] <= hi}
    for line in open(source_jsonl, encoding="utf-8"):
        d = json.loads(line)
        if d["id"] in keep:
            yield d


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", choices=["pset", "workbook", "minif2f", "dsp_v1", "select"], required=True)
    ap.add_argument("--src", type=Path, required=True)
    ap.add_argument("--dst", type=Path, required=True)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--max-chars", type=int, default=2000)
    ap.add_argument("--split", default="test")
    ap.add_argument("--from", dest="from_jsonl", type=Path)
    ap.add_argument("--lo", type=int, default=1)
    ap.add_argument("--hi", type=int, default=7)
    args = ap.parse_args()
    random.seed(args.seed)
    if args.source == "pset":
        rows = load_pset(args.src, args.limit, args.seed, args.max_chars)
    elif args.source == "workbook":
        rows = load_workbook(args.src, args.limit, args.seed, args.max_chars)
    elif args.source == "minif2f":
        rows = load_minif2f(args.src, args.split)
    elif args.source == "dsp_v1":
        rows = load_dsp_v1(args.src, args.limit, args.seed, args.max_chars)
    else:
        rows = select(args.src, args.from_jsonl, args.lo, args.hi)
    args.dst.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with open(args.dst, "w", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
            n += 1
    print(json.dumps(dict(rows=n, dst=str(args.dst), source=args.source)))


if __name__ == "__main__":
    main()
