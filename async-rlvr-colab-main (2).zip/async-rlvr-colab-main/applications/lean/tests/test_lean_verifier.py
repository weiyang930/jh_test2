from applications.lean.lean_repl import classify
from applications.lean.lean_verifier import build_code, normalize_statement, reward_from_result, strip_header

STMT = "theorem foo (x : ℝ) (h : 0 < x) : 0 < x ^ 2 := by\n"


def test_normalize_removes_sorry_and_header():
    s = "import Mathlib\nopen Nat\n\n/-- doc -/\ntheorem foo (x : ℝ) : x = x := by sorry"
    out = normalize_statement(s)
    assert out == "/-- doc -/\ntheorem foo (x : ℝ) : x = x := by\n"
    assert normalize_statement("theorem t : 1 = 1 := sorry") == "theorem t : 1 = 1 := by\n"


def test_build_code_completion_style():
    code = build_code("  positivity\n```\n\nSome trailing text", STMT)
    assert code == STMT + "  positivity\n"


def test_build_code_restated_theorem_block():
    resp = "Here is the proof:\n```lean4\nimport Mathlib\n\ntheorem foo (x : ℝ) (h : 0 < x) : 0 < x ^ 2 := by\n  positivity\n```"
    code = build_code(resp, STMT)
    assert code.startswith("theorem foo") and "import" not in code and code.endswith("positivity\n")


def test_classify_rules():
    assert classify({"messages": [{"severity": "error", "data": "x"}]}).status == "lean_error"
    assert classify({"messages": [{"severity": "warning", "data": "declaration uses 'sorry'"}]}).status == "sorry"
    assert classify({"sorries": [{"pos": 1}], "messages": []}).status == "sorry"
    assert classify({"messages": [{"severity": "info", "data": "ok"}], "env": 1}).status == "pass"


def test_strip_header():
    assert strip_header("import Mathlib\nset_option maxHeartbeats 0\nopen Nat\n\ntheorem t : True := by\n  trivial") == "theorem t : True := by\n  trivial"


def test_resource_fail_vs_repl_error():
    late = reward_from_result("repl_error", 69.0, "x", "repl eof")
    assert late.stage == "resource_fail" and late.reward_valid and late.reward == 0.0
    early = reward_from_result("repl_error", 0.5, "x", "repl eof")
    assert early.stage == "repl_error" and not early.reward_valid
    assert reward_from_result("timeout", 300.0, "x").reward_valid
