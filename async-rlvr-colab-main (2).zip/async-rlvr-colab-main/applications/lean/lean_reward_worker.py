"""ROLL reward worker for Lean 4 theorem proving: one persistent Mathlib REPL per CPU actor.

Same contract as ``applications.rtl.codev_reward_worker.CodeVRewardWorker``: one job in flight per actor,
``cancel_verification`` served on a second actor thread (``max_concurrency: 2``) kills the running check, per-sample
timing columns and a JSONL event per check. Reward 1.0 iff the proof compiles without errors or sorries within
``LEAN_TIMEOUT_S`` (the tau of this domain); a timeout is a valid failure, only REPL infrastructure faults are invalid.
"""
from __future__ import annotations

import json
import os
import threading
import time
from typing import List, Optional

import numpy as np
import torch

from applications.lean.lean_repl import DEFAULT_HEADER, LeanRepl
from applications.lean.lean_verifier import LeanReward, build_code, cancelled_reward, reward_from_result
from roll.configs.worker_config import WorkerConfig
from roll.distributed.executor.worker import Worker
from roll.distributed.scheduler.decorator import Dispatch, register
from roll.distributed.scheduler.protocol import DataProto
from roll.models.model_providers import default_tokenizer_provider

MAX_CONSECUTIVE_REPL_ERRORS = 10


class LeanRewardWorker(Worker):
    """Budgeted Lean kernel check; never silently train on an infrastructure fault."""

    def __init__(self, worker_config: WorkerConfig):
        super().__init__(worker_config=worker_config)
        self.rank_info.dp_rank = self.rank_info.rank
        self.rank_info.dp_size = self.rank_info.world_size
        self.tokenizer = default_tokenizer_provider(model_args=self.worker_config.model_args)
        self.workspace = os.environ.get("LEAN_WORKSPACE", "/root/lean/goedel/mathlib4")
        self.timeout_s = float(os.environ.get("LEAN_TIMEOUT_S", "300"))
        self.header = os.environ.get("LEAN_HEADER", DEFAULT_HEADER).replace("\\n", "\n")
        self.repl = LeanRepl(self.workspace, repl_cmd=os.environ.get("LEAN_REPL_CMD", "lake exe repl"), header=self.header,
                             import_timeout_s=float(os.environ.get("LEAN_IMPORT_TIMEOUT_S", "900")),
                             mem_limit_gb=float(os.environ.get("LEAN_MEM_LIMIT_GB", "0")))
        self._current: Optional[str] = None
        self._cancelled: set = set()
        self._lock = threading.Lock()
        self._repl_error_streak = 0
        self._n_checks = 0
        self._recycle_every = int(os.environ.get("LEAN_REPL_RECYCLE", "100"))   # the REPL keeps one env per command
        self.event_file = None
        self._event_fh = None

    @register(dispatch_mode=Dispatch.ONE_TO_ALL)
    def initialize(self, pipeline_config):
        out_dir = getattr(pipeline_config, "output_dir", None)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
            name = os.environ.get("WORKER_NAME", f"lean-reward-{self.rank}")
            self.event_file = os.path.join(out_dir, f"verifier_events.{name}.jsonl")
            self._event_fh = open(self.event_file, "a", encoding="utf-8")
        started = self.repl.start()
        self.logger.info(f"LeanRewardWorker: workspace={self.workspace} timeout={self.timeout_s}s "
                         f"header_import={started.status} ({started.elapsed_s:.1f}s) {started.detail}")
        if not started.is_pass:
            raise RuntimeError(f"Lean REPL failed to import the header: {started.detail}")

    def _log_event(self, event: dict) -> None:
        if self._event_fh is None:
            return
        self._event_fh.write(json.dumps(event, ensure_ascii=False) + "\n")
        self._event_fh.flush()

    # ------------------------------------------------------------------ one check
    def _check(self, rollout_id: str, response: str, statement: str) -> LeanReward:
        with self._lock:
            if rollout_id in self._cancelled:
                self._cancelled.discard(rollout_id)
                return cancelled_reward(0.0)
            self._current = rollout_id
        t0 = time.time()
        try:
            if not response.strip():
                return reward_from_result("extract_fail", 0.0, "", "empty response")
            code = build_code(response, statement)
            if self._recycle_every and self._n_checks and self._n_checks % self._recycle_every == 0:
                self.repl.kill()   # run() restarts it; drops accumulated environments (43 GB RSS seen without this)
            self._n_checks += 1
            result = self.repl.run(code, self.timeout_s)
        finally:
            with self._lock:
                self._current = None
                cancelled = rollout_id in self._cancelled
                self._cancelled.discard(rollout_id)
        if cancelled:
            return cancelled_reward(time.time() - t0)
        detail = result.detail or (result.errors[0].get("data", "")[:300] if result.errors else "")
        return reward_from_result(result.status, result.elapsed_s, code, detail)

    def cancel_verification(self, rollout_id: str) -> bool:
        """Kill the REPL if ``rollout_id`` is being checked; a cancel that arrives early is honoured at launch."""
        with self._lock:
            self._cancelled.add(rollout_id)
            running = self._current == rollout_id
        if running:
            self.repl.kill()
        return running

    @register(dispatch_mode=Dispatch.DP_MP_COMPUTE, clear_cache=False)
    def compute_rewards(self, data: DataProto) -> DataProto:
        texts = self.tokenizer.batch_decode(data.batch["responses"], skip_special_tokens=True)
        statements = data.non_tensor_batch["ground_truth"]
        rollout_ids = data.non_tensor_batch.get("rollout_id", np.array([f"nord_{i}" for i in range(len(texts))], dtype=object))
        results: List[LeanReward] = []
        starts, ends = [], []
        for text, statement, rollout_id in zip(texts, statements, rollout_ids):
            starts.append(time.time())
            result = self._check(str(rollout_id), text, str(statement))
            ends.append(time.time())
            results.append(result)
            self._log_event(dict(event="verify", rollout_id=str(rollout_id), worker=self.worker_name,
                                 t_worker_start=starts[-1], t_worker_end=ends[-1],
                                 verifier_execution_s=ends[-1] - starts[-1], reward=result.reward, stage=result.stage,
                                 is_pass=result.is_pass, reward_valid=result.reward_valid, reason=result.reason,
                                 verify_time_s=result.verify_time_s, repl_restarts=self.repl.restarts,
                                 code_chars=len(result.code), verifier_protocol="lean4-repl",
                                 verifier_config=dict(timeout_s=self.timeout_s, workspace=self.workspace)))
            self._note_repl_error_streak(result)
        scores = torch.tensor([r.reward for r in results], dtype=torch.float32)
        return DataProto.from_dict(
            tensors=dict(token_level_rewards=torch.zeros_like(data.batch["responses"], dtype=torch.float32),
                         response_level_rewards=scores, scores=scores.clone()),
            non_tensors=dict(
                verifier_stage=np.array([r.stage for r in results], dtype=object),
                reward_valid=np.array([r.reward_valid for r in results], dtype=object),
                # one REPL process per check: wall time is the CPU-seconds proxy (Lean is single-threaded here)
                verifier_cpu_core_seconds=np.array([r.verify_time_s for r in results], dtype=object),
                t_worker_start=np.array(starts, dtype=object), t_worker_end=np.array(ends, dtype=object),
                verify_worker=np.array([str(self.worker_name or f"lean-reward-{self.rank}")] * len(results), dtype=object),
            ),
        )

    def _note_repl_error_streak(self, result: LeanReward) -> None:
        if result.stage == "cancelled":
            return
        self._repl_error_streak = self._repl_error_streak + 1 if result.stage == "repl_error" else 0
        if self._repl_error_streak >= MAX_CONSECUTIVE_REPL_ERRORS:
            raise RuntimeError(f"Lean REPL failed {self._repl_error_streak} checks in a row: {result.reason}")
