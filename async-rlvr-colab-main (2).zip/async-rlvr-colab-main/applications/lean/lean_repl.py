"""Persistent Lean 4 REPL process: one Mathlib import per process, one proof check per command.

The REPL (leanprover-community/repl) reads JSON commands separated by a blank line and answers with one JSON object
followed by a blank line. The header (``import Mathlib ...``) is sent once and becomes environment 0; every proof is
then checked with ``{"cmd": code, "env": 0}``. A proof that exceeds ``timeout_s`` cannot be interrupted inside Lean, so
the whole process is killed and restarted lazily on the next call (same as DeepSeek-Prover / Goedel verifiers).
"""
from __future__ import annotations

import json
import os
import pty
import queue
import resource
import shlex
import signal
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass, field
from typing import List, Optional

DEFAULT_HEADER = "import Mathlib\nimport Aesop\n\nset_option maxHeartbeats 0\n\nopen BigOperators Real Nat Topology Rat\n\n"
EOF_SENTINEL = {"__eof__": True}


@dataclass
class ReplResult:
    status: str                      # pass | lean_error | sorry | timeout | repl_error | cancelled
    elapsed_s: float
    errors: List[dict] = field(default_factory=list)
    sorries: List[dict] = field(default_factory=list)
    warnings: List[dict] = field(default_factory=list)
    detail: str = ""

    @property
    def is_pass(self) -> bool:
        return self.status == "pass"


def classify(resp: dict) -> ReplResult:
    """DeepSeek-Prover / Goedel acceptance rule: no error, no sorry, no 'declaration uses sorry' or 'failed' warning."""
    messages = resp.get("messages", [])
    errors = [m for m in messages if m.get("severity") == "error"]
    warnings = [m for m in messages if m.get("severity") == "warning"]
    sorries = resp.get("sorries", [])
    if errors:
        status = "lean_error"
    elif sorries or any("declaration uses 'sorry'" in w.get("data", "") or "failed" in w.get("data", "") for w in warnings):
        status = "sorry"
    else:
        status = "pass"
    return ReplResult(status=status, elapsed_s=0.0, errors=errors, sorries=sorries, warnings=warnings)


class LeanRepl:
    """One REPL process; not thread-safe except for ``kill`` (used by the cancellation thread)."""

    def __init__(self, workspace: str, repl_cmd: str = "lake exe repl", header: str = DEFAULT_HEADER,
                 import_timeout_s: float = 600.0, mem_limit_gb: float = 0.0, lake_path: Optional[str] = None):
        self.workspace = workspace
        self.header = header
        self.import_timeout_s = import_timeout_s
        self.mem_limit_gb = mem_limit_gb
        self.lake_path = lake_path or os.path.expanduser("~/.elan/bin/lake")
        cmd = shlex.split(repl_cmd)
        if cmd and cmd[0] == "lake":
            cmd[0] = self.lake_path
        self.cmd = cmd
        self.proc: Optional[subprocess.Popen] = None
        self._q: "queue.Queue[object]" = queue.Queue()
        self._reader: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self.restarts = 0
        self.env_id = 0

    # ------------------------------------------------------------------ process lifecycle
    def _preexec(self):
        os.setsid()
        if self.mem_limit_gb > 0:
            limit = int(self.mem_limit_gb * 1024 ** 3)
            resource.setrlimit(resource.RLIMIT_AS, (limit, limit))

    def _read_loop(self, master_fd: int, q: "queue.Queue[object]") -> None:
        """Read the REPL's stdout through a pty master: JSON blocks separated by blank lines (pty emits CRLF)."""
        def emit(block: List[str]) -> None:
            text = "\n".join(block)
            try:
                q.put(json.loads(text))
            except json.JSONDecodeError:
                q.put({"__raw__": text})
        pending, block = "", []
        while True:
            try:
                data = os.read(master_fd, 65536)
            except OSError:  # EIO once the slave side is closed (process gone)
                break
            if not data:
                break
            pending += data.decode("utf-8", "replace")
            while "\n" in pending:
                line, pending = pending.split("\n", 1)
                line = line.rstrip("\r")
                if line.strip() == "":
                    if block:
                        emit(block)
                        block = []
                else:
                    block.append(line)
        if block:
            emit(block)
        q.put(EOF_SENTINEL)
        try:
            os.close(master_fd)
        except OSError:
            pass

    def start(self) -> ReplResult:
        """Spawn the REPL and load the header as env 0."""
        self.kill()
        env = dict(os.environ)
        env.setdefault("PATH", "")
        env["PATH"] = os.path.dirname(self.lake_path) + os.pathsep + env["PATH"]
        self._q = queue.Queue()
        master_fd, slave_fd = pty.openpty()
        self._stderr = tempfile.TemporaryFile(mode="w+b")
        with self._lock:
            self.proc = subprocess.Popen(self.cmd, cwd=self.workspace, stdin=subprocess.PIPE, stdout=slave_fd,
                                         stderr=self._stderr, preexec_fn=self._preexec, env=env)
        os.close(slave_fd)
        self._reader = threading.Thread(target=self._read_loop, args=(master_fd, self._q), daemon=True)
        self._reader.start()
        t0 = time.time()
        resp = self._send({"cmd": self.header}, self.import_timeout_s)
        if resp is None or resp is EOF_SENTINEL or "__raw__" in resp:
            self.kill()
            return ReplResult("repl_error", time.time() - t0,
                              detail=f"header import failed: {str(resp)[:200]}; stderr: {self.stderr_tail()}; cmd={self.cmd} cwd={self.workspace} HOME={os.environ.get('HOME')}")
        if any(m.get("severity") == "error" for m in resp.get("messages", [])):
            self.kill()
            return ReplResult("repl_error", time.time() - t0, detail=f"header errors: {str(resp)[:300]}")
        self.env_id = int(resp.get("env", 0))
        self.restarts += 1
        return ReplResult("pass", time.time() - t0)

    def stderr_tail(self, n: int = 400) -> str:
        """Last bytes of the REPL's stderr (diagnostics for repl_error)."""
        fh = getattr(self, "_stderr", None)
        if fh is None:
            return ""
        try:
            fh.flush()
            size = fh.seek(0, os.SEEK_END)
            fh.seek(max(0, size - n))
            return fh.read().decode("utf-8", "replace").strip().replace("\n", " | ")
        except (OSError, ValueError):
            return ""

    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def kill(self) -> None:
        with self._lock:
            proc, self.proc = self.proc, None
        if proc is None:
            return
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            proc.wait(timeout=5)
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------ commands
    def _send(self, command: dict, timeout_s: float):
        with self._lock:
            proc = self.proc
        if proc is None or proc.poll() is not None:
            return None
        try:
            proc.stdin.write((json.dumps(command, ensure_ascii=False) + "\n\n").encode("utf-8"))  # type: ignore[union-attr]
            proc.stdin.flush()  # type: ignore[union-attr]
        except (BrokenPipeError, OSError):
            return None
        try:
            return self._q.get(timeout=timeout_s)
        except queue.Empty:
            return None

    def run(self, code: str, timeout_s: float) -> ReplResult:
        """Check ``code`` (header excluded) against env 0; restart the process first if it is not alive."""
        t0 = time.time()
        if not self.alive():
            started = self.start()
            if not started.is_pass:
                return ReplResult("repl_error", time.time() - t0, detail=started.detail)
        resp = self._send({"cmd": code, "env": self.env_id}, timeout_s)
        elapsed = time.time() - t0
        if resp is None:
            # timeout (queue empty) or process gone before/while writing
            if self.alive():
                self.kill()
                return ReplResult("timeout", elapsed, detail=f"no verdict within {timeout_s:.0f} s")
            return ReplResult("repl_error", elapsed, detail="repl process exited")
        if resp is EOF_SENTINEL:
            tail = self.stderr_tail()
            self.kill()
            return ReplResult("repl_error", elapsed, detail=f"repl eof; stderr: {tail}")
        if "__raw__" in resp:
            self.kill()
            return ReplResult("repl_error", elapsed, detail=f"non-json output: {resp['__raw__'][:300]}")
        result = classify(resp)
        result.elapsed_s = elapsed
        return result
