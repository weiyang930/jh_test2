"""Sample n proofs per prompt with vLLM, check them with a pool of Lean REPL workers, report pass@k, group
informativeness at G, and the verification-time distribution. Used to pick the RL training subset (mixed groups) and
to evaluate miniF2F before/after training.

Usage: probe_and_eval.py --model PATH --data prompts.jsonl --out DIR [--n 8] [--limit 2000] [--workers 48]
       [--timeout 300] [--max-tokens 1024] [--gpu 1] [--regen]  (writes attempts.jsonl, summary.json)
"""
from __future__ import annotations

import argparse
import collections
import json
import multiprocessing as mp
import os
import random
import time
from pathlib import Path

from applications.lean.lean_repl import DEFAULT_HEADER, LeanRepl
from applications.lean.lean_verifier import build_code

_REPL = None


_N_CMDS = 0
_RECYCLE = 0


def _init_worker(workspace: str, repl_cmd: str, header: str, mem_limit_gb: float = 0.0, recycle: int = 0):
    """Pool initializer: one REPL per worker, RLIMIT_AS-capped, recycled every ``recycle`` commands (env growth)."""
    global _REPL, _RECYCLE
    _REPL = LeanRepl(workspace, repl_cmd=repl_cmd, header=header, mem_limit_gb=mem_limit_gb)
    _RECYCLE = recycle


def _verify(task):
    global _N_CMDS
    idx, code, timeout = task
    if _RECYCLE and _N_CMDS and _N_CMDS % _RECYCLE == 0:
        _REPL.kill()   # run() restarts it; drops the environments accumulated by earlier commands
    _N_CMDS += 1
    r = _REPL.run(code, timeout)
    return idx, r.status, r.elapsed_s, (r.errors[0].get("data", "")[:200] if r.errors else r.detail[:200])


def quantiles(xs, qs=(0.5, 0.9, 0.95, 0.99)):
    xs = sorted(xs)
    return {f"p{int(q * 100)}": (xs[min(len(xs) - 1, int(q * (len(xs) - 1)))] if xs else None) for q in qs}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--n", type=int, default=8)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--workers", type=int, default=48)
    ap.add_argument("--timeout", type=float, default=300.0)
    ap.add_argument("--max-tokens", type=int, default=1024)
    ap.add_argument("--temperature", type=float, default=1.0)
    ap.add_argument("--top-p", type=float, default=0.95)
    ap.add_argument("--gpu", default="0")
    ap.add_argument("--dtype", default="bfloat16")
    ap.add_argument("--tokenizer", default=None)
    ap.add_argument("--gpu-mem", type=float, default=0.85)
    ap.add_argument("--workspace", default=os.environ.get("LEAN_WORKSPACE", "/root/lean/goedel/mathlib4"))
    ap.add_argument("--repl-cmd", default=os.environ.get("LEAN_REPL_CMD", "lake exe repl"))
    ap.add_argument("--regen", action="store_true", help="ignore cached generations.jsonl")
    ap.add_argument("--mem-limit-gb", type=float, default=float(os.environ.get("LEAN_MEM_LIMIT_GB", "16")),
                    help="RLIMIT_AS per REPL process; 0 = unlimited (a single runaway check reached 43 GB RSS)")
    ap.add_argument("--recycle", type=int, default=100, help="restart each REPL after this many commands; 0 = never")
    ap.add_argument("--groups", default="4,8", help="group sizes for the informative-share estimate")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    rows = [json.loads(l) for l in open(args.data, encoding="utf-8")]
    if args.limit and len(rows) > args.limit:
        random.Random(args.seed).shuffle(rows)
        rows = rows[: args.limit]
    gen_path = args.out / "generations.jsonl"
    if gen_path.exists() and not args.regen:
        gens = [json.loads(l) for l in open(gen_path)]
    else:
        os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
        from vllm import LLM, SamplingParams
        llm = LLM(model=args.model, tensor_parallel_size=1, gpu_memory_utilization=args.gpu_mem, max_model_len=4096,
                  seed=args.seed, dtype="bfloat16")
        sp = SamplingParams(n=args.n, temperature=args.temperature, top_p=args.top_p, max_tokens=args.max_tokens, stop=["```"], seed=args.seed)
        t0 = time.time()
        outs = llm.generate([r["prompt"] for r in rows], sp)
        gen_s = time.time() - t0
        gens = []
        for r, o in zip(rows, outs):
            for j, c in enumerate(o.outputs):
                gens.append(dict(id=r["id"], j=j, response=c.text, tokens=len(c.token_ids), finish=c.finish_reason))
        with open(gen_path, "w", encoding="utf-8") as fh:
            for g in gens:
                fh.write(json.dumps(g, ensure_ascii=False) + "\n")
        json.dump(dict(generation_s=gen_s, prompts=len(rows), n=args.n), open(args.out / "generation_meta.json", "w"))
        del llm
    stmt = {r["id"]: r["ground_truth"] for r in rows}
    tasks = [(i, build_code(g["response"], stmt[g["id"]]), args.timeout) for i, g in enumerate(gens)]
    t0 = time.time()
    results = [None] * len(tasks)
    with mp.get_context("spawn").Pool(args.workers, initializer=_init_worker,
                                           initargs=(args.workspace, args.repl_cmd, DEFAULT_HEADER, args.mem_limit_gb, args.recycle)) as pool:
        done = 0
        for idx, status, elapsed, detail in pool.imap_unordered(_verify, tasks, chunksize=1):
            results[idx] = (status, elapsed, detail)
            done += 1
            if done % 200 == 0:
                print(f"verified {done}/{len(tasks)} in {time.time() - t0:.0f}s", flush=True)
    verify_wall = time.time() - t0
    with open(args.out / "attempts.jsonl", "w", encoding="utf-8") as fh:
        for g, (status, elapsed, detail) in zip(gens, results):
            fh.write(json.dumps(dict(id=g["id"], j=g["j"], status=status, verify_time_s=round(elapsed, 3), tokens=g["tokens"],
                                     finish=g["finish"], detail=detail), ensure_ascii=False) + "\n")
    # ---- summary
    per = collections.defaultdict(lambda: dict(passes=0, n=0))
    status_counts = collections.Counter()
    times = []
    for g, (status, elapsed, _) in zip(gens, results):
        per[g["id"]]["n"] += 1
        per[g["id"]]["passes"] += int(status == "pass")
        status_counts[status] += 1
        times.append(elapsed)
    n = args.n
    rates = [p["passes"] / p["n"] for p in per.values()]
    passk = {f"pass@{k}": sum(1 for p in per.values() if p["passes"] > 0) / len(per) for k in (n,)}
    # expected informative share for random groups of size G drawn from each problem's probe rate
    inf = {}
    for G in [int(x) for x in args.groups.split(",")]:
        inf[f"informative_share_G{G}"] = sum(1 - r ** G - (1 - r) ** G for r in rates) / len(rates)
    total = sum(times)
    tail = sorted(times, reverse=True)
    summary = dict(model=args.model, data=str(args.data), prompts=len(per), n=n, attempt_pass_rate=status_counts["pass"] / len(gens),
                   status_counts=dict(status_counts), **passk, **inf,
                   mixed_at_probe=sum(1 for p in per.values() if 0 < p["passes"] < p["n"]) / len(per),
                   all_fail=sum(1 for p in per.values() if p["passes"] == 0) / len(per), all_pass=sum(1 for p in per.values() if p["passes"] == p["n"]) / len(per),
                   verify_time=dict(mean=total / len(times), **quantiles(times), max=max(times),
                                    share_time_top1pct=sum(tail[: max(1, len(tail) // 100)]) / total,
                                    share_time_over_60s=sum(t for t in times if t > 60) / total,
                                    frac_over_60s=sum(1 for t in times if t > 60) / len(times)),
                   verify_wall_s=verify_wall, workers=args.workers, timeout_s=args.timeout,
                   problems={pid: dict(passes=p["passes"], n=p["n"]) for pid, p in per.items()})
    json.dump(summary, open(args.out / "summary.json", "w"), indent=1)
    printable = {k: v for k, v in summary.items() if k != "problems"}
    print(json.dumps(printable, indent=1))


if __name__ == "__main__":
    main()
