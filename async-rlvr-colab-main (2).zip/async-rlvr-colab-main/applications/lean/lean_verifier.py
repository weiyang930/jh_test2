"""Turn a model response into the Lean code to check, and the check into a reward record (pure functions)."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional

HEADER_PREFIXES = ("import ", "set_option ", "open ")
THEOREM_RE = re.compile(r"^\s*(theorem|lemma|example)\b", re.M)
NAME_RE = re.compile(r"^\s*(?:theorem|lemma)\s+([^\s:({\[]+)", re.M)

PROMPT_TEMPLATE = "Complete the following Lean 4 code:\n\n```lean4\n{header}{statement}"


def strip_header(code: str) -> str:
    """Drop import / set_option / open lines (the REPL env 0 already holds the header)."""
    lines = [line for line in code.split("\n") if not line.strip().startswith(HEADER_PREFIXES)]
    return "\n".join(lines).lstrip("\n")


def normalize_statement(formal_statement: str) -> str:
    """Header-free statement ending in ':= by\\n' with any trailing 'sorry' removed (prompt + proof prefix)."""
    body = strip_header(formal_statement).rstrip()
    body = re.sub(r":=\s*by\s+sorry\s*$", ":= by", body)
    body = re.sub(r":=\s*sorry\s*$", ":= by", body)
    if not re.search(r":=\s*by\s*$", body):
        body = body + " := by" if ":=" not in body.split("\n")[-1] else body
    return body + "\n"


def theorem_name(statement: str) -> Optional[str]:
    m = NAME_RE.search(statement)
    return m.group(1) if m else None


def build_code(response: str, statement: str) -> str:
    """Code to send to the REPL.

    DeepSeek-Prover style completions continue the prompt, so the statement is prepended. If the model restated the
    whole theorem inside a ```lean4 block (Goedel / Kimina style), that block is used as is.
    """
    text = response
    if "```lean4" in text:
        text = text.split("```lean4", 1)[1]
    elif text.lstrip().startswith("```lean"):
        text = text.split("```lean", 1)[1]
    body = text.split("```", 1)[0]
    candidate = strip_header(body)
    name = theorem_name(statement)
    if THEOREM_RE.search(candidate) and name and name in candidate:
        return candidate.rstrip() + "\n"
    return (statement.rstrip("\n") + "\n" + body.rstrip()).rstrip() + "\n"


@dataclass
class LeanReward:
    reward: float
    stage: str          # pass | lean_error | sorry | timeout | repl_error | extract_fail | cancelled
    is_pass: bool
    reward_valid: bool
    reason: str
    verify_time_s: float
    code: str


RESOURCE_FAIL_AFTER_S = 10.0


def reward_from_result(status: str, elapsed_s: float, code: str, detail: str = "") -> LeanReward:
    """Map a REPL status to the reward record.

    A REPL that dies while checking a proof after a long run (memory blow-up, OOM-killed) is a verdict on that proof
    ('resource_fail', valid failure, like a timeout); a REPL fault at start or within seconds is infrastructure and
    invalidates the group.
    """
    if status == "repl_error" and elapsed_s >= RESOURCE_FAIL_AFTER_S:
        status = "resource_fail"
    is_pass = status == "pass"
    valid = status != "repl_error"
    return LeanReward(reward=1.0 if is_pass else 0.0, stage=status, is_pass=is_pass, reward_valid=valid,
                      reason=detail[:500], verify_time_s=elapsed_s, code=code)


def cancelled_reward(elapsed_s: float) -> LeanReward:
    return LeanReward(reward=0.0, stage="cancelled", is_pass=False, reward_valid=False, reason="cancelled by scheduler",
                      verify_time_s=elapsed_s, code="")
