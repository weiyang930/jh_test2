#!/usr/bin/env python3
"""Fit the controller's tables p(t|S) and R(t) from a prior run or a probe, write JSON for verify_controller.Tables.

Sources:
  --run <dir>        a pipeline run (reads <dir>/output/events.jsonl: sample_done with t_worker_start/end,
                     verifier_execution_s, verifier_stage; same schema as the E-C runs)
  --probe <attempts.jsonl>   a probe_and_eval / probe_rtl attempts file (id, j, status|stage, verify_time_s);
                     siblings are assumed to start together, so sibling state at age t = outcomes finished by t
usage: fit_controller_tables.py (--run DIR | --probe FILE) --tau 180 --out tables.json [--min-count 20]
       [--censoring drop|km] [--audit all|only|exclude]
  censoring drop (default, the pre-10-25 behaviour): checks cancelled before a verdict are left out.
  censoring km:  a cancelled check counts as at risk up to its cancel age (grid-interval cumulative incidence of
                 pass vs fail, Kaplan-Meier style); unbiased when the cancel decision depends only on (age, sibling
                 state), which is what the controller conditions on. R(t) is then the KM mean remaining time.
  audit only / exclude: fit on the audit-lane groups alone (never cancelled: the unbiased reference) or without
                 them; comparing the two is the P2 check for selection bias in the tables.
"""
from __future__ import annotations

import argparse
import collections
import json
import statistics as st

GRID = [0, 2, 5, 10, 20, 30, 45, 60, 90, 120, 180, 240]
STATES = ("none", "fail", "pass")


def groups_from_run(path: str) -> dict:
    groups, audit = collections.defaultdict(list), {}
    for line in open(path, errors="ignore"):
        try:
            e = json.loads(line)
        except Exception:
            continue
        if e.get("event") != "sample_done" or e.get("verifier_execution_s") is None:
            continue
        if not (e.get("t_worker_start") and e.get("t_worker_end")):
            continue
        k = (e.get("prompt_id"), e.get("sampling_start_step"))
        stage = str(e.get("verifier_stage"))
        groups[k].append({"start": float(e["t_worker_start"]), "dur": float(e["verifier_execution_s"]),
                          "pass": stage == "pass", "censored": False, "audit": bool(audit.get(k, False))})
    return groups


def groups_from_run_full(path: str) -> dict:
    """Like groups_from_run, plus checks cancelled while RUNNING (censored at their running age, taken from the
    governor's cancel records in verify_queue_events.jsonl next to events.jsonl: ``running_s`` excludes queue wait,
    unlike sample_canceled.elapsed_s) and the audit flag of every group (prompt_begin.audit)."""
    import os
    groups, audit, step_by_prompt = collections.defaultdict(list), {}, {}
    for line in open(path, errors="ignore"):
        try:
            e = json.loads(line)
        except Exception:
            continue
        k = (e.get("prompt_id"), e.get("sampling_start_step"))
        ev = e.get("event")
        if ev == "prompt_begin":
            audit[k] = bool(e.get("audit", False)); step_by_prompt[e.get("prompt_id")] = e.get("sampling_start_step")
        elif ev == "sample_done" and e.get("verifier_execution_s") is not None and e.get("t_worker_start") and e.get("t_worker_end"):
            groups[k].append({"start": float(e["t_worker_start"]), "dur": float(e["verifier_execution_s"]),
                              "pass": str(e.get("verifier_stage")) == "pass", "censored": False})
    gov = os.path.join(os.path.dirname(path), "verify_queue_events.jsonl")
    if os.path.exists(gov):
        for line in open(gov, errors="ignore"):
            if '"cancel"' not in line:
                continue
            try:
                e = json.loads(line)
            except Exception:
                continue
            if e.get("event") != "cancel" or e.get("state") != "running" or not e.get("running_s"):
                continue
            k = (e.get("prompt_id"), step_by_prompt.get(e.get("prompt_id")))
            dur = float(e["running_s"])
            groups[k].append({"start": float(e.get("ts", 0.0)) - dur, "dur": dur, "pass": False, "censored": True})
    for k, jobs in groups.items():
        for x in jobs:
            x["audit"] = audit.get(k, False)
    return groups


def groups_from_probe(path: str) -> dict:
    groups = collections.defaultdict(list)
    for line in open(path, errors="ignore"):
        a = json.loads(line)
        status = a.get("status") or a.get("stage")
        t = a.get("verify_time_s")
        if t is None:
            continue
        groups[a["id"]].append({"start": 0.0, "dur": float(t), "pass": status == "pass", "censored": False, "audit": False})
    return groups


def sib_state(jobs, j, t_age):
    t_abs = jobs[j]["start"] + t_age
    done = [x["pass"] for k, x in enumerate(jobs) if k != j and x["start"] + x["dur"] <= t_abs]
    if not done:
        return "none"
    return "pass" if any(done) else "fail"


def _select(groups: dict, audit: str) -> dict:
    if audit == "all":
        return groups
    want = audit == "only"
    return {k: v for k, v in groups.items() if bool(v and v[0].get("audit", False)) == want}


def fit_km(groups: dict, tau: float, min_count: int):
    """Grid-interval cumulative incidence with censoring. For each cell (t, S): among checks still running at t in
    sibling state S, p = P(eventual pass) = sum_m h_pass(m) * prod_{j<m} (1 - h_pass(j) - h_fail(j)), hazards per grid
    interval from the checks observed through that interval (a cancelled check leaves the risk set at its cancel age).
    R(t) = KM expected remaining time to any verdict, capped at tau."""
    grid = [g for g in GRID if g < tau] + [tau]
    risk = collections.Counter(); ev_pass = collections.Counter(); ev_fail = collections.Counter()
    risk_p = collections.Counter(); end_p = collections.Counter()
    for jobs in groups.values():
        for j, x in enumerate(jobs):
            dur = min(x["dur"], tau); cens = x.get("censored", False)
            verdict_pass = (x["pass"] and x["dur"] <= tau) and not cens
            for t in grid[:-1]:
                if dur <= t:
                    break
                s = sib_state(jobs, j, t)
                for m in range(grid.index(t), len(grid) - 1):
                    a, b = grid[m], grid[m + 1]
                    if dur <= a:
                        break
                    if dur <= b:                       # verdict or cancellation inside this interval
                        if cens:
                            break                       # leaves the risk set, no event
                        risk[(t, s, m)] += 1
                        (ev_pass if verdict_pass else ev_fail)[(t, s, m)] += 1
                        break
                    risk[(t, s, m)] += 1               # observed through the whole interval
            # pooled remaining-time KM (state-free, like the original R)
            for m, (a, b) in enumerate(zip(grid[:-1], grid[1:])):
                if dur <= a:
                    break
                if dur <= b:
                    if not cens:
                        risk_p[m] += 1; end_p[m] += 1
                    break
                risk_p[m] += 1
    def cell_p(t, s):
        surv, total, n0 = 1.0, 0.0, 0
        for m in range(grid.index(t), len(grid) - 1):
            r = risk[(t, s, m)]
            if m == grid.index(t):
                n0 = r
            if r == 0:
                break
            hp, hf = ev_pass[(t, s, m)] / r, ev_fail[(t, s, m)] / r
            total += surv * hp
            surv *= max(0.0, 1.0 - hp - hf)
        return total, n0
    p, counts = {}, {}
    pooled = {}
    for t in grid[:-1]:
        # pooled over states: merge the three cells' risk sets
        surv, total = 1.0, 0.0
        for m in range(grid.index(t), len(grid) - 1):
            r = sum(risk[(t, s, m)] for s in STATES)
            if r == 0:
                break
            hp = sum(ev_pass[(t, s, m)] for s in STATES) / r; hf = sum(ev_fail[(t, s, m)] for s in STATES) / r
            total += surv * hp; surv *= max(0.0, 1.0 - hp - hf)
        pooled[t] = (total, sum(risk[(t, s, grid.index(t))] for s in STATES))
        for s in STATES:
            v, n0 = cell_p(t, s)
            counts[f"{t}|{s}"] = n0
            if n0 >= min_count:
                p[(t, s)] = v
            elif pooled[t][1] >= min_count:
                p[(t, s)] = pooled[t][0]
    R = {}
    for k, t in enumerate(grid[:-1]):
        surv, exp_rem = 1.0, 0.0
        if risk_p[k] < min_count:
            continue
        for m in range(k, len(grid) - 1):
            r = risk_p[m]
            if r == 0:
                break
            h = end_p[m] / r
            exp_rem += surv * (1.0 - h / 2.0) * (grid[m + 1] - grid[m])   # verdicts mid-interval on average
            surv *= 1.0 - h
        R[t] = exp_rem
    R[int(tau)] = 0.0
    return p, R, counts


def fit(groups: dict, tau: float, min_count: int, censoring: str = "drop", audit: str = "all"):
    groups = _select(groups, audit)
    if censoring == "km":
        return fit_km(groups, tau, min_count)
    groups = {k: [x for x in v if not x.get("censored", False)] for k, v in groups.items()}
    num, den, rem = collections.Counter(), collections.Counter(), collections.defaultdict(list)
    for jobs in groups.values():
        for j, x in enumerate(jobs):
            for t in GRID:
                if x["dur"] > t:
                    s = sib_state(jobs, j, t)
                    den[(t, s)] += 1
                    num[(t, s)] += x["pass"] and x["dur"] <= tau
                    rem[t].append(min(x["dur"], tau) - t)
    pooled_num, pooled_den = collections.Counter(), collections.Counter()
    for (t, s), d in den.items():
        pooled_den[t] += d
        pooled_num[t] += num[(t, s)]
    p = {}
    for t in GRID:
        for s in STATES:
            if den[(t, s)] >= min_count:
                p[(t, s)] = num[(t, s)] / den[(t, s)]
            elif pooled_den[t] >= min_count:
                p[(t, s)] = pooled_num[t] / pooled_den[t]
    R = {t: float(st.mean(v)) for t, v in rem.items() if len(v) >= min_count}
    return p, R, {f"{t}|{s}": den[(t, s)] for (t, s) in den}


def main() -> None:
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--run")
    g.add_argument("--probe")
    ap.add_argument("--tau", type=float, default=180.0)
    ap.add_argument("--min-count", type=int, default=20)
    ap.add_argument("--out", required=True)
    ap.add_argument("--censoring", choices=("drop", "km"), default="drop")
    ap.add_argument("--audit", choices=("all", "only", "exclude"), default="all")
    a = ap.parse_args()
    groups = groups_from_run_full(a.run.rstrip("/") + "/output/events.jsonl") if a.run else groups_from_probe(a.probe)
    p, R, counts = fit(groups, a.tau, a.min_count, a.censoring, a.audit)
    out = {"tau": a.tau, "grid": GRID, "source": a.run or a.probe, "n_groups": len(groups), "censoring": a.censoring, "audit": a.audit,
           "n_jobs": sum(len(v) for v in groups.values()),
           "p": {f"{t}|{s}": round(v, 5) for (t, s), v in p.items()}, "R": {str(t): round(v, 3) for t, v in R.items()},
           "counts": counts}
    json.dump(out, open(a.out, "w"), indent=1)
    print(f"groups {len(groups)} jobs {out['n_jobs']}")
    for t in GRID:
        row = {s: round(p[(t, s)], 3) for s in STATES if (t, s) in p}
        if row:
            print(f"  t={t:3d} p={row} R={R.get(t, float('nan')):.1f}")
    print("wrote", a.out)


if __name__ == "__main__":
    main()
