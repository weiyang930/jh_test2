"""Pooled prompt admission with exact two-stage propensities (E0 of the
verification-aware RLVR design; see research/design_verification_aware_rlvr.md).

Per learner step:
  stage 1: strict SRSWOR of ``pool_size`` candidates from the eligible pool
           (a dedicated seeded RNG - never dataloader order or worker state);
           candidate_prob = pool_size / N_t.
  stage 2: mode "uniform"  -> m uniform picks   (conditional prob m/pool_size);
           mode "predict"  -> top-``exploit`` by predictor score (prob 1) plus
           ``audit`` uniform picks from the remainder (prob audit/(pool-exploit));
           during warm-up "predict" falls back to uniform.

Every candidate (selected or not) is logged to ``admission_events.jsonl`` with
both stage probabilities and path_propensity = stage1 * stage2. Unselected
candidates return to the eligible pool after a short cooldown; selected ones are
retired for the run. The predictor is pluggable and refits online from group
outcomes reported by the rollout loop; IPW weights are audit-only and are never
applied to the training loss here.
"""
import json
import os
import pickle
import random
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np

from roll.utils.logging import get_logger

logger = get_logger()


def _structural_features(prompt: str, gt: str) -> List[float]:
    # mirrors experiments/analysis/difficulty_predictor_backtest.py
    return [
        len(prompt), len(gt),
        gt.count("\n"),
        len(re.findall(r"\balways\b", gt)),
        len(re.findall(r"\bposedge\b|\bnegedge\b", gt)),
        len(re.findall(r"\binput\b|\boutput\b", gt)),
        len(re.findall(r"\bcase\b", gt)),
        len(re.findall(r"\bif\b", gt)),
        len(re.findall(r"\breg\b", gt)),
        len(re.findall(r"\bwire\b", gt)),
        len(re.findall(r"<=", gt)),
        float("state" in gt.lower() or "fsm" in prompt.lower()),
        float("counter" in prompt.lower()),
        float("shift" in prompt.lower()),
        float("memory" in prompt.lower() or "ram" in prompt.lower()),
    ]


def item_text(item: dict) -> Tuple[str, str]:
    """(prompt, ground_truth) from a dataset row; messages may be a JSON string or list."""
    msgs = item.get("messages") or item.get("prompt", "")   # Lean rows carry a raw `prompt`, RTL rows `messages`
    if isinstance(msgs, str):
        try:
            msgs = json.loads(msgs)
        except json.JSONDecodeError:
            return msgs, str(item.get("ground_truth", ""))
    prompt = msgs[-1]["content"] if isinstance(msgs, list) and msgs else str(msgs)
    return prompt, str(item.get("ground_truth", ""))


class TwoHeadDifficultyPredictor:
    """Default predictor: TF-IDF + structural features, one head per U-shape end.

    Labels (unified with the offline gate): all_pass := every reward == 1.0;
    too_hard := zero-variance and not all_pass (includes all-0.5 and all-0.9).
    Interchangeable with direct/polynomial variants (leveled offline comparison
    showed parity); kept as default for interpretability only.
    """

    name = "two_head_tfidf_v1"

    def __init__(self):
        self._lock = threading.Lock()
        self._model = None  # (tfidf, mu, sd, clf_easy, clf_hard)
        self.version = 0

    def fit(self, texts: List[Tuple[str, str]], all_pass: List[int], too_hard: List[int]) -> bool:
        from scipy import sparse
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.linear_model import LogisticRegression

        y_easy, y_hard = np.array(all_pass), np.array(too_hard)
        if len(texts) < 64 or y_easy.sum() < 8 or y_hard.sum() < 8 or (1 - y_easy).sum() < 8 or (1 - y_hard).sum() < 8:
            return False
        joined = [p + "\n" + g for p, g in texts]
        tfidf = TfidfVectorizer(max_features=20000, ngram_range=(1, 2), sublinear_tf=True, min_df=2)
        Xt = tfidf.fit_transform(joined)
        Xs = np.array([_structural_features(p, g) for p, g in texts], dtype=float)
        mu, sd = Xs.mean(0), Xs.std(0) + 1e-9
        X = sparse.hstack([Xt, sparse.csr_matrix((Xs - mu) / sd)]).tocsr()
        clf_easy = LogisticRegression(max_iter=2000).fit(X, y_easy)
        clf_hard = LogisticRegression(max_iter=2000).fit(X, y_hard)
        with self._lock:
            self._model = (tfidf, mu, sd, clf_easy, clf_hard)
            self.version += 1
        return True

    def is_ready(self) -> bool:
        return self._model is not None

    def score(self, texts: List[Tuple[str, str]]) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Returns (utility, p_easy, p_hard); utility = 1 - p_easy - p_hard."""
        from scipy import sparse

        with self._lock:
            model = self._model
        if model is None:
            n = len(texts)
            return np.zeros(n), np.full(n, np.nan), np.full(n, np.nan)
        tfidf, mu, sd, clf_easy, clf_hard = model
        joined = [p + "\n" + g for p, g in texts]
        Xt = tfidf.transform(joined)
        Xs = np.array([_structural_features(p, g) for p, g in texts], dtype=float)
        X = sparse.hstack([Xt, sparse.csr_matrix((Xs - mu) / sd)]).tocsr()
        p_easy = clf_easy.predict_proba(X)[:, 1]
        p_hard = clf_hard.predict_proba(X)[:, 1]
        return 1.0 - p_easy - p_hard, p_easy, p_hard

    def save(self, path: str):
        with self._lock:
            with open(path, "wb") as fh:
                pickle.dump({"name": self.name, "version": self.version, "model": self._model}, fh)


@dataclass
class _Outcome:
    dataset_index: int
    all_pass: int
    too_hard: int


class PooledAdmissionPolicy:
    """Owns the per-step candidate pool, selection, propensity logging, and the
    online predictor lifecycle. Constructed by DynamicSamplingScheduler via the
    ``prompt_admission_policy_cls`` extension point (training schedulers only)."""

    def __init__(self, scheduler, pipeline_config, mode: str = "uniform", pool_size: int = 256,
                 batch: int = 64, exploit: int = 56, audit: int = 8, cooldown_steps: int = 2,
                 refit_interval: int = 10, warmup_min_groups: int = 640, seed: Optional[int] = None,
                 bundle_path: Optional[str] = None, mu: float = 0.0,
                 exclude_ids_path: Optional[str] = None, **_ignored):
        assert mode in ("uniform", "predict", "cost_aware"), f"unknown admission mode {mode}"
        if mode == "cost_aware":
            assert bundle_path, "cost_aware mode needs a pretrained score bundle"
        assert exploit + audit == batch, f"{exploit}+{audit} != {batch}"
        self.scheduler = scheduler
        self.mode = mode
        self.pool_size, self.batch, self.exploit, self.audit = pool_size, batch, exploit, audit
        self.cooldown_steps = cooldown_steps
        self.refit_interval = refit_interval
        self.warmup_min_groups = warmup_min_groups
        self.seed = int(seed if seed is not None else getattr(pipeline_config, "seed", 42))
        self.rng = random.Random(self.seed)

        self.dataset = scheduler.dataset
        ids = list(self.dataset["id"])
        self.index_by_id = {str(i): idx for idx, i in enumerate(ids)}
        self.id_by_index = {idx: str(i) for idx, i in enumerate(ids)}
        self.retired: set = set()          # selected once -> out for the run
        self.cooling: Dict[int, int] = {}  # index -> last pool step (unselected members)
        self.queue: List[int] = []
        self.current_step: Optional[int] = None

        self.predictor = TwoHeadDifficultyPredictor()
        self.outcomes: List[_Outcome] = []
        self._refit_thread: Optional[threading.Thread] = None
        self.mu = mu
        self.bundle = None
        if bundle_path:
            from applications.rtl.verify_governor import ScoreBundle
            self.bundle = ScoreBundle(bundle_path)
        if exclude_ids_path:
            with open(exclude_ids_path) as fh:
                excluded = {str(i) for i in json.load(fh)}
            n_excl = 0
            for i_str, idx in self.index_by_id.items():
                if i_str in excluded:
                    self.retired.add(idx); n_excl += 1
            logger.info(f"PooledAdmissionPolicy: excluded {n_excl} pretraining ids from eligibility")

        out_dir = getattr(pipeline_config, "output_dir", None) or "."
        os.makedirs(out_dir, exist_ok=True)
        self.snapshot_dir = os.path.join(out_dir, "admission_predictor")
        os.makedirs(self.snapshot_dir, exist_ok=True)
        self._fh = open(os.path.join(out_dir, "admission_events.jsonl"), "a", encoding="utf-8")
        self._log(event="policy_init", mode=mode, pool_size=pool_size, batch=batch, exploit=exploit,
                  audit=audit, cooldown_steps=cooldown_steps, refit_interval=refit_interval,
                  warmup_min_groups=warmup_min_groups, seed=self.seed, dataset_size=len(ids),
                  predictor=self.predictor.name)
        logger.info(f"PooledAdmissionPolicy: mode={mode} pool={pool_size} batch={batch} "
                    f"exploit/audit={exploit}/{audit} seed={self.seed} N={len(ids)}")

    # ------------------------------------------------------------------ logging
    def _log(self, **event):
        event["ts"] = time.time()
        self._fh.write(json.dumps(event, ensure_ascii=False) + "\n")
        self._fh.flush()

    # ------------------------------------------------------------------ lifecycle
    def _eligible(self, step: int) -> List[int]:
        return [i for i in range(len(self.dataset))
                if i not in self.retired
                and (i not in self.cooling or step - self.cooling[i] > self.cooldown_steps)]

    def on_step(self, step: int):
        """Draw the pool, select the step's admission queue, log every candidate."""
        self.current_step = step
        self._maybe_refit(step)

        eligible = self._eligible(step)
        n_t = len(eligible)
        pool = self.rng.sample(eligible, min(self.pool_size, n_t))
        stage1 = len(pool) / n_t

        texts = [item_text(self.dataset[i]) for i in pool]
        online_ready = self.predictor.is_ready() and len(self.outcomes) >= self.warmup_min_groups
        if self.mode == "cost_aware":
            # difficulty: online heads once warmed (they track policy drift), else the
            # pretrained bundle; cost: always the bundle (quasi-stationary c_eqy)
            bs = [self.bundle.score("\n".join(t)) for t in texts]
            if online_ready:
                utility, p_easy, p_hard = self.predictor.score(texts)
            else:
                utility = np.array([b["utility"] for b in bs])
                p_easy = np.array([b["p_easy"] for b in bs])
                p_hard = np.array([b["p_hard"] for b in bs])
            utility = utility - self.mu * np.array([b["cost_norm"] for b in bs])
            warmed = True
        else:
            warmed = self.mode == "predict" and online_ready
            utility, p_easy, p_hard = self.predictor.score(texts) if warmed else (
                np.zeros(len(pool)), np.full(len(pool), np.nan), np.full(len(pool), np.nan))

        order = list(range(len(pool)))
        self.rng.shuffle(order)                                   # random tie-break
        order.sort(key=lambda k: -utility[k])                     # stable sort
        rank = {k: r for r, k in enumerate(order)}

        if warmed:
            exploit_set = set(order[: self.exploit])
            rest = order[self.exploit:]
            audit_set = set(self.rng.sample(rest, self.audit))
            # inclusion probability: 1 for exploit ranks, audit/len(rest) for every
            # other pool member (drawn into the audit slots or not)
            slot, stage2 = {}, {}
            for k in range(len(pool)):
                if k in exploit_set:
                    slot[k], stage2[k] = "exploit", 1.0
                else:
                    slot[k], stage2[k] = ("audit" if k in audit_set else "none"), self.audit / len(rest)
            selected = exploit_set | audit_set
        else:
            picked = set(self.rng.sample(range(len(pool)), min(self.batch, len(pool))))
            uniform_p = min(self.batch, len(pool)) / len(pool)
            tag = "warmup" if self.mode == "predict" else "uniform"
            slot = {k: (tag if k in picked else "none") for k in range(len(pool))}
            stage2 = {k: uniform_p for k in range(len(pool))}
            selected = picked

        for k, idx in enumerate(pool):
            sel = k in selected
            self._log(event="candidate", step=step, pool_id=step, dataset_id=self.id_by_index[idx],
                      eligible_pool_size=n_t, predictor_version=self.predictor.version,
                      p_easy=None if np.isnan(p_easy[k]) else float(p_easy[k]),
                      p_hard=None if np.isnan(p_hard[k]) else float(p_hard[k]),
                      utility=float(utility[k]), rank=rank[k],
                      stage1_prob=stage1, stage2_prob=float(stage2[k]),
                      path_propensity=stage1 * float(stage2[k]),
                      selected=sel, slot=slot[k] if sel else "none")
            if sel:
                self.retired.add(idx)
                self.cooling.pop(idx, None)
            else:
                self.cooling[idx] = step

        self.queue = [idx for k, idx in enumerate(pool) if k in selected]
        self.rng.shuffle(self.queue)
        self._log(event="step_queue", step=step, queue_size=len(self.queue),
                  warmed=warmed, observed_groups=len(self.outcomes))

    def next_item(self) -> dict:
        if self.queue:
            return self.dataset[self.queue.pop()]
        # replacement request beyond the step's quota (e.g. after a canceled prompt):
        # single uniform draw, logged so the audit can exclude or model it.
        eligible = self._eligible(self.current_step or 0)
        idx = self.rng.choice(eligible)
        self.retired.add(idx)
        self._log(event="candidate", step=self.current_step, pool_id=None,
                  dataset_id=self.id_by_index[idx], eligible_pool_size=len(eligible),
                  predictor_version=self.predictor.version, p_easy=None, p_hard=None,
                  utility=None, rank=None, stage1_prob=1.0 / len(eligible), stage2_prob=1.0,
                  path_propensity=1.0 / len(eligible), selected=True, slot="fallback")
        return self.dataset[idx]

    # ------------------------------------------------------------------ outcomes
    def observe(self, dataset_id: str, rewards: List[float]):
        """Called by the rollout loop on group commit."""
        idx = self.index_by_id.get(str(dataset_id))
        if idx is None or not rewards:
            return
        zero_var = len(set(rewards)) == 1
        all_pass = int(zero_var and rewards[0] == 1.0)
        self.outcomes.append(_Outcome(idx, all_pass, int(zero_var and not all_pass)))

    def _maybe_refit(self, step: int):
        if self.mode not in ("predict", "cost_aware") or step % self.refit_interval != 0 or not self.outcomes:
            return
        if self._refit_thread is not None and self._refit_thread.is_alive():
            return
        snapshot = list(self.outcomes)

        def _fit():
            texts = [item_text(self.dataset[o.dataset_index]) for o in snapshot]
            ok = self.predictor.fit(texts, [o.all_pass for o in snapshot], [o.too_hard for o in snapshot])
            if ok:
                path = os.path.join(self.snapshot_dir, f"v{self.predictor.version}.pkl")
                self.predictor.save(path)
                self._log(event="predictor_refit", step=step, version=self.predictor.version,
                          n_groups=len(snapshot), snapshot=path)

        self._refit_thread = threading.Thread(target=_fit, daemon=True)
        self._refit_thread.start()
