# RTL reward protocol: eqy-v2

This adapter intentionally changes the historical verifier configuration. Do
not pool v1 and v2 training results without identifying the verifier version.
The archived reference implementation is unchanged.

## Preparation and proof

1. Extract the final fenced Verilog answer (including CodeV-style reasoning /
   answer wrappers); retain support for legacy headerless completions.
2. Run the existing Icarus syntax/elaboration check (30 s default).
3. Prepare golden and candidate in separate Yosys processes: hierarchy
   selection, flattening, strict driver/undriven checks, `memory_map`, clock
   lowering, cleanup. Save the elaborated port metadata and normalized RTLIL.
4. Reject unusable references: missing behavior/black boxes, no observable
   outputs, entirely unconstrained outputs, unsupported bidirectional ports,
   or conflicting drivers. Check exact port names, directions and widths
   before attempting equivalence.
5. Feed normalized RTLIL to EQY. Join bits of each vector (`join *`) to avoid
   unnecessary per-bit proof-process launches only for combinational bitwise /
   wiring designs. Designs with storage or multiplication, division, remainder
   or exponentiation retain their original cutpoints. Broad joins caused a
   divider timeout and sequential partitioner regressions in the pinned 2024
   toolchain during testing, so they are deliberately not used there.
   Try SMT induction at depth 10,
   then ABC PDR for partitions the first strategy cannot prove.

Preparation and **all** proof strategies share one 180 s wall-clock budget.
The induction strategy may spend up to 30 s on a partition before trying PDR;
this is not a 30 s cap on the whole verification. Process cleanup can add a
small amount of wall time after the deadline. EQY uses one worker by default.

Neither source RTL nor reference reset values are rewritten. No reset
sequence, initial-state constraints, or `setundef -zero` is added by this
adapter. EQY retains its standard golden-X/don't-care semantics; this is not
a proof of analog timing or of arbitrary event-simulator behavior.

## Clock semantics

Default: `RTL_EQY_CLOCK_MODE=clk2fflogic`. Yosys lowers clocked storage to
generic storage driven by the implicit global step, with explicit edge
detection. This supports multiple clocks and makes asynchronous activity
between clock edges observable in the formal model. It also handles the
unsupported async-register representation found in the CodeV-R1 pilot.

This is still a discrete digital model. Yosys documents a negative-hold-time
assumption for asynchronous controls: deasserting reset simultaneously with
a clock edge retains the reset value for that edge. Metastability, analog
timing, and arbitrary sub-step glitches are outside this model.

Optional: `RTL_EQY_CLOCK_MODE=async2sync` is only appropriate when the task's
input/reset protocol satisfies Yosys's synchronized-input assumption. It is
**not** an automatic fallback from a failed multi-clock proof. `none` disables
clock lowering for diagnostic comparisons, not historical-v1 reproduction.

The adapter uses Yosys auto-top by default rather than choosing the first
declared helper module. Callers can supply `gold_top` / `gate_top` explicitly.
Datasets containing multiple unrelated root modules need an explicit top;
automatic top selection must not be used to guess the intended design.

## Rewards and failure handling

| Outcome | Scalar | Meaning |
| --- | ---: | --- |
| `pass` | 1.0 | Non-vacuous reference/interface checks succeeded and EQY produced its PASS artifact |
| `syntax_fail`, `syntax_timeout` | 0.5 | Candidate not accepted by the syntax stage in budget |
| `interface_mismatch`, `candidate_invalid`, `candidate_prepare_fail` | 0.9 | Candidate not certifiable by this RTL protocol |
| `eqy_counterexample` | 0.9 | A base-case/PDR counterexample exists in an EQY partition |
| `eqy_unknown`, `eqy_timeout` | 0.9 | Not certified in budget, **not** established functional incorrectness |
| Bad reference/configuration or crashed/missing tool | placeholder only | `reward_valid=False`; the worker logs the failure and raises before returning a training reward batch |

The .5/.9/1 ladder is retained to avoid changing GRPO reward shaping in the
same patch. The functional component is explicitly **proof success within
the configured budget**, not an oracle that perfectly labels correctness.
A partition counterexample is not necessarily a replayed whole-design trace;
EQY cutpoints can make a partition obligation stronger than end-to-end output
equivalence. Induction-only failures are always UNKNOWN.

Run golden preflight and exclude unusable prompts **before** training. At
runtime, do not silently drop one bad completion: that changes the GRPO group
normalization. Infrastructure failures must be fixed/retried; the worker
fails closed instead of feeding their placeholder scores to the learner.
Exception: if a strategy already returned a valid UNKNOWN and its optional
fallback subsequently errors, retain UNKNOWN and log the fallback failure.
This is still a non-success (.9) budgeted reward, never a correctness claim.
This patch does not implement automatic group retries or dataset filtering.

Each result/event includes `protocol`, configuration, outcome/reason,
`reward_valid`, and stage exit codes/timings. `keep_artifacts=True` preserves
source, prepared designs, configuration and proof logs in a unique workspace.

## Settings and tests

Environment variables:

- `RTL_OSS_CAD_BIN`: installed OSS CAD Suite `bin` directory.
- `RTL_EQY_TIMEOUT_S=180`: shared preparation/proof deadline.
- `RTL_EQY_DEPTH=10`: induction depth, not a finite simulation horizon.
- `RTL_EQY_INDUCTION_TIMEOUT_S=30`: per-partition first-strategy budget.
- `RTL_EQY_JOBS=1`: internal EQY parallelism; account for reward-worker count.
- `RTL_EQY_CLOCK_MODE=clk2fflogic`: clock-lowering protocol.

Run from the repository root:

```sh
python applications/rtl/tests/test_verifier.py
RTL_OSS_CAD_BIN=/path/to/oss-cad-suite/bin python applications/rtl/tests/test_verifier_eda.py
```

The first suite needs only Python. The second uses real tools, positive and
negative circuits, a ROM, asynchronous reset/clock-edge mismatches, multi-module
hierarchy, invalid interfaces/references, and independent concurrent workspaces.
It skips explicitly when the required toolchain is not installed.

Primary tool documentation:

- [memory_map](https://yosyshq.readthedocs.io/projects/yosys/en/0.40/cmd/memory_map.html)
- [clk2fflogic](https://yosyshq.readthedocs.io/projects/yosys/en/0.40/cmd/clk2fflogic.html)
- [async2sync](https://yosyshq.readthedocs.io/projects/yosys/en/0.40/cmd/async2sync.html)
- [EQY strategies](https://yosyshq.readthedocs.io/projects/eqy/en/latest/strategies.html)
- [EQY partition grouping](https://yosyshq.readthedocs.io/projects/eqy/en/latest/config.html#collect-sections)
