"""History-based prompt admission (the 'selector' arm): which prompts get a GRPO group this step.

Per prompt (dataset id) it keeps what earlier groups of the same prompt did: visits, informative groups, all-pass
groups, all-fail groups, verifier CPU-seconds, and cancellations. A cancelled group (stale expiry or controller
abandonment) has NO outcome: it never enters the informative posterior, only its verifier-seconds enter the cost
(2026-10-25 fix; before, cancellations counted as zero-gradient and fed a censoring loop). Each learner step it fills a queue of ``batch`` prompts:
  uniform    random among eligible prompts (control; same bookkeeping and logs)
  skip       exclude prompts whose last group was zero-gradient (all-pass or all-fail); an epsilon share of the
             queue is drawn uniformly from the excluded set so every prompt keeps a known revisit probability
  weighted   sample without replacement with weight = posterior P(informative) / (1 + cost_scale * mean cpu-s),
             P(informative) ~ Beta(alpha + informative, beta + zero-gradient); epsilon share uniform
  ucb        posterior mean + sqrt(2 ln(step+1) / (visits+1)) bonus, top-``batch`` deterministic + epsilon uniform
  prior      weight = P(group informative | probe pass rate q) = 1 - q^G - (1-q)^G from a one-time probe
             (``prior_path`` = probe summary.json with per-problem passes/n), sharpened online by the Beta posterior
             of observed groups; epsilon share uniform. The online form of offline difficulty filtering.
  topk       the slide-16 rule (2026-10-25): ``pool_size`` uniform candidates among the eligible prompts, score
             V - rho_t * C (V = posterior P(informative) from completed groups, C = mean verifier-seconds per group
             including cancelled checks), the ``audit`` lowest slots filled uniformly from the remaining candidates
             (the audit lane); ``visit_budget`` > 0 caps admissions per prompt within ``budget_window`` steps so the
             selector cannot farm a few always-informative prompts (coverage stays at the uniform level);
             price="shared" reads the verification governor's current price (one price for admission and stopping),
             price="const" uses ``rho``.
The epsilon share of every queue is the audit lane: those prompts are tagged (``is_audit``), logged with their
inclusion probability, and the verification controller must not abandon their groups (they keep the hazard tables'
tail observed). Prompts seen within ``cooldown_steps`` steps are not eligible again. next_item() beyond the step's queue (replacement
after an abandoned group) draws from the same distribution. Every decision is logged to admission_events.jsonl.
Interface expected by DynamicSamplingScheduler / RTLRolloutLoop: on_step(step), next_item(), observe_group(...),
release(dataset_id).
"""
from __future__ import annotations

import json
import math
import os
import random
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from roll.utils.logging import get_logger

logger = get_logger()
MODES = ("uniform", "skip", "weighted", "ucb", "prior", "topk")


@dataclass
class _Stats:
    k: int = -1                  # dataset index (for the text prior)
    visits: int = 0
    informative: int = 0
    all_pass: int = 0
    all_fail: int = 0
    cancelled: int = 0
    constant_partial: int = 0     # constant non-pass graded reward (RTL 0.5 / 0.75 / 0.9): zero-gradient, not all_pass
    cpu_s: float = 0.0
    cancelled_cpu_s: float = 0.0
    last_step: int = -10 ** 9
    steps: list = field(default_factory=list)   # admission steps (visit budget)
    outcomes: list = field(default_factory=list)   # (step, kind) of completed groups, for the windowed posterior
    last_kind: str = "none"      # none | informative | all_pass | all_fail | constant_partial | cancelled


class HistoryAdmissionPolicy:
    def __init__(self, scheduler, pipeline_config, mode: str = "weighted", batch: int = 64, epsilon: float = 0.1,
                 cooldown_steps: int = 2, alpha: float = 1.0, beta: float = 1.0, cost_scale: float = 0.0,
                 seed: Optional[int] = None, prior_path: Optional[str] = None, group_size: int = 8, pool_size: int = 256,
                 audit: Optional[int] = None, price: str = "const", rho: float = 0.0, visit_budget: int = 0, window: int = 0,
                 budget_window: int = 100, text: bool = False, text_refit_interval: int = 50, text_prior_weight: float = 2.0,
                 text_window: int = 100, **_ignored):
        assert mode in MODES, f"unknown history admission mode {mode}"
        assert price in ("const", "shared"), price
        self.mode, self.batch, self.epsilon = mode, int(batch), float(epsilon)
        self.scheduler = scheduler
        self.pool_size, self.price_mode, self.rho = int(pool_size), price, float(rho)
        self.window = int(window)   # > 0: the informative posterior uses only outcomes from the last `window` steps
                                    # (the policy learns the problems it is trained on; a cumulative posterior keeps
                                    # rating a solved problem informative, 2026-10-26 pilot collapse; S6 sim)
        self.audit = int(audit) if audit is not None else max(1, int(batch) // 8)
        self.visit_budget, self.budget_window = int(visit_budget), int(budget_window)
        self.cooldown_steps, self.alpha, self.beta, self.cost_scale = int(cooldown_steps), float(alpha), float(beta), float(cost_scale)
        self.seed = int(seed if seed is not None else getattr(pipeline_config, "seed", 42))
        self.rng = random.Random(self.seed)
        self.dataset = scheduler.dataset
        ids = [str(self.dataset[i]["id"]) for i in range(len(self.dataset))]
        assert len(set(ids)) == len(ids), "history admission needs unique dataset ids"
        self.index_by_id = {i: k for k, i in enumerate(ids)}
        self.id_by_index = {k: i for k, i in enumerate(ids)}
        self.stats: Dict[int, _Stats] = {k: _Stats(k=k) for k in range(len(ids))}
        # text heads (TF-IDF + structural features, applications/rtl/admission.TwoHeadDifficultyPredictor): refit every
        # text_refit_interval steps on the groups completed in the last text_window steps; their V(x) is the prior of
        # the per-prompt posterior, worth text_prior_weight observed groups (unseen prompts rank by text alone)
        self.text, self.text_refit_interval = bool(text), int(text_refit_interval)
        self.text_prior_weight, self.text_window = float(text_prior_weight), int(text_window)
        self._text_records: list = []          # (step, k, all_pass, too_hard)
        self._v_text: Optional[list] = None    # per-k text prior, refreshed at every refit
        self._texts: Optional[list] = None
        self._text_predictor = None
        self._text_thread: Optional[threading.Thread] = None
        self._text_version = 0
        self.group_size = int(group_size)
        self.prior: Dict[int, float] = {}
        if mode == "prior":
            assert prior_path, "prior mode needs prior_path (probe summary.json)"
            probs = json.load(open(prior_path))["problems"]
            for i, k in self.index_by_id.items():
                rec = probs.get(i)
                if rec and rec.get("n"):
                    q = rec["passes"] / rec["n"]
                    self.prior[k] = max(1e-6, 1.0 - q ** self.group_size - (1.0 - q) ** self.group_size)
            missing = len(ids) - len(self.prior)
            logger.info(f"HistoryAdmissionPolicy prior: {len(self.prior)} problems with probe stats, {missing} without (weight = mean)")
        self.queue: List[int] = []
        self.current_step: int = 0
        self.audit_ids: set = set()                       # dataset ids whose current group is an audit draw
        self._audit_last: set = set()
        self._pending_cancel_cost: Dict[str, float] = {}  # verifier-seconds of cancelled checks, from the governor
        out_dir = getattr(pipeline_config, "output_dir", None) or "."
        os.makedirs(out_dir, exist_ok=True)
        self._fh = open(os.path.join(out_dir, "admission_events.jsonl"), "a", encoding="utf-8")
        self._log(event="policy_init", policy="history", mode=mode, batch=batch, epsilon=epsilon, cooldown_steps=cooldown_steps,
                  alpha=alpha, beta=beta, cost_scale=cost_scale, n_prompts=len(ids), seed=self.seed, pool_size=self.pool_size,
                  audit=self.audit, price=price, rho=self.rho, visit_budget=self.visit_budget, budget_window=self.budget_window, window=self.window,
                  text=self.text, text_refit_interval=self.text_refit_interval, text_prior_weight=self.text_prior_weight, text_window=self.text_window)
        logger.info(f"HistoryAdmissionPolicy: mode={mode} batch={batch} eps={epsilon} N={len(ids)}")

    # ------------------------------------------------------------------ bookkeeping
    def _log(self, **event):
        event.setdefault("step", self.current_step)
        self._fh.write(json.dumps(event, ensure_ascii=False) + "\n")
        self._fh.flush()

    def _p_inform(self, s: _Stats) -> float:
        """P(next group of this prompt is informative): Beta posterior over its completed groups (cancelled groups carry
        no outcome); with ``window`` > 0 only the outcomes of the last ``window`` steps count."""
        if self.window > 0:
            recent = [k for st, k in s.outcomes if st >= self.current_step - self.window]
            inf = sum(1 for k in recent if k == "informative"); zero = len(recent) - inf
        else:
            inf, zero = s.informative, s.all_pass + s.all_fail + s.constant_partial
        a, b = self.alpha, self.beta
        if self._v_text is not None and 0 <= s.k < len(self._v_text):   # text prior as pseudo-counts
            v = min(0.99, max(0.01, float(self._v_text[s.k])))
            a, b = self.text_prior_weight * v, self.text_prior_weight * (1.0 - v)
        return (a + inf) / (a + b + inf + zero)

    # ------------------------------------------------------------------ text heads
    def _maybe_refit_text(self, step: int):
        if not self.text or step <= 0 or step % self.text_refit_interval != 0:
            return
        if self._text_thread is not None and self._text_thread.is_alive():
            return
        recs = [r for r in self._text_records if r[0] >= step - self.text_window]
        if len(recs) < 64:
            self._log(event="text_refit_skipped", step=step, n_records=len(recs))
            return
        if self._texts is None:
            from applications.rtl.admission import item_text
            self._texts = [item_text(self.dataset[k]) for k in range(len(self.stats))]
        texts = [self._texts[r[1]] for r in recs]; y_easy = [r[2] for r in recs]; y_hard = [r[3] for r in recs]

        def _fit():
            t0 = time.time()
            try:
                from applications.rtl.admission import TwoHeadDifficultyPredictor
                pred = self._text_predictor or TwoHeadDifficultyPredictor()
                if not pred.fit(texts, y_easy, y_hard):
                    self._log(event="text_refit_skipped", step=step, n_records=len(recs), reason="class_counts")
                    return
                v, _, _ = pred.score(self._texts)
                self._text_predictor, self._v_text, self._text_version = pred, [float(x) for x in v], pred.version
                self._log(event="text_refit", step=step, n_records=len(recs), version=pred.version, elapsed_s=round(time.time() - t0, 1),
                          v_mean=round(sum(self._v_text) / len(self._v_text), 4), v_p10=round(sorted(self._v_text)[len(self._v_text) // 10], 4),
                          v_p90=round(sorted(self._v_text)[9 * len(self._v_text) // 10], 4))
            except Exception as exc:  # the selector must never take the pipeline down
                self._log(event="text_refit_error", step=step, error=repr(exc)[:300])
        self._text_thread = threading.Thread(target=_fit, daemon=True)
        self._text_thread.start()

    def _weight(self, k: int, step: int) -> float:
        s = self.stats[k]
        p = self._p_inform(s)
        if self.mode == "prior":
            mean_prior = (sum(self.prior.values()) / len(self.prior)) if self.prior else 0.5
            prior = self.prior.get(k, mean_prior)
            n_obs = s.informative + s.all_pass + s.all_fail + s.constant_partial
            p = (prior * 2.0 + s.informative) / (2.0 + n_obs)   # probe prior worth two observed groups
        if self.mode == "ucb":
            p = p + math.sqrt(2.0 * math.log(step + 2) / (s.visits + 1))
        cost = (s.cpu_s / s.visits) if s.visits else 0.0
        return max(p, 1e-6) / (1.0 + self.cost_scale * cost)

    def current_price(self) -> float:
        """rho_t: the governor's price when price="shared" and a controller is running, else the constant rho."""
        if self.price_mode == "shared":
            gov = getattr(self.scheduler, "verify_governor", None)
            p = getattr(gov, "current_price", None)
            if p is not None:
                return float(p)
        return self.rho

    def _score(self, k: int, step: int, price: float) -> float:
        """V - rho_t * C: posterior P(informative) minus the price of the mean verifier-seconds one group of this prompt
        has cost so far (completed and cancelled groups alike; no observation -> the running mean over all prompts)."""
        s = self.stats[k]
        n = s.informative + s.all_pass + s.all_fail + s.constant_partial + s.cancelled
        cost = (s.cpu_s / n) if n else self._mean_cost()
        return self._p_inform(s) - price * cost

    def _mean_cost(self) -> float:
        tot = sum(st.cpu_s for st in self.stats.values())
        n = sum(st.informative + st.all_pass + st.all_fail + st.constant_partial + st.cancelled for st in self.stats.values())
        return (tot / n) if n else 0.0

    def _eligible(self, step: int) -> List[int]:
        el = [k for k, s in self.stats.items() if step - s.last_step > self.cooldown_steps]
        if self.visit_budget > 0:
            lo = step - self.budget_window
            el = [k for k in el if sum(1 for t in self.stats[k].steps if t > lo) < self.visit_budget]
        return el

    def _draw(self, step: int, n: int, exclude: set) -> List[int]:
        """Draw n distinct prompts for this step according to the mode."""
        elig = [k for k in self._eligible(step) if k not in exclude]
        if not elig:
            elig = [k for k in self.stats if k not in exclude] or list(self.stats)
        n = min(n, len(elig))
        n_eps = int(round(self.epsilon * n)) if self.mode != "uniform" else 0
        picked: List[int] = []
        self._audit_last = set()
        if self.mode == "uniform":
            picked = self.rng.sample(elig, n)
        elif self.mode == "topk":
            price = self.current_price(); self._last_price = price
            cand = self.rng.sample(elig, min(self.pool_size, len(elig)))
            cand.sort(key=lambda k: -self._score(k, step, price))
            n_audit = min(self.audit, n) if n >= self.batch else 0      # replacement draws (n=1) are not audits
            picked = cand[: n - n_audit]
            picked = self._fill_audit(picked, cand[n - n_audit:], n)
        elif self.mode == "skip":
            good = [k for k in elig if self.stats[k].last_kind in ("none", "informative", "cancelled")]
            bad = [k for k in elig if k not in set(good)]
            n_good = min(n - n_eps, len(good))
            picked = self.rng.sample(good, n_good)
            rest = [k for k in bad + good if k not in set(picked)]
            picked = self._fill_audit(picked, rest, n)
        else:  # weighted / ucb / prior
            w = {k: self._weight(k, step) for k in elig}
            if self.mode == "ucb":
                order = sorted(elig, key=lambda k: -w[k])
                picked = order[: n - n_eps]
            else:
                pool = list(elig)
                for _ in range(n - n_eps):
                    tot = sum(w[k] for k in pool)
                    r = self.rng.random() * tot
                    acc = 0.0
                    for i, k in enumerate(pool):
                        acc += w[k]
                        if acc >= r:
                            picked.append(pool.pop(i))
                            break
            rest = [k for k in elig if k not in set(picked)]
            picked = self._fill_audit(picked, rest, n)
        return picked

    def _fill_audit(self, picked: List[int], rest: List[int], n: int) -> List[int]:
        """The uniform fill of a queue is the audit lane: tagged, with a known inclusion probability."""
        extra = self.rng.sample(rest, min(n - len(picked), len(rest)))
        self._audit_last.update(extra)
        self._audit_prob = (len(extra) / len(rest)) if rest else 0.0
        return picked + extra

    # ------------------------------------------------------------------ scheduler interface
    def on_step(self, step: int):
        self.current_step = step
        self._maybe_refit_text(step)
        picked = self._draw(step, self.batch, exclude=set())
        for k in picked:
            s = self.stats[k]
            audit = k in self._audit_last
            if audit:
                self.audit_ids.add(self.id_by_index[k])
            self._log(event="admit", dataset_id=self.id_by_index[k], slot="audit" if audit else "exploit", mode=self.mode,
                      visits=s.visits, p_inform=round(self._p_inform(s), 4), last_kind=s.last_kind,
                      weight=round(self._weight(k, step), 5), audit=audit,
                      propensity=round(getattr(self, "_audit_prob", 0.0), 5) if audit else None)
            s.last_step = step
        self.queue = list(picked)
        self.rng.shuffle(self.queue)
        n_zero = sum(1 for s in self.stats.values() if s.last_kind in ("all_pass", "all_fail", "constant_partial"))
        self._log(event="step_queue", queue_size=len(self.queue), n_seen=sum(1 for s in self.stats.values() if s.visits),
                  n_last_zero_gradient=n_zero, price=getattr(self, "_last_price", None), n_eligible=len(self._eligible(step)))

    def next_item(self) -> dict:
        if not self.queue:
            k = self._draw(self.current_step, 1, exclude=set())[0]
            self.stats[k].last_step = self.current_step
            self._log(event="admit", dataset_id=self.id_by_index[k], slot="replacement", mode=self.mode,
                      visits=self.stats[k].visits, p_inform=round(self._p_inform(self.stats[k]), 4), last_kind=self.stats[k].last_kind)
            self.queue.append(k)
        k = self.queue.pop()
        self.stats[k].visits += 1
        self.stats[k].steps.append(self.current_step)
        return self.dataset[k]

    def observe_group(self, dataset_id: str, prompt_id: int, rewards: List[float], cpu_seconds: float, valid: bool,
                      stages: Optional[List[str]] = None):
        """One finished group. ``informative`` = reward variance > 0 (what GRPO uses); the zero-gradient kinds are told
        apart by the verifier verdicts (``stages``), not by reward > 0: RTL grades failures 0.5 / 0.75 / 0.9."""
        k = self.index_by_id.get(str(dataset_id))
        if k is None:
            return
        s = self.stats[k]
        self.audit_ids.discard(str(dataset_id))
        s.cpu_s += float(cpu_seconds or 0.0)
        if not valid or not rewards:
            kind = "cancelled"
            s.cancelled_cpu_s += float(cpu_seconds or 0.0)
        elif len(set(rewards)) > 1:
            kind = "informative"
        elif stages:
            n_pass = sum(1 for st in stages if str(st) == "pass")
            kind = "all_pass" if n_pass == len(stages) else ("all_fail" if n_pass == 0 else "informative")
        else:
            kind = "all_pass" if rewards[0] >= 1.0 else ("all_fail" if rewards[0] <= 0 else "constant_partial")
        setattr(s, kind, getattr(s, kind) + 1)
        s.last_kind = kind
        if kind != "cancelled":
            s.outcomes.append((self.current_step, kind))
            if len(s.outcomes) > 64:
                del s.outcomes[:-64]
            if self.text:
                self._text_records.append((self.current_step, k, int(kind == "all_pass"), int(kind in ("all_fail", "constant_partial"))))
                if len(self._text_records) > 20000:
                    del self._text_records[:-20000]
        self._log(event="observe", dataset_id=str(dataset_id), prompt_id=prompt_id, kind=kind, cpu_s=round(float(cpu_seconds or 0.0), 2),
                  visits=s.visits, p_inform=round(self._p_inform(s), 4))

    def release(self, dataset_id: str, cpu_seconds: Optional[float] = None):
        """Prompt task cancelled (stale GC or controller abandonment): no outcome, so the informative posterior is
        untouched; the verifier-seconds the cancelled checks consumed (from the governor via ``note_cancel_cost``, or
        passed explicitly) enter the cost estimate."""
        k = self.index_by_id.get(str(dataset_id))
        if k is None:
            return
        s = self.stats[k]
        self.audit_ids.discard(str(dataset_id))
        cost = float(cpu_seconds) if cpu_seconds is not None else self._pending_cancel_cost.pop(str(dataset_id), 0.0)
        s.cancelled += 1
        s.cancelled_cpu_s += cost
        s.cpu_s += cost
        s.last_kind = "cancelled"
        self._log(event="release", dataset_id=str(dataset_id), visits=s.visits, cancelled_cpu_s=round(cost, 2),
                  p_inform=round(self._p_inform(s), 4))

    def note_cancel_cost(self, dataset_id: str, running_s: float):
        """Called by the verification governor for every cancelled check: verifier-seconds it had consumed."""
        self._pending_cancel_cost[str(dataset_id)] = self._pending_cancel_cost.get(str(dataset_id), 0.0) + float(running_s or 0.0)

    def is_audit(self, dataset_id: str) -> bool:
        """True while ``dataset_id``'s current group is an audit draw (the controller must not abandon it)."""
        return str(dataset_id) in self.audit_ids
