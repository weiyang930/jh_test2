"""Instrumented rollout loop for the RTL native-async baseline.

Subclasses ROLL's ``UserDefinedRolloutLoop`` (the configured
``user_defined_rollout_loop_cls`` extension point) to record the full per-prompt
/ per-sample lifecycle without changing any scheduler semantics:

    - prompt admission / sampling_start_step binding;
    - per-member generation attempts and partial-rollout resumptions;
    - reward submission / worker start / worker end / reward return
      (separating reward-queue wait from verifier execution);
    - atomic group commit, filtering, cancellation (native stale GC), errors.

Events go to ``<output_dir>/events.jsonl`` (single scheduler process per domain,
line-buffered).  Each committed response additionally carries non-tensor columns
(`group_id`, `group_member_index`, `target_group_size`, `sampling_start_step`,
timing fields) so staleness and group identity survive into the learner batch.
"""
import asyncio
import copy
import json
import os
import time
from typing import List, Optional

import numpy as np
import torch

from roll.distributed.scheduler.generate_scheduler import RolloutContext, expand_requests
from roll.distributed.scheduler.protocol import DataProto
from roll.distributed.scheduler.router import is_report_data_finished
from roll.distributed.scheduler.user_defined_rollout_loop import (
    UserDefinedRolloutLoop,
    postprocess_output_data,
    postprocess_paused_data,
    query_filter,
)
from roll.utils.logging import get_logger

logger = get_logger()

RELEASED_STAGE = "released"


def fill_released_members(responses: List[DataProto]) -> List[bool]:
    """Partial release: mark placeholder rows (verifier_stage "released") and give them the verified members' mean
    reward so group-shaped learner code (compaction, difficulty mask, masked group normalization) sees whole groups.
    Every row gets a ``member_filler`` tensor column (1 = released placeholder, masked out of the loss)."""
    released = [str(r.non_tensor_batch.get("verifier_stage", ["?"])[0]) == RELEASED_STAGE for r in responses]
    verified = [float(r.batch["response_level_rewards"][0]) for r, rel in zip(responses, released) if not rel]
    fill = float(np.mean(verified)) if verified else 0.0
    for response, rel in zip(responses, released):
        n = response.batch.batch_size[0]
        response.batch["member_filler"] = torch.full((n,), int(rel), dtype=torch.long)
        if rel:
            response.batch["response_level_rewards"] = torch.full((n,), fill, dtype=torch.float32)
            if "scores" in response.batch.keys():
                response.batch["scores"] = torch.full((n,), fill, dtype=torch.float32)
    return released



class _EventWriter:
    def __init__(self):
        self._fh = None
        self._path = None

    def ensure_open(self, output_dir: str):
        if self._fh is None and output_dir:
            os.makedirs(output_dir, exist_ok=True)
            self._path = os.path.join(output_dir, "events.jsonl")
            self._fh = open(self._path, "a", encoding="utf-8")
            logger.info(f"RTL rollout loop event log: {self._path}")

    def log(self, **event):
        if self._fh is None:
            return
        event["ts"] = time.time()
        self._fh.write(json.dumps(event, ensure_ascii=False) + "\n")
        self._fh.flush()


class RTLRolloutLoop(UserDefinedRolloutLoop):
    """UserDefinedRolloutLoop with full lifecycle instrumentation (no semantic change)."""

    def __init__(self):
        super().__init__()
        self.events = _EventWriter()
        self.run_id = os.environ.get("RUN_ID", "unset")
        self._dataset_id_by_prompt: dict = {}
        self._audit_by_prompt: dict = {}   # prompt_id -> admitted through the audit lane (never abandoned)

    async def process_new_prompt(self, context: RolloutContext) -> Optional[List[DataProto]]:
        self.events.ensure_open(getattr(context.pipeline_config, "output_dir", None))
        num_return_sequences = context.meta_info["generation_config"]["num_return_sequences"]
        t_admit = time.time()
        # per-prompt progress state, reported on cancellation (native stale GC)
        state = {
            "gen_started": 0,
            "gen_finished": 0,
            "reward_submitted": 0,
            "reward_finished": 0,
        }
        try:
            responses = await self._process_new_prompt_impl(
                context, num_return_sequences, t_admit, state
            )
        except asyncio.CancelledError:
            # Native ReplayBuffer.gc()/shutdown cancelled this prompt task.
            admission = getattr(context._scheduler, "admission_policy", None)
            if hasattr(admission, "release"):
                admission.release(self._dataset_id_by_prompt.get(context.prompt_id, "?"))
            self.events.log(
                event="prompt_canceled",
                run_id=self.run_id,
                prompt_id=context.prompt_id,
                dataset_id=self._dataset_id_by_prompt.pop(context.prompt_id, "?"),
                sampling_start_step=context.sampling_start_step,
                target_group_size=num_return_sequences,
                outcome_observed=False,
                reward=None,
                **state,
            )
            raise
        except BaseException as exc:
            admission = getattr(context._scheduler, "admission_policy", None)
            if hasattr(admission, "release"):
                admission.release(self._dataset_id_by_prompt.get(context.prompt_id, "?"))
            self.events.log(
                event="prompt_exception",
                run_id=self.run_id,
                prompt_id=context.prompt_id,
                dataset_id=self._dataset_id_by_prompt.pop(context.prompt_id, "?"),
                sampling_start_step=context.sampling_start_step,
                error=repr(exc)[:500],
                **state,
            )
            raise
        return responses

    async def _process_new_prompt_impl(
        self, context: RolloutContext, num_return_sequences: int, t_admit: float, state: dict
    ) -> Optional[List[DataProto]]:
        is_num_return_sequences_expand = context.is_num_return_sequences_expand

        # STEP 1: dataset item
        request_data, domain = context.get_request_data(meta_info=context.meta_info)
        dataset_id = str(np.asarray(request_data.non_tensor_batch.get("id", ["?"])).flatten()[0])
        self._dataset_id_by_prompt[context.prompt_id] = dataset_id
        admission = getattr(context._scheduler, "admission_policy", None)
        audit = bool(getattr(admission, "is_audit", lambda _d: False)(dataset_id))
        self._audit_by_prompt[context.prompt_id] = audit
        request_data_list = expand_requests(
            data=request_data,
            num_return_sequences=num_return_sequences,
            is_num_return_sequences_expand=is_num_return_sequences_expand,
        )

        # STEP 2: generate + reward all members
        async with context.do_generate_and_reward(max_concurrency=num_return_sequences):
            self.events.log(
                event="prompt_begin",
                run_id=self.run_id,
                prompt_id=context.prompt_id,
                dataset_id=dataset_id,
                domain=domain,
                sampling_start_step=context.sampling_start_step,
                target_group_size=num_return_sequences,
                t_admit=t_admit,
                audit=audit,
            )
            tasks = [
                asyncio.create_task(
                    self._generate_and_reward_instrumented(
                        context=context, req=req, domain=domain, member_index=idx, state=state
                    )
                ) for idx, req in enumerate(request_data_list)
            ]
            try:
                responses_list = await asyncio.gather(*tasks)
            except BaseException:
                # Drain siblings before leaving the context so its inflight
                # assertion cannot obscure the actual verifier/resume error.
                for task in tasks:
                    task.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)
                raise
            if not all(sublist is not None for sublist in responses_list):
                return None
            responses: List[DataProto] = [item for sublist in responses_list for item in sublist]

        # Observe complete groups BEFORE filtering: otherwise a selector trained
        # with dynamic sampling would only ever receive positive utility labels.
        if len(responses) != num_return_sequences:
            raise RuntimeError(f"Incomplete CodeV group: {len(responses)}/{num_return_sequences}")
        released = fill_released_members(responses)   # partial release: placeholder rows -> group-mean reward, member_filler
        verified = [r for r, rel in zip(responses, released) if not rel]
        group_rewards = [float(r.batch["response_level_rewards"][0]) for r in verified]
        group_valid = all(bool(r.non_tensor_batch.get("reward_valid", [True])[0]) for r in verified)
        if any(released) and not (len(verified) >= 2 and len(set(round(r, 6) for r in group_rewards)) > 1):
            group_valid = False  # a released group must be informative on its verified members
        admission_policy = getattr(context._scheduler, "admission_policy", None)
        if hasattr(admission_policy, "observe_group"):
            admission_policy.observe_group(
                dataset_id, context.prompt_id, group_rewards,
                sum(float(r.non_tensor_batch.get("verifier_cpu_core_seconds", [0.0])[0]) for r in responses),
                group_valid,
                stages=[str(r.non_tensor_batch.get("verifier_stage", ["?"])[0]) for r in verified],
            )
        if not group_valid:
            self.events.log(event="prompt_invalid", run_id=self.run_id, prompt_id=context.prompt_id,
                            dataset_id=dataset_id, sampling_start_step=context.sampling_start_step,
                            stages=[str(r.non_tensor_batch.get("verifier_stage", ["?"])[0]) for r in responses])
            self._dataset_id_by_prompt.pop(context.prompt_id, None)
            return None

        # STEP 3: prompt-level filter (native; no_filter in the RTL baseline config)
        if not context.is_val and not query_filter(responses, context.pipeline_config):
            self.events.log(
                event="prompt_filtered",
                run_id=self.run_id,
                prompt_id=context.prompt_id,
                dataset_id=dataset_id,
                sampling_start_step=context.sampling_start_step,
                rewards=[float(r.batch["response_level_rewards"][0]) for r in responses],
            )
            self._dataset_id_by_prompt.pop(context.prompt_id, None)
            return None

        # Stamp group identity / staleness columns onto every member response (actual_group_size = verified members).
        actual_group_size = len(verified)
        for member_index, response in enumerate(responses):
            n = response.batch.batch_size[0]
            response.non_tensor_batch["group_id"] = np.array([context.prompt_id] * n, dtype=object)
            response.non_tensor_batch["group_member_index"] = np.array([member_index] * n, dtype=object)
            response.non_tensor_batch["target_group_size"] = np.array([num_return_sequences] * n, dtype=object)
            response.non_tensor_batch["actual_group_size"] = np.array([actual_group_size] * n, dtype=object)
            response.non_tensor_batch["sampling_start_step"] = np.array(
                [context.sampling_start_step] * n, dtype=object
            )

        if len(responses) != num_return_sequences:
            # ragged group: fail loudly, never silently reshape
            raise RuntimeError(
                f"RTL baseline requires complete groups: prompt {context.prompt_id} "
                f"produced {len(responses)}/{num_return_sequences} members"
            )

        committed_rewards = group_rewards
        admission_policy = getattr(context._scheduler, "admission_policy", None)
        if admission_policy is not None and not hasattr(admission_policy, "observe_group"):
            admission_policy.observe(dataset_id, committed_rewards)
        self._dataset_id_by_prompt.pop(context.prompt_id, None)
        self.events.log(
            event="prompt_commit",
            run_id=self.run_id,
            prompt_id=context.prompt_id,
            dataset_id=dataset_id,
            sampling_start_step=context.sampling_start_step,
            group_size=actual_group_size,
            released=int(sum(released)),
            rewards=[float(r.batch["response_level_rewards"][0]) for r in responses],
            stages=[str(r.non_tensor_batch.get("verifier_stage", ["?"])[0]) for r in responses],
            outcome_observed=True,
            t_admit=t_admit,
            t_commit=time.time(),
        )
        return responses

    async def _generate_and_reward_instrumented(
        self, context: RolloutContext, req: DataProto, domain: str, member_index: int, state: dict
    ):
        """Mirror of the base ``_generate_and_reward_impl`` with timing hooks.

        Control flow is identical to
        ``UserDefinedRolloutLoop._generate_and_reward_impl`` (including the
        5-retry response-filter loop and partial-rollout resumption).
        """
        responses: List[DataProto] = []

        for _ in range(5):
            original_req = copy.deepcopy(req)
            collect_unfinished = req.meta_info.get("collect_unfinished", False)

            gen_attempts = 0
            resumptions = 0
            t_gen_start = time.time()
            state["gen_started"] += 1
            while True:
                gen_attempts += 1
                data = await context.generate(req=req, domain=domain)
                if data is None:
                    return  # shutdown: abort prompt
                elif is_report_data_finished(data):
                    req = postprocess_output_data(req, data, context.sequence_length)
                    break
                else:
                    if not collect_unfinished:
                        logger.info(f"received unfinished response {context.prompt_id=}")
                        return
                    else:
                        resumptions += 1
                        req = postprocess_paused_data(
                            req, data, context.sequence_length, context.prompt_length
                        )
            t_gen_end = time.time()
            state["gen_finished"] += 1

            t_reward_submit = time.time()
            state["reward_submitted"] += 1
            req.meta_info["member_index"] = member_index  # read by VerifyQueueGovernor for cancel records
            req.meta_info["audit"] = self._audit_by_prompt.get(context.prompt_id, False)  # audit lane: the controller leaves it alone
            req.meta_info["sampling_start_step"] = context.sampling_start_step   # group age in steps, for the expiry release
            try:
                rewards = await context.compute_rewards(req=req, domain=domain)
            except asyncio.CancelledError:
                # stale-GC / shutdown cancellation while verifying (the governor kills the job itself)
                self.events.log(
                    event="sample_canceled",
                    run_id=self.run_id,
                    prompt_id=context.prompt_id,
                    dataset_id=self._dataset_id_by_prompt.get(context.prompt_id, "?"),
                    member_index=member_index,
                    sampling_start_step=context.sampling_start_step,
                    phase="verifying",
                    elapsed_s=time.time() - t_reward_submit,
                    reason="prompt_task_cancelled",
                )
                raise
            t_reward_return = time.time()
            state["reward_finished"] += 1

            metrics = req.meta_info.pop("metrics", {})
            req.union(rewards)
            req_metrics = req.meta_info.pop("metrics", {})
            req.meta_info["metrics"] = {**metrics, **req_metrics}

            t_worker_start = float(req.non_tensor_batch.get("t_worker_start", [t_reward_submit])[0])
            t_worker_end = float(req.non_tensor_batch.get("t_worker_end", [t_reward_return])[0])
            self.events.log(
                event="sample_done",
                run_id=self.run_id,
                prompt_id=context.prompt_id,
                dataset_id=self._dataset_id_by_prompt.get(context.prompt_id, "?"),
                member_index=member_index,
                sampling_start_step=context.sampling_start_step,
                gen_attempts=gen_attempts,
                partial_rollout_resumptions=resumptions,
                t_gen_start=t_gen_start,
                t_gen_end=t_gen_end,
                gen_duration_s=t_gen_end - t_gen_start,
                t_reward_submit=t_reward_submit,
                t_worker_start=t_worker_start,
                t_worker_end=t_worker_end,
                t_reward_return=t_reward_return,
                reward_queue_wait_s=t_worker_start - t_reward_submit,
                verifier_execution_s=t_worker_end - t_worker_start,
                verifier_cpu_core_seconds=float(req.non_tensor_batch.get("verifier_cpu_core_seconds", [0.0])[0]),
                reward_valid=bool(req.non_tensor_batch.get("reward_valid", [True])[0]),
                response_tokens=int(req.batch["response_mask"].sum()),
                reward_return_overhead_s=t_reward_return - t_worker_end,
                reward=float(req.batch["response_level_rewards"][0]),
                verifier_stage=str(req.non_tensor_batch.get("verifier_stage", ["?"])[0]),
                verify_worker=str(req.non_tensor_batch.get("verify_worker", ["?"])[0]),
            )

            # timing columns preserved into the learner batch
            output_count = req.batch.batch_size[0]
            assert output_count == req.meta_info["generation_config"]["num_return_sequences"]
            for key, value in [
                ("t_gen_start", t_gen_start),
                ("t_gen_end", t_gen_end),
                ("t_reward_submit", t_reward_submit),
                ("t_reward_return", t_reward_return),
                ("t_worker_start", t_worker_start),
                ("t_worker_end", t_worker_end),
                ("partial_rollout_resumptions", resumptions),
            ]:
                req.non_tensor_batch[key] = np.array([value] * output_count, dtype=object)

            batch_expanded = [req[[idx]] for idx in range(output_count)]
            response_filter_count = 0
            for batch_item in batch_expanded:
                # response_filter is a no-op in the base implementation; keep parity
                responses.append(batch_item)

            if response_filter_count == 0:
                break
            else:
                original_req.meta_info["generation_config"]["num_return_sequences"] = response_filter_count
                req = original_req

        return responses
