"""ROLL reward worker for RTL (Verilog) verification.

Wraps ``applications.rtl.verifier.verify_rtl_sample`` (versioned EQY reward)
as a ROLL ``compute_rewards`` worker usable by both the
sync cluster dispatch path and the native async per-request path
(``RolloutContext.compute_rewards`` -> ``reward_worker.compute_rewards.remote``).

Concurrency model: this worker is synchronous, so each Ray actor processes one
``compute_rewards`` call at a time; verifier parallelism = ``world_size``.

Instrumentation: per-sample worker-side timestamps (``t_worker_start``,
``t_worker_end``) are returned in ``non_tensor_batch`` so the rollout loop can
separate reward-queue wait from verifier execution.  One JSONL event per sample
is appended (flushed) to ``<output_dir>/verifier_events.<worker_name>.jsonl``.
"""
import json
import os
import time
from typing import Optional

import torch
import numpy as np

from roll.configs.worker_config import WorkerConfig
from roll.distributed.executor.worker import Worker
from roll.distributed.scheduler.decorator import Dispatch, register
from roll.distributed.scheduler.protocol import DataProto
from roll.models.model_providers import default_tokenizer_provider

from applications.rtl.verifier import verify_rtl_sample


class RTLRewardWorker(Worker):
    """Budgeted EQY proof reward; never silently train on invalid references."""

    def __init__(self, worker_config: WorkerConfig):
        super().__init__(worker_config=worker_config)
        # CPU reward workers dispatch DP over ranks (same as MathRuleRewardWorker)
        self.rank_info.dp_rank = self.rank_info.rank
        self.rank_info.dp_size = self.rank_info.world_size
        self.tokenizer = default_tokenizer_provider(model_args=self.worker_config.model_args)
        self.workspace_root: str = os.environ.get("RTL_WORKSPACE_ROOT", "/tmp/rtl_verify")
        self.keep_artifacts: bool = os.environ.get("RTL_KEEP_ARTIFACTS", "0") == "1"
        self.event_file = None
        self._event_fh = None

    @register(dispatch_mode=Dispatch.ONE_TO_ALL)
    def initialize(self, pipeline_config):
        # NOTE: deliberately does not call super().initialize (no model strategy
        # is created for rule-based reward workers, same as MathRuleRewardWorker).
        os.makedirs(self.workspace_root, exist_ok=True)
        out_dir = getattr(pipeline_config, "output_dir", None)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
            worker_name = os.environ.get("WORKER_NAME", f"rtl-reward-{self.rank}")
            self.event_file = os.path.join(out_dir, f"verifier_events.{worker_name}.jsonl")
            self._event_fh = open(self.event_file, "a", encoding="utf-8")
        self.logger.info(
            f"RTLRewardWorker initialized: workspace_root={self.workspace_root} "
            f"event_file={self.event_file} keep_artifacts={self.keep_artifacts}"
        )

    def _log_event(self, event: dict):
        if self._event_fh is None:
            return
        self._event_fh.write(json.dumps(event, ensure_ascii=False) + "\n")
        self._event_fh.flush()

    @register(dispatch_mode=Dispatch.DP_MP_COMPUTE, clear_cache=False)
    def compute_rewards(self, data: DataProto):
        """
        Return DataProto with token_level_rewards / response_level_rewards / scores,
        plus worker-side timing columns for queue-wait separation.
        """
        # Matches the reference decode: verl naive manager decodes valid response
        # ids with skip_special_tokens=True.
        response_text_list = self.tokenizer.batch_decode(data.batch["responses"], skip_special_tokens=True)
        ground_truths = data.non_tensor_batch["ground_truth"]
        rollout_ids = data.non_tensor_batch.get(
            "rollout_id", np.array([f"nord_{i}" for i in range(len(response_text_list))], dtype=object)
        )

        rewards, stages, t_starts, t_ends, verify_durations = [], [], [], [], []
        for response, ground_truth, rollout_id in zip(response_text_list, ground_truths, rollout_ids):
            t_worker_start = time.time()
            result = verify_rtl_sample(
                solution_str=response,
                ground_truth=str(ground_truth),
                workspace_root=self.workspace_root,
                sample_id=str(rollout_id),
                keep_artifacts=self.keep_artifacts,
            )
            t_worker_end = time.time()
            rewards.append(result.reward)
            stages.append(result.stage)
            t_starts.append(t_worker_start)
            t_ends.append(t_worker_end)
            verify_durations.append(result.total_duration_s)
            self._log_event(
                {
                    "event": "verify",
                    "rollout_id": str(rollout_id),
                    "t_worker_start": t_worker_start,
                    "t_worker_end": t_worker_end,
                    "verifier_execution_s": t_worker_end - t_worker_start,
                    "reward": result.reward,
                    "stage": result.stage,
                    "is_pass": result.is_pass,
                    "reward_valid": result.reward_valid,
                    "reason": result.reason,
                    "verifier_protocol": result.protocol,
                    "verifier_config": result.config,
                    "stage_details": result.stages,
                    "worker": os.environ.get("WORKER_NAME", ""),
                }
            )
            if not result.reward_valid:
                # Dropping one completion would change the GRPO group's
                # normalization. Stop with a diagnostic instead; preflight
                # references before training, and fix/retry tool failures.
                raise RuntimeError(
                    f"Invalid RTL reward for rollout {rollout_id}: {result.stage}: "
                    f"{result.reason}. No reward batch was returned."
                )

        token_level_rewards = torch.zeros_like(data.batch["responses"], dtype=torch.float32)
        response_level_rewards = torch.tensor(rewards, dtype=torch.float32)
        scores = response_level_rewards.clone()

        output = DataProto.from_dict(
            tensors={
                "token_level_rewards": token_level_rewards,
                "response_level_rewards": response_level_rewards,
                "scores": scores,
            },
            non_tensors={
                "verifier_stage": np.array(stages, dtype=object),
                "t_worker_start": np.array(t_starts, dtype=object),
                "t_worker_end": np.array(t_ends, dtype=object),
            },
        )
        output.meta_info = {"metrics": {"verifier_execution_s": verify_durations}}
        return output
