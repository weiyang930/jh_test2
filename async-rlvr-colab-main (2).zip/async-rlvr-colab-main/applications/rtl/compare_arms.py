"""Build the two-arm comparison: tables, per-step curves and the accuracy-vs-GPU-hours figure."""
import argparse
import json
import re
from collections import defaultdict
from pathlib import Path

import numpy as np

GPUS = 6


def load_jsonl(path: Path) -> list:
    return [json.loads(l) for l in path.open() if l.strip()] if path.exists() else []


def step_metrics(stdout: Path) -> dict:
    out = {}
    for line in stdout.open(errors='ignore'):
        idx = line.find('{"time/step_total"')
        if idx < 0:
            continue
        try:
            m = json.loads(line[idx:].strip())
        except json.JSONDecodeError:
            continue
        out[int(m['system/global_step'])] = m
    return out


def arm_summary(root: Path, run_id: str) -> dict:
    out = root / 'runs' / run_id / 'output'
    manifest = json.loads((root / 'runs' / run_id / 'manifest.json').read_text())
    learner = load_jsonl(out / 'learner_events.jsonl')
    credits = load_jsonl(out / 'cost_credit_events.jsonl')
    metrics = step_metrics(root / 'runs' / run_id / 'stdout.log')
    aux_cfg = out / 'cost_aux_config.json'
    t_launch = json.loads(aux_cfg.read_text())['t_launch'] if aux_cfg.exists() else next(
        e['ts'] for e in learner if e['event'] == 'run_start')
    step_end = {e['step']: e for e in learner if e['event'] == 'step_end'}
    ckpt_steps = sorted({e['step'] for e in learner if e['event'] == 'checkpoint_end'})
    batches = {c['step']: c for c in credits if c['event'] == 'batch_credit'}
    samples = defaultdict(list)
    for c in credits:
        if c['event'] == 'sample_credit':
            samples[c['step']].append(c)
    rows = []
    for s in sorted(step_end):
        m = metrics.get(s, {})
        b = batches.get(s, {})
        cex = [x for x in samples[s] if x['stage'] == 'eqy_counterexample' and x['class_size'] >= 2]
        pas = [x for x in samples[s] if x['stage'] == 'pass' and x['class_size'] >= 2]
        rows.append(dict(
            step=s, elapsed_s=step_end[s]['ts'] - t_launch, gpu_hours=GPUS * (step_end[s]['ts'] - t_launch) / 3600,
            learner_wait_s=b.get('cost/learner_wait_s'), verif_attr_s=b.get('cost/verification_attributable_s'),
            d_nonzero_frac=b.get('cost/d_nonzero_frac'), adv_nonzero=b.get('cost/adv_nonzero_samples'),
            weighted_samples=b.get('cost/weighted_samples'), calib_err_s=b.get('cost/replay_calibration_err_s'),
            groups_kept=m.get('compaction/groups_kept'), samples_trained=m.get('actor/valid_samples@sum'),
            gen_score_mean=m.get('rtl/scheduler/rtl/score/mean'), train_score_mean=m.get('critic/score/mean'),
            pg_loss=m.get('actor/pg_loss@sum'), aux_loss=m.get('cost/aux_loss@sum'), grad_norm=m.get('actor_train/grad_norm'),
            response_len=m.get('token/response_length/mean'), step_train_s=m.get('time/step_train'),
            cex_raw_cost_mean=float(np.mean([x['raw_cost'] for x in cex])) if cex else None,
            cex_eff_cost_mean=float(np.mean([x['effective_cost'] for x in cex])) if cex else None,
            cex_adv_abs_mean=float(np.mean([abs(x['advantage']) for x in cex])) if cex else None,
            pass_raw_cost_mean=float(np.mean([x['raw_cost'] for x in pas])) if pas else None,
            timeouts=sum(x['stage'] == 'eqy_timeout' for x in samples[s]),
        ))
    evals = {}
    for summary in (root / 'eval' / 'results').glob(f'{run_id}-checkpoint-*/verilogeval-v1/machine/full/temp-0p2/summary.json'):
        d = json.loads(summary.read_text())
        step = int(re.search(r'checkpoint-(\d+)', str(summary)).group(1))
        evals[step] = dict(pass_at_k=d['pass_at_k'], passed=d['passed_generations'], n=d['num_generations'],
                           elapsed_s=step_end[step]['ts'] - t_launch if step in step_end else None,
                           gpu_hours=GPUS * (step_end[step]['ts'] - t_launch) / 3600 if step in step_end else None)
    all_s = [x for s in samples for x in samples[s]]
    crit = [x for x in all_s if x['d_local'] > 0]

    def spearman(a, b):
        if len(a) < 3:
            return None
        ra, rb = np.argsort(np.argsort(a)), np.argsort(np.argsort(b))
        return float(np.corrcoef(ra, rb)[0, 1])

    return dict(
        run_id=run_id, manifest=manifest, steps=len(rows), last_elapsed_s=rows[-1]['elapsed_s'] if rows else None,
        checkpoint_steps=ckpt_steps, per_step=rows, evals=evals,
        totals=dict(samples=len(all_s), critical=len(crit), critical_frac=len(crit) / max(len(all_s), 1),
                    weighted_frac=sum(x['class_size'] >= 2 for x in all_s) / max(len(all_s), 1),
                    spearman_raw_vs_eff_critical=spearman([x['raw_cost'] for x in crit], [x['effective_cost'] for x in crit]),
                    spearman_raw_vs_eff_all=spearman([x['raw_cost'] for x in all_s], [x['effective_cost'] for x in all_s]),
                    mean_learner_wait_s=float(np.mean([r['learner_wait_s'] for r in rows if r['learner_wait_s'] is not None])) if rows else None,
                    mean_verif_attr_s=float(np.mean([r['verif_attr_s'] for r in rows if r['verif_attr_s'] is not None])) if rows else None,
                    mean_step_s=float(np.mean(np.diff([r['elapsed_s'] for r in rows]))) if len(rows) > 1 else None),
    )


def plot(arms: list, init_eval: dict, out_png: Path) -> None:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))
    ax = axes[0]
    for arm in arms:
        xs = [0.0] + [e['gpu_hours'] for _, e in sorted(arm['evals'].items())]
        ys = [init_eval['pass_at_k']['pass@1']] + [e['pass_at_k']['pass@1'] for _, e in sorted(arm['evals'].items())]
        ax.plot(xs, ys, marker='o', label=arm['run_id'])
    ax.set_xlabel('cumulative allocated GPU-hours (arm only)'); ax.set_ylabel('VerilogEval-v1 machine pass@1 (n=20, T=0.2)')
    ax.set_title('independent accuracy vs budget'); ax.legend(); ax.grid(alpha=.3)
    ax = axes[1]
    for arm in arms:
        ax.plot([r['step'] for r in arm['per_step']], [r['learner_wait_s'] for r in arm['per_step']], label=f"{arm['run_id']} learner wait")
        ax.plot([r['step'] for r in arm['per_step']], [r['verif_attr_s'] for r in arm['per_step']], '--', label=f"{arm['run_id']} verification-attributable")
    ax.set_xlabel('step'); ax.set_ylabel('seconds'); ax.set_title('per-step wait decomposition'); ax.legend(fontsize=7); ax.grid(alpha=.3)
    ax = axes[2]
    for arm in arms:
        ax.plot([r['step'] for r in arm['per_step']], [r['cex_raw_cost_mean'] for r in arm['per_step']], label=f"{arm['run_id']} raw C (cex class)")
        ax.plot([r['step'] for r in arm['per_step']], [r['cex_eff_cost_mean'] for r in arm['per_step']], '--', label=f"{arm['run_id']} effective cost (cex class)")
    ax.set_xlabel('step'); ax.set_ylabel('seconds'); ax.set_title('within-class costs (eqy_counterexample, class size>=2)'); ax.legend(fontsize=7); ax.grid(alpha=.3)
    fig.tight_layout(); fig.savefig(out_png, dpi=130)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=Path('/workspace/rtl-blocking-cost-20260910'))
    ap.add_argument('--arms', default='async_blocking_cost,async_baseline')
    ap.add_argument('--out', type=Path, default=None)
    args = ap.parse_args()
    out_dir = args.out or (args.root / 'analysis')
    out_dir.mkdir(parents=True, exist_ok=True)
    init_eval = json.loads((args.root / 'eval/results/salv-init/verilogeval-v1/machine/full/temp-0p2/summary.json').read_text())
    arms = []
    for run_id in args.arms.split(','):
        if (args.root / 'runs' / run_id / 'output' / 'learner_events.jsonl').exists():
            arms.append(arm_summary(args.root, run_id))
    probe = json.loads((args.root / 'probe/probe_summary.json').read_text())
    probe_cex = json.loads((args.root / 'probe/probe_counterexample_summary.json').read_text())
    report = dict(init_eval=init_eval, probe={k: v for k, v in probe.items() if k != 'pairs'},
                  probe_counterexample={k: v for k, v in probe_cex.items() if k != 'sign'},
                  probe_counterexample_sign={k: v for k, v in probe_cex['sign'].items() if k != 'rows'}, arms=arms)
    (out_dir / 'report.json').write_text(json.dumps(report, indent=2, default=float) + '\n')
    try:
        plot(arms, init_eval, out_dir / 'accuracy_vs_gpu_hours.png')
    except Exception as exc:  # noqa: BLE001
        print('plot failed:', exc)
    for arm in arms:
        t = arm['totals']
        print(arm['run_id'], 'steps', arm['steps'], 'elapsed_s', round(arm['last_elapsed_s'] or 0),
              'mean_step_s', t['mean_step_s'] and round(t['mean_step_s'], 1), 'mean_wait', t['mean_learner_wait_s'] and round(t['mean_learner_wait_s'], 1),
              'verif_attr', t['mean_verif_attr_s'] and round(t['mean_verif_attr_s'], 1), 'critical_frac', round(t['critical_frac'], 3),
              'spearman_crit', t['spearman_raw_vs_eff_critical'])
        for step, e in sorted(arm['evals'].items()):
            print('  eval step', step, 'gpu_h', e['gpu_hours'] and round(e['gpu_hours'], 2), e['pass_at_k'])


if __name__ == '__main__':
    main()
