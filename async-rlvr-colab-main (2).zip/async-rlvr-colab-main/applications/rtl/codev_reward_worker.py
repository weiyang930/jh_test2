"""EQY-v2 CPU actor with per-sample process accounting, explicit validity and out-of-band cancellation."""
import json
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Set
from uuid import uuid4

import numpy as np
import torch

from applications.rtl.rtl_reward_worker import RTLRewardWorker
from applications.rtl.verifier import kill_process_group, kill_sample_orphans, remove_sample_workspaces
from roll.configs.worker_config import WorkerConfig
from roll.distributed.scheduler.decorator import Dispatch, register
from roll.distributed.scheduler.protocol import DataProto


MAX_CONSECUTIVE_TOOL_ERRORS = 25
TOOL_ERROR_STAGES = {'syntax_tool_error', 'eqy_tool_error'}
CANCELLED_STAGE = 'cancelled'


def cancelled_result(duration_s: float) -> dict:
    """Verdict placeholder for a verification killed by the scheduler (never trained on: reward_valid=False)."""
    return dict(reward=0.0, stage=CANCELLED_STAGE, is_pass=False, total_duration_s=duration_s, workspace='',
                stages=[], reward_valid=False, reason='cancelled by scheduler', protocol='eqy-v2', config={},
                cpu_user_s=0.0, cpu_system_s=0.0, cpu_core_seconds=0.0, cpu_accounting='cancelled')


class CodeVRewardWorker(RTLRewardWorker):
    """Keep exactly one EDA job in flight per actor; don't multiply thread pools.

    ``cancel_verification`` is served on a second actor thread (``worker_config.max_concurrency: 2``,
    Ray threaded actor) while ``compute_rewards`` blocks on the child, so the scheduler can kill a
    discarded sample's verifier tree instead of letting it run to its timeout.
    """

    def __init__(self, worker_config: WorkerConfig):
        super().__init__(worker_config=worker_config)
        self._children: Dict[str, subprocess.Popen] = {}
        self._cancelled: Set[str] = set()
        self._child_lock = threading.Lock()
        self._tool_error_streak = 0

    @register(dispatch_mode=Dispatch.DP_MP_COMPUTE, clear_cache=False)
    def compute_rewards(self, data: DataProto) -> DataProto:
        texts = self.tokenizer.batch_decode(data.batch['responses'], skip_special_tokens=True)
        results, starts, ends = [], [], []
        for index, (text, golden) in enumerate(zip(texts, data.non_tensor_batch['ground_truth'])):
            identifier = str(data.non_tensor_batch.get('rollout_id', ['unknown'] * len(texts))[index])
            request = dict(solution_str=text, ground_truth=str(golden), workspace_root=self.workspace_root,
                           sample_id=identifier, keep_artifacts=self.keep_artifacts)
            starts.append(time.time())
            completed = self._run_child(request)
            ends.append(time.time())
            if completed is None:
                result = cancelled_result(ends[-1] - starts[-1])
            elif completed.returncode:
                # Accounting-process failure is an infrastructure fault, not a model failure:
                # return an invalid sample so the rollout loop drops the whole group.
                result = dict(reward=0.5, stage='accounting_process_fail', is_pass=False, total_duration_s=ends[-1] - starts[-1],
                              workspace='', stages=[], reward_valid=False, reason=completed.stderr[-500:],
                              protocol='eqy-v2', config={}, cpu_user_s=0.0, cpu_system_s=0.0, cpu_core_seconds=0.0,
                              cpu_accounting='failed')
            else:
                result = json.loads(completed.stdout)
            if not result['reward_valid'] and self.event_file and result['stage'] != CANCELLED_STAGE:
                folder = Path(self.event_file).parent / 'invalid_verifier_payloads'
                folder.mkdir(exist_ok=True)
                artifact = folder / (uuid4().hex + '.json')
                artifact.write_text(json.dumps(dict(request=request, result=result), ensure_ascii=False))
                result['invalid_payload_path'] = str(artifact)
            self._log_event(dict(event='verify', rollout_id=identifier, worker=self.worker_name,
                                 t_worker_start=starts[-1], t_worker_end=ends[-1],
                                 verifier_execution_s=ends[-1] - starts[-1], **result))
            self._note_tool_error_streak(result)
            results.append(result)
        scores = torch.tensor([r['reward'] for r in results], dtype=torch.float32)
        return DataProto.from_dict(
            tensors=dict(token_level_rewards=torch.zeros_like(data.batch['responses'], dtype=torch.float32),
                         response_level_rewards=scores, scores=scores.clone()),
            non_tensors=dict(
                verifier_stage=np.array([r['stage'] for r in results], dtype=object),
                reward_valid=np.array([r['reward_valid'] for r in results], dtype=object),
                verifier_cpu_core_seconds=np.array([r['cpu_core_seconds'] for r in results], dtype=object),
                t_worker_start=np.array(starts, dtype=object), t_worker_end=np.array(ends, dtype=object),
                verify_worker=np.array([str(self.worker_name or f'rtl-reward-{self.rank}')] * len(results), dtype=object),
            ),
        )

    def cancel_verification(self, rollout_id: str) -> bool:
        """Kill ``rollout_id``'s verifier child and its detached solver sessions; True if a child was running.

        A cancellation that arrives before the child is launched is honoured at launch time.
        """
        with self._child_lock:
            self._cancelled.add(rollout_id)
            proc = self._children.get(rollout_id)
        if proc is None:
            return False
        kill_process_group(proc.pid)
        kill_sample_orphans(rollout_id)
        return True

    def _run_child(self, request: dict) -> Optional[subprocess.CompletedProcess]:
        """Run one verifier child; None if the sample was cancelled before launch or while running."""
        rollout_id = request['sample_id']
        with self._child_lock:
            if rollout_id in self._cancelled:
                self._cancelled.discard(rollout_id)
                return None
            proc = subprocess.Popen(self._child_command(), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, text=True, start_new_session=True)
            self._children[rollout_id] = proc
        try:
            stdout, stderr = proc.communicate(json.dumps(request))
        finally:
            with self._child_lock:
                self._children.pop(rollout_id, None)
                cancelled = rollout_id in self._cancelled
                # a cancel racing a normal completion leaves a stale rollout_id here: harmless, never reused
                self._cancelled.discard(rollout_id)
        if (cancelled or proc.returncode) and not self.keep_artifacts:
            # the child died before its own cleanup: sweep detached solvers, then its workspace
            kill_sample_orphans(rollout_id)
            remove_sample_workspaces(self.workspace_root, rollout_id)
        if cancelled:
            return None
        return subprocess.CompletedProcess(proc.args, proc.returncode, stdout, stderr)

    @staticmethod
    def _child_command() -> List[str]:
        return [sys.executable, '-m', 'applications.rtl.codev_verify_child']

    def _note_tool_error_streak(self, result: dict) -> None:
        """Abort the worker on a sustained EDA tool outage; a cancellation is not a verdict and leaves the streak.

        Candidate-specific tool failures (e.g. EQY partition errors) are returned with reward_valid=False so
        the rollout loop excludes the whole group; only a streak of MAX_CONSECUTIVE_TOOL_ERRORS aborts.
        """
        if result['stage'] == CANCELLED_STAGE:
            return
        if result['stage'] not in TOOL_ERROR_STAGES:
            self._tool_error_streak = 0
            return
        self._tool_error_streak += 1
        if self._tool_error_streak >= MAX_CONSECUTIVE_TOOL_ERRORS:
            raise RuntimeError(
                f"EDA tool error streak {self._tool_error_streak}: {result['stage']}: {result['reason']}")
