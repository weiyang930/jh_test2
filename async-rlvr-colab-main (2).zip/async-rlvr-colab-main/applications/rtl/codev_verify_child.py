"""One isolated verifier process, including CPU accounting for reaped descendants."""
import ctypes
import json
import os
import resource
import signal
import sys
import time
from dataclasses import asdict
from pathlib import Path

from applications.rtl import sim_fallback
from applications.rtl.verifier import verify_rtl_sample


def reap_descendants(max_wait_s: float = 30.0) -> bool:
    """Terminate and reap children adopted by this per-sample subreaper; False if some survive."""
    deadline = time.monotonic() + max_wait_s
    while time.monotonic() < deadline:
        try:
            pid, _ = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError:
            return True
        if pid:
            continue
        children_file = Path(f'/proc/self/task/{os.getpid()}/children')
        for child in children_file.read_text().split():
            try:
                os.kill(int(child), signal.SIGKILL)
            except ProcessLookupError:
                pass
        time.sleep(0.01)
    return False


def main() -> None:
    """Run EQY with Linux subreaper accounting; never sum concurrent wall times."""
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise OSError(ctypes.get_errno(), 'Cannot enable verifier child accounting')
    request = json.load(sys.stdin)
    result = verify_rtl_sample(**request)
    value = asdict(result)
    # EQY timeout -> CodeV-R1 simulation decides (only when RTL_SIM_FALLBACK=1); runs inside this process group, so a
    # scheduler cancellation kills the simulation too, and its descendants are reaped and accounted below
    sim_fallback.apply(value, request["solution_str"], request["ground_truth"], request["workspace_root"])
    reaped = reap_descendants()
    own = resource.getrusage(resource.RUSAGE_SELF)
    children = resource.getrusage(resource.RUSAGE_CHILDREN)
    if not reaped:
        # A stuck descendant (e.g. solver in uninterruptible I/O) must not kill training:
        # keep the verdict, flag the accounting as incomplete.
        value['reap_incomplete'] = True
    value['cpu_user_s'] = own.ru_utime + children.ru_utime
    value['cpu_system_s'] = own.ru_stime + children.ru_stime
    value['cpu_core_seconds'] = value['cpu_user_s'] + value['cpu_system_s']
    value['cpu_accounting'] = 'isolated_linux_subreaper_self_plus_waited_descendants'
    print(json.dumps(value), flush=True)


if __name__ == '__main__':
    main()
