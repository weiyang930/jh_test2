"""Reusable-prompt admission for short CodeV value/verification-cost smokes.

This smoke predicts measured verifier CPU, not GPU cost or a marginal dollar
bill. Queue delay is never used as a cost label. All generated token counts and
end-to-end allocated GPU time are reported separately.
"""
import json
import math
import os
import pickle
import random
import time
from collections import deque
from pathlib import Path

import numpy as np

from applications.rtl.admission import _structural_features, item_text


class CodeVAdmissionPolicy:
    """Observe every complete group before filtering, including zero-variance groups."""

    def __init__(self, scheduler, pipeline_config, mode: str = 'uniform', batch: int = 32,
                 mu: float = 0.1, exploration: float = 0.25, pool_multiplier: int = 4,
                 warmup_min_groups: int = 64, fit_interval: int = 1, max_groups_per_step: int = 1024):
        if mode not in {'uniform', 'value_cost'}:
            raise ValueError(mode)
        self.dataset = scheduler.dataset
        self.mode, self.batch, self.mu = mode, batch, mu
        self.exploration, self.pool_multiplier = exploration, pool_multiplier
        self.warmup_min_groups, self.fit_interval = warmup_min_groups, fit_interval
        self.max_groups_per_step = max_groups_per_step
        self.rng = random.Random(pipeline_config.seed)
        self.ids = [str(x) for x in self.dataset['id']]
        self.indices = {x: i for i, x in enumerate(self.ids)}
        if len(self.ids) != len(self.indices):
            raise ValueError('Admission requires unique dataset ids')
        self.reserved, self.used, self.invalid = set(), set(), set()
        self.queue, self.slots = [], {}
        self.observations = deque(maxlen=2048)
        self.model = None
        self.cost_reference = None
        self.version, self.step, self.last_fit, self.issued = 0, 0, -1, 0
        self.path = Path(pipeline_config.output_dir)
        self.path.mkdir(parents=True, exist_ok=True)
        self.handle = (self.path / 'admission_events.jsonl').open('a', buffering=1)
        self._log(event='policy_init', mode=mode, batch=batch, mu=mu, exploration=exploration,
                  warmup_min_groups=warmup_min_groups, cost_scope='verifier_cpu_core_seconds',
                  dataset_size=len(self.ids), permanent_retirement=False)

    def _log(self, **values) -> None:
        self.handle.write(json.dumps(dict(ts=time.time(), **values), allow_nan=False) + '\n')

    def on_step(self, step: int) -> None:
        self.step, self.used, self.issued = step, set(), 0
        self._fit()

    def _features(self, indices: list) -> tuple:
        texts = [item_text(self.dataset[i]) for i in indices]
        return ['\n'.join(t) for t in texts], np.array([_structural_features(*t) for t in texts])

    def _fit(self) -> None:
        if self.mode != 'value_cost' or len(self.observations) < self.warmup_min_groups:
            return
        if self.last_fit >= 0 and self.step - self.last_fit < self.fit_interval:
            return
        from scipy import sparse
        from sklearn.ensemble import ExtraTreesRegressor
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.linear_model import LogisticRegression
        start, cpu_start = time.perf_counter(), time.process_time()
        records = list(self.observations)
        y = np.array([r['useful'] for r in records])
        if min(int(y.sum()), int((1 - y).sum())) < 4:
            self._log(event='fit_not_ready', step=self.step, groups=len(y), positives=int(y.sum()))
            return
        texts, structural = self._features([r['index'] for r in records])
        vectorizer = TfidfVectorizer(max_features=4000, ngram_range=(1, 2), min_df=2)
        text_features = vectorizer.fit_transform(texts)
        mean, std = structural.mean(0), structural.std(0) + 1e-6
        features = sparse.hstack([text_features, sparse.csr_matrix((structural - mean) / std)]).tocsr()
        utility = LogisticRegression(max_iter=500, random_state=42).fit(features, y)
        costs = np.array([r['cpu_s'] for r in records])
        cost = ExtraTreesRegressor(n_estimators=64, max_depth=8, min_samples_leaf=8,
                                   random_state=42, n_jobs=1).fit(structural, costs)
        if self.cost_reference is None:
            self.cost_reference = max(float(costs.mean()), 1e-6)
        self.model = vectorizer, mean, std, utility, cost
        self.version += 1
        self.last_fit = self.step
        with (self.path / f'predictor_v{self.version}.pkl').open('wb') as handle:
            pickle.dump(dict(model=self.model, cost_reference=self.cost_reference), handle)
        self._log(event='predictor_fit', step=self.step, version=self.version, groups=len(records),
                  positives=int(y.sum()), cost_reference=self.cost_reference,
                  elapsed_s=time.perf_counter()-start, cpu_s=time.process_time()-cpu_start)

    def _scores(self, indices: list) -> tuple:
        from scipy import sparse
        texts, structural = self._features(indices)
        vectorizer, mean, std, utility, cost = self.model
        features = sparse.hstack([vectorizer.transform(texts), sparse.csr_matrix((structural-mean)/std)]).tocsr()
        values = utility.predict_proba(features)[:, 1]
        costs = cost.predict(structural)
        return values - self.mu * costs / self.cost_reference, values, costs

    def _refill(self) -> None:
        start, cpu_start = time.perf_counter(), time.process_time()
        eligible = [i for i in range(len(self.ids)) if i not in self.reserved | self.used | self.invalid]
        count = min(self.batch, len(eligible))
        if count == 0:
            raise RuntimeError('No eligible CodeV prompts remain in this update')
        warmed = self.mode == 'value_cost' and self.model is not None
        if warmed:
            explore_count = min(count, math.ceil(self.exploration * count))
            explore = self.rng.sample(eligible, explore_count)
            remaining = [i for i in eligible if i not in set(explore)]
            pool = self.rng.sample(remaining, min(self.pool_multiplier * count, len(remaining)))
            score, utility, cost = self._scores(pool)
            order = list(range(len(pool)))
            self.rng.shuffle(order)
            order.sort(key=lambda k: -score[k])
            exploit = [pool[k] for k in order[:count-explore_count]]
            selected = explore + exploit
            for k, i in enumerate(pool):
                self._log(event='scored_candidate', step=self.step, dataset_id=self.ids[i],
                          predictor_version=self.version, score=float(score[k]),
                          utility=float(utility[k]), predicted_cpu_s=float(cost[k]),
                          pool_inclusion_probability=len(pool)/len(remaining), selected=i in exploit)
            slots = {i: ('explore' if i in explore else 'exploit') for i in selected}
            exploration_probability = explore_count/len(eligible)
        else:
            selected = self.rng.sample(eligible, count)
            slots = {i: 'uniform' for i in selected}
            exploration_probability = count/len(eligible)
        for i in selected:
            self.reserved.add(i)
            self.slots[i] = slots[i]
            self._log(event='selected', step=self.step, dataset_id=self.ids[i], slot=slots[i],
                      predictor_version=self.version, random_inclusion_probability=exploration_probability)
        self.rng.shuffle(selected)
        self.queue.extend(selected)
        self._log(event='selection_round', step=self.step, warmed=warmed, selected=count,
                  eligible=len(eligible), elapsed_s=time.perf_counter()-start,
                  cpu_s=time.process_time()-cpu_start)

    def next_item(self) -> dict:
        if self.issued >= self.max_groups_per_step:
            raise RuntimeError('CodeV smoke refill limit exceeded; inspect reward validity and zero-variance rate')
        if not self.queue:
            self._refill()
        index = self.queue.pop()
        self.used.add(index)
        self.issued += 1
        return self.dataset[index]

    def observe_group(self, dataset_id: str, group_id: int, rewards: list,
                      cpu_seconds: float, valid: bool) -> None:
        """Receive useful and filtered group outcomes once, before learner filtering."""
        index = self.indices[dataset_id]
        slot = self.slots.pop(index, 'unknown')
        self.reserved.discard(index)
        if not valid:
            self.invalid.add(index)
        elif slot in {'uniform', 'explore'}:
            self.observations.append(dict(index=index, useful=int(len(set(rewards)) > 1), cpu_s=cpu_seconds))
        self._log(event='observed_group', step=self.step, group_id=group_id, dataset_id=dataset_id,
                  slot=slot, valid=valid, useful=len(set(rewards)) > 1,
                  cpu_core_seconds=cpu_seconds, rewards=rewards)

    def release(self, dataset_id: str) -> None:
        """Release a canceled in-flight prompt without inventing a reward label."""
        index = self.indices.get(dataset_id)
        if index is not None:
            self.reserved.discard(index)
            self.slots.pop(index, None)
