#!/usr/bin/env python3
"""Zero-GPU replay of the group-level controller on logged verification jobs: what each rule would have abandoned.

For every logged group (prompt) with its members' real start/end/pass, walk time forward on the GRID ages and apply
verify_controller.decide with the given tables. Reports, per (mode, parameter): groups abandoned, verifier-seconds
saved (remaining durations of cancelled checks), informative groups lost (abandoned groups that ended informative),
and the resulting informative groups per verifier-second relative to no controller.
Sources as in fit_controller_tables.py: --run <dir> (events.jsonl) or --probe <attempts.jsonl>; tables from --tables.
usage: replay_controller.py (--run DIR | --probe FILE) --tables tables.json --tau 180 [--lams 1e-4,3e-4,1e-3,3e-3,1e-2]
       [--thetas 0.02,0.05,0.1,0.2,0.3] [--min-age 2] [--out summary.json]
"""
from __future__ import annotations

import argparse
import json

from applications.rtl import verify_controller as vc
from applications.rtl.fit_controller_tables import groups_from_probe, groups_from_run

GRID = vc.GRID


def replay(groups: dict, tables: vc.Tables, mode: str, lam: float, theta: float, min_age: float, tau: float) -> dict:
    n_groups = len(groups)
    inform_total = sum(1 for js in groups.values() if 0 < sum(j["pass"] for j in js) < len(js))
    work_total = sum(min(j["dur"], tau) for js in groups.values() for j in js)
    abandoned = lost = 0
    saved = 0.0
    for pid, jobs in groups.items():
        t0 = min(j["start"] for j in jobs)
        ends = [(j["start"] - t0 + min(j["dur"], tau), j["pass"] and j["dur"] <= tau) for j in jobs]
        final_inf = 0 < sum(p for _, p in ends) < len(ends)
        decided = False
        for age in GRID:
            if age <= 0 or age >= tau:
                continue
            now = t0 + age
            observed = [p for e, p in ends if e <= age]
            active = [(j, e) for j, (e, _) in zip(jobs, ends) if e > age]
            if not active:
                break
            ages = [max(0.0, now - j["start"]) for j, _ in active]
            g = vc.GroupView(pid, observed=[1.0 if p else 0.0 for p in observed], active_ages=ages, group_size=len(jobs))
            d = vc.decide(g, tables, mode, lam, theta, lam, min_age)
            if d.action == "abandon":
                abandoned += 1
                lost += final_inf
                saved += sum(e - age for _, e in active)
                decided = True
                break
    kept_inf = inform_total - lost
    work_after = work_total - saved
    base_rate = inform_total / work_total if work_total else 0.0
    new_rate = kept_inf / work_after if work_after else 0.0
    return dict(mode=mode, lam=lam, theta=theta, groups=n_groups, informative=inform_total, abandoned=abandoned,
                lost_informative=lost, saved_frac=round(saved / work_total, 4) if work_total else 0.0,
                lost_frac=round(lost / inform_total, 4) if inform_total else 0.0,
                inform_per_verifier_s_gain=round(new_rate / base_rate - 1, 4) if base_rate else 0.0)


def main() -> None:
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--run")
    g.add_argument("--probe")
    ap.add_argument("--tables", required=True)
    ap.add_argument("--tau", type=float, default=180.0)
    ap.add_argument("--lams", default="1e-4,3e-4,1e-3,3e-3,1e-2")
    ap.add_argument("--thetas", default="0.02,0.05,0.1,0.2,0.3")
    ap.add_argument("--min-age", type=float, default=2.0)
    ap.add_argument("--out")
    a = ap.parse_args()
    groups = groups_from_run(a.run.rstrip("/") + "/output/events.jsonl") if a.run else groups_from_probe(a.probe)
    tables = vc.Tables.load(a.tables)
    rows = []
    for lam in [float(x) for x in a.lams.split(",")]:
        rows.append(replay(groups, tables, "const", lam, 0.0, a.min_age, a.tau))
    for th in [float(x) for x in a.thetas.split(",")]:
        rows.append(replay(groups, tables, "posterior", 0.0, th, a.min_age, a.tau))
    print(f"{'mode':9s} {'param':>8s} {'abandon':>8s} {'lost_inf':>8s} {'saved%':>7s} {'lost%':>6s} {'gain%':>7s}   (groups {rows[0]['groups']}, informative {rows[0]['informative']})")
    for r in rows:
        prm = r["lam"] if r["mode"] == "const" else r["theta"]
        print(f"{r['mode']:9s} {prm:8.4g} {r['abandoned']:8d} {r['lost_informative']:8d} {100*r['saved_frac']:7.1f} {100*r['lost_frac']:6.1f} {100*r['inform_per_verifier_s_gain']:7.1f}")
    if a.out:
        json.dump(rows, open(a.out, "w"), indent=1)


if __name__ == "__main__":
    main()
