"""Simulation fallback for EQY timeouts: CodeV-R1's random-stimulus testbench checker decides the label.

Reward scheme (decided 2026-10-04): EQY with a short budget (RTL_EQY_TIMEOUT_S, 30 s in the fallback arms) decides every
sample it can certify; when EQY times out, the CodeV-R1 simulation checker (IPRC-DIP/CodeV-R1 @277ac46e,
verl/verl/utils/reward_score/codev_eval_toolkit/verify.py, fetched verbatim by experiments/ec/pod_setup.sh and never
vendored here) compares the candidate with the golden design on random stimuli: pass -> 1.0, otherwise 0.9 (the EQY
failure reward). This mirrors research/reward_eval_audit_20260925/hybrid_reward_run.py, which measured the scheme offline.

Inputs, all from the environment of the per-sample verifier child:
  RTL_SIM_FALLBACK=1   enable
  RTL_CODEV_TK         directory holding CodeV-R1's verify.py
  RTL_SIM_META         JSON sidecar {sha256(golden code): port info} written by prepare_codev_dataset.py --sim-meta-out
  RTL_SIM_TIMEOUT_S    wall-clock budget of one simulation (default 30, as in CodeV-R1's verify_one_sample_wrapper)
Infrastructure problems (missing toolkit or port info, unparsable golden design) never become a model verdict: the caller
keeps the EQY timeout label and records why the fallback did not decide.
"""
from __future__ import annotations

import functools
import hashlib
import importlib.util
import json
import multiprocessing as mp
import os
import re
import shutil
import time
import uuid
from pathlib import Path
from typing import Optional

PASS_REWARD, FAIL_REWARD = 1.0, 0.9
_VERILOG_BLOCK = re.compile(r"```verilog\s*([\s\S]*?)\s*```")  # CodeV-R1 eval_codev.extract_verilog, verbatim regex


def enabled() -> bool:
    return os.environ.get("RTL_SIM_FALLBACK", "0") == "1"


def golden_key(golden_code: str) -> str:
    return hashlib.sha256(golden_code.encode("utf-8")).hexdigest()


def extract_verilog(text: str) -> Optional[str]:
    """Last fenced verilog block, as CodeV-R1's checker does (the offline hybrid audit used the same rule)."""
    matches = _VERILOG_BLOCK.findall(text)
    return matches[-1] if matches else None


@functools.lru_cache(maxsize=2)
def _load_meta(path: str) -> dict:
    with open(path) as handle:
        return json.load(handle)


def port_info(golden_code: str, meta_path: Optional[str] = None) -> Optional[tuple]:
    """CodeV-R1 port_info tuple (sets of tuples, as pickled in the dataset) or None when unknown."""
    path = meta_path or os.environ.get("RTL_SIM_META")
    if not path or not os.path.exists(path):
        return None
    entry = _load_meta(path).get(golden_key(golden_code))
    if entry is None:
        return None
    return tuple({tuple(item) for item in entry[name]} for name in
                 ("input_port_width", "output_port_width", "clock_port_polarity", "reset_port_polarity_sync"))


def _load_codev_verify(toolkit_dir: str):
    path = Path(toolkit_dir) / "verify.py"
    spec = importlib.util.spec_from_file_location("codev_r1_verify", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _simulate(golden_code: str, dut_code: str, ports: tuple, toolkit_dir: str, workdir: str, queue) -> None:
    """CodeV-R1 verify_one_sample, minus its verl import; runs in a throwaway process."""
    os.makedirs(workdir, exist_ok=True)
    os.chdir(workdir)  # the checker writes and executes tb.vvp here: must not be a noexec mount such as /dev/shm
    # CodeV-R1 shells out to a bare `iverilog`; the reward worker does not put the EDA tools on PATH, the verifier does
    os.environ["PATH"] = f"{os.environ.get('RTL_OSS_CAD_BIN', '/opt/oss-cad-suite/bin')}:{os.environ.get('PATH', '')}"
    tools = _load_codev_verify(toolkit_dir).eda_tools(quiet=True)
    try:
        gold_top, gate_top = tools.auto_top(golden_code), tools.auto_top(dut_code)
    except Exception as exc:  # parse failure of either design
        queue.put({"correct": False, "parse_error": str(exc.args)[:300]})
        return
    uid = uuid.uuid4().hex
    gold_path, dut_path, tb_dir = f"{workdir}/{uid}_gold.v", f"{workdir}/{uid}_dut.v", f"{workdir}/{uid}_tb"
    os.makedirs(tb_dir, exist_ok=True)
    Path(gold_path).write_text(golden_code)
    Path(dut_path).write_text(dut_code)
    try:
        # CodeV-R1 @277ac46e returns a 6-tuple (correct, error_rate, input_port_width, output_port_width,
        # clock_port_polarity, reset_port_polarity_sync); unpacking 3 raised, so every fallback ended undecided
        correct, error_rate, *_ = tools.equiv_with_testbench(gold_path, dut_path, gold_top, gate_top, tb_dir,
                                                             port_info=ports)
        queue.put({"correct": bool(correct), "error_rate": error_rate})
    except Exception as exc:
        queue.put({"correct": False, "test_error": str(exc.args)[:300]})


def check(solution_str: str, golden_code: str, workdir: str) -> dict:
    """Run the fallback. Returns {decided, correct, sim_s, sim_detail}; decided=False means keep the EQY verdict."""
    t0 = time.monotonic()
    toolkit = os.environ.get("RTL_CODEV_TK", "")
    if not toolkit or not (Path(toolkit) / "verify.py").exists():
        return dict(decided=False, correct=False, sim_s=0.0, sim_detail="codev toolkit missing (RTL_CODEV_TK)")
    ports = port_info(golden_code)
    if ports is None:
        return dict(decided=False, correct=False, sim_s=0.0, sim_detail="no port info for this golden design")
    dut = extract_verilog(solution_str)
    if dut is None:  # EQY found code to time out on, but no fenced block: the candidate cannot pass CodeV's checker
        return dict(decided=True, correct=False, sim_s=time.monotonic() - t0, sim_detail="no fenced verilog block")
    timeout_s = float(os.environ.get("RTL_SIM_TIMEOUT_S", "30"))
    queue = mp.get_context("fork").Queue()
    proc = mp.get_context("fork").Process(target=_simulate, args=(golden_code, dut, ports, toolkit, workdir, queue))
    proc.start()
    proc.join(timeout_s)
    if proc.is_alive():
        proc.kill()
        proc.join()
        # CodeV-R1 counts a simulation timeout as incorrect; keep that semantics
        return dict(decided=True, correct=False, sim_s=time.monotonic() - t0, sim_detail="simulation timeout")
    try:
        out = queue.get(timeout=2.0)
    except Exception:  # child died without reporting (e.g. killed by the OOM killer)
        out = {"correct": False, "test_error": f"no result (exitcode {proc.exitcode})"}
    if "parse_error" in out:
        # CodeV-R1 scores parse errors as incorrect; a golden-side parse error would be an infrastructure fault, but the
        # checker does not say which side failed. EQY already parsed both designs before timing out, so treat it as a
        # testbench-construction failure and keep the EQY verdict.
        return dict(decided=False, correct=False, sim_s=time.monotonic() - t0, sim_detail=f"parse_error {out['parse_error']}")
    if "test_error" in out:
        return dict(decided=False, correct=False, sim_s=time.monotonic() - t0, sim_detail=f"test_error {out['test_error']}")
    return dict(decided=True, correct=out["correct"], sim_s=time.monotonic() - t0,
                sim_detail=f"error_rate {out.get('error_rate')}")


def apply(value: dict, solution_str: str, golden_code: str, workspace_root: str) -> dict:
    """Rewrite an EQY-timeout verdict dict in place with the simulation label; no-op for any other stage."""
    if not enabled() or value.get("stage") != "eqy_timeout":
        return value
    workdir = str(Path(workspace_root).resolve() / f"sim_{uuid.uuid4().hex}")
    try:
        sim = check(solution_str, golden_code, workdir)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
    value.update(eqy_stage="eqy_timeout", sim_decided=sim["decided"], sim_s=sim["sim_s"], sim_detail=sim["sim_detail"])
    value["total_duration_s"] = value.get("total_duration_s", 0.0) + sim["sim_s"]
    if sim["decided"]:
        value.update(stage="sim_pass" if sim["correct"] else "sim_fail", is_pass=sim["correct"], reward_valid=True,
                     reward=PASS_REWARD if sim["correct"] else FAIL_REWARD)
    return value
