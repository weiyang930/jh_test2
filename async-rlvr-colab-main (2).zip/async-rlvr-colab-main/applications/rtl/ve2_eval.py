"""VerilogEval v2 (spec-to-rtl) evaluation with the official prompt and pass rule, host side.

Prompt = the harness's sv-generate text for task spec-to-rtl (system message, "Question:" + <Prob>_prompt.txt, optional
rules suffix, "[BEGIN]/[DONE]" no-explain suffix, "Answer:"). Judgement = the Makefile recipe:
``iverilog -Wall -Winfloop -Wno-timescale -g2012 -s tb -o bin <Prob>_test.sv <Prob>_ref.sv <sample>.sv`` then a 30 s run;
a sample passes when the log has no "syntax error"/"error" line, no TIMEOUT, and reports "Mismatches: 0 in N samples"
(sv-iv-analyze). Reports unbiased pass@k over n samples.
"""
from __future__ import annotations

import argparse
import collections
import json
import math
import os
import re
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

SYSTEM_MSG = "\nYou are a Verilog RTL designer that only writes code using correct\nVerilog syntax.\n"
RULES_SUFFIX = """
Here are some additional rules and coding conventions.

 - declare all ports and signals as logic; do not to use wire or reg

 - for combinational logic with an always block do not explicitly specify
   the sensitivity list; instead use always @(*)

 - all sized numeric constants must have a size greater than zero
   (e.g, 0'b0 is not a valid expression)

 - an always block must read at least one signal otherwise it will never
   be executed; use an assign statement instead of an always block in
   situations where there is no need to read any signals

 - if the module uses a synchronous reset signal, this means the reset
   signal is sampled with respect to the clock. When implementing a
   synchronous reset signal, do not include posedge reset in the
   sensitivity list of any sequential always block.
"""
NO_EXPLAIN_SUFFIX = "\nEnclose your code with [BEGIN] and [DONE]. Only output the code snippet\nand do NOT output anything else.\n"
IVERILOG_FLAGS = ["-Wall", "-Winfloop", "-Wno-timescale", "-g2012", "-s", "tb"]
MISMATCH_RE = re.compile(r"^Mismatches: (\d+) in \d+ samples$")


def build_prompt(problem_prompt: str, rules: bool) -> str:
    full = "\nQuestion:\n" + problem_prompt.strip() + "\n"
    if rules:
        full += RULES_SUFFIX
    full = full.rstrip() + "\n" + NO_EXPLAIN_SUFFIX
    full += "\nAnswer:\n"
    return full.rstrip()


def extract_code(text: str) -> str:
    """[BEGIN]..[DONE] first, then a fenced block, then the raw text; drop stray fence markers."""
    # models close the block with [DONE], [END] or nothing at all (SALV writes [END]); take what follows [BEGIN]
    m = re.search(r"\[BEGIN\](.*?)(?:\[DONE\]|\[END\]|$)", text, re.DOTALL)
    if m and m.group(1).strip():
        code = m.group(1)
    else:
        blocks = re.findall(r"```(?:\w+)?\n(.*?)```", text, re.DOTALL)
        code = blocks[-1] if blocks else text
    code = re.sub(r"^```\w*\s*$", "", code, flags=re.MULTILINE)
    code = re.sub(r"\[(BEGIN|DONE|END)\]", "", code)
    return code.strip() + "\n"


def judge_sample(work: Path, prob: str, ds: Path, code: str, oss_bin: str) -> tuple[str, float]:
    work.mkdir(parents=True, exist_ok=True)
    sv = work / f"{prob}.sv"
    sv.write_text(code, encoding="utf-8")
    env = dict(os.environ, PATH=f"{oss_bin}:{os.environ['PATH']}")
    t0 = time.time()
    comp = subprocess.run([f"{oss_bin}/iverilog", *IVERILOG_FLAGS, "-o", str(work / prob), str(ds / f"{prob}_test.sv"),
                           str(ds / f"{prob}_ref.sv"), str(sv)], capture_output=True, text=True, env=env, timeout=120)
    log = comp.stdout + comp.stderr
    status = None
    if comp.returncode != 0 or not (work / prob).exists():
        status = "syntax_error" if "syntax error" in log else "compile_error"
    else:
        try:
            run = subprocess.run([str(work / prob)], capture_output=True, text=True, timeout=30, cwd=work, env=env)
            log += run.stdout + run.stderr
        except subprocess.TimeoutExpired:
            status = "timeout"
    (work / f"{prob}.log").write_text(log, encoding="utf-8")
    if status is None:
        if "syntax error" in log:
            status = "syntax_error"
        elif any("error" in line for line in log.splitlines()):
            status = "compile_error"
        else:
            mm = [MISMATCH_RE.match(l.strip()) for l in log.splitlines()]
            mm = [int(x.group(1)) for x in mm if x]
            status = "pass" if mm and mm[-1] == 0 else ("mismatch" if mm else "runtime_error")
    return status, time.time() - t0


def pass_at_k(n: int, c: int, k: int) -> float:
    return 1.0 if n - c < k else 1.0 - math.comb(n - c, k) / math.comb(n, k)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--dataset", type=Path, default=Path("/workspace/bench/VerilogEval_v2.0.0/dataset_spec-to-rtl"))
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--n", type=int, default=20)
    ap.add_argument("--temperature", type=float, default=1.0)
    ap.add_argument("--top-p", type=float, default=1.0)
    ap.add_argument("--max-tokens", type=int, default=4096)
    ap.add_argument("--max-model-len", type=int, default=8192)
    ap.add_argument("--rules", action="store_true", help="append the in-context rules suffix (harness -r)")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--gpu", default="0")
    ap.add_argument("--dtype", default="bfloat16")
    ap.add_argument("--tokenizer", default=None, help="tokenizer path if the checkpoint dir has none")
    ap.add_argument("--gpu-mem", type=float, default=0.85)
    ap.add_argument("--workers", type=int, default=32)
    ap.add_argument("--oss-bin", default="/opt/oss-cad-suite/bin")
    ap.add_argument("--work", type=Path, default=Path("/root/ve2_work"))
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--regen", action="store_true")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    probs = sorted(p.name[:-11] for p in args.dataset.glob("*_prompt.txt"))
    if args.limit:
        probs = probs[: args.limit]
    print(f"{len(probs)} problems", flush=True)

    gen_path = args.out / "generations.jsonl"
    if gen_path.exists() and not args.regen:
        gens = [json.loads(l) for l in open(gen_path, encoding="utf-8")]
    else:
        os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu
        from vllm import LLM, SamplingParams
        llm = LLM(model=args.model, tokenizer=args.tokenizer or args.model, dtype=args.dtype, gpu_memory_utilization=args.gpu_mem,
                  max_model_len=args.max_model_len, seed=args.seed)
        sp = SamplingParams(n=args.n, temperature=args.temperature, top_p=args.top_p, max_tokens=args.max_tokens, seed=args.seed)
        convs = [[{"role": "system", "content": SYSTEM_MSG.strip()},
                  {"role": "user", "content": build_prompt((args.dataset / f"{p}_prompt.txt").read_text(), args.rules)}] for p in probs]
        t0 = time.time()
        outs = llm.chat(convs, sp)
        gens = [dict(id=p, j=j, response=c.text, tokens=len(c.token_ids), finish=c.finish_reason)
                for p, o in zip(probs, outs) for j, c in enumerate(o.outputs)]
        with open(gen_path, "w", encoding="utf-8") as fh:
            for g in gens:
                fh.write(json.dumps(g, ensure_ascii=False) + "\n")
        json.dump(dict(generation_s=time.time() - t0, problems=len(probs), n=args.n, model=args.model, rules=args.rules),
                  open(args.out / "generation_meta.json", "w"))
        del llm

    import hashlib
    work_root = args.work / f"{args.out.name}_{hashlib.md5(str(args.out.resolve()).encode()).hexdigest()[:8]}"   # unique per --out
    t0 = time.time()

    def judge(g):
        status, dt = judge_sample(work_root / f"{g['id']}_{g['j']}", g["id"], args.dataset, extract_code(g["response"]), args.oss_bin)
        return dict(id=g["id"], j=g["j"], tokens=g["tokens"], finish=g["finish"], status=status, exec_s=dt)

    results = []
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        for i, f in enumerate(as_completed([ex.submit(judge, g) for g in gens]), 1):
            results.append(f.result())
            if i % 500 == 0:
                print(f"judged {i}/{len(gens)} in {time.time() - t0:.0f}s", flush=True)
    results.sort(key=lambda r: (r["id"], r["j"]))
    with open(args.out / "attempts.jsonl", "w", encoding="utf-8") as fh:
        for r in results:
            fh.write(json.dumps(r) + "\n")
    per = collections.defaultdict(lambda: [0, 0])
    for r in results:
        per[r["id"]][0] += 1
        per[r["id"]][1] += r["status"] == "pass"
    ks = [k for k in (1, 5, 10, 20) if k <= args.n]
    summary = dict(model=args.model, benchmark="VerilogEval_v2.0.0 spec-to-rtl", problems=len(per), n=args.n, temperature=args.temperature,
                   rules=args.rules, status_counts=dict(collections.Counter(r["status"] for r in results)),
                   **{f"pass@{k}": sum(pass_at_k(n, c, k) for n, c in per.values()) / len(per) for k in ks},
                   mean_response_tokens=sum(r["tokens"] for r in results) / len(results),
                   finish_length_share=sum(r["finish"] == "length" for r in results) / len(results),
                   judge_wall_s=time.time() - t0, per_problem={k: dict(n=v[0], passes=v[1]) for k, v in per.items()})
    json.dump(summary, open(args.out / "summary.json", "w"), indent=1)
    print(json.dumps({k: v for k, v in summary.items() if k != "per_problem"}, indent=1))


if __name__ == "__main__":
    main()
