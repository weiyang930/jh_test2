#!/usr/bin/env python3
"""Zero-GPU simulation of the history selector on a probe: repeated epochs over a prompt pool.

Each prompt's true pass probability p_i and mean verify cost c_i come from the probe (n samples per prompt). A visit
draws a GRPO group of G Bernoulli(p_i) outcomes and costs G * c_i verifier-seconds (all-fail groups cost the probe's
measured mean, so timeout-heavy prompts stay expensive). Modes mirror history_admission.HistoryAdmissionPolicy.
Reports informative groups per visit and per verifier-second over the run, by mode and epsilon.
usage: sim_history_selector.py --probe attempts.jsonl --G 8 --B 32 --steps 300 [--eps 0.1] [--seed 0]
"""
from __future__ import annotations

import argparse
import collections
import json
import math
import random


def load_probe(path: str):
    att = collections.defaultdict(list)
    for line in open(path, errors="ignore"):
        a = json.loads(line)
        st = a.get("status") or a.get("stage")
        att[a["id"]].append((st == "pass", float(a.get("verify_time_s") or 0.0)))
    ids = sorted(att)
    p = {i: sum(x for x, _ in att[i]) / len(att[i]) for i in ids}
    c = {i: sum(t for _, t in att[i]) / len(att[i]) for i in ids}
    return ids, p, c


def run(ids, p, c, mode, G, B, steps, eps, cooldown, rng, alpha=1.0, beta=1.0, cost_scale=0.0):
    stats = {i: dict(v=0, inf=0, zero=0, last=-10 ** 9, last_kind="none", cpu=0.0) for i in ids}
    tot_inf = tot_visits = 0
    tot_cost = 0.0
    for step in range(steps):
        elig = [i for i in ids if step - stats[i]["last"] > cooldown] or list(ids)
        n_eps = int(round(eps * B)) if mode != "uniform" else 0
        if mode == "uniform":
            picked = rng.sample(elig, min(B, len(elig)))
        elif mode == "skip":
            good = [i for i in elig if stats[i]["last_kind"] in ("none", "informative")]
            picked = rng.sample(good, min(B - n_eps, len(good)))
            rest = [i for i in elig if i not in set(picked)]
            picked += rng.sample(rest, min(B - len(picked), len(rest)))
        else:
            def w(i):
                s = stats[i]
                pi = (alpha + s["inf"]) / (alpha + beta + s["inf"] + s["zero"])
                if mode == "ucb":
                    pi += math.sqrt(2 * math.log(step + 2) / (s["v"] + 1))
                cost = s["cpu"] / s["v"] if s["v"] else 0.0
                return max(pi, 1e-6) / (1 + cost_scale * cost)
            if mode == "ucb":
                picked = sorted(elig, key=lambda i: -w(i))[: B - n_eps]
            else:
                pool, picked = list(elig), []
                ws = {i: w(i) for i in pool}
                for _ in range(min(B - n_eps, len(pool))):
                    tot = sum(ws[i] for i in pool)
                    r = rng.random() * tot
                    acc = 0.0
                    for k, i in enumerate(pool):
                        acc += ws[i]
                        if acc >= r:
                            picked.append(pool.pop(k))
                            break
            rest = [i for i in elig if i not in set(picked)]
            picked += rng.sample(rest, min(B - len(picked), len(rest)))
        for i in picked:
            s = stats[i]
            passes = sum(rng.random() < p[i] for _ in range(G))
            inf = 0 < passes < G
            cost = G * c[i]
            s["v"] += 1; s["last"] = step; s["cpu"] += cost
            s["inf" if inf else "zero"] += 1
            s["last_kind"] = "informative" if inf else ("all_pass" if passes == G else "all_fail")
            tot_visits += 1; tot_inf += inf; tot_cost += cost
    return dict(mode=mode, eps=eps, informative_per_visit=round(tot_inf / tot_visits, 4),
                informative_per_1000_verifier_s=round(1000 * tot_inf / tot_cost, 3), visits=tot_visits,
                distinct_prompts=sum(1 for s in stats.values() if s["v"]))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--probe", required=True)
    ap.add_argument("--G", type=int, default=8)
    ap.add_argument("--B", type=int, default=32)
    ap.add_argument("--steps", type=int, default=300)
    ap.add_argument("--eps", default="0.05,0.1,0.2")
    ap.add_argument("--cooldown", type=int, default=2)
    ap.add_argument("--cost-scale", type=float, default=0.0)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    ids, p, c = load_probe(a.probe)
    print(f"pool {len(ids)} prompts, B={a.B} G={a.G} steps={a.steps} => {a.B * a.steps / len(ids):.1f} visits per prompt on average")
    rows = [run(ids, p, c, "uniform", a.G, a.B, a.steps, 0.0, a.cooldown, random.Random(a.seed))]
    for eps in [float(x) for x in a.eps.split(",")]:
        for mode in ("skip", "weighted", "ucb"):
            rows.append(run(ids, p, c, mode, a.G, a.B, a.steps, eps, a.cooldown, random.Random(a.seed), cost_scale=a.cost_scale))
    base = rows[0]
    print(f"{'mode':9s} {'eps':>5s} {'inf/visit':>10s} {'inf/1000s':>10s} {'x uniform (per s)':>18s} {'prompts':>8s}")
    for r in rows:
        print(f"{r['mode']:9s} {r['eps']:5.2f} {r['informative_per_visit']:10.3f} {r['informative_per_1000_verifier_s']:10.2f} "
              f"{r['informative_per_1000_verifier_s'] / base['informative_per_1000_verifier_s']:18.2f} {r['distinct_prompts']:8d}")


if __name__ == "__main__":
    main()
