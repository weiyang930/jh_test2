"""Local blocking-cost credit (D_local) from the observed async verification timeline.

Given the fixed, already-observed dependency graph of one learner batch (generation
release times, per-worker execution order, whole-group joins, and the learner's own
ready time), shortening verification task ``i`` by a fraction ``epsilon`` and
re-propagating the max-plus timeline tells how much earlier the batch could have
started training:

    D_local_i      = t_b(C) - t_b(C - epsilon * C_i * e_i)
    effective_cost = D_local_i / epsilon

Everything here is numpy/pure python so the same code runs in unit tests, offline
replay and the training driver.  Nothing uses information from after the batch was
received: releases, worker order, batch membership and slack are all observed facts.

Approximation range (recorded, not hidden):
  * worker assignment and per-worker order are frozen (FIFO governor, one job in
    flight per worker), so a counterfactual never re-routes a job to another worker;
  * per-job unexplained scheduling slack (observed start minus the max of release and
    previous end on the same worker) is kept fixed;
  * the batch membership is fixed to the groups the learner actually consumed;
  * tied bottlenecks yield D=0 for each member individually (no additive credit).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, Hashable, Iterable, List, Optional, Sequence, Tuple

import numpy as np

JobKey = Tuple[int, int]  # (prompt_id, member_index)


@dataclass
class Job:
    key: JobKey
    worker: str
    release: float  # verification request submitted (generation finished)
    start: float  # worker began executing
    end: float  # worker finished executing
    ret: float  # result returned to the rollout loop
    reward: float = float("nan")
    stage: str = "?"
    valid: bool = True

    @property
    def service(self) -> float:
        return max(self.end - self.start, 0.0)


@dataclass
class Group:
    prompt_id: int
    members: List[JobKey]
    t_commit: float


@dataclass
class Timeline:
    """Per-worker chains with fixed slack; ``replay`` reproduces observed ends exactly."""

    chains: Dict[str, List[Job]]
    slack: Dict[JobKey, float]
    negative_slack_jobs: int = 0
    by_key: Dict[JobKey, Job] = field(default_factory=dict)

    @classmethod
    def build(cls, jobs: Iterable[Job]) -> "Timeline":
        chains: Dict[str, List[Job]] = {}
        for job in jobs:
            chains.setdefault(job.worker, []).append(job)
        slack: Dict[JobKey, float] = {}
        negative = 0
        by_key: Dict[JobKey, Job] = {}
        for worker, chain in chains.items():
            chain.sort(key=lambda j: (j.start, j.key))
            prev_end = -math.inf
            for job in chain:
                gap = job.start - max(job.release, prev_end)
                if gap < 0:
                    negative += 1
                    gap = 0.0
                slack[job.key] = gap
                prev_end = job.end
                by_key[job.key] = job
        return cls(chains=chains, slack=slack, negative_slack_jobs=negative, by_key=by_key)

    def replay(self, scale: Optional[Dict[JobKey, float]] = None,
               global_scale: float = 1.0) -> Dict[JobKey, float]:
        """Return counterfactual end time per job with fixed order/slack."""
        scale = scale or {}
        ends: Dict[JobKey, float] = {}
        for chain in self.chains.values():
            prev_end = -math.inf
            for job in chain:
                start = max(job.release, prev_end) + self.slack[job.key]
                end = start + job.service * global_scale * scale.get(job.key, 1.0)
                ends[job.key] = end
                prev_end = end
        return ends

    def replay_from(self, worker: str, key: JobKey, factor: float,
                    baseline_ends: Dict[JobKey, float]) -> Dict[JobKey, float]:
        """Cheaper replay: only the chain containing ``key`` from that job onward can move."""
        chain = self.chains[worker]
        idx = next(i for i, j in enumerate(chain) if j.key == key)
        ends: Dict[JobKey, float] = {}
        prev_end = baseline_ends[chain[idx - 1].key] if idx > 0 else -math.inf
        for pos in range(idx, len(chain)):
            job = chain[pos]
            start = max(job.release, prev_end) + self.slack[job.key]
            end = start + job.service * (factor if pos == idx else 1.0)
            if pos > idx and abs(end - baseline_ends[job.key]) < 1e-12:
                break  # downstream no longer affected
            ends[job.key] = end
            prev_end = end
        return ends


def group_ready_times(groups: Sequence[Group], jobs: Dict[JobKey, Job],
                      ends: Dict[JobKey, float], baseline_ends: Dict[JobKey, float]) -> Dict[int, float]:
    """Group availability = observed commit time shifted by the change in its latest member."""
    ready: Dict[int, float] = {}
    for group in groups:
        rets = []
        for key in group.members:
            job = jobs[key]
            shift = baseline_ends[key] - ends.get(key, baseline_ends[key])
            rets.append(job.ret - shift)
        observed_max_ret = max(jobs[k].ret for k in group.members)
        commit_overhead = max(group.t_commit - observed_max_ret, 0.0)
        ready[group.prompt_id] = max(rets) + commit_overhead
    return ready


def batch_ready_time(t_request: float, ready: Dict[int, float]) -> float:
    return max([t_request] + list(ready.values()))


@dataclass
class BatchCredit:
    t_request: float
    t_b: float
    t_b_all_half: float
    learner_wait_s: float
    verification_attributable_s: float
    d_local: Dict[JobKey, float]
    effective_cost: Dict[JobKey, float]
    raw_cost: Dict[JobKey, float]
    on_critical: Dict[JobKey, bool]
    calibration_max_abs_err_s: float
    negative_slack_jobs: int


def compute_batch_credit(timeline: Timeline, groups: Sequence[Group], t_request: float,
                         epsilon: float = 0.1) -> BatchCredit:
    """D_local for every member of every batch group on the fixed timeline."""
    jobs = timeline.by_key
    baseline_ends = timeline.replay()
    calib = max((abs(baseline_ends[j.key] - j.end) for j in jobs.values()), default=0.0)
    ready0 = group_ready_times(groups, jobs, baseline_ends, baseline_ends)
    t_b = batch_ready_time(t_request, ready0)
    half_ends = timeline.replay(global_scale=0.5)
    t_b_half = batch_ready_time(t_request, group_ready_times(groups, jobs, half_ends, baseline_ends))

    d_local: Dict[JobKey, float] = {}
    eff: Dict[JobKey, float] = {}
    raw: Dict[JobKey, float] = {}
    critical: Dict[JobKey, bool] = {}
    factor = 1.0 - epsilon
    for group in groups:
        for key in group.members:
            job = jobs[key]
            raw[key] = job.service
            if t_b <= t_request or job.service <= 0:
                d_local[key], eff[key], critical[key] = 0.0, 0.0, False
                continue
            cf_ends = dict(baseline_ends)
            cf_ends.update(timeline.replay_from(job.worker, key, factor, baseline_ends))
            ready_cf = group_ready_times(groups, jobs, cf_ends, baseline_ends)
            t_b_cf = batch_ready_time(t_request, ready_cf)
            d = max(t_b - t_b_cf, 0.0)
            d_local[key] = d
            eff[key] = d / epsilon
            critical[key] = d > 1e-9
    return BatchCredit(
        t_request=t_request, t_b=t_b, t_b_all_half=t_b_half,
        learner_wait_s=max(t_b - t_request, 0.0),
        verification_attributable_s=max(t_b - t_b_half, 0.0),
        d_local=d_local, effective_cost=eff, raw_cost=raw, on_critical=critical,
        calibration_max_abs_err_s=calib, negative_slack_jobs=timeline.negative_slack_jobs,
    )


# --------------------------------------------------------------------------- weights
@dataclass
class ClassWeights:
    weight: Dict[Hashable, float]
    advantage: Dict[Hashable, float]
    class_size: Dict[Hashable, int]
    n_classes: int
    n_weighted: int


def within_class_weights(samples: Sequence[dict], eta: float, cost_scale: float,
                         classes: Sequence[str], cost_key: str = "effective_cost") -> ClassWeights:
    """w_i = n * softmax(-eta * cost_i / scale) within (group, reward, stage); A_i = w_i - 1.

    Each sample dict needs ``key``, ``group_id``, ``reward``, ``stage``, ``valid`` and the
    cost field.  Samples outside the enabled classes, invalid samples and classes with
    fewer than two members get weight 1 (advantage 0).  Weights sum to the class size.
    """
    buckets: Dict[Tuple[Hashable, float, str], List[dict]] = {}
    for sample in samples:
        if not sample.get("valid", True) or sample["stage"] not in classes:
            continue
        buckets.setdefault((sample["group_id"], float(sample["reward"]), sample["stage"]), []).append(sample)
    weight: Dict[Hashable, float] = {s["key"]: 1.0 for s in samples}
    advantage: Dict[Hashable, float] = {s["key"]: 0.0 for s in samples}
    class_size: Dict[Hashable, int] = {s["key"]: 0 for s in samples}
    n_classes = n_weighted = 0
    for members in buckets.values():
        if len(members) < 2:
            continue
        n_classes += 1
        scores = np.array([float(m[cost_key]) / cost_scale for m in members], dtype=np.float64)
        logits = -eta * scores
        logits -= logits.max()  # numerically stable softmax
        probs = np.exp(logits)
        probs /= probs.sum()
        for member, p in zip(members, probs):
            w = float(len(members) * p)
            weight[member["key"]] = w
            advantage[member["key"]] = w - 1.0
            class_size[member["key"]] = len(members)
            n_weighted += 1
    return ClassWeights(weight=weight, advantage=advantage, class_size=class_size,
                        n_classes=n_classes, n_weighted=n_weighted)


# --------------------------------------------------------------------------- event parsing
def jobs_from_sample_events(events: Iterable[dict]) -> List[Job]:
    """Build jobs from ``sample_done`` events (needs ``verify_worker`` and worker timestamps)."""
    jobs: List[Job] = []
    for ev in events:
        if ev.get("event") != "sample_done":
            continue
        worker = ev.get("verify_worker")
        if worker is None:
            continue
        jobs.append(Job(
            key=(int(ev["prompt_id"]), int(ev["member_index"])), worker=str(worker),
            release=float(ev["t_reward_submit"]), start=float(ev["t_worker_start"]),
            end=float(ev["t_worker_end"]), ret=float(ev["t_reward_return"]),
            reward=float(ev.get("reward", float("nan"))), stage=str(ev.get("verifier_stage", "?")),
            valid=bool(ev.get("reward_valid", True)),
        ))
    return jobs


def groups_from_commit_events(events: Iterable[dict], group_size: int) -> Dict[int, Group]:
    groups: Dict[int, Group] = {}
    for ev in events:
        if ev.get("event") != "prompt_commit":
            continue
        pid = int(ev["prompt_id"])
        groups[pid] = Group(prompt_id=pid, members=[(pid, i) for i in range(int(ev.get("group_size", group_size)))],
                            t_commit=float(ev["t_commit"]))
    return groups
