"""Group-level verification controller (the 'scheduler' arm), pure decision logic + fitted tables.

State per in-flight GRPO group (one prompt, G members): observed rewards (n done, s passes) and the active checks
(2026-10-25: "informative" is the learner's definition, reward variance > 0 among the observed members -- RTL grades
failures 0.5 / 0.75 / 0.9, and 9.6 % of Stage-1 groups are informative with no pass at all; "pass" is the verifier's
verdict (``observed_pass``, or reward >= 1 when the governor did not record verdicts), never reward > 0)
with their ages. Tables fitted on a prior run of the same verifier: p(t|S) = P(check passes | still running at age
t, sibling state S in {none, fail, pass}) and R(t) = E[min(T, tau) - t | T > t] in verifier-seconds.

Decision (every ``interval_s``, decoupled consumption): a group that is already informative (0 < s < n) is always
continued. Otherwise its continuation value is P(group becomes informative | state) and its cost is the expected
remaining verifier-seconds of all active checks:
  P_inform = 1 - prod(1 - p_j)                      if the observed members all failed (s == 0, n > 0)
           = 1 - prod(p_j)                          if they all passed (s == n > 0)
           = 1 - prod(1 - p_j) - prod(p_j)          if nothing is observed yet
  R_sum    = sum_j R(t_j)
Modes:
  const      continue  iff  P_inform - lam * R_sum > 0           (lam: informative groups per verifier-second)
  dynamic    same with lam_t = kappa * EMA_30s(queued / workers)   (bid price tracks the verifier backlog)
  posterior  continue  iff  P_inform >= theta                      (the 'visible in flight' rule, no price)
Abandoning a group cancels all its queued/running checks; the prompt is aborted and a fresh prompt replaces it.
Checks younger than ``min_age_s`` and groups with every member already decided are never touched.

Partial release (``release`` mode, informative groups only, n >= ceil(release_frac * G) members observed):
  slow       release iff the oldest active check is older than ``release_slow_s``
  index      release iff lam_eff * R_sum > (G - n) / G   (finishing the rest costs more than the 1/G weight each
             extra member adds to an already informative group; lam_eff as in the const/dynamic mode)
Releasing cancels the remaining checks and lets the group be consumed with its n verified members; the released
members are returned as placeholder rows (reward_valid False, verifier_stage "released") that the learner masks.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

GRID = [0, 2, 5, 10, 20, 30, 45, 60, 90, 120, 180, 240]
STATES = ("none", "fail", "pass")
MODES = ("none", "const", "dynamic", "posterior")
RELEASE_MODES = ("none", "slow", "index", "expiry")   # expiry: release instead of letting the replay buffer discard the group


class Tables:
    """p(t|S) and R(t) on GRID, loaded from fit_controller_tables.py output; nearest grid point at or below t."""

    def __init__(self, p: Dict[Tuple[int, str], float], R: Dict[int, float], tau: float, source: str = ""):
        self.p, self.R, self.tau, self.source = dict(p), dict(R), float(tau), source
        self.grid = sorted({t for t, _ in self.p} | set(self.R))

    @classmethod
    def load(cls, path: str) -> "Tables":
        d = json.load(open(path))
        p = {(int(k.split("|")[0]), k.split("|")[1]): float(v) for k, v in d["p"].items()}
        R = {int(k): float(v) for k, v in d["R"].items()}
        return cls(p, R, d.get("tau", 180.0), d.get("source", path))

    def _bucket(self, age: float) -> int:
        b = self.grid[0]
        for t in self.grid:
            if t <= age:
                b = t
        return b

    def p_pass(self, age: float, state: str) -> float:
        t = self._bucket(age)
        for s in (state, "none"):
            if (t, s) in self.p:
                return self.p[(t, s)]
        # fall back to the nearest earlier bucket with data
        for tt in sorted(self.grid, reverse=True):
            if tt <= t and (tt, state) in self.p:
                return self.p[(tt, state)]
        return 0.0

    def remaining(self, age: float) -> float:
        t = self._bucket(age)
        if t in self.R:
            return max(0.0, self.R[t])
        return max(0.0, self.tau - age)


@dataclass
class GroupView:
    prompt_id: int
    observed: List[float]            # rewards of finished members (graded on RTL: 0.5 / 0.75 / 0.9 are failures, 1.0 pass)
    active_ages: List[float]         # age in seconds of each queued/running check (0 for queued)
    group_size: int
    observed_pass: Optional[List[bool]] = None   # verifier verdicts of the finished members (same order as observed)
    age_steps: Optional[int] = None              # learner steps since the group was admitted (expiry release)
    expiry_steps: Optional[int] = None           # staleness limit: the replay buffer discards the group at this age


@dataclass
class Decision:
    prompt_id: int
    action: str                      # continue | abandon | release | skip
    p_inform: float
    r_sum: float
    price: float
    n_obs: int
    s_obs: int
    n_active: int
    reason: str = ""


def passes_of(g: "GroupView") -> List[bool]:
    """Verifier verdicts of the observed members: recorded verdicts if the governor has them, else reward >= 1."""
    if g.observed_pass is not None and len(g.observed_pass) == len(g.observed):
        return [bool(x) for x in g.observed_pass]
    return [float(r) >= 1.0 for r in g.observed]


def is_informative(observed: Sequence[float]) -> bool:
    """The learner's definition: GRPO has a gradient iff the group's rewards are not all equal."""
    return len(set(round(float(r), 6) for r in observed)) > 1


def sibling_state(passes: Sequence[bool]) -> str:
    if not passes:
        return "none"
    return "pass" if any(passes) else "fail"


def p_informative(p_list: Sequence[float], s: int, n: int) -> float:
    if n > 0 and 0 < s < n:
        return 1.0
    all_fail = math.prod(1.0 - p for p in p_list) if p_list else 1.0
    all_pass = math.prod(p for p in p_list) if p_list else 1.0
    if n == 0:
        return max(0.0, 1.0 - all_fail - all_pass)
    return max(0.0, 1.0 - all_fail) if s == 0 else max(0.0, 1.0 - all_pass)


def decide(g: GroupView, tables: Tables, mode: str, lam: float, theta: float, price: float, min_age_s: float,
           min_obs: int = 0, release: str = "none", release_frac: float = 0.75, release_slow_s: float = 30.0) -> Decision:
    """min_obs: never abandon before this many members are observed (guards against early all-fail streaks)."""
    passes = passes_of(g)
    n, s = len(g.observed), int(sum(passes))
    if mode == "none" or not g.active_ages:
        return Decision(g.prompt_id, "skip", 1.0, 0.0, price, n, s, len(g.active_ages), "no_active" if not g.active_ages else "off")
    if n > 0 and is_informative(g.observed):
        return _decide_release(g, tables, mode, lam, price, min_age_s, release, release_frac, release_slow_s, n, s)
    if max(g.active_ages) < min_age_s:
        return Decision(g.prompt_id, "skip", 1.0, 0.0, price, n, s, len(g.active_ages), "too_young")
    if n < min_obs:
        return Decision(g.prompt_id, "skip", 1.0, 0.0, price, n, s, len(g.active_ages), "too_few_observed")
    state = sibling_state(passes)
    ps = [tables.p_pass(a, state) for a in g.active_ages]   # P(informative) >= P(a pass arrives): a differently graded failure also counts, so this is a lower bound
    p_inf = p_informative(ps, s, n)
    r_sum = sum(tables.remaining(a) for a in g.active_ages)
    if mode == "posterior":
        act = "continue" if p_inf >= theta else "abandon"
        return Decision(g.prompt_id, act, p_inf, r_sum, theta, n, s, len(g.active_ages), "posterior_rule")
    lam_eff = lam if mode == "const" else price
    act = "continue" if p_inf - lam_eff * r_sum > 0 else "abandon"
    return Decision(g.prompt_id, act, p_inf, r_sum, lam_eff, n, s, len(g.active_ages), f"{mode}_price")


def _decide_release(g: GroupView, tables: Tables, mode: str, lam: float, price: float, min_age_s: float, release: str,
                    release_frac: float, release_slow_s: float, n: int, s: int) -> Decision:
    """Informative group: continue, or release its slow / expensive remainder (see module docstring)."""
    assert release in RELEASE_MODES, release
    n_active = len(g.active_ages)
    cont = Decision(g.prompt_id, "continue", 1.0, 0.0, price, n, s, n_active, "already_informative")
    if release == "none" or n < math.ceil(release_frac * g.group_size):
        return cont
    oldest = max(g.active_ages)
    r_sum = sum(tables.remaining(a) for a in g.active_ages)
    if release == "expiry":
        # consume the informative remainder one step before the staleness gc would throw the whole group away
        if g.age_steps is None or g.expiry_steps is None or g.age_steps < g.expiry_steps - 1:
            return cont
        return Decision(g.prompt_id, "release", 1.0, r_sum, price, n, s, n_active, "release_expiry")
    if release == "slow":
        if oldest < release_slow_s:
            return cont
        return Decision(g.prompt_id, "release", 1.0, r_sum, price, n, s, n_active, "release_slow")
    if oldest < min_age_s:
        return cont
    lam_eff = lam if mode in ("const", "posterior") else price
    if lam_eff * r_sum > (g.group_size - n) / g.group_size:
        return Decision(g.prompt_id, "release", 1.0, r_sum, lam_eff, n, s, n_active, "release_index")
    return cont


class PriceTracker:
    """EMA of queued/workers (the bid price's state); kappa scales it to informative-groups per verifier-second."""

    def __init__(self, kappa: float, half_life_s: float = 30.0):
        self.kappa, self.half_life_s = kappa, half_life_s
        self.ema: Optional[float] = None
        self.t_last: Optional[float] = None

    def update(self, now: float, queued: int, workers: int) -> float:
        x = queued / max(1, workers)
        if self.ema is None or self.t_last is None:
            self.ema = x
        else:
            dt = max(0.0, now - self.t_last)
            a = 1.0 - 0.5 ** (dt / max(self.half_life_s, 1e-9))
            self.ema = a * x + (1 - a) * self.ema
        self.t_last = now
        return self.kappa * self.ema
