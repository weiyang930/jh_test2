"""CodeV actor plus an auxiliary within-class cost policy loss.

``L_total = L_original_RL + beta * L_cost`` where ``L_cost`` is the same clipped
importance-ratio surrogate as the main policy loss, evaluated with the per-sample
cost advantage ``A_cost = w - 1`` (``batch["cost_advantages"]``, filled by the
driver before any learner forward pass).  The original reward path, GRPO
normalisation, masks and train/infer correction are untouched; ``beta == 0``
returns the base loss unchanged (baseline arm).
"""
import os

import torch

from applications.rtl.codev_actor_worker import CodeVActorWorker
from roll.utils.functionals import agg_loss

COST_AUX_BETA_ENV = 'RTL_COST_AUX_BETA'


def cost_aux_beta() -> float:
    return float(os.environ.get(COST_AUX_BETA_ENV, '0'))


class BlockingCostActorWorker(CodeVActorWorker):
    """Adds beta * clipped surrogate(A_cost) using the same log-probs as the RL loss."""

    def loss_func(self, data, output_tensor: torch.Tensor):
        beta = cost_aux_beta()
        if beta == 0.0 or 'cost_advantages' not in data.batch:
            total_loss, metrics = super().loss_func(data, output_tensor)
            metrics['cost/aux_loss@sum'] = 0.0
            metrics['cost/aux_beta@mean'] = beta
            return total_loss, metrics

        captured = {}
        original_log_probs = self.strategy.op_compute_log_probs

        def capture(**kwargs):
            captured['log_probs'] = original_log_probs(**kwargs)
            return captured['log_probs']

        self.strategy.op_compute_log_probs = capture
        try:
            total_loss, metrics = super().loss_func(data, output_tensor)
        finally:
            self.strategy.op_compute_log_probs = original_log_probs

        log_probs = captured['log_probs']
        old_log_probs = data.batch['old_log_probs']
        response_mask = data.batch['response_mask'][:, 1:].long()
        final_response_mask = data.batch.get('final_response_mask', response_mask)
        cost_adv = data.batch['cost_advantages']
        if cost_adv.shape != log_probs.shape:
            raise RuntimeError(f'cost_advantages {tuple(cost_adv.shape)} vs log_probs {tuple(log_probs.shape)}')

        cfg = self.pipeline_config
        clip_low = cfg.pg_clip_low if cfg.use_pg_clip_range else cfg.pg_clip
        clip_high = cfg.pg_clip_high if cfg.use_pg_clip_range else cfg.pg_clip
        if cfg.importance_sampling == 'token':
            ratio = (log_probs - old_log_probs).exp()
        else:
            log_ratio = log_probs - old_log_probs
            masked = (log_ratio * final_response_mask).sum(-1) / final_response_mask.sum(-1).clamp(min=1)
            ratio = masked.exp().unsqueeze(-1).expand_as(log_ratio)
        surr1 = ratio * cost_adv
        surr2 = ratio.clamp(1 - clip_low, 1 + clip_high) * cost_adv
        loss = -torch.min(surr1, surr2)
        if cfg.train_infer_correction.is_weight.enabled and 'train_infer_is_weight' in data.batch:
            loss = loss * data.batch['train_infer_is_weight']
        batch_num_tokens = data.meta_info['batch_num_tokens']
        global_valid_samples = data.meta_info['global_valid_samples']
        aux = agg_loss(loss_mat=loss, loss_mask=final_response_mask, loss_agg_mode=cfg.loss_agg_mode,
                       batch_num_tokens=batch_num_tokens['final_response_mask'],
                       global_valid_samples=global_valid_samples['final_response_mask'])
        total = total_loss + beta * aux * cfg.rl_loss_coef

        active = ((cost_adv.abs() > 0) & (final_response_mask > 0)).float()
        metrics['cost/aux_loss@sum'] = aux.detach().item()
        metrics['cost/aux_beta@mean'] = beta
        metrics['cost/active_tokens@sum'] = active.sum().item()
        metrics['cost/adv_abs_mean@mean'] = (cost_adv.abs() * final_response_mask).sum().item() / max(final_response_mask.sum().item(), 1)
        metrics['actor/total_loss@sum'] = total.detach().item()
        return total, metrics
