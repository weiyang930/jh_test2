#!/usr/bin/env python3
"""Recount a probe_rtl attempts.jsonl with the cascaded reward: informative share at G = P(the G rewards of a group are
not all equal), from the per-problem reward-level frequencies (plug-in), next to the binary pass-mixed share.
Older attempts files have no `reward` field: the stage is mapped to the verifier's reward level.
usage: probe_recount.py attempts.jsonl [attempts2.jsonl ...] [--groups 4,8]"""
import argparse, collections, json

STAGE_REWARD = {"pass": 1.0, "header_extract_fail": 0.75, "top_config_error": 0.75, "gold_invalid": 0.75, "gold_prepare_fail": 0.75,
                "syntax_fail": 0.5, "syntax_timeout": 0.5, "syntax_tool_error": 0.5}   # every other (EQY-level) stage: 0.9


def reward_of(e: dict) -> float:
    return float(e["reward"]) if e.get("reward") is not None else STAGE_REWARD.get(str(e.get("stage")), 0.9)


def recount(path: str, groups: list) -> dict:
    per = collections.defaultdict(collections.Counter); passes = collections.Counter(); n = collections.Counter()
    for line in open(path):
        e = json.loads(line); pid = e["id"]; per[pid][round(reward_of(e), 3)] += 1; n[pid] += 1; passes[pid] += int(e.get("stage") == "pass")
    out = {"file": path, "problems": len(per), "n": max(n.values())}
    for G in groups:
        out[f"informative_share_G{G}"] = sum(1 - sum((c / n[p]) ** G for c in per[p].values()) for p in per) / len(per)
        out[f"pass_mixed_share_G{G}"] = sum(1 - (passes[p] / n[p]) ** G - (1 - passes[p] / n[p]) ** G for p in per) / len(per)
    out["constant_level_share"] = sum(1 for p in per if len(per[p]) == 1) / len(per)
    out["all_fail_share"] = sum(1 for p in per if passes[p] == 0) / len(per)
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("files", nargs="+"); ap.add_argument("--groups", default="4,8")
    a = ap.parse_args(); groups = [int(x) for x in a.groups.split(",")]
    for f in a.files:
        r = recount(f, groups); print(json.dumps(r))
