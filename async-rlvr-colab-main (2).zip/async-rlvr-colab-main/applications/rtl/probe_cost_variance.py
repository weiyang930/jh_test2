"""Probe: does the same prompt/same verifier class produce reproducibly different EQY cost?

Generates ``n_prompts`` x ``group_size`` SALV answers with vLLM (training sampling
settings), verifies every answer through the exact training verifier child process
on ``workers`` sequential CPU slots, then re-verifies a fixed set of same-class
candidate pairs ``repeats`` times in randomized order to measure the noise floor.
Outputs gate-A statistics per class plus raw records.
"""
import argparse
import json
import os
import random
import statistics
import subprocess
import sys
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np


def load_prompts(path: Path, n: int, seed: int) -> list:
    rows = [json.loads(l) for l in path.open() if l.strip()]
    rng = random.Random(seed)
    rng.shuffle(rows)
    return rows[:n]


def generate(model: str, rows: list, group_size: int, max_tokens: int, temperature: float, seed: int) -> list:
    from vllm import LLM, SamplingParams
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(model)
    prompts = [tok.apply_chat_template(json.loads(r['messages']), tokenize=False, add_generation_prompt=True)
               for r in rows]
    llm = LLM(model=model, tensor_parallel_size=1, gpu_memory_utilization=0.85, max_model_len=4096,
              seed=seed, dtype='bfloat16')
    params = SamplingParams(n=group_size, temperature=temperature, top_p=1.0, max_tokens=max_tokens, seed=seed)
    t0 = time.time()
    outputs = llm.generate(prompts, params)
    gen_s = time.time() - t0
    samples = []
    for row, out in zip(rows, outputs):
        for m, o in enumerate(out.outputs):
            samples.append(dict(id=row['id'], member=m, text=o.text, tokens=len(o.token_ids),
                                finish_reason=o.finish_reason, ground_truth=row['ground_truth']))
    return samples, gen_s


def verify_one(sample: dict, workspace: str, tag: str) -> dict:
    request = dict(solution_str=sample['text'], ground_truth=sample['ground_truth'], workspace_root=workspace,
                   sample_id=f"{sample['id']}_{sample['member']}_{tag}", keep_artifacts=False)
    t0 = time.time()
    done = subprocess.run([sys.executable, '-m', 'applications.rtl.codev_verify_child'], input=json.dumps(request),
                          capture_output=True, text=True, check=False)
    t1 = time.time()
    if done.returncode:
        raise RuntimeError(done.stderr[-1000:])
    result = json.loads(done.stdout)
    return dict(id=sample['id'], member=sample['member'], tag=tag, reward=result['reward'], stage=result['stage'],
                valid=result['reward_valid'], exec_s=t1 - t0, cpu_s=result['cpu_core_seconds'],
                t_start=t0, t_end=t1)


def verify_many(samples: list, workers: int, workspace: str, tag: str) -> list:
    with ThreadPoolExecutor(max_workers=workers) as pool:
        return list(pool.map(lambda s: verify_one(s, workspace, tag), samples))


def select_pairs(results: list, classes: list, n_pairs: int, seed: int) -> list:
    """Half from the largest within-class spreads (tail), half uniformly (ordinary)."""
    rng = random.Random(seed)
    by_group = defaultdict(list)
    for r in results:
        if r['valid']:
            by_group[(r['id'], r['reward'], r['stage'])].append(r)
    pairs = []
    for cls in classes:
        candidates = []
        for (gid, reward, stage), members in by_group.items():
            if stage != cls or len(members) < 2:
                continue
            members = sorted(members, key=lambda r: r['exec_s'])
            candidates.append(dict(cls=cls, id=gid, low=members[0], high=members[-1],
                                   spread=members[-1]['exec_s'] - members[0]['exec_s']))
        if not candidates:
            continue
        candidates.sort(key=lambda c: -c['spread'])
        per_class = max(n_pairs // len(classes), 2)
        tail = candidates[:per_class // 2]
        rest = candidates[per_class // 2:]
        rng.shuffle(rest)
        pairs.extend([dict(c, kind='tail') for c in tail] + [dict(c, kind='ordinary') for c in rest[:per_class - len(tail)]])
    return pairs


def gate_a(results: list, repeat_records: list, classes: list, rel_floor: float = 0.10) -> dict:
    by_key = defaultdict(list)
    for r in repeat_records:
        by_key[(r['id'], r['member'])].append(r['exec_s'])
    per_candidate_sd = [statistics.pstdev(v) for v in by_key.values() if len(v) >= 2]
    sigma_rep = float(np.sqrt(np.mean(np.square(per_candidate_sd)))) if per_candidate_sd else float('nan')
    out = dict(sigma_rep_pooled_s=sigma_rep, sigma_rep_median_s=float(np.median(per_candidate_sd)) if per_candidate_sd else None,
               n_repeat_candidates=len(by_key), classes={})
    groups = defaultdict(list)
    for r in results:
        if r['valid']:
            groups[(r['id'], r['reward'], r['stage'])].append(r['exec_s'])
    n_groups_total = len({r['id'] for r in results})
    for cls in classes:
        spreads, means = [], []
        for (gid, reward, stage), costs in groups.items():
            if stage == cls and len(costs) >= 2:
                spreads.append(max(costs) - min(costs))
                means.append(float(np.mean(costs)))
        eligible = len(spreads)
        threshold = [max(3 * sigma_rep, rel_floor * m) for m in means]
        over = sum(1 for s, t in zip(spreads, threshold) if s > t)
        out['classes'][cls] = dict(
            eligible_groups=eligible, eligible_group_frac=eligible / max(n_groups_total, 1),
            frac_over_threshold=over / max(eligible, 1), n_over_threshold=over,
            spread_p50=float(np.median(spreads)) if spreads else None,
            spread_p90=float(np.percentile(spreads, 90)) if spreads else None,
            mean_cost=float(np.mean(means)) if means else None)
    return out


def sign_consistency(pairs: list, repeat_records: list) -> dict:
    by_key = defaultdict(list)
    for r in repeat_records:
        by_key[(r['id'], r['member'])].append(r['exec_s'])
    consistent = total = 0
    rows = []
    for p in pairs:
        lo = by_key.get((p['id'], p['low']['member']), [])
        hi = by_key.get((p['id'], p['high']['member']), [])
        if len(lo) < 2 or len(hi) < 2:
            continue
        total += 1
        ok = min(hi) > max(lo)
        consistent += ok
        rows.append(dict(cls=p['cls'], kind=p['kind'], id=p['id'], original_spread=p['spread'],
                         low_repeats=lo, high_repeats=hi, consistent=ok))
    return dict(pairs_evaluated=total, sign_consistent_frac=consistent / max(total, 1), rows=rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--data', required=True, type=Path)
    ap.add_argument('--out', required=True, type=Path)
    ap.add_argument('--n-prompts', type=int, default=128)
    ap.add_argument('--group-size', type=int, default=4)
    ap.add_argument('--max-tokens', type=int, default=2048)
    ap.add_argument('--temperature', type=float, default=1.0)
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--pairs', type=int, default=32)
    ap.add_argument('--repeats', type=int, default=3)
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--classes', default='pass,eqy_counterexample')
    ap.add_argument('--workspace', default='/tmp/rtl_probe_verify')
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    classes = args.classes.split(',')

    rows = load_prompts(args.data, args.n_prompts, args.seed)
    samples, gen_s = generate(args.model, rows, args.group_size, args.max_tokens, args.temperature, args.seed)
    (args.out / 'generations.jsonl').write_text(''.join(json.dumps(s) + '\n' for s in samples))

    t0 = time.time()
    results = verify_many(samples, args.workers, args.workspace, 'base')
    verify_s = time.time() - t0
    (args.out / 'verification.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in results))

    pairs = select_pairs(results, classes, args.pairs, args.seed)
    candidates = []
    for p in pairs:
        for side in ('low', 'high'):
            r = p[side]
            s = next(s for s in samples if s['id'] == r['id'] and s['member'] == r['member'])
            candidates.append(s)
    rng = random.Random(args.seed + 1)
    repeat_records = []
    t0 = time.time()
    for rep in range(args.repeats):
        order = list(candidates)
        rng.shuffle(order)
        repeat_records.extend(verify_many(order, args.workers, args.workspace, f'rep{rep}'))
    repeat_s = time.time() - t0
    (args.out / 'repeats.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in repeat_records))

    stage_counts = defaultdict(int)
    for r in results:
        stage_counts[r['stage']] += 1
    tokens = [s['tokens'] for s in samples]
    summary = dict(
        model=args.model, n_prompts=len(rows), group_size=args.group_size, n_samples=len(samples),
        temperature=args.temperature, max_tokens=args.max_tokens, workers=args.workers, seed=args.seed,
        generation_s=gen_s, verification_s=verify_s, repeat_s=repeat_s,
        tokens_mean=float(np.mean(tokens)), tokens_p50=float(np.median(tokens)),
        tokens_p90=float(np.percentile(tokens, 90)), tokens_max=int(max(tokens)),
        truncation_frac=sum(s['finish_reason'] == 'length' for s in samples) / len(samples),
        stage_counts=dict(stage_counts), pass_rate=stage_counts['pass'] / len(samples),
        exec_s_by_stage={st: dict(n=len(v), p50=float(np.median(v)), mean=float(np.mean(v)), p90=float(np.percentile(v, 90)))
                         for st, v in defaultdict(list, {k: [r['exec_s'] for r in results if r['stage'] == k]
                                                         for k in stage_counts}).items()},
        gate_a=gate_a(results, repeat_records, classes),
        sign=sign_consistency(pairs, repeat_records),
        pairs=[dict(cls=p['cls'], kind=p['kind'], id=p['id'], spread=p['spread']) for p in pairs],
    )
    (args.out / 'probe_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k not in ('pairs',)}, indent=2))


if __name__ == '__main__':
    main()
