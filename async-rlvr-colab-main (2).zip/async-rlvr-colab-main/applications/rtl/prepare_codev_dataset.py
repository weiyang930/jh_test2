"""Adapt pinned CodeV parquet rows without leaking golden code into the prompt."""
import argparse
import hashlib
import io
import json
import pickle
from pathlib import Path

import pyarrow.parquet as pq


class PrimitiveUnpickler(pickle.Unpickler):
    """Only permit pickle's primitive data opcodes, never imported constructors."""

    def find_class(self, module: str, name: str) -> object:
        raise pickle.UnpicklingError(f'Unexpected constructor {module}.{name}')


SALV_SYSTEM_PROMPT = 'You are a helpful assistant.'
SALV_USER_SUFFIX = '\n\nGive me the complete Verilog code in a verilog code block, without additional explanation.'


def build_messages(source_prompt: list, protocol: str) -> list:
    """Return chat messages for the requested output protocol.

    ``codev_cot`` keeps the pinned CodeV messages verbatim (system forces <think>/<answer>).
    ``salv_direct`` replaces the CoT system message with the SALV model-card style and asks
    for a fenced Verilog answer; the full user specification is preserved unchanged.
    ``plain`` keeps only the user specification (no system prompt), for instruction-tuned models such as EARL-SFT.
    """
    messages = [{'role': m['role'], 'content': m['content']} for m in source_prompt]
    if protocol == 'codev_cot':
        return messages
    if protocol not in ('salv_direct', 'plain'):
        raise ValueError(f'Unknown prompt protocol {protocol}')
    users = [m for m in messages if m['role'] == 'user']
    if len(users) != 1:
        raise ValueError(f'Expected exactly one user message, found {len(users)}')
    if protocol == 'plain':   # user specification only, no system prompt: OriGen / EARL-SFT style instruction models
        return [{'role': 'user', 'content': users[0]['content']}]
    return [{'role': 'system', 'content': SALV_SYSTEM_PROMPT},
            {'role': 'user', 'content': users[0]['content'].rstrip() + SALV_USER_SUFFIX}]


def write_sim_meta(src: Path, dst: Path) -> dict:
    """Sidecar for the simulation fallback: {sha256(golden code): CodeV-R1 port info as JSON lists}."""
    meta = {}
    for row in pq.read_table(src).to_pylist():
        answer = PrimitiveUnpickler(io.BytesIO(row['reward_model']['ground_truth'])).load()['answer']
        key = hashlib.sha256(answer['code'].encode('utf-8')).hexdigest()
        meta[key] = {name: sorted([list(item) for item in answer.get(name, ())], key=repr)
                     for name in ('input_port_width', 'output_port_width', 'clock_port_polarity',
                                  'reset_port_polarity_sync')}
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(json.dumps(meta, sort_keys=True))
    return dict(entries=len(meta), target=str(dst), target_sha256=hashlib.sha256(dst.read_bytes()).hexdigest())


def convert(src: Path, dst: Path, protocol: str = 'codev_cot') -> dict:
    """Keep every source row and its exact chat messages; extract answer.code."""
    rows = pq.read_table(src).to_pylist()
    ids = set()
    dst.parent.mkdir(parents=True, exist_ok=True)
    with dst.open('w') as handle:
        for row in rows:
            ground = PrimitiveUnpickler(io.BytesIO(row['reward_model']['ground_truth'])).load()
            code = ground['answer']['code']
            if not isinstance(code, str) or not code.strip():
                raise ValueError('Missing golden Verilog')
            identifier = str(row['problem_id'])
            if identifier in ids:
                raise ValueError(f'Duplicate problem_id {identifier}')
            ids.add(identifier)
            prompt = build_messages(row['prompt'], protocol)
            record = dict(id=identifier, data_source='codev', messages=json.dumps(prompt, ensure_ascii=False),
                          ground_truth=code, question=prompt[-1]['content'], tag='rtl', difficulty='')
            handle.write(json.dumps(record, ensure_ascii=False) + '\n')
    return dict(rows=len(rows), protocol=protocol, source=str(src), source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),
                target=str(dst), target_sha256=hashlib.sha256(dst.read_bytes()).hexdigest())


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--src', type=Path, required=True)
    parser.add_argument('--dst', type=Path, required=True)
    parser.add_argument('--protocol', choices=['codev_cot', 'salv_direct', 'plain'], default='codev_cot')
    parser.add_argument('--sim-meta-out', type=Path, help='also write the simulation-fallback port-info sidecar')
    args = parser.parse_args()
    if args.sim_meta_out:
        print(json.dumps(write_sim_meta(args.src, args.sim_meta_out)))
    result = convert(args.src, args.dst, args.protocol)
    args.dst.with_suffix('.manifest.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
