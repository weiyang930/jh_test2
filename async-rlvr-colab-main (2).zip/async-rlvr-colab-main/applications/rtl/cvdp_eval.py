"""CVDP non-agentic evaluation without Docker (host mode).

Reproduces NVlabs/cvdp_benchmark's non-agentic flow for code-generation categories: the same system prompt (folder
context + category guidance), the same user prompt (input context files + "Provide me one answer for this request"),
the same response parsing (first fenced block, else raw text; JSON {"code": [...]} for multi-file problems), and the
same judgement (pytest on the problem's cocotb harness, pass iff return code 0 within the Docker timeout). The only
difference is that the harness runs on the host with the container paths /code and /src rewritten to the issue dir.
Samples n responses per problem and reports unbiased pass@k.
"""
from __future__ import annotations

import argparse
import collections
import json
import math
import os
import re
import shutil
import signal
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

FOLDERS = """You are a helpful assistance.
Consider that you have a folder structure like the following:\n
    - rtl/*   : Contains files which are RTL code.
    - verif/* : Contains files which are used to verify the correctness of the RTL code.
    - docs/*  : Contains files used to document the project, like Block Guides, RTL Plans and Verification Plans.

When generating files, return the file name in the correct place at the folder structure.
"""
CATEGORY_GUIDANCE = {
    2: "You are solving an 'RTL Code Completion' problem. To solve this problem correctly, you should only respond with the RTL code generated according to the requirements.",
    3: "You are solving a 'Specification to RTL Translation' problem. To solve this problem correctly, you should only respond with the RTL code translated from the specification.",
    4: "You are solving an 'RTL Code Modification' problem. To solve this problem correctly, you should only respond with the modified RTL code according to the requirements.",
}
SCHEMA = ['{ "code": [{ "<name>" : "<code>"}] }', '{ "response": "<response>" }']
VOLUMES = ("docs", "rundir", "rtl", "verif", "src")


def build_prompts(row: dict) -> tuple[str, str, list[str]]:
    """System and user prompt exactly as CopilotProcessor.create_context + ModelHelpers.create_system_prompt."""
    cat = int(row["categories"][0][3:])
    files = list(row["output"]["context"].keys())
    prompt = ""
    for file, cxt in row["input"]["context"].items():
        prompt += f"\nConsider the following content for the file {file}:\n```\n{cxt}\n```"
    prompt += f"\nProvide me one answer for this request: {row['input']['prompt']}\n"
    if len(files) == 1:
        prompt += f"Please provide your response as plain text without any JSON formatting. Your response will be saved directly to: {files[0]}.\n"
    elif len(files) > 1:
        prompt += f"Name the files as: {files}.\n"
    else:
        prompt += "Provide your response below.\n"
    system = FOLDERS + f"\n{CATEGORY_GUIDANCE[cat]}\n"
    if len(files) != 1:
        system += "\nProvide the response in one of the following JSON schemas: \n" + "\nor\n".join(SCHEMA)
        system += ("\nThe response should be in JSON format, including double-quotes around keys and values, and proper "
                   "escaping of quotes within values, and escaping of newlines.")
    return system, prompt, files


def extract_code_blocks(text: str) -> list[str]:
    pattern = r"```(?:(\w+)\n)?(.*?)```"
    out, pos = [], 0
    while True:
        m = re.search(pattern, text[pos:], re.DOTALL)
        if not m:
            return out
        out.append(m.group(2))
        pos += m.end()


def parse_response(res: str, files: list[str]) -> dict[str, str] | None:
    """Map output file -> content, following ModelHelpers.parse_model_response."""
    if len(files) == 1:
        blocks = extract_code_blocks(res)
        return {files[0]: blocks[0] if blocks else res.strip()}
    try:
        text = re.sub(r"[\x00-\x1F\x7F]", "", res.strip())
        start, end = text.find("{"), text[::-1].find("}")
        data = json.loads(text[start:-end if end else None])
        out = {}
        for item in data.get("code", []):
            for name, code in item.items():
                if not isinstance(code, str):  # non-string content: the CVDP harness cannot parse it either -> sample fails
                    return None
                blocks = extract_code_blocks(code)
                out[name] = blocks[0] if blocks else code
        return out or None
    except Exception:  # noqa: BLE001
        return None


def materialize(issue: Path, row: dict, outputs: dict[str, str]) -> None:
    """Issue dir = input context files + model outputs + harness files, like Repository.prepare()."""
    if issue.exists():
        shutil.rmtree(issue)
    for vol in VOLUMES:
        (issue / vol).mkdir(parents=True, exist_ok=True)
    for rel, content in list(row["input"]["context"].items()) + list(outputs.items()) + list(row["harness"]["files"].items()):
        p = issue / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")


def harness_env(issue: Path, oss_bin: str, py: str = "") -> dict[str, str]:
    env = dict(os.environ)
    venv_bin = str(Path(py).parent) + ":" if py else ""   # venv first: oss-cad-suite ships its own python3
    env["PATH"] = f"{venv_bin}{oss_bin}:{env['PATH']}"
    env_file = issue / "src" / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            if "=" not in line or line.strip().startswith("#"):
                continue
            k, v = line.split("=", 1)
            v = v.strip().replace("/code/", f"{issue}/").replace("/src", f"{issue}/src")
            env[k.strip()] = v
    env["PYTHONPATH"] = f"{issue}/src"
    return env


def run_harness(issue: Path, py: str, oss_bin: str, timeout_s: float) -> tuple[int, float, str]:
    cmd = [py, "-m", "pytest", "-s", "--log-cli-level=INFO", "-o", f"cache_dir={issue}/rundir/.cache",
           f"{issue}/src/test_runner.py", "-v"]
    t0 = time.time()
    proc = subprocess.Popen(cmd, cwd=issue / "rundir", env=harness_env(issue, oss_bin, py), stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, start_new_session=True)
    try:
        out, _ = proc.communicate(timeout=timeout_s)
        rc = proc.returncode
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        out, _ = proc.communicate()
        rc = -9
    (issue / "pytest.log").write_text(out or "", encoding="utf-8")
    return rc, time.time() - t0, (out or "")[-600:]


def pass_at_k(n: int, c: int, k: int) -> float:
    if n - c < k:
        return 1.0
    return 1.0 - math.comb(n - c, k) / math.comb(n, k)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--data", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--categories", default="cid003")
    ap.add_argument("--n", type=int, default=10)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--temperature", type=float, default=1.0)
    ap.add_argument("--top-p", type=float, default=1.0)
    ap.add_argument("--max-tokens", type=int, default=4096)
    ap.add_argument("--max-model-len", type=int, default=16384)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--gpu", default="0")
    ap.add_argument("--dtype", default="bfloat16")
    ap.add_argument("--tokenizer", default=None, help="tokenizer path if the checkpoint dir has none")
    ap.add_argument("--gpu-mem", type=float, default=0.85)
    ap.add_argument("--workers", type=int, default=32)
    ap.add_argument("--timeout", type=float, default=600.0, help="DOCKER_TIMEOUT default of the official harness")
    ap.add_argument("--python", default="/root/cvdp/venv/bin/python", help="interpreter with cocotb 2.0.1 + pytest")
    ap.add_argument("--oss-bin", default="/opt/oss-cad-suite/bin")
    ap.add_argument("--regen", action="store_true")
    ap.add_argument("--keep-issues", action="store_true")
    ap.add_argument("--issues-root", type=Path, default=Path("/root/cvdp/issues"),
                    help="local-disk scratch for harness runs (network volumes break pytest cache/chmod and are slow)")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    cats = set(args.categories.split(","))
    rows = [json.loads(l) for l in open(args.data, encoding="utf-8")]
    rows = [r for r in rows if r["categories"][0] in cats]
    if args.limit:
        rows = rows[: args.limit]
    print(f"{len(rows)} problems in {sorted(cats)}", flush=True)

    gen_path = args.out / "generations.jsonl"
    if gen_path.exists() and not args.regen:
        gens = [json.loads(l) for l in open(gen_path, encoding="utf-8")]
    else:
        os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu
        from vllm import LLM, SamplingParams
        llm = LLM(model=args.model, tokenizer=args.tokenizer or args.model, dtype=args.dtype, gpu_memory_utilization=args.gpu_mem,
                  max_model_len=args.max_model_len, seed=args.seed)
        sp = SamplingParams(n=args.n, temperature=args.temperature, top_p=args.top_p, max_tokens=args.max_tokens, seed=args.seed)
        convs = []
        for r in rows:
            system, user, _ = build_prompts(r)
            convs.append([{"role": "system", "content": system}, {"role": "user", "content": user}])
        t0 = time.time()
        outs = llm.chat(convs, sp)
        gens = []
        for r, o in zip(rows, outs):
            for j, c in enumerate(o.outputs):
                gens.append(dict(id=r["id"], j=j, response=c.text, tokens=len(c.token_ids), finish=c.finish_reason))
        with open(gen_path, "w", encoding="utf-8") as fh:
            for g in gens:
                fh.write(json.dumps(g, ensure_ascii=False) + "\n")
        json.dump(dict(generation_s=time.time() - t0, problems=len(rows), n=args.n, model=args.model),
                  open(args.out / "generation_meta.json", "w"))
        del llm

    by_id = {r["id"]: r for r in rows}
    import hashlib
    # unique per --out: concurrent evaluations (one checkpoint per GPU) must not share issue dirs
    issues_root = args.issues_root / f"{args.out.name}_{hashlib.md5(str(args.out.resolve()).encode()).hexdigest()[:8]}"
    issues_root.mkdir(parents=True, exist_ok=True)

    def judge(g: dict) -> dict:
        row = by_id[g["id"]]
        _, _, files = build_prompts(row)
        outputs = parse_response(g["response"], files)
        rec = dict(id=g["id"], j=g["j"], tokens=g["tokens"], finish=g["finish"])
        if not outputs:
            return {**rec, "status": "parse_fail", "rc": None, "exec_s": 0.0}
        issue = issues_root / f"{g['id']}_{g['j']}"
        materialize(issue, row, outputs)
        rc, dt, tail = run_harness(issue, args.python, args.oss_bin, args.timeout)
        status = "pass" if rc == 0 else ("timeout" if rc == -9 else "fail")
        if not args.keep_issues:
            shutil.rmtree(issue, ignore_errors=True)
        return {**rec, "status": status, "rc": rc, "exec_s": dt, "tail": tail if status != "pass" else ""}

    t0 = time.time()
    results = []
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = [ex.submit(judge, g) for g in gens]
        for i, f in enumerate(as_completed(futs), 1):
            results.append(f.result())
            if i % 50 == 0:
                print(f"judged {i}/{len(gens)} in {time.time() - t0:.0f}s", flush=True)
    results.sort(key=lambda r: (r["id"], r["j"]))
    with open(args.out / "attempts.jsonl", "w", encoding="utf-8") as fh:
        for r in results:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")

    per = collections.defaultdict(lambda: [0, 0])
    for r in results:
        per[r["id"]][0] += 1
        per[r["id"]][1] += r["status"] == "pass"
    ks = [k for k in (1, 5, 10) if k <= args.n]
    summary = dict(model=args.model, data=str(args.data), categories=sorted(cats), problems=len(per), n=args.n,
                   temperature=args.temperature, status_counts=dict(collections.Counter(r["status"] for r in results)),
                   **{f"pass@{k}": sum(pass_at_k(n, c, k) for n, c in per.values()) / len(per) for k in ks},
                   mean_response_tokens=sum(r["tokens"] for r in results) / len(results),
                   finish_length_share=sum(r["finish"] == "length" for r in results) / len(results),
                   mean_exec_s=sum(r["exec_s"] for r in results) / len(results), judge_wall_s=time.time() - t0,
                   per_problem={k: dict(n=v[0], passes=v[1]) for k, v in per.items()})
    json.dump(summary, open(args.out / "summary.json", "w"), indent=1)
    print(json.dumps({k: v for k, v in summary.items() if k != "per_problem"}, indent=1))


if __name__ == "__main__":
    main()
