"""Regression for dense-model partial rollouts crossing a policy update."""
import numpy as np
import torch
import pytest

from roll.distributed.scheduler.protocol import DataProto
from roll.distributed.scheduler.user_defined_rollout_loop import postprocess_paused_data, postprocess_output_data


def request():
    return DataProto.from_dict(
        tensors={'input_ids': torch.tensor([[0, 0, 10, 11]]),
                 'attention_mask': torch.tensor([[0, 0, 1, 1]]),
                 'position_ids': torch.tensor([[0, 0, 0, 1]])},
        non_tensors={'id': np.array(['one'], dtype=object)},
        meta_info={'generation_config': {'num_return_sequences': 1}})


def test_dense_two_pauses_preserve_tokens_logprobs_and_prompt_mask():
    req = request()
    for tokens, probs in [([12, 13], [-.1, -.2]), ([14], [-.3])]:
        result = DataProto(meta_info={'output_token_ids': [tokens], 'output_logprobs': [probs]})
        req = postprocess_paused_data(req, result, sequence_length=12, prompt_length=4)
        assert 'routed_experts' not in req.batch
        assert isinstance(req.batch['input_ids'], torch.Tensor)
    assert req.batch['input_ids'].tolist() == [[0, 0, 10, 11, 12, 13, 14]]
    assert req.batch['attention_mask'].tolist() == [[0, 0, 1, 1, 1, 1, 1]]
    assert req.meta_info['pre_output_logprobs'] == [[-.1, -.2, -.3]]
    final = DataProto(meta_info={'output_token_ids': [[15, 2]], 'output_logprobs': [[-.4, -.5]],
                                'eos_token_id': 2, 'pad_token_id': 0})
    output = postprocess_output_data(req, final, sequence_length=12)
    assert output.batch['responses'][0, :5].tolist() == [12, 13, 14, 15, 2]
    response_positions = output.batch['response_mask'][0, 1:].bool()
    torch.testing.assert_close(output.batch['infer_logprobs'][0, response_positions],
                               torch.tensor([-.1, -.2, -.3, -.4, -.5]))
    assert output.batch['input_ids'][0, :7].tolist() == [10, 11, 12, 13, 14, 15, 2]
    assert output.non_tensor_batch['id'].tolist() == ['one']


@pytest.mark.parametrize('payload', [
    {'finish_reasons': ['abort']},
    {'output_token_ids': None, 'output_logprobs': None},
    {'output_token_ids': [], 'output_logprobs': []},
    {'output_token_ids': [[]], 'output_logprobs': None},
])
def test_aborted_before_first_token_keeps_original_request(payload):
    req = request()
    assert postprocess_paused_data(req, DataProto(meta_info=payload),
                                   sequence_length=12, prompt_length=4) is req


def test_nonempty_partial_without_probabilities_is_not_silently_repaired():
    with pytest.raises(ValueError, match='original inference logprobs'):
        postprocess_paused_data(request(), DataProto(meta_info={'output_token_ids': [[12]],
                                                              'output_logprobs': None}), 12, 4)
