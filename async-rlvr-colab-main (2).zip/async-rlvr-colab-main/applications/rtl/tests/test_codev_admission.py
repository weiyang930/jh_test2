"""Check group labels and repeat sampling required by the 3,033-row CodeV set."""
from types import SimpleNamespace

from applications.rtl.codev_admission import CodeVAdmissionPolicy


class Rows(list):
    def __getitem__(self, key):
        if isinstance(key, str):
            return [row[key] for row in self]
        return super().__getitem__(key)


def make_policy(tmp_path, size=16, **kwargs):
    data = Rows([dict(id=str(i), messages=[dict(role='user', content=f'counter {i}')],
                      ground_truth=f'module m{i}(input a, output b); assign b=a; endmodule') for i in range(size)])
    return CodeVAdmissionPolicy(SimpleNamespace(dataset=data), SimpleNamespace(seed=42, output_dir=str(tmp_path)),
                                batch=4, **kwargs)


def test_prompts_reusable_across_updates_and_zero_variance_observed(tmp_path) -> None:
    policy = make_policy(tmp_path)
    seen = []
    for step in range(20):
        policy.on_step(step)
        for _ in range(4):
            row = policy.next_item()
            seen.append(row['id'])
            policy.observe_group(row['id'], len(seen), [0.9] * 16, 2.5, True)
    assert len(seen) == 80 and len(set(seen)) <= 16
    assert len(policy.observations) == 80
    assert all(record['useful'] == 0 and record['cpu_s'] == 2.5 for record in policy.observations)


def test_inflight_prompt_not_reselected_and_invalid_reference_quarantined(tmp_path) -> None:
    policy = make_policy(tmp_path)
    policy.on_step(0)
    first = policy.next_item()
    policy.on_step(1)
    second = policy.next_item()
    assert first['id'] != second['id']
    policy.observe_group(first['id'], 1, [0.9] * 16, 5.0, False)
    assert policy.indices[first['id']] in policy.invalid
    assert not policy.observations


def test_predictor_gets_both_group_classes_and_raw_mean_cpu(tmp_path) -> None:
    policy = make_policy(tmp_path, size=100, mode='value_cost', warmup_min_groups=64)
    policy.on_step(0)
    for index in range(64):
        row = policy.next_item()
        rewards = [0.9] * 16 if index % 2 else [0.9] * 15 + [1.0]
        policy.observe_group(row['id'], index, rewards, 2.0 + index % 2, True)
    policy.on_step(1)
    assert policy.version == 1
    assert policy.cost_reference == 2.5
    while policy.queue:
        row = policy.next_item()
        policy.observe_group(row['id'], 100, [1.0] * 16, 2.0, True)
    policy.next_item()
    assert 'exploit' in policy.slots.values() and 'explore' in policy.slots.values()
