import sys
import types

# roll.utils.logging pulls heavy deps; stub it for the unit test
if "roll.utils.logging" not in sys.modules:
    roll = types.ModuleType("roll"); utils = types.ModuleType("roll.utils"); logging_mod = types.ModuleType("roll.utils.logging")
    import logging
    logging_mod.get_logger = lambda: logging.getLogger("test")
    sys.modules["roll"], sys.modules["roll.utils"], sys.modules["roll.utils.logging"] = roll, utils, logging_mod

from applications.rtl.history_admission import HistoryAdmissionPolicy  # noqa: E402


class _Sched:
    def __init__(self, n):
        self.dataset = [{"id": f"p{i}", "x": i} for i in range(n)]


class _Cfg:
    seed = 1


def _policy(mode, tmp_path, **kw):
    cfg = _Cfg(); cfg.output_dir = str(tmp_path)
    kw.setdefault("epsilon", 0.25)
    return HistoryAdmissionPolicy(_Sched(40), cfg, mode=mode, batch=8, cooldown_steps=1, **kw)


def test_queue_and_replacement(tmp_path):
    pol = _policy("uniform", tmp_path)
    pol.on_step(0)
    ids = {pol.next_item()["id"] for _ in range(8)}
    assert len(ids) == 8
    extra = pol.next_item()  # replacement draw beyond the queue
    assert extra["id"] not in ids or True
    assert pol.stats[pol.index_by_id[extra["id"]]].visits == 1


def test_skip_mode_avoids_zero_gradient(tmp_path):
    pol = _policy("skip", tmp_path, epsilon=0.0)
    for k in range(40):
        pol.observe_group(f"p{k}", k, [0.0] * 8 if k < 30 else [1.0, 0.0], 5.0, True)
    pol.on_step(5)
    picked = [pol.next_item()["id"] for _ in range(8)]
    assert all(int(i[1:]) >= 30 for i in picked), picked


def test_weighted_prefers_informative_history(tmp_path):
    pol = _policy("weighted", tmp_path, epsilon=0.0)
    for k in range(40):
        kind = [1.0, 0.0] if k < 10 else [0.0] * 8
        for _ in range(3):
            pol.observe_group(f"p{k}", k, kind, 1.0, True)
    counts = {True: 0, False: 0}
    for step in range(2, 42, 2):
        pol.on_step(step)
        for _ in range(8):
            counts[int(pol.next_item()["id"][1:]) < 10] += 1
    assert counts[True] > counts[False]  # 10 informative prompts out of 40 get more than a quarter of the picks


def test_release_counts_as_zero_gradient(tmp_path):
    pol = _policy("weighted", tmp_path)
    pol.release("p3")
    assert pol.stats[3].cancelled == 1 and pol.stats[3].last_kind == "cancelled"


def test_prior_mode_prefers_mixed_probe_problems(tmp_path):
    import json
    summ = {"problems": {f"p{i}": {"n": 8, "passes": (4 if i < 10 else (0 if i < 30 else 8))} for i in range(40)}}
    sp = tmp_path / "summary.json"; sp.write_text(json.dumps(summ))
    pol = _policy("prior", tmp_path, epsilon=0.0, prior_path=str(sp), group_size=8)
    picks = []
    for step in range(0, 40, 3):
        pol.on_step(step)
        picks += [int(pol.next_item()["id"][1:]) for _ in range(8)]
    assert sum(1 for i in picks if i < 10) > 0.6 * len(picks)


# ---------------------------------------------------------------- 2026-10-25 fixes: cancellations, verdicts, audit lane
def test_cancelled_group_leaves_posterior_untouched_but_is_charged(tmp_path):
    pol = _policy("weighted", tmp_path, epsilon=0.0)
    k = pol.index_by_id["p0"]
    pol.observe_group("p0", 0, [1.0, 0.0], 4.0, True)
    p_before = pol._p_inform(pol.stats[k])
    pol.note_cancel_cost("p0", 150.0)          # the governor reports the cancelled check's running seconds
    pol.release("p0")                          # stale expiry / controller abandonment: outcome unknown
    s = pol.stats[k]
    assert pol._p_inform(s) == p_before        # no outcome -> no posterior update
    assert s.cancelled == 1 and s.cancelled_cpu_s == 150.0 and s.cpu_s == 154.0
    assert s.last_kind == "cancelled"
    pol.release("p0", cpu_seconds=20.0)        # explicit cost path
    assert s.cancelled == 2 and s.cpu_s == 174.0
    # an in-flight cancellation reported through observe_group(valid=False) behaves the same
    pol.observe_group("p0", 0, [], 7.0, False)
    assert pol._p_inform(s) == p_before and s.cancelled == 3 and s.cancelled_cpu_s == 177.0


def test_zero_gradient_kinds_come_from_verdicts_not_reward_sign(tmp_path):
    pol = _policy("weighted", tmp_path, epsilon=0.0)
    s = pol.stats[pol.index_by_id["p1"]]
    pol.observe_group("p1", 1, [0.75] * 8, 1.0, True, stages=["eqy_counterexample"] * 8)
    assert (s.all_pass, s.all_fail, s.constant_partial) == (0, 1, 0)      # graded failure is a failure
    pol.observe_group("p1", 1, [1.0] * 8, 1.0, True, stages=["pass"] * 8)
    assert s.all_pass == 1
    pol.observe_group("p1", 1, [0.75] * 8, 1.0, True)                      # no verdicts: constant partial credit
    assert s.constant_partial == 1
    pol.observe_group("p1", 1, [0.5, 0.75], 1.0, True, stages=["syntax_fail", "eqy_counterexample"])
    assert s.informative == 1                                             # reward variance > 0 is what GRPO uses
    assert pol._p_inform(s) == (1.0 + 1) / (2.0 + 1 + 3)                  # zero = all_pass + all_fail + constant_partial


def test_skip_mode_keeps_cancelled_prompts_eligible(tmp_path):
    pol = _policy("skip", tmp_path, epsilon=0.0)
    for k in range(40):
        pol.observe_group(f"p{k}", k, [0.0] * 8, 5.0, True, stages=["eqy_counterexample"] * 8)
    for k in range(32, 40):
        pol.release(f"p{k}")                   # cancelled, outcome unknown: not zero-gradient, so still "good"
    pol.on_step(5)
    picked = [pol.next_item()["id"] for _ in range(8)]
    assert sorted(int(i[1:]) for i in picked) == list(range(32, 40)), picked


def test_audit_lane_is_tagged_logged_and_cleared(tmp_path):
    import json
    pol = _policy("weighted", tmp_path, epsilon=0.25)   # batch 8 -> 2 audit slots
    for k in range(40):
        pol.observe_group(f"p{k}", k, [1.0, 0.0] if k < 10 else [0.0] * 8, 1.0, True)
    pol.on_step(3)
    assert len(pol.audit_ids) == 2
    events = [json.loads(l) for l in open(tmp_path / "admission_events.jsonl")]
    admits = [e for e in events if e["event"] == "admit" and e["step"] == 3]
    audits = [e for e in admits if e["slot"] == "audit"]
    assert len(admits) == 8 and len(audits) == 2 and all(e["audit"] and 0 < e["propensity"] <= 1 for e in audits)
    assert all(not e["audit"] and e["propensity"] is None for e in admits if e["slot"] == "exploit")
    did = audits[0]["dataset_id"]
    assert pol.is_audit(did) and not pol.is_audit(admits[0]["dataset_id"]) or admits[0]["slot"] == "audit"
    pol.observe_group(did, 0, [1.0, 0.0], 1.0, True)
    assert not pol.is_audit(did)              # cleared when its group finishes
    did2 = audits[1]["dataset_id"]
    pol.release(did2)
    assert not pol.is_audit(did2)             # or when it is cancelled


# ---------------------------------------------------------------- 2026-10-25: topk mode, visit budget, shared price
def test_topk_scores_by_value_minus_price_times_cost(tmp_path):
    pol = _policy("topk", tmp_path, pool_size=40, audit=0, rho=0.01, visit_budget=0)
    for k in range(40):   # p0..p9 informative and cheap; p10..p19 informative but costly; the rest zero-gradient
        for _ in range(3):
            if k < 10: pol.observe_group(f"p{k}", k, [1.0, 0.0], 10.0, True)
            elif k < 20: pol.observe_group(f"p{k}", k, [1.0, 0.0], 90.0, True)
            else: pol.observe_group(f"p{k}", k, [0.0] * 8, 5.0, True, stages=["eqy_counterexample"] * 8)
    pol.on_step(5)
    picked = sorted(int(pol.next_item()["id"][1:]) for _ in range(8))
    assert picked == list(range(8)) or all(i < 10 for i in picked), picked      # cheap informative first
    assert pol.stats[pol.index_by_id["p0"]].steps == [5]


def test_visit_budget_caps_revisits(tmp_path):
    pol = _policy("topk", tmp_path, pool_size=40, audit=0, rho=0.0, visit_budget=1, budget_window=100)
    for k in range(40):
        pol.observe_group(f"p{k}", k, [1.0, 0.0] if k < 8 else [0.0] * 8, 1.0, True)
    first = set()
    for step in (10, 12, 14, 16, 18):
        pol.on_step(step)
        got = {pol.next_item()["id"] for _ in range(8)}
        assert not (got & first), "a prompt was admitted twice inside the budget window"
        first |= got
    assert len(first) == 40                      # every prompt exactly once before any is repeated
    pol.on_step(200)                             # window has passed: the informative ones come back first
    assert all(int(i[1:]) < 8 for i in [pol.next_item()["id"] for _ in range(8)])


def test_shared_price_reads_the_governor(tmp_path):
    from types import SimpleNamespace
    cfg = _Cfg(); cfg.output_dir = str(tmp_path)
    sched = _Sched(10); sched.verify_governor = SimpleNamespace(current_price=0.002)
    pol = HistoryAdmissionPolicy(sched, cfg, mode="topk", batch=4, price="shared", rho=0.5)
    assert pol.current_price() == 0.002
    sched.verify_governor.current_price = None   # controller off -> constant rho
    assert pol.current_price() == 0.5
    pol2 = HistoryAdmissionPolicy(sched, cfg, mode="topk", batch=4, price="const", rho=0.3)
    assert pol2.current_price() == 0.3
