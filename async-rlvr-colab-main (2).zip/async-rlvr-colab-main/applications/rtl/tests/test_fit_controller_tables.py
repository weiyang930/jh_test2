"""Censoring-aware table fit: with cancellations that depend only on age, the km estimate recovers the uncensored
table while the drop estimate is biased; the audit filters split groups by their flag."""
import random

from applications.rtl.fit_controller_tables import fit, GRID


def _synthetic(n_groups=3000, seed=0):
    rng = random.Random(seed); groups = {}
    for g in range(n_groups):
        jobs = []
        for _ in range(4):
            # two populations: fast (mostly fail quickly) and slow (pass with 40 % after 30-150 s)
            if rng.random() < 0.7:
                dur, ok = rng.uniform(0.5, 20.0), rng.random() < 0.15
            else:
                dur, ok = rng.uniform(30.0, 170.0), rng.random() < 0.40
            jobs.append({"start": 0.0, "dur": dur, "pass": ok, "censored": False, "audit": g % 10 == 0})
        groups[g] = jobs
    return groups


def _censor(groups, cancel_at, p_cancel, seed=1):
    """Same checks, with a share of those still running at cancel_at cancelled there (age-based, outcome-blind)."""
    rng = random.Random(seed); out = {}
    for g, jobs in groups.items():
        new = []
        for x in jobs:
            x = dict(x)
            if x["dur"] > cancel_at and rng.random() < p_cancel:
                x.update(dur=cancel_at + rng.uniform(0, 5), pass_true=x["pass"], **{"pass": False, "censored": True})
            new.append(x)
        out[g] = new
    return out


def test_km_recovers_truth_under_age_based_cancellation():
    base = _synthetic()
    truth, _, _ = fit(base, 180.0, 20, "drop", "all")
    cens = _censor(base, cancel_at=45.0, p_cancel=0.8)
    drop, _, _ = fit(cens, 180.0, 20, "drop", "all")
    km, _, _ = fit(cens, 180.0, 20, "km", "all")
    # the well-populated cells: still running at 20 / 30 s with a sibling already failed
    for t in (20, 30):
        assert abs(km[(t, "fail")] - truth[(t, "fail")]) < 0.04, (t, km[(t, "fail")], truth[(t, "fail")])
        assert abs(km[(t, "fail")] - truth[(t, "fail")]) < abs(drop[(t, "fail")] - truth[(t, "fail")]), t
    # drop sees only the 20 % of slow checks that survived to a verdict: its (30, fail) cell is built on far fewer checks


def test_km_matches_drop_without_censoring():
    g = _synthetic()
    a, Ra, _ = fit(g, 180.0, 20, "drop", "all"); b, Rb, _ = fit(g, 180.0, 20, "km", "all")
    for key in a:
        assert abs(a[key] - b[key]) < 0.03, (key, a[key], b[key])
    for t in (0, 30, 90):
        assert abs(Ra[t] - Rb[t]) < 0.15 * max(Ra[t], 1.0), (t, Ra[t], Rb[t])


def test_audit_filters_split_groups():
    g = _synthetic(n_groups=500)
    only, _, c_only = fit(g, 180.0, 5, "drop", "only"); excl, _, c_excl = fit(g, 180.0, 5, "drop", "exclude")
    assert c_only["0|none"] == 50 * 4 and c_excl["0|none"] == 450 * 4
    assert (0, "none") in only and (0, "none") in excl
