"""Targeted checks for the local blocking-cost credit (D_local) and class weights."""
import itertools
import random

import numpy as np
import pytest

from applications.rtl.blocking_cost import (
    Group, Job, Timeline, compute_batch_credit, within_class_weights,
)


def _job(pid, m, worker, release, start, service, ret_overhead=0.01, **kw):
    end = start + service
    return Job(key=(pid, m), worker=worker, release=release, start=start, end=end, ret=end + ret_overhead, **kw)


def _groups(jobs, commit_overhead=0.02):
    by_pid = {}
    for j in jobs:
        by_pid.setdefault(j.key[0], []).append(j)
    return [Group(pid, [j.key for j in sorted(js, key=lambda x: x.key)], max(j.ret for j in js) + commit_overhead)
            for pid, js in by_pid.items()]


def test_replay_reproduces_observed_timeline_with_gaps():
    jobs = [_job(1, 0, "w0", 0.0, 0.5, 1.0), _job(1, 1, "w0", 0.2, 1.9, 0.7), _job(2, 0, "w1", 0.0, 0.0, 3.0)]
    tl = Timeline.build(jobs)
    ends = tl.replay()
    for j in jobs:
        assert ends[j.key] == pytest.approx(j.end, abs=1e-9)
    assert tl.negative_slack_jobs == 0


def test_masked_batch_has_zero_credit():
    jobs = [_job(1, 0, "w0", 0.0, 0.0, 1.0), _job(1, 1, "w1", 0.0, 0.0, 2.0)]
    credit = compute_batch_credit(Timeline.build(jobs), _groups(jobs), t_request=50.0)
    assert credit.learner_wait_s == 0.0
    assert all(v == 0.0 for v in credit.d_local.values())
    assert credit.verification_attributable_s == 0.0


def test_critical_task_shortening_reduces_wait():
    jobs = [_job(1, 0, "w0", 0.0, 0.0, 1.0), _job(1, 1, "w1", 0.0, 0.0, 20.0)]
    credit = compute_batch_credit(Timeline.build(jobs), _groups(jobs), t_request=10.0, epsilon=0.1)
    assert credit.learner_wait_s == pytest.approx(10.03, abs=1e-6)
    assert credit.d_local[(1, 0)] == 0.0
    assert credit.d_local[(1, 1)] == pytest.approx(2.0, abs=1e-6)
    assert credit.effective_cost[(1, 1)] == pytest.approx(20.0, abs=1e-6)
    assert credit.on_critical[(1, 1)] and not credit.on_critical[(1, 0)]


def test_worker_predecessor_dependency_propagates():
    # job A (group 1) runs first on w0, then job B (group 2) is the last needed job.
    a = _job(1, 0, "w0", 0.0, 0.0, 10.0)
    b = _job(2, 0, "w0", 0.0, 10.0, 5.0)  # released at 0, starts when A ends
    others = [_job(1, 1, "w1", 0.0, 0.0, 1.0), _job(2, 1, "w1", 0.0, 1.0, 1.0)]
    jobs = [a, b] + others
    credit = compute_batch_credit(Timeline.build(jobs), _groups(jobs), t_request=0.0, epsilon=0.1)
    assert credit.d_local[b.key] == pytest.approx(0.5, abs=1e-6)
    assert credit.d_local[a.key] == pytest.approx(1.0, abs=1e-6)  # freeing w0 earlier propagates
    assert credit.d_local[(1, 1)] == 0.0


def test_tied_bottlenecks_are_not_additive():
    jobs = [_job(1, 0, "w0", 0.0, 0.0, 10.0), _job(2, 0, "w1", 0.0, 0.0, 10.0)]
    credit = compute_batch_credit(Timeline.build(jobs), _groups(jobs), t_request=0.0, epsilon=0.1)
    assert credit.d_local[(1, 0)] == 0.0 and credit.d_local[(2, 0)] == 0.0
    assert credit.learner_wait_s > 0


def test_generation_bound_wait_gives_zero_credit():
    # the last group's member is released late (generation), verification is short
    jobs = [_job(1, 0, "w0", 0.0, 0.0, 1.0), _job(1, 1, "w1", 30.0, 30.0, 0.5)]
    credit = compute_batch_credit(Timeline.build(jobs), _groups(jobs), t_request=5.0, epsilon=0.1)
    assert credit.learner_wait_s > 20
    assert credit.d_local[(1, 1)] == pytest.approx(0.05, abs=1e-9)  # only its own service matters
    assert credit.verification_attributable_s == pytest.approx(0.25, abs=1e-6)  # only the late member's own service


def _samples(costs, stage="pass", reward=1.0, group_id=7):
    return [dict(key=i, group_id=group_id, reward=reward, stage=stage, valid=True, effective_cost=c)
            for i, c in enumerate(costs)]


def test_class_weights_sum_to_class_size_and_are_order_invariant():
    costs = [0.1, 2.0, 0.5, 0.1]
    base = within_class_weights(_samples(costs), eta=1.0, cost_scale=1.0, classes=["pass"])
    assert sum(base.weight.values()) == pytest.approx(4.0)
    assert sum(base.advantage.values()) == pytest.approx(0.0, abs=1e-12)
    assert base.weight[1] < base.weight[0]
    for perm in itertools.permutations(range(4)):
        shuffled = [dict(_samples(costs)[p]) for p in perm]
        res = within_class_weights(shuffled, eta=1.0, cost_scale=1.0, classes=["pass"])
        for s in shuffled:
            assert res.weight[s["key"]] == pytest.approx(base.weight[s["key"]])


def test_invalid_and_disabled_classes_get_zero_advantage():
    samples = _samples([0.1, 5.0]) + _samples([0.1, 5.0], stage="eqy_timeout", reward=0.9, group_id=8)
    samples[0]["valid"] = False
    res = within_class_weights(samples, eta=1.0, cost_scale=1.0, classes=["pass", "eqy_fail"])
    assert res.n_classes == 0
    assert all(v == 0.0 for v in res.advantage.values())


def test_singleton_class_and_zero_costs_are_neutral():
    samples = _samples([0.3]) + _samples([0.0, 0.0, 0.0], group_id=9)
    res = within_class_weights(samples, eta=3.0, cost_scale=0.5, classes=["pass"])
    assert all(abs(v) < 1e-12 for v in res.advantage.values())


def test_random_timelines_keep_calibration_and_monotone_credit():
    rng = random.Random(0)
    for _ in range(50):
        jobs, t = [], 0.0
        for pid in range(6):
            for m in range(2):
                w = f"w{rng.randrange(2)}"
                release = rng.uniform(0, 5)
                jobs.append(Job(key=(pid, m), worker=w, release=release, start=0, end=0, ret=0))
        # sequential per worker with random slack
        chains = {}
        for j in jobs:
            chains.setdefault(j.worker, []).append(j)
        for chain in chains.values():
            rng.shuffle(chain)
            prev = 0.0
            for j in chain:
                j.start = max(j.release, prev) + rng.uniform(0, 0.2)
                j.end = j.start + rng.uniform(0.05, 3.0)
                j.ret = j.end + 0.01
                prev = j.end
        credit = compute_batch_credit(Timeline.build(jobs), _groups(jobs), t_request=rng.uniform(0, 8), epsilon=0.1)
        assert credit.calibration_max_abs_err_s < 1e-9
        for k, d in credit.d_local.items():
            assert 0.0 <= d <= 0.1 * credit.raw_cost[k] + 1e-9
            assert d <= credit.learner_wait_s + 1e-9
