"""Gate 3: estimator numerical equivalence, old (verl GRPO) vs new (ROLL grpo).

Old: verl compute_grpo_outcome_advantage — adv = (score - group_mean)/(group_std + 1e-6)
     (unbiased std), broadcast over response tokens; rejection_sample drops
     groups with all rewards == 1.0 (solve_all) or all == 0.0 (solve_none,
     unreachable with the RTL reward floor of 0.5).

New: ROLL reward_norm(norm_mean=group, norm_std=group) -> expand_to_token_level
     -> compute_reinforce_return(gamma=1)  => advantage per response token.
     ROLL-native rejection: difficulty_mask(low=0.0, high=0.9999) masks exactly
     the groups whose mean score == 1.0 (all-pass), matching solve_all.

Run: python applications/rtl/tests/test_estimator_equivalence.py
"""
import sys

import torch

sys.path.insert(0, "/workspace/async-rlvr")

from roll.utils.functionals import reward_norm, compute_reinforce_return  # noqa: E402

TOL = 1e-5


def verl_grpo_advantage(rewards: torch.Tensor, n: int, eps: float = 1e-6) -> torch.Tensor:
    """Reference formula from /workspace/archer-LLM verl core_algos.py:177."""
    out = rewards.clone().float()
    groups = rewards.view(-1, n)
    for g in range(groups.shape[0]):
        vals = groups[g]
        mean = torch.mean(vals)
        std = torch.std(vals)  # unbiased, matches torch.std in reference
        out[g * n : (g + 1) * n] = (vals - mean) / (std + eps)
    return out


def roll_grpo_advantage(rewards: torch.Tensor, n: int) -> torch.Tensor:
    normalized = reward_norm(
        rewards.clone().float(), n_sample=n, running_ctrl={}, norm_mean_type="group", norm_std_type="group"
    )
    # place at last token of a 3-token response, gamma=1 reinforce return
    T = 3
    token_level = torch.zeros(rewards.shape[0], T)
    token_level[:, -1] = normalized
    adv, ret = compute_reinforce_return(token_level, gamma=1.0, lambd=0.95)
    # every response token carries the normalized score under gamma=1
    assert torch.allclose(adv, normalized.unsqueeze(-1).expand_as(adv)), "reinforce broadcast mismatch"
    return normalized


def old_rejection_keep(group_rewards: torch.Tensor) -> bool:
    """verl dapo_ray_trainer rejection_sample: drop solve_none / solve_all."""
    return not ((group_rewards == 0).all() or (group_rewards == 1).all())


def new_difficulty_mask_keep(group_rewards: torch.Tensor, low=0.0, high=0.9999) -> bool:
    """ROLL difficulty_mask semantics (strict inequalities on group mean score)."""
    m = group_rewards.float().mean()
    return bool((m > low) and (m < high))


def main() -> bool:
    ok = True
    n = 4
    groups = [
        [0.5, 0.9, 1.0, 1.0],     # required case
        [0.5, 0.75, 0.9, 1.0],    # full reward-mapping spread
        [0.5, 0.5, 0.5, 0.5],     # uniform non-pass: kept, zero advantage
        [1.0, 1.0, 1.0, 1.0],     # all-pass: dropped by rejection sampling
        [1.0, 1.0, 1.0, 0.9],     # near-all-pass: kept
        [0.9, 0.9, 0.9, 0.9],     # uniform eqy-fail: kept, zero advantage
    ]
    flat = torch.tensor([r for g in groups for r in g])

    old = verl_grpo_advantage(flat, n)
    new = roll_grpo_advantage(flat, n)
    max_err = (old - new).abs().max().item()
    print(f"advantage max abs diff over {len(groups)} groups: {max_err:.2e}  (tol {TOL})")
    print("group [0.5,0.9,1.0,1.0]  old:", [f"{v:+.4f}" for v in old[:4]])
    print("group [0.5,0.9,1.0,1.0]  new:", [f"{v:+.4f}" for v in new[:4]])
    ok &= max_err < TOL

    print("--- rejection sampling / difficulty-mask agreement ---")
    for g in groups:
        t = torch.tensor(g)
        keep_old = old_rejection_keep(t)
        keep_new = new_difficulty_mask_keep(t)
        agree = keep_old == keep_new
        ok &= agree
        print(f"group {g}: old_keep={keep_old} new_keep={keep_new} {'OK' if agree else 'MISMATCH'}")

    # solve_none case (not reachable with RTL rewards but must agree if it were 0)
    # note: mean=0.0 -> difficulty_mask drops (mean > low fails) == old drops. verify:
    t = torch.tensor([0.0, 0.0, 0.0, 0.0])
    agree = old_rejection_keep(t) == new_difficulty_mask_keep(t)
    ok &= agree
    print(f"group [0,0,0,0]: old_keep={old_rejection_keep(t)} new_keep={new_difficulty_mask_keep(t)} {'OK' if agree else 'MISMATCH'}")

    print(f"Gate 3: {'PASS' if ok else 'FAIL'}")
    return ok


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
