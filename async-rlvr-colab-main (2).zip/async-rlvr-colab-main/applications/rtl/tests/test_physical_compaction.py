"""CPU unit tests for physical group compaction and the partial-tail mini-batch iterator.

Run: python -m pytest applications/rtl/tests/test_physical_compaction.py -q
"""
import numpy as np
import torch

from roll.distributed.scheduler.protocol import DataProto
from roll.utils.functionals import (
    get_sample_level_mask,
    make_minibatch_iterator_with_partial_tail,
    physical_group_compaction,
)

N_SAMPLE = 4


def make_batch(group_scores: list[list[float]], with_group_id: bool = True) -> DataProto:
    """Build a batch of len(group_scores) groups, N_SAMPLE contiguous rows per group."""
    scores = torch.tensor([s for group in group_scores for s in group], dtype=torch.float32)
    batch_size = scores.size(0)
    seq_len = 8
    data = DataProto.from_dict(
        tensors={
            "scores": scores,
            "response_mask": torch.ones(batch_size, seq_len, dtype=torch.long),
            "responses": torch.ones(batch_size, seq_len - 1, dtype=torch.long),
        }
    )
    if with_group_id:
        data.non_tensor_batch["group_id"] = np.array(
            [g for g in range(len(group_scores)) for _ in range(N_SAMPLE)], dtype=object
        )
    return data


def test_drops_zero_variance_groups_and_aligns():
    # groups: variance, all-0.5, variance, all-1.0, variance -> keep 3, alignment 8 needs 4 groups
    data = make_batch(
        [
            [0.5, 1.0, 0.5, 0.9],
            [0.5, 0.5, 0.5, 0.5],
            [0.9, 1.0, 0.9, 0.9],
            [1.0, 1.0, 1.0, 1.0],
            [0.5, 0.75, 0.9, 1.0],
        ]
    )
    compacted, metrics = physical_group_compaction(data, n_sample=N_SAMPLE, alignment=8)
    assert metrics["compaction/groups_zero_variance"] == 2
    assert metrics["compaction/groups_kept"] == 3
    assert metrics["compaction/groups_filler"] == 1
    assert compacted.batch.batch_size[0] == 16
    assert compacted.batch.batch_size[0] % 8 == 0
    # filler group is zero-variance and flagged; kept groups are not
    filler = compacted.batch["compaction_filler"].reshape(-1, N_SAMPLE)
    scores = compacted.batch["scores"].reshape(-1, N_SAMPLE)
    for g in range(4):
        is_zero_var = bool((scores[g] == scores[g, 0]).all())
        assert bool(filler[g, 0]) == is_zero_var
    # group rows stay contiguous
    gids = compacted.non_tensor_batch["group_id"].reshape(-1, N_SAMPLE)
    assert (gids == gids[:, :1]).all()


def test_no_zero_variance_is_identity():
    data = make_batch([[0.5, 1.0, 0.5, 0.9], [0.9, 1.0, 0.9, 0.9]])
    compacted, metrics = physical_group_compaction(data, n_sample=N_SAMPLE, alignment=8)
    assert compacted.batch.batch_size[0] == 8
    assert metrics["compaction/groups_filler"] == 0
    assert metrics["compaction/removed_fraction"] == 0.0


def test_all_zero_variance_keeps_aligned_filler():
    data = make_batch([[0.5] * 4, [1.0] * 4, [0.9] * 4, [0.75] * 4])
    compacted, metrics = physical_group_compaction(data, n_sample=N_SAMPLE, alignment=8)
    assert metrics["compaction/groups_kept"] == 0
    # empty-batch guard (2026-10-26): compacting to zero rows breaks batch_balance, so the batch is kept as is
    # (all advantages zero, a no-op step) and the step is flagged instead of being emptied
    assert compacted is data and compacted.batch.batch_size[0] == 16
    assert metrics["compaction/empty_step"] == 1


def test_all_zero_variance_32_groups_returns_batch_unchanged():
    """The kept=0 guard at the production group count: 32 zero-variance groups come back untouched."""
    levels = [0.5, 0.75, 0.9, 1.0]
    data = make_batch([[levels[g % 4]] * N_SAMPLE for g in range(32)])
    scores_before = data.batch["scores"].clone()
    compacted, metrics = physical_group_compaction(data, n_sample=N_SAMPLE, alignment=8)
    assert compacted is data and compacted.batch.batch_size[0] == 32 * N_SAMPLE
    assert torch.equal(compacted.batch["scores"], scores_before)
    assert "compaction_filler" not in compacted.batch
    assert metrics == {"compaction/groups_total": 32, "compaction/groups_kept": 0, "compaction/groups_dropped": 0,
                       "compaction/filler_groups": 32, "compaction/empty_step": 1}


def test_trims_when_not_enough_filler():
    # 3 variance groups, 0 droppable, alignment 8 -> trim kept down to 2 groups
    data = make_batch([[0.5, 1.0, 0.5, 0.9]] * 3)
    compacted, metrics = physical_group_compaction(data, n_sample=N_SAMPLE, alignment=8)
    assert compacted.batch.batch_size[0] == 8
    assert metrics["compaction/groups_kept"] == 2


def test_group_id_mismatch_raises():
    data = make_batch([[0.5, 1.0, 0.5, 0.9], [0.9, 1.0, 0.9, 0.9]])
    data.non_tensor_batch["group_id"] = np.array([0, 0, 1, 1, 1, 1, 0, 0], dtype=object)
    try:
        physical_group_compaction(data, n_sample=N_SAMPLE, alignment=8)
    except RuntimeError as exc:
        assert "group_id" in str(exc)
    else:
        raise AssertionError("expected RuntimeError on non-contiguous groups")


def test_filler_rows_are_masked_out():
    class _Cfg:
        max_len_mask = False
        difficulty_mask = False
        error_max_len_clip = False

    # 3 variance groups (12 rows, not 8-aligned) + 1 zero-variance -> 1 filler group
    data = make_batch(
        [[0.5, 1.0, 0.5, 0.9], [0.5, 0.5, 0.5, 0.5], [0.9, 1.0, 0.9, 0.9], [0.5, 0.75, 0.9, 1.0]]
    )
    compacted, _ = physical_group_compaction(data, n_sample=N_SAMPLE, alignment=8)
    masked, metrics = get_sample_level_mask(compacted, _Cfg())
    final = masked.batch["final_response_mask"].reshape(-1, N_SAMPLE, 7)
    filler = masked.batch["compaction_filler"].reshape(-1, N_SAMPLE)
    assert ((final.sum(dim=-1) > 0) == (filler == 0)).all()
    assert metrics["actor/compaction_filler_ratio"] > 0


def test_partial_tail_iterator_covers_all_rows():
    data = make_batch([[0.5, 1.0, 0.5, 0.9]] * 11)  # 44 rows
    seen = []
    sizes = []
    for mb in make_minibatch_iterator_with_partial_tail(data, mini_batch_size=32, epochs=2, seed=42):
        sizes.append(mb.batch.batch_size[0])
        seen.extend(mb.non_tensor_batch["group_id"].tolist())
    assert sizes == [32, 12, 32, 12]
    assert len(seen) == 88
