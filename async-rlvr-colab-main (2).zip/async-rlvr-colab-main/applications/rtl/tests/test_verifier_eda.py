"""Real toolchain regressions, serial and CPU-only; no model/framework import.

RTL_OSS_CAD_BIN=/path/to/oss-cad-suite/bin python applications/rtl/tests/test_verifier_eda.py
"""
import sys
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from applications.rtl import verifier as v  # noqa: E402

COMB = "module top(input a,b, output y); assign y=a&b; endmodule"
ASYNC = "module top(input clk,rst,d, output reg q); always @(posedge clk or posedge rst) if(rst) q<=0; else q<=d; endmodule"


@unittest.skipUnless(all((Path(v.DEFAULT_OSS_CAD_BIN) / tool).exists() for tool in ("yosys", "eqy", "iverilog")),
                     "set RTL_OSS_CAD_BIN to an installed OSS CAD Suite")
class EDARegression(unittest.TestCase):
    def setUp(self):
        self.scratch = tempfile.TemporaryDirectory(prefix="eqy_eda_tests_")
        self.addCleanup(self.scratch.cleanup)

    def verify(self, gold, gate, **kwargs):
        return v.verify_rtl_sample(gate, gold, self.scratch.name, self.id(), **kwargs)

    def test_comb_positive(self):
        self.assertTrue(self.verify(COMB, COMB.replace("a&b", "~(~a|~b)")).is_pass)

    def test_comb_counterexample(self):
        self.assertEqual(self.verify(COMB, COMB.replace("a&b", "a|b")).stage, "eqy_counterexample")

    def test_hierarchical_join_crash_retries_and_keeps_wrong_answer_negative(self):
        code = (Path(__file__).parent / 'fixtures/codev_64235.v').read_text()
        good = self.verify(code, code, keep_artifacts=True)
        self.assertTrue(good.is_pass, good.reason)
        self.assertIn('eqy_nojoin_retry', [stage['name'] for stage in good.stages])
        self.assertTrue((Path(good.workspace) / 'check_join_failed').exists())
        wrong = code.replace('(A ^ B) ^ Cin', '(A | B) ^ Cin')
        self.assertNotEqual(code, wrong)
        bad = self.verify(code, wrong)
        self.assertEqual(bad.stage, 'eqy_counterexample', bad.reason)

    def test_headerless_legacy_input(self):
        self.assertTrue(self.verify(COMB, "assign y=a&b; endmodule").is_pass)

    def test_fenced_cot_input(self):
        text = "<think>not Verilog</think>\n<answer>```verilog\n" + COMB + "\n```</answer>"
        self.assertTrue(self.verify(COMB, text).is_pass)

    def test_comments_before_module(self):
        self.assertTrue(self.verify(COMB, "// A correct answer\n" + COMB).is_pass)

    def test_async_positive(self):
        self.assertTrue(self.verify(ASYNC, ASYNC).is_pass)

    def test_reset_value_negative(self):
        self.assertEqual(self.verify(ASYNC, ASYNC.replace("q<=0", "q<=1")).stage, "eqy_counterexample")

    def test_clock_polarity_negative(self):
        self.assertEqual(self.verify(ASYNC, ASYNC.replace("posedge clk", "negedge clk")).stage,
                         "eqy_counterexample")

    def test_async_vs_sync_is_not_silently_equated(self):
        self.assertEqual(self.verify(ASYNC, ASYNC.replace(" or posedge rst", "")).stage, "eqy_counterexample")

    def test_rom_positive(self):
        code = """module top(input [1:0] a, output reg [7:0] y);
        always @* case(a) 0:y=17; 1:y=55; 2:y=94; 3:y=123; endcase
        endmodule"""
        self.assertTrue(self.verify(code, code).is_pass)

    def test_rom_negative(self):
        code = """module top(input [1:0] a, output reg [7:0] y);
        always @* case(a) 0:y=17; 1:y=55; 2:y=94; 3:y=123; endcase
        endmodule"""
        self.assertEqual(self.verify(code, code.replace("y=94", "y=95")).stage, "eqy_counterexample")

    def test_auto_top_is_not_first_helper(self):
        code = "module helper(input a, output y); assign y=~a; endmodule\nmodule main(input a, output y); helper h(a,y); endmodule"
        self.assertTrue(self.verify(code, "module main(input a, output y); assign y=~a; endmodule").is_pass)

    def test_width_mismatch_rejected(self):
        result = self.verify(COMB, COMB.replace("output y", "output [1:0] y"))
        self.assertEqual(result.stage, "interface_mismatch")
        self.assertFalse(result.is_pass)

    def test_extra_input_rejected(self):
        self.assertEqual(self.verify(COMB, COMB.replace("input a,b", "input a,b,c")).stage, "interface_mismatch")

    def test_outputless_reference_is_not_a_reward(self):
        code = "module top(input a); wire unused = a; endmodule"
        result = self.verify(code, code)
        self.assertFalse(result.is_pass)
        self.assertFalse(result.reward_valid)

    def test_all_x_reference_is_not_a_reward(self):
        code = "module top(input a, output y); assign y=1'bx; endmodule"
        result = self.verify(code, code)
        self.assertFalse(result.reward_valid)

    def test_constant_reference_is_valid(self):
        code = "module top(input a, output y); assign y=1'b0; endmodule"
        self.assertTrue(self.verify(code, code).is_pass)

    def test_multidriver_reference_rejected(self):
        code = "module top(input clk,rst, output reg q); always @(negedge clk) if(rst) q<=~q; always @(rst) if(!rst) q<=0; endmodule"
        result = self.verify(code, code)
        self.assertEqual(result.stage, "gold_prepare_fail")
        self.assertFalse(result.reward_valid)

    def test_syntax_failure_preserves_reward(self):
        result = self.verify(COMB, COMB.replace("a&b", "a&"))
        self.assertEqual((result.reward, result.stage), (.5, "syntax_fail"))

    def test_concurrent_workspaces_are_independent(self):
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda gate: self.verify(COMB, gate), [COMB, COMB.replace("a&b", "a|b")]))
        self.assertTrue(results[0].is_pass)
        self.assertEqual(results[1].stage, "eqy_counterexample")
        self.assertNotEqual(results[0].workspace, results[1].workspace)


if __name__ == "__main__":
    unittest.main(verbosity=2)
