"""CPU unit tests for PooledAdmissionPolicy (E0 sampling + propensity logging).

Run: python -m pytest applications/rtl/tests/test_admission.py -q
"""
import json
import time

import numpy as np
import pytest

from applications.rtl.admission import PooledAdmissionPolicy, TwoHeadDifficultyPredictor


class FakeDataset:
    """Minimal stand-in for an HF Dataset: int indexing -> row, "id" -> column."""

    def __init__(self, n):
        self.rows = []
        for i in range(n):
            kind = "easy" if i % 2 == 0 else "hard"
            body = ("assign out = in; " if kind == "easy" else "always @(posedge clk) case (state) ") * 6
            self.rows.append({
                "id": str(i),
                "messages": json.dumps([{"role": "user", "content": f"{kind} circuit spec {i} {body}"}]),
                "ground_truth": f"module m{i}(); {body} endmodule",
            })

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, key):
        if key == "id":
            return [r["id"] for r in self.rows]
        return self.rows[key]


class FakeScheduler:
    def __init__(self, n=2048):
        self.dataset = FakeDataset(n)


class FakeConfig:
    seed = 42
    output_dir = None


def make_policy(tmp_path, mode="uniform", **kw):
    cfg = FakeConfig()
    cfg.output_dir = str(tmp_path)
    defaults = dict(mode=mode, pool_size=256, batch=64, exploit=56, audit=8,
                    cooldown_steps=2, refit_interval=1, warmup_min_groups=8)
    defaults.update(kw)
    return PooledAdmissionPolicy(scheduler=FakeScheduler(), pipeline_config=cfg, **defaults)


def read_events(tmp_path):
    return [json.loads(l) for l in open(tmp_path / "admission_events.jsonl")]


def test_uniform_mode_probabilities_and_queue(tmp_path):
    policy = make_policy(tmp_path, mode="uniform")
    policy.on_step(0)
    ev = [e for e in read_events(tmp_path) if e["event"] == "candidate"]
    assert len(ev) == 256
    sel = [e for e in ev if e["selected"]]
    assert len(sel) == 64
    for e in ev:
        assert e["stage1_prob"] == pytest.approx(256 / 2048)
        assert e["stage2_prob"] == pytest.approx(64 / 256)
        assert e["path_propensity"] == pytest.approx((256 / 2048) * (64 / 256))
    # queue serves exactly the selected ids
    served = {str(policy.next_item()["id"]) for _ in range(64)}
    assert served == {e["dataset_id"] for e in sel}


def test_inclusion_probabilities_sum_to_batch(tmp_path):
    """Design invariant: sum of stage-2 inclusion probs over the pool = batch size."""
    policy = make_policy(tmp_path, mode="predict")
    # warm the predictor with separable outcomes: even ids all-pass, odd ids informative
    for i in range(96):
        rewards = [1.0] * 4 if i % 3 == 0 else ([0.9] * 4 if i % 3 == 1 else [0.9, 1.0, 0.9, 0.9])
        policy.observe(str(i), rewards)
    policy.on_step(0)  # triggers refit (interval 1) in a thread
    policy._refit_thread.join(timeout=60)
    assert policy.predictor.is_ready()
    policy.on_step(1)
    ev = [e for e in read_events(tmp_path) if e["event"] == "candidate" and e["step"] == 1]
    assert len(ev) == 256
    total = sum(e["stage2_prob"] for e in ev)
    assert total == pytest.approx(64.0)
    slots = {e["slot"] for e in ev if e["selected"]}
    assert slots == {"exploit", "audit"}
    n_exploit = sum(1 for e in ev if e["slot"] == "exploit")
    n_audit = sum(1 for e in ev if e["slot"] == "audit")
    assert (n_exploit, n_audit) == (56, 8)
    for e in ev:
        if e["slot"] == "exploit":
            assert e["stage2_prob"] == pytest.approx(1.0)
        else:
            assert e["stage2_prob"] == pytest.approx(8 / 200)


def test_predictor_prefers_informative(tmp_path):
    policy = make_policy(tmp_path, mode="predict")
    for i in range(192):
        rewards = [1.0] * 4 if i % 2 == 0 else ([0.9] * 4 if i % 4 == 1 else [0.9, 1.0, 0.9, 0.9])
        policy.observe(str(i), rewards)
    policy.on_step(0)
    policy._refit_thread.join(timeout=60)
    policy.on_step(1)
    ev = [e for e in read_events(tmp_path) if e["event"] == "candidate" and e["step"] == 1]
    exploit_ids = [int(e["dataset_id"]) for e in ev if e["slot"] == "exploit"]
    # even ids are the all-pass ("easy" text) pattern; exploit picks should avoid them
    even_frac = sum(1 for i in exploit_ids if i % 2 == 0) / len(exploit_ids)
    assert even_frac < 0.35


def test_cooldown_and_retirement(tmp_path):
    policy = make_policy(tmp_path, mode="uniform", cooldown_steps=2)
    policy.on_step(0)
    ev0 = [e for e in read_events(tmp_path) if e["event"] == "candidate" and e["step"] == 0]
    selected0 = {e["dataset_id"] for e in ev0 if e["selected"]}
    unselected0 = {e["dataset_id"] for e in ev0 if not e["selected"]}
    policy.on_step(1)
    ev1 = [e for e in read_events(tmp_path) if e["event"] == "candidate" and e["step"] == 1]
    ids1 = {e["dataset_id"] for e in ev1}
    assert not (ids1 & selected0), "retired prompts must not reappear"
    assert not (ids1 & unselected0), "cooling prompts must not reappear within cooldown"
    policy.on_step(4)  # step - last_pool_step(0) = 4 > 2 -> eligible again
    ev4 = [e for e in read_events(tmp_path) if e["event"] == "candidate" and e["step"] == 4]
    assert {e["dataset_id"] for e in ev4} & unselected0, "cooldown must expire"


def test_fallback_draw_logged(tmp_path):
    policy = make_policy(tmp_path, mode="uniform")
    policy.on_step(0)
    for _ in range(64):
        policy.next_item()
    extra = policy.next_item()  # replacement beyond quota
    ev = read_events(tmp_path)
    fb = [e for e in ev if e.get("slot") == "fallback"]
    assert len(fb) == 1 and fb[0]["dataset_id"] == str(extra["id"])


def test_observe_labels():
    pred = TwoHeadDifficultyPredictor()
    policy = PooledAdmissionPolicy.__new__(PooledAdmissionPolicy)
    policy.index_by_id = {"7": 7}
    policy.outcomes = []
    policy.observe("7", [1.0, 1.0, 1.0, 1.0])
    policy.observe("7", [0.9, 0.9, 0.9, 0.9])
    policy.observe("7", [0.5, 1.0, 0.9, 0.9])
    o = policy.outcomes
    assert (o[0].all_pass, o[0].too_hard) == (1, 0)
    assert (o[1].all_pass, o[1].too_hard) == (0, 1)
    assert (o[2].all_pass, o[2].too_hard) == (0, 0)
