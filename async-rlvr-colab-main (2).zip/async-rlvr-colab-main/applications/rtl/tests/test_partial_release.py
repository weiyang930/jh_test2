"""CPU unit tests for partial release: placeholder filling in the rollout loop and masked group normalization.

Run: python -m pytest applications/rtl/tests/test_partial_release.py -q
"""
import numpy as np
import pytest
import torch

from roll.distributed.scheduler.protocol import DataProto
from roll.utils.functionals import get_sample_level_mask, reward_norm


def _member(reward: float, stage: str, seq_len: int = 6) -> DataProto:
    scores = torch.tensor([reward], dtype=torch.float32)
    return DataProto.from_dict(
        tensors={"response_level_rewards": scores, "scores": scores.clone(),
                 "response_mask": torch.ones(1, seq_len, dtype=torch.long), "responses": torch.ones(1, seq_len - 1, dtype=torch.long)},
        non_tensors={"verifier_stage": np.array([stage], dtype=object), "reward_valid": np.array([stage != "released"], dtype=object)},
    )


def test_fill_released_members_marks_and_fills():
    from applications.rtl.rtl_rollout_loop import fill_released_members
    members = [_member(1.0, "pass"), _member(0.0, "fail"), _member(0.0, "fail"), _member(0.0, "released")]
    released = fill_released_members(members)
    assert released == [False, False, False, True]
    assert [int(m.batch["member_filler"][0]) for m in members] == [0, 0, 0, 1]
    assert float(members[3].batch["response_level_rewards"][0]) == pytest.approx(1 / 3)
    assert float(members[3].batch["scores"][0]) == pytest.approx(1 / 3)
    assert float(members[0].batch["response_level_rewards"][0]) == 1.0   # verified rows untouched


def test_masked_group_norm_matches_verified_only_statistics():
    # group A: verified (1, 0, 0) + one released placeholder at the mean; group B: all verified
    rewards = torch.tensor([1.0, 0.0, 0.0, 1 / 3, 1.0, 1.0, 0.0, 0.0])
    filler = torch.tensor([0, 0, 0, 1, 0, 0, 0, 0])
    out = reward_norm(rewards, n_sample=4, norm_mean_type="group", norm_std_type="group", member_mask=1.0 - filler.float())
    ref_a = reward_norm(torch.tensor([1.0, 0.0, 0.0]), n_sample=3, norm_mean_type="group", norm_std_type="group")
    assert torch.allclose(out[:3], ref_a, atol=1e-5)
    assert out[3].item() == 0.0
    ref_b = reward_norm(rewards[4:], n_sample=4, norm_mean_type="group", norm_std_type="group")
    assert torch.allclose(out[4:], ref_b, atol=1e-5)
    # without a mask the placeholder shrinks the std: the masked path must differ from the naive one
    naive = reward_norm(rewards, n_sample=4, norm_mean_type="group", norm_std_type="group")
    assert not torch.allclose(naive[:3], ref_a, atol=1e-3)


def test_sample_mask_zeroes_released_rows():
    class Cfg:
        max_len_mask = False
        difficulty_mask = False
        error_max_len_clip = False
    data = DataProto.from_dict(tensors={"response_mask": torch.ones(4, 6, dtype=torch.long), "responses": torch.ones(4, 5, dtype=torch.long),
                                        "member_filler": torch.tensor([0, 0, 0, 1])})
    data, metrics = get_sample_level_mask(data, Cfg())
    assert data.batch["final_response_mask"].sum(-1).tolist() == [5, 5, 5, 0]
    assert metrics["actor/released_member_ratio"] == pytest.approx(0.25)
