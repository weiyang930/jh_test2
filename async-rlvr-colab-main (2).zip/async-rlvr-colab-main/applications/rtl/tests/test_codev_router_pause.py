"""A paused router must abort credit waiters before they reach the GPU worker."""
import asyncio
from types import SimpleNamespace

import pytest

from roll.distributed.scheduler.router import PromptAffinityRouter


class Manager:
    need_suspend = False
    need_shutdown = False


class Worker:
    def __init__(self):
        self.started = []
        self.pending = {}
        self.generate_request = SimpleNamespace(remote=self.generate)
        self.abort_requests = SimpleNamespace(remote=self.abort)

    async def generate(self, payload):
        rid = payload['rid']
        self.started.append(rid)
        future = asyncio.get_running_loop().create_future()
        self.pending[rid] = future
        return await future

    async def abort(self, request_ids):
        for rid in request_ids:
            future = self.pending.get(rid)
            if future is not None and not future.done():
                future.set_result({'finish_reasons': ['abort']})


@pytest.mark.parametrize('stop_flag', ['need_suspend', 'need_shutdown'])
def test_pause_releases_same_prompt_and_new_prompt_credit_waiters(stop_flag):
    async def exercise():
        manager, worker = Manager(), Worker()
        router = PromptAffinityRouter(manager, [worker], '', SimpleNamespace(max_running_requests=1))
        await router.initialize()
        tasks = [asyncio.create_task(router.generate_request(
            {'rid': str(i), 'sampling_params': {'n': 1}}, str(i), 0 if i < 3 else i
        )) for i in range(8)]
        for _ in range(10):
            await asyncio.sleep(0)
        assert worker.started == ['0']
        setattr(manager, stop_flag, True)
        await router.abort_all([str(i) for i in range(8)])
        results = await asyncio.wait_for(asyncio.gather(*tasks), timeout=1)
        assert all(r['finish_reasons'] == ['abort'] for r in results)
        assert worker.started == ['0'], 'Credit waiters must not start after pause'
        assert router.worker_loads == {0: 0}
        assert router.dp_inflight_requests == [set()]
        setattr(manager, stop_flag, False)
        resumed = asyncio.create_task(router.generate_request(
            {'rid': 'resumed', 'sampling_params': {'n': 1}}, 'resumed', 0))
        for _ in range(5):
            await asyncio.sleep(0)
        worker.pending['resumed'].set_result({'finish_reasons': ['length'], 'output_token_ids': [[1, 2]]})
        assert (await resumed)['output_token_ids'] == [[1, 2]]
        assert router.worker_loads == {0: 0}
    asyncio.run(exercise())
