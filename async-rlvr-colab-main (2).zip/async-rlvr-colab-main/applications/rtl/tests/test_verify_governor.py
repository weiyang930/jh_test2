"""CPU unit tests for VerifyQueueGovernor (E2 central verification queue)."""
import asyncio
import json
import sys
import threading
import time

import numpy as np
import pytest

from applications.rtl.verify_governor import VerifyQueueGovernor


class FakeRef:
    def __init__(self, coro):
        self._coro = coro

    def __await__(self):
        return self._coro.__await__()


class FakeReq:
    """Carries a scripted reward + service time."""

    def __init__(self, reward, service_s, seq_tag, member_index=0):
        self.non_tensor_batch = {"id": [seq_tag], "messages": ["m"], "ground_truth": ["g"], "rollout_id": [seq_tag]}
        self.batch = {"response_level_rewards": [reward]}
        self.meta_info = {"member_index": member_index}
        self.reward, self.service_s = reward, service_s


class FakeWorkerHandle:
    """Sleeps service_s per job; ``cancel_verification`` ends a running job early like a killed child."""

    def __init__(self, log):
        self.log = log
        self.cancelled = []
        self._cancel_events = {}

        class _Compute:
            def __init__(m, outer): m.outer = outer

            def remote(m, req):
                async def run():
                    rid = req.non_tensor_batch["rollout_id"][0]
                    event = m.outer._cancel_events[rid] = asyncio.Event()
                    try:
                        await asyncio.wait_for(event.wait(), timeout=req.service_s)
                        return req  # killed: placeholder verdict the governor must drop
                    except asyncio.TimeoutError:
                        m.outer.log.append(req.non_tensor_batch["id"][0])
                        return req
                    finally:
                        m.outer._cancel_events.pop(rid, None)
                return FakeRef(run())

        class _Cancel:
            def __init__(m, outer): m.outer = outer

            def remote(m, rollout_id):
                m.outer.cancelled.append(rollout_id)
                if rollout_id in m.outer._cancel_events:
                    m.outer._cancel_events[rollout_id].set()
                return None
        self.compute_rewards = _Compute(self)
        self.cancel_verification = _Cancel(self)


class FakeCluster:
    def __init__(self, n, log):
        self.workers = [FakeWorkerHandle(log) for _ in range(n)]


class FakeScheduler:
    def __init__(self, n_workers, log):
        self.reward_clusters = {"rtl": FakeCluster(n_workers, log)}


class Cfg:
    seed = 42
    output_dir = None


def run(coro):
    # asyncio.run: get_event_loop() raised "no current event loop" once another test module had closed it
    return asyncio.run(coro)


def make(tmp_path, n_workers=1, **kw):
    cfg = Cfg(); cfg.output_dir = str(tmp_path)
    log = []
    gov = VerifyQueueGovernor(scheduler=FakeScheduler(n_workers, log), pipeline_config=cfg,
                              epsilon=0.0, **kw)
    return gov, log


def test_fifo_order_and_completion(tmp_path):
    async def main():
        gov, log = make(tmp_path, n_workers=1, policy="fifo")
        jobs = [gov.submit(FakeReq(1.0, 0.01, f"j{i}"), "rtl", prompt_id=i) for i in range(5)]
        await asyncio.gather(*jobs)
        assert log == [f"j{i}" for i in range(5)]
    run(main())


def test_all_jobs_complete_under_concurrency(tmp_path):
    async def main():
        gov, log = make(tmp_path, n_workers=3, policy="fifo")
        jobs = [gov.submit(FakeReq(0.9, 0.005 * (i % 4 + 1), f"j{i}"), "rtl", prompt_id=i // 4)
                for i in range(24)]
        res = await asyncio.gather(*jobs)
        assert len(res) == 24 and len(log) == 24
        assert not gov.pending["rtl"] and len(gov.free_workers["rtl"]) == 3
    run(main())


def test_joint_prioritizes_determined_informative(tmp_path, monkeypatch):
    async def main():
        gov, log = make(tmp_path, n_workers=1, policy="fifo")
        gov.policy = "joint"  # bypass bundle assert; inject scores directly
        gov.bundle = True

        def fake_scores(prompt_id, req):
            return {"utility": 0.1, "cost_hat": 1.0, "cost_norm": 0.0, "p_easy": None, "p_hard": None}
        gov._job_scores = fake_scores
        # group 7 already has mixed rewards observed -> determined informative
        gov.group_rewards[7] = [0.9, 1.0]
        blocker = gov.submit(FakeReq(1.0, 0.05, "blocker"), "rtl", prompt_id=99)
        await asyncio.sleep(0.01)  # blocker occupies the single worker
        low = gov.submit(FakeReq(0.9, 0.01, "low_value"), "rtl", prompt_id=98)
        hot = gov.submit(FakeReq(1.0, 0.01, "determined_informative"), "rtl", prompt_id=7)
        await asyncio.gather(blocker, low, hot)
        assert log.index("determined_informative") < log.index("low_value")
    run(main())


def test_dispatch_logging_action_prob(tmp_path):
    async def main():
        gov, log = make(tmp_path, n_workers=1, policy="fifo")
        await asyncio.gather(*[gov.submit(FakeReq(1.0, 0.005, f"j{i}"), "rtl", prompt_id=i)
                               for i in range(4)])
        ev = [json.loads(l) for l in open(tmp_path / "verify_queue_events.jsonl")]
        disp = [e for e in ev if e["event"] == "dispatch"]
        assert len(disp) == 4
        assert all(0 < e["action_prob"] <= 1.0 for e in disp)
        assert all("queue_wait_s" in e and "group_observed" in e for e in disp)
    run(main())


def test_group_state_updates_on_completion(tmp_path):
    async def main():
        gov, log = make(tmp_path, n_workers=2, policy="fifo", group_size=2)
        await gov.submit(FakeReq(0.9, 0.005, "a"), "rtl", prompt_id=5)
        assert gov.group_rewards.get(5) == [0.9]
        await gov.submit(FakeReq(1.0, 0.005, "b"), "rtl", prompt_id=5)
        assert 5 not in gov.group_rewards  # freed after group_size completions
    run(main())


# ---------------------------------------------------------------------------------------------
# cancellation (decoupled consumption): queued jobs dropped, running jobs killed, futures cancelled
# ---------------------------------------------------------------------------------------------

def _events(tmp_path, kind):
    return [e for e in (json.loads(l) for l in open(tmp_path / "verify_queue_events.jsonl")) if e["event"] == kind]


def test_cancel_queued_job_is_dropped(tmp_path):
    async def main():
        gov, log = make(tmp_path, n_workers=1, policy="fifo")
        blocker = asyncio.create_task(gov.submit(FakeReq(1.0, 0.05, "blocker"), "rtl", prompt_id=1))
        await asyncio.sleep(0.01)  # blocker occupies the single worker
        queued = asyncio.create_task(gov.submit(FakeReq(1.0, 0.01, "queued", member_index=2), "rtl", prompt_id=2))
        await asyncio.sleep(0)
        assert [j.prompt_id for j in gov.pending["rtl"]] == [2]
        assert gov.cancel(2, reason="stale_gc") == 1
        assert gov.pending["rtl"] == [] and 2 not in gov.active_jobs
        with pytest.raises(asyncio.CancelledError):
            await queued
        await blocker
        assert log == ["blocker"]  # the cancelled job never reached a worker
        cancel = _events(tmp_path, "cancel")
        assert len(cancel) == 1 and cancel[0]["state"] == "queued" and cancel[0]["prompt_id"] == 2
        assert cancel[0]["member_index"] == 2 and cancel[0]["reason"] == "stale_gc" and cancel[0]["elapsed_s"] >= 0
    run(main())


def test_cancel_running_job_kills_it_and_drops_the_verdict(tmp_path):
    async def main():
        gov, log = make(tmp_path, n_workers=1, policy="fifo")
        worker = gov.free_workers["rtl"][0]
        running = asyncio.create_task(gov.submit(FakeReq(1.0, 5.0, "slow"), "rtl", prompt_id=3))
        await asyncio.sleep(0.01)
        assert gov.active_jobs[3][0].state == "running"
        t0 = time.monotonic()
        assert gov.cancel(3, reason="stale_gc") == 1
        with pytest.raises(asyncio.CancelledError):
            await running
        await asyncio.sleep(0.02)  # _run drains the killed job
        assert time.monotonic() - t0 < 1.0  # did not wait for the 5 s service time
        assert worker.cancelled == ["slow"]
        assert log == [] and 3 not in gov.group_rewards and 3 not in gov.active_jobs
        assert len(gov.free_workers["rtl"]) == 1
        await gov.submit(FakeReq(1.0, 0.01, "after"), "rtl", prompt_id=4)  # worker usable afterwards
        assert log == ["after"]
        cancel = _events(tmp_path, "cancel")
        assert cancel[0]["state"] == "running" and cancel[0]["running_s"] is not None
    run(main())


def test_awaiter_cancellation_reaches_running_job(tmp_path):
    """ReplayBuffer.gc -> task.cancel() path: cancelling the awaiting task kills the job too."""
    async def main():
        gov, log = make(tmp_path, n_workers=1, policy="fifo")
        worker = gov.free_workers["rtl"][0]
        running = asyncio.create_task(gov.submit(FakeReq(1.0, 5.0, "slow"), "rtl", prompt_id=5))
        await asyncio.sleep(0.01)
        running.cancel()
        with pytest.raises(asyncio.CancelledError):
            await running
        await asyncio.sleep(0.02)
        assert worker.cancelled == ["slow"] and log == [] and len(gov.free_workers["rtl"]) == 1
        assert _events(tmp_path, "cancel")[0]["reason"] == "awaiter_cancelled"
    run(main())


def test_pump_skips_cancelled_futures(tmp_path):
    async def main():
        gov, log = make(tmp_path, n_workers=1, policy="fifo")
        workers, gov.free_workers["rtl"] = gov.free_workers["rtl"], []  # hold the worker back: submits only enqueue
        dead = asyncio.create_task(gov.submit(FakeReq(1.0, 0.01, "dead"), "rtl", prompt_id=6))
        live = asyncio.create_task(gov.submit(FakeReq(1.0, 0.01, "live"), "rtl", prompt_id=7))
        await asyncio.sleep(0)
        assert [j.prompt_id for j in gov.pending["rtl"]] == [6, 7]
        gov.pending["rtl"][0].future.cancel()  # awaiter gone, governor not told
        gov.free_workers["rtl"] = workers
        gov._pump("rtl")  # synchronous: the dead job's own except-handler has not run yet
        assert [j.prompt_id for j in gov.pending["rtl"]] == []
        with pytest.raises(asyncio.CancelledError):
            await dead
        await live
        assert log == ["live"]
        assert _events(tmp_path, "cancel")[0]["reason"] == "awaiter_gone"
    run(main())


# ---------------------------------------------------------------------------------------------
# CodeVRewardWorker side: child kill + tool-error streak untouched by cancellations
# ---------------------------------------------------------------------------------------------

def test_cancelled_verdict_does_not_touch_tool_error_streak():
    from applications.rtl.codev_reward_worker import (MAX_CONSECUTIVE_TOOL_ERRORS, CodeVRewardWorker,
                                                      cancelled_result)

    worker = CodeVRewardWorker.__new__(CodeVRewardWorker)
    worker._tool_error_streak = MAX_CONSECUTIVE_TOOL_ERRORS - 1
    worker._note_tool_error_streak(cancelled_result(1.0))
    assert worker._tool_error_streak == MAX_CONSECUTIVE_TOOL_ERRORS - 1  # neither incremented nor reset
    with pytest.raises(RuntimeError):
        worker._note_tool_error_streak(dict(stage="eqy_tool_error", reason="outage"))
    worker._tool_error_streak = 3
    worker._note_tool_error_streak(dict(stage="pass", reason=""))
    assert worker._tool_error_streak == 0


def test_run_child_cancel_kills_process(monkeypatch, tmp_path):
    from applications.rtl.codev_reward_worker import CodeVRewardWorker

    worker = CodeVRewardWorker.__new__(CodeVRewardWorker)
    worker._children, worker._cancelled, worker._child_lock = {}, set(), threading.Lock()
    # set by RTLRewardWorker.__init__, which __new__ skips; the cancel path sweeps workspace_root
    worker.keep_artifacts, worker.workspace_root = False, str(tmp_path)
    monkeypatch.setattr(CodeVRewardWorker, "_child_command",
                        staticmethod(lambda: [sys.executable, "-c", "import time; time.sleep(30)"]))
    sample_id = "rtl_cancel_" + "a" * 32
    outcome = {}
    thread = threading.Thread(target=lambda: outcome.update(value=worker._run_child(dict(sample_id=sample_id))))
    t0 = time.monotonic()
    thread.start()
    while sample_id not in worker._children and time.monotonic() - t0 < 5:
        time.sleep(0.01)
    assert worker.cancel_verification(sample_id) is True
    thread.join(timeout=5)
    assert not thread.is_alive() and outcome["value"] is None and time.monotonic() - t0 < 10
    assert worker._children == {} and worker._cancelled == set()
    # a cancel that arrives before launch is honoured at launch time
    assert worker.cancel_verification("early") is False
    assert worker._run_child(dict(sample_id="early")) is None


def test_release_resolves_remaining_members_with_placeholders(tmp_path):
    """Partial release: the running check is killed, the queued one dropped, both awaiters get placeholder verdicts."""
    async def main():
        gov, log = make(tmp_path, n_workers=1, policy="fifo")
        worker = gov.free_workers["rtl"][0]
        done = await gov.submit(FakeReq(1.0, 0.01, "m0"), "rtl", prompt_id=9)
        running = asyncio.create_task(gov.submit(FakeReq(0.0, 5.0, "m1"), "rtl", prompt_id=9))
        queued = asyncio.create_task(gov.submit(FakeReq(0.0, 5.0, "m2"), "rtl", prompt_id=9))
        await asyncio.sleep(0.01)
        assert [j.state for j in gov.active_jobs[9]] == ["running", "queued"]
        t0 = time.monotonic()
        assert gov.release(9) == 2
        r1, r2 = await running, await queued
        assert time.monotonic() - t0 < 1.0
        for r in (r1, r2):
            assert r.non_tensor_batch["verifier_stage"][0] == "released" and r.non_tensor_batch["reward_valid"][0] is False
        assert done.reward == 1.0 and worker.cancelled == ["m1"]
        await asyncio.sleep(0.02)
        assert log == ["m0"] and 9 not in gov.active_jobs and 9 not in gov.group_rewards
        assert len(gov.free_workers["rtl"]) == 1 and not gov.pending["rtl"]
        await gov.submit(FakeReq(1.0, 0.01, "after"), "rtl", prompt_id=10)
        assert log == ["m0", "after"]
        rel = _events(tmp_path, "release")
        assert sorted(e["state"] for e in rel) == ["queued", "running"] and rel[0]["reason"] == "controller_release"
        assert gov.release(9) == 0 and gov.cancel(9) == 0
    run(main())
