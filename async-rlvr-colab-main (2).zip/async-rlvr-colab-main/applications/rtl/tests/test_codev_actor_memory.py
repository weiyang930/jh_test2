"""Numerical checks for the CodeV long-sequence memory adapter."""
from types import SimpleNamespace

import torch
import torch.nn.functional as F

from applications.rtl.codev_actor_worker import chunked_entropy, install_bounded_forward, selected_log_probs


def test_chunked_values_and_gradients() -> None:
    torch.manual_seed(42)
    for dtype in [torch.float32, torch.bfloat16]:
        a = torch.randn(2, 17, 257, dtype=dtype, requires_grad=True)
        b = a.detach().clone().requires_grad_(True)
        labels = torch.randint(0, 257, (2, 17))
        weights = torch.randn(2, 17)
        actual = selected_log_probs(a, labels, chunk_size=5)
        expected = F.log_softmax(b.float(), -1).gather(-1, labels[..., None]).squeeze(-1)
        torch.testing.assert_close(actual, expected)
        (actual * weights).sum().backward()
        (expected * weights).sum().backward()
        torch.testing.assert_close(a.grad, b.grad)
        with torch.no_grad():
            x = a.float()
            expected_entropy = torch.logsumexp(x, -1) - (x.softmax(-1) * x).sum(-1)
            torch.testing.assert_close(chunked_entropy(a, 5), expected_entropy)


def test_padding_trim_preserves_response_alignment() -> None:
    calls = []

    def forward(**kwargs):
        calls.append(kwargs)
        return torch.zeros(1, kwargs['input_ids'].shape[1], 13)

    strategy = SimpleNamespace(worker=SimpleNamespace(rank_info=SimpleNamespace(cp_size=1)),
                               _fsdp2_forward=forward)
    install_bounded_forward(strategy)
    ids = torch.tensor([[1, 2, 3, 4, 0, 0]])
    attention = torch.tensor([[1, 1, 1, 1, 0, 0]])
    response = torch.tensor([[0, 0, 1, 1, 0, 0]])
    logits = strategy._fsdp2_forward(ids, attention, torch.arange(6)[None, :], {})
    assert calls[0]['input_ids'].shape == (1, 4)
    result = strategy.op_compute_log_probs(logits, ids, response)
    expected = torch.tensor([[0, -13.0, -13.0, 0, 0]])
    expected[expected != 0] = -torch.log(torch.tensor(13.0))
    torch.testing.assert_close(result, expected)
