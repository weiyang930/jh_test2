"""Gate 1 + Gate 2: scalar reward parity and concurrent verifier correctness.

Gate 1 runs fixed cases through BOTH the reference implementation
(reference_code/archer_llm/dapo/reward_wo_header.py, imported read-only) and the
production adapter (applications/rtl/verifier.py) and requires exact reward and
scalar agreement on these clean controls (v2 refines failure classifications).

Gate 2 runs the adapter concurrently (4 processes) and requires identical
rewards vs sequential execution, no workspace collisions and no orphans.

Run: python applications/rtl/tests/test_reward_parity.py
"""
import concurrent.futures
import os
import subprocess
import sys
import time

REPO = "/workspace/async-rlvr"
sys.path.insert(0, REPO)
sys.path.insert(0, os.path.join(REPO, "reference_code/archer_llm"))

os.environ["PATH"] = "/opt/oss-cad-suite/bin:" + os.environ.get("PATH", "")

from applications.rtl.verifier import verify_rtl_sample  # noqa: E402

GT = """module top_module(input a, input b, output out);
    assign out = a & b;
endmodule
"""

CASES = {
    # name: (solution, expected_reward, expected_stage)
    "pass_demorgan": (
        "module top_module(input a, input b, output out);\n    assign out = ~(~a | ~b);\nendmodule\n",
        1.0,
        "pass",
    ),
    "eqy_fail_or": (
        "module top_module(input a, input b, output out);\n    assign out = a | b;\nendmodule\n",
        0.9,
        "eqy_counterexample",
    ),
    "syntax_fail": (
        "module top_module(input a, input b, output out);\n    assign out = a &;\nendmodule\n",
        0.5,
        "syntax_fail",
    ),
    "headerless_pass": (
        "    assign out = a & b;\nendmodule\n",
        1.0,
        "pass",
    ),
}
BAD_GT_CASE = ("anything", "this is not verilog", 0.75, "header_extract_fail")


def run_reference(solution: str, ground_truth: str) -> float:
    """Reference impl, executed in an isolated cwd (it writes ./reward_tmp)."""
    from dapo.reward_wo_header import _compute_base_reward_wo_header_no_header

    res = _compute_base_reward_wo_header_no_header(solution, ground_truth, question="")
    return float(res["score"])


def run_adapter(args):
    name, solution, ground_truth = args
    r = verify_rtl_sample(
        solution_str=solution,
        ground_truth=ground_truth,
        workspace_root="/tmp/rtl_gate_test",
        sample_id=name,
    )
    return name, r.reward, r.stage


def orphan_count() -> int:
    out = subprocess.run(
        ["bash", "-c", "ps aux | grep -E 'iverilog|eqy|yosys|sby|smtbmc' | grep -v grep | wc -l"],
        capture_output=True, text=True,
    )
    return int(out.stdout.strip())


def gate1():
    print("=== Gate 1: reference parity ===")
    scratch = "/tmp/rtl_gate_ref_cwd"
    os.makedirs(scratch, exist_ok=True)
    os.chdir(scratch)  # reference writes ./reward_tmp relative to cwd
    ok = True
    for name, (solution, expected_reward, expected_stage) in CASES.items():
        ref = run_reference(solution, GT)
        _, new, stage = run_adapter((name, solution, GT))
        match = (ref == new == expected_reward) and stage == expected_stage
        ok &= match
        print(f"{name:20s} ref={ref:4.2f} new={new:4.2f} stage={stage:20s} expected=({expected_reward},{expected_stage}) {'OK' if match else 'MISMATCH'}")
    # bad ground truth case
    name, bad_gt, expected_reward, expected_stage = BAD_GT_CASE
    ref = run_reference("module x(); endmodule", bad_gt)
    _, new, stage = run_adapter(("bad_gt", "module x(); endmodule", bad_gt))
    match = (ref == new == expected_reward) and stage == expected_stage
    ok &= match
    print(f"{'bad_ground_truth':20s} ref={ref:4.2f} new={new:4.2f} stage={stage:20s} expected=({expected_reward},{expected_stage}) {'OK' if match else 'MISMATCH'}")
    print(f"Gate 1: {'PASS' if ok else 'FAIL'}")
    return ok


def gate2():
    print("=== Gate 2: concurrent verifier ===")
    jobs = [(f"conc_{i}_{name}", sol, GT) for i in range(1) for name, (sol, _, _) in CASES.items()]
    # sequential
    t0 = time.time()
    seq = {run_adapter(j)[0].split("_", 2)[2]: run_adapter(j)[1:] for j in jobs}
    t_seq = time.time() - t0
    # concurrent x4 (4 distinct cases in flight simultaneously)
    t0 = time.time()
    with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
        conc_results = list(pool.map(run_adapter, jobs))
    t_conc = time.time() - t0
    ok = True
    for name, reward, stage in conc_results:
        base = name.split("_", 2)[2]
        expected_reward, expected_stage = CASES[base][1], CASES[base][2]
        match = reward == expected_reward and stage == expected_stage
        ok &= match
        print(f"{name:24s} reward={reward:4.2f} stage={stage:16s} {'OK' if match else 'MISMATCH'}")
    orphans = orphan_count()
    ok &= orphans == 0
    print(f"sequential={t_seq:.1f}s concurrent(4)={t_conc:.1f}s slowdown_vs_1job={t_conc / max(t_seq / len(jobs), 1e-9):.2f}x orphans={orphans}")
    print(f"Gate 2: {'PASS' if ok else 'FAIL'}")
    return ok


if __name__ == "__main__":
    g1 = gate1()
    g2 = gate2()
    sys.exit(0 if (g1 and g2) else 1)
