"""Text heads as the prior of the top-K selector (torch-free; needs scikit-learn): after a refit, prompts whose text
looks all-pass or all-fail rank below mixed-looking prompts even when they have no history of their own."""
import json
import random
import time
from types import SimpleNamespace

import pytest

pytest.importorskip("sklearn")
from applications.rtl.history_admission import HistoryAdmissionPolicy


def _dataset(n):
    rows = []
    for i in range(n):
        kind = ("easy", "hard", "mixed")[i % 3]
        words = {"easy": "trivial wire assign passthrough buffer", "hard": "pipelined fifo arbiter cdc handshake", "mixed": "counter mux decoder shift register"}[kind]
        prompt = f"Design module m{i}: {words} {words} variant {i}"
        rows.append({"id": str(i), "messages": json.dumps([{"role": "user", "content": prompt}]), "ground_truth": f"module m{i} endmodule"})
    return rows


def test_text_prior_orders_unseen_prompts(tmp_path):
    rows = _dataset(240)
    sched = SimpleNamespace(dataset=rows, verify_governor=None)
    cfg = SimpleNamespace(output_dir=str(tmp_path), seed=0)
    pol = HistoryAdmissionPolicy(sched, cfg, mode="topk", batch=32, pool_size=256, audit=4, price="const", rho=0.0,
                                 visit_budget=2, window=50, text=True, text_refit_interval=10, text_window=100)
    rng = random.Random(0)
    # 150 observed groups on the first 150 prompts, outcomes follow the text kind (with a little noise)
    for step in range(1, 11):
        pol.on_step(step)
        for i in range((step - 1) * 15, step * 15):
            kind = ("easy", "hard", "mixed")[i % 3]
            if rng.random() < 0.1:
                kind = "mixed"
            rewards = {"easy": [1.0] * 8, "hard": [0.0] * 8, "mixed": [1.0, 0.0] * 4}[kind]
            stages = ["pass" if r == 1.0 else "fail" for r in rewards]
            pol.observe_group(str(i), prompt_id=i, rewards=rewards, cpu_seconds=10.0, valid=True, stages=stages)
    pol.on_step(10)   # refit fires at step 10
    for _ in range(100):
        if pol._v_text is not None:
            break
        time.sleep(0.1)
    assert pol._v_text is not None, "text refit did not produce a prior"
    unseen = range(150, 240)   # never observed: V comes from the text prior alone
    v = {kind: [pol._p_inform(pol.stats[i]) for i in unseen if ("easy", "hard", "mixed")[i % 3] == kind] for kind in ("easy", "hard", "mixed")}
    mean = {k: sum(x) / len(x) for k, x in v.items()}
    assert mean["mixed"] > mean["easy"] and mean["mixed"] > mean["hard"], mean
    # observed outcomes still dominate the prior: a mixed-looking prompt seen all-pass 6 times ranks below an unseen mixed one
    s = pol.stats[2]
    assert s.informative >= 0
    pol.stats[2].outcomes = [(10, "all_pass")] * 6
    assert pol._p_inform(pol.stats[2]) < mean["mixed"]
