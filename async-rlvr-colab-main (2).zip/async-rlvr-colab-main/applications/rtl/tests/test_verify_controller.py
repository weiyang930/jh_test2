import math
import sys
import types

import pytest

from applications.rtl import verify_controller as vc


def _tables():
    p = {}
    for t in vc.GRID:
        p[(t, "none")] = 0.2 if t < 20 else 0.02
        p[(t, "fail")] = 0.1 if t < 20 else 0.02
        p[(t, "pass")] = 0.6 if t < 20 else 0.03
    R = {t: max(1.0, 120.0 - t) for t in vc.GRID}
    return vc.Tables(p, R, tau=180.0, source="unit")


def test_p_informative_cases():
    assert vc.p_informative([0.5, 0.5], s=0, n=0) == pytest.approx(0.5)      # 1 - 0.25 - 0.25
    assert vc.p_informative([0.1, 0.1], s=0, n=3) == pytest.approx(1 - 0.81)  # observed all fail
    assert vc.p_informative([0.9], s=2, n=2) == pytest.approx(1 - 0.9)        # observed all pass
    assert vc.p_informative([0.0], s=1, n=3) == 1.0                           # already informative


def test_decide_rules():
    tb = _tables()
    g_inf = vc.GroupView(1, observed=[1.0, 0.0], active_ages=[50.0], group_size=4)
    assert vc.decide(g_inf, tb, "const", 1e-3, 0.1, 0.0, 2.0).action == "continue"
    g_young = vc.GroupView(2, observed=[0.0], active_ages=[1.0], group_size=4)
    assert vc.decide(g_young, tb, "const", 1e-3, 0.1, 0.0, 2.0).action == "skip"
    # all observed fail, one old check: p=0.02, R=60 -> 0.02 - lam*60
    g_old = vc.GroupView(3, observed=[0.0, 0.0, 0.0], active_ages=[60.0], group_size=4)
    assert vc.decide(g_old, tb, "const", 1e-3, 0.1, 0.0, 2.0).action == "abandon"
    assert vc.decide(g_old, tb, "const", 1e-5, 0.1, 0.0, 2.0).action == "continue"
    assert vc.decide(g_old, tb, "posterior", 0.0, 0.1, 0.0, 2.0).action == "abandon"
    assert vc.decide(g_old, tb, "posterior", 0.0, 0.01, 0.0, 2.0).action == "continue"
    # dynamic: price passed in decides
    assert vc.decide(g_old, tb, "dynamic", 0.0, 0.1, 1e-5, 2.0).action == "continue"
    assert vc.decide(g_old, tb, "dynamic", 0.0, 0.1, 1e-2, 2.0).action == "abandon"
    assert vc.decide(g_old, tb, "none", 0.0, 0.1, 0.0, 2.0).action == "skip"


def test_tables_lookup_and_price():
    tb = _tables()
    assert tb.p_pass(7.0, "pass") == 0.6 and tb.p_pass(25.0, "fail") == 0.02
    assert tb.remaining(0.0) == 120.0 and tb.remaining(300.0) >= 0.0
    pt = vc.PriceTracker(kappa=2.0, half_life_s=30.0)
    assert pt.update(0.0, queued=32, workers=32) == pytest.approx(2.0)
    assert pt.update(30.0, queued=0, workers=32) == pytest.approx(1.0)  # one half-life toward 0


def test_release_rules():
    tb = _tables()
    g = vc.GroupView(1, observed=[1.0, 0.0, 0.0], active_ages=[40.0], group_size=4)   # informative, 3/4 observed
    assert vc.decide(g, tb, "const", 1e-3, 0.1, 0.0, 2.0).action == "continue"                       # release off
    assert vc.decide(g, tb, "const", 1e-3, 0.1, 0.0, 2.0, release="slow", release_slow_s=30.0).action == "release"
    assert vc.decide(g, tb, "const", 1e-3, 0.1, 0.0, 2.0, release="slow", release_slow_s=60.0).action == "continue"
    # index: age 40 s falls in the 30 s bucket, R = 90 s; 1e-3 * 90 = 0.09 < 1/4 -> continue; 1e-2 * 90 = 0.9 > 1/4 -> release
    assert vc.decide(g, tb, "const", 1e-3, 0.1, 0.0, 2.0, release="index").action == "continue"
    d = vc.decide(g, tb, "const", 1e-2, 0.1, 0.0, 2.0, release="index")
    assert d.action == "release" and d.reason == "release_index" and d.r_sum == pytest.approx(90.0)
    # dynamic mode prices with the tracker value
    assert vc.decide(g, tb, "dynamic", 0.0, 0.1, 1e-2, 2.0, release="index").action == "release"
    # below the 3/4 threshold or not informative: never released
    g2 = vc.GroupView(2, observed=[1.0, 0.0], active_ages=[40.0, 40.0], group_size=4)
    assert vc.decide(g2, tb, "const", 1e-2, 0.1, 0.0, 2.0, release="index").action == "continue"
    g3 = vc.GroupView(3, observed=[0.0, 0.0, 0.0], active_ages=[40.0], group_size=4)
    assert vc.decide(g3, tb, "const", 1e-2, 0.1, 0.0, 2.0, release="index").action != "release"
    with pytest.raises(AssertionError):
        vc.decide(g, tb, "const", 1e-2, 0.1, 0.0, 2.0, release="bogus")
    # expiry: release one step before the replay buffer would discard the group (age >= expiry - 1), never earlier
    ge = vc.GroupView(4, observed=[1.0, 0.0, 0.0], active_ages=[5.0], group_size=4, age_steps=1, expiry_steps=2)
    d = vc.decide(ge, tb, "const", 1e-3, 0.1, 0.0, 2.0, release="expiry")
    assert d.action == "release" and d.reason == "release_expiry"
    ge.age_steps = 0
    assert vc.decide(ge, tb, "const", 1e-3, 0.1, 0.0, 2.0, release="expiry").action == "continue"
    ge.age_steps = None
    assert vc.decide(ge, tb, "const", 1e-3, 0.1, 0.0, 2.0, release="expiry").action == "continue"   # no step info: never


# ---------------------------------------------------------------- 2026-10-25: graded rewards
def test_graded_failures_are_not_passes_but_two_grades_are_informative():
    tab = _tables() if "_tables" in globals() else None
    assert vc.sibling_state([False, False]) == "fail" and vc.sibling_state([False, True]) == "pass" and vc.sibling_state([]) == "none"
    g = vc.GroupView(1, observed=[0.75, 0.75, 0.9], active_ages=[40.0], group_size=4)            # three graded failures, two grades
    assert vc.passes_of(g) == [False, False, False]
    assert vc.is_informative([0.75, 0.75, 0.9]) and not vc.is_informative([0.75, 0.75])
    g2 = vc.GroupView(2, observed=[0.9, 0.9], active_ages=[40.0], group_size=4, observed_pass=[False, False])
    assert vc.passes_of(g2) == [False, False]                                                 # recorded verdicts win
    g3 = vc.GroupView(3, observed=[0.9, 0.9], active_ages=[40.0], group_size=4, observed_pass=[True, False])
    assert vc.passes_of(g3) == [True, False]
