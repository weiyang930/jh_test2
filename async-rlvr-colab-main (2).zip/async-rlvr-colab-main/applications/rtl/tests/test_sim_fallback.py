"""EQY-timeout simulation fallback: label rewriting, port-info sidecar round trip, infrastructure-failure handling."""
import io
import json
import pickle
import shutil
from pathlib import Path

import pytest

from applications.rtl import sim_fallback
from applications.rtl.prepare_codev_dataset import write_sim_meta

GOLD = "module m(input a, output b); assign b = a; endmodule"
ANSWER = dict(code=GOLD, input_port_width={("a", 1)}, output_port_width={("b", 1)}, clock_port_polarity=set(),
              reset_port_polarity_sync={("rst", 1, True)})


def timeout_verdict() -> dict:
    return dict(reward=0.9, stage="eqy_timeout", is_pass=False, total_duration_s=30.0, reward_valid=True)


@pytest.fixture
def meta_file(tmp_path, monkeypatch):
    path = tmp_path / "sim_meta.json"
    path.write_text(json.dumps({sim_fallback.golden_key(GOLD): {
        k: [list(x) for x in v] for k, v in ANSWER.items() if k != "code"}}))
    monkeypatch.setenv("RTL_SIM_META", str(path))
    sim_fallback._load_meta.cache_clear()
    return path


def test_port_info_round_trip_restores_sets_of_tuples(meta_file):
    ports = sim_fallback.port_info(GOLD)
    assert ports == (ANSWER["input_port_width"], ANSWER["output_port_width"], set(), ANSWER["reset_port_polarity_sync"])
    assert sim_fallback.port_info("module other; endmodule") is None


def test_sidecar_writer_matches_runtime_lookup(tmp_path, monkeypatch):
    pa = pytest.importorskip("pyarrow")
    pq = pytest.importorskip("pyarrow.parquet")
    src = tmp_path / "rl.parquet"
    gt = pickle.dumps({"answer": ANSWER})
    pq.write_table(pa.table({"problem_id": ["1"], "reward_model": [{"ground_truth": gt}]}), src)
    out = write_sim_meta(src, tmp_path / "meta.json")
    assert out["entries"] == 1
    monkeypatch.setenv("RTL_SIM_META", str(tmp_path / "meta.json"))
    sim_fallback._load_meta.cache_clear()
    assert sim_fallback.port_info(GOLD)[3] == {("rst", 1, True)}


def test_disabled_or_non_timeout_is_untouched(monkeypatch, tmp_path):
    monkeypatch.setenv("RTL_SIM_FALLBACK", "0")
    v = timeout_verdict()
    assert sim_fallback.apply(dict(v), "x", GOLD, str(tmp_path)) == v
    monkeypatch.setenv("RTL_SIM_FALLBACK", "1")
    passed = dict(v, stage="pass", reward=1.0, is_pass=True)
    assert sim_fallback.apply(dict(passed), "x", GOLD, str(tmp_path)) == passed


@pytest.mark.parametrize("correct,stage,reward", [(True, "sim_pass", 1.0), (False, "sim_fail", 0.9)])
def test_decided_simulation_rewrites_label(monkeypatch, tmp_path, correct, stage, reward):
    monkeypatch.setenv("RTL_SIM_FALLBACK", "1")
    monkeypatch.setattr(sim_fallback, "check",
                        lambda *a: dict(decided=True, correct=correct, sim_s=2.0, sim_detail="error_rate 0.0"))
    v = sim_fallback.apply(timeout_verdict(), "x", GOLD, str(tmp_path))
    assert (v["stage"], v["reward"], v["is_pass"], v["reward_valid"]) == (stage, reward, correct, True)
    assert v["eqy_stage"] == "eqy_timeout" and v["total_duration_s"] == pytest.approx(32.0)
    assert not list(tmp_path.iterdir())  # scratch dir removed


def test_infrastructure_failure_keeps_eqy_verdict(monkeypatch, tmp_path, meta_file):
    monkeypatch.setenv("RTL_SIM_FALLBACK", "1")
    monkeypatch.setenv("RTL_CODEV_TK", str(tmp_path / "missing"))
    v = sim_fallback.apply(timeout_verdict(), "```verilog\nmodule m; endmodule\n```", GOLD, str(tmp_path))
    assert v["stage"] == "eqy_timeout" and v["reward"] == 0.9 and v["sim_decided"] is False
    assert "toolkit missing" in v["sim_detail"]


def test_missing_port_info_keeps_eqy_verdict(monkeypatch, tmp_path):
    (tmp_path / "tk").mkdir()
    (tmp_path / "tk" / "verify.py").write_text("")
    monkeypatch.setenv("RTL_CODEV_TK", str(tmp_path / "tk"))
    monkeypatch.setenv("RTL_SIM_META", str(tmp_path / "absent.json"))
    out = sim_fallback.check("```verilog\nmodule m; endmodule\n```", GOLD, str(tmp_path / "w"))
    assert out["decided"] is False and "port info" in out["sim_detail"]


def test_no_fenced_block_is_a_fail(monkeypatch, tmp_path, meta_file):
    (tmp_path / "tk").mkdir()
    (tmp_path / "tk" / "verify.py").write_text("")
    monkeypatch.setenv("RTL_CODEV_TK", str(tmp_path / "tk"))
    out = sim_fallback.check("module m; endmodule", GOLD, str(tmp_path / "w"))
    assert out["decided"] is True and out["correct"] is False


FAKE_CODEV_VERIFY = """
class eda_tools:
    \"\"\"Stand-in for CodeV-R1 verify.py @277ac46e: same call signature and the same 6-tuple return.\"\"\"
    def __init__(self, quiet=False):
        pass

    def auto_top(self, verilog_code):
        return "m"

    def equiv_with_testbench(self, golden_path, gate_path, golden_top, gate_top, tb_dir, port_info=None, seed=0,
                             outerLoopNum=None, innerLoopNum=None, timeout=60):
        assert port_info is not None
        input_port_width, output_port_width, clock_port_polarity, reset_port_polarity_sync = port_info
        same = open(golden_path).read() == open(gate_path).read()
        return (same, 0.0 if same else 1.0, input_port_width, output_port_width, clock_port_polarity,
                reset_port_polarity_sync)
"""


@pytest.mark.parametrize("dut,correct", [(GOLD, True), (GOLD.replace("assign b = a", "assign b = ~a"), False)])
def test_checker_six_tuple_is_decided(monkeypatch, tmp_path, meta_file, dut, correct):
    """CodeV-R1's checker returns 6 values; the fallback must decide on them (it raised and stayed undecided before)."""
    (tmp_path / "tk").mkdir()
    (tmp_path / "tk" / "verify.py").write_text(FAKE_CODEV_VERIFY)
    monkeypatch.setenv("RTL_CODEV_TK", str(tmp_path / "tk"))
    out = sim_fallback.check(f"```verilog\n{dut}\n```", GOLD, str(tmp_path / "w"))
    assert out["decided"] is True and out["correct"] is correct, out
    assert out["sim_detail"].startswith("error_rate"), out


@pytest.mark.skipif(shutil.which("iverilog") is None, reason="needs iverilog (oss-cad-suite) on PATH")
def test_real_checker_gold_vs_gold(monkeypatch, tmp_path, meta_file):
    tk = Path(__import__("os").environ.get("RTL_CODEV_TK_TEST", ""))
    if not (tk / "verify.py").exists():
        pytest.skip("set RTL_CODEV_TK_TEST to a directory with CodeV-R1 verify.py")
    monkeypatch.setenv("RTL_CODEV_TK", str(tk))
    monkeypatch.setenv("RTL_OSS_CAD_BIN", str(Path(shutil.which("iverilog")).parent))
    # the shared fixture declares a reset port "rst" that GOLD does not have; CodeV's testbench then fails to compile
    # (error_rate 1.0). The real checker needs port info that matches the design, as the dataset sidecar provides.
    real_meta = tmp_path / "sim_meta_real.json"
    real_meta.write_text(json.dumps({sim_fallback.golden_key(GOLD): {
        "input_port_width": [["a", 1]], "output_port_width": [["b", 1]], "clock_port_polarity": [],
        "reset_port_polarity_sync": []}}))
    monkeypatch.setenv("RTL_SIM_META", str(real_meta))
    sim_fallback._load_meta.cache_clear()
    out = sim_fallback.check(f"```verilog\n{GOLD}\n```", GOLD, str(tmp_path / "w"))
    assert out["decided"] and out["correct"], out
    wrong = GOLD.replace("assign b = a", "assign b = ~a")
    out = sim_fallback.check(f"```verilog\n{wrong}\n```", GOLD, str(tmp_path / "w2"))
    assert out["decided"] and not out["correct"], out
