"""Dependency-free unit tests; real EDA integration lives in test_verifier_eda.py."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from applications.rtl import verifier as v  # noqa: E402


class VerifierTests(unittest.TestCase):
    def setUp(self):
        self.scratch = tempfile.TemporaryDirectory()
        self.addCleanup(self.scratch.cleanup)
        self.root = Path(self.scratch.name)

    def put(self, name, contents):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(contents)
        return path

    def test_default_normalizes_memory_and_all_clocks_both_sides(self):
        config = v.generate_eqy_content("g", "c", self.root / "g.v", self.root / "c.v")
        self.assertEqual(config.count("memory_map"), 2)
        self.assertEqual(config.count("clk2fflogic"), 2)
        self.assertIn("depth 10", config)
        self.assertIn("engine abc pdr", config)
        self.assertNotIn("setundef", config)

    def test_async2sync_requires_explicit_mode(self):
        config = v.generate_eqy_content(None, None, self.root / "g.v", self.root / "c.v",
                                        v.VerifierConfig(clock_mode="async2sync"))
        self.assertEqual(config.count("async2sync"), 2)
        self.assertNotIn("clk2fflogic", config)

    def test_prepared_config_does_not_reelaborate(self):
        config = v.generate_eqy_content(None, None, self.root / "g.il", self.root / "c.il", prepared=True)
        self.assertEqual(config.count("read_rtlil"), 2)
        self.assertNotIn("memory_map", config)

    def test_joining_does_not_merge_expensive_arithmetic_cones(self):
        simple = self.put("simple.json", json.dumps({"modules": {"top": {"cells": {"a": {"type": "$xor"}}}}}))
        divider = self.put("divider.json", json.dumps({"modules": {"top": {"cells": {"b": {"type": "$div"}}}}}))
        self.assertTrue(v._join_vectors_for_designs(simple))
        self.assertFalse(v._join_vectors_for_designs(simple, divider))
        self.assertFalse(v._join_vectors_for_designs(divider, simple))
        config = v.generate_eqy_content(None, None, self.root / "g.il", self.root / "c.il",
                                        prepared=True, join_vectors=False)
        self.assertNotIn("join *", config)

    def test_sequential_feedback_boundaries_are_not_joined(self):
        for kind in ("$dff", "$adff", "$sdffe", "$dlatch", "$ff"):
            path = self.put("storage.json", json.dumps({"modules": {"top": {"cells": {"a": {"type": kind}}}}}))
            self.assertFalse(v._join_vectors_for_designs(path))

    def test_invalid_config(self):
        for kwargs in ({"timeout_s": 0}, {"timeout_s": float("nan")}, {"timeout_s": float("inf")},
                       {"jobs": 0}, {"depth": 0}, {"clock_mode": "guess"}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                v.VerifierConfig(**kwargs)

    def test_reject_command_in_top(self):
        with self.assertRaises(ValueError):
            v._prepare_commands(self.root / "g.v", "top; shell command", v.VerifierConfig())

    def test_fenced_final_answer(self):
        text = "<think>```verilog\nwrong\n```</think>\n```verilog\nmodule top; endmodule\n```"
        self.assertEqual(v._extract_solution(text), "module top; endmodule")

    def test_comment_prefix_header(self):
        self.assertEqual(v.extract_first_module_name("// prose\nmodule top(input a); endmodule"), "top")

    def test_no_output_and_blackbox_rejected(self):
        for attributes, ports in [({}, {"a": {"direction": "input", "bits": [1]}}),
                                  ({"blackbox": "1"}, {"y": {"direction": "output", "bits": [1]}})]:
            path = self.put("ports.json", json.dumps({"modules": {"TOP_EQUIV": {
                "attributes": attributes, "ports": ports}}}))
            with self.assertRaises(ValueError):
                v._design_ports(path)

    def test_ports_signature(self):
        path = self.put("ports.json", json.dumps({"modules": {"TOP_EQUIV": {"ports": {
            "a": {"direction": "input", "bits": [2]}, "y": {"direction": "output", "bits": [3, 4]}}}}}))
        self.assertEqual(v._design_ports(path), {"a": ("input", 1), "y": ("output", 2)})

    def test_pass_requires_success_artifact(self):
        result = v.StageResult("eqy", returncode=0)
        self.assertEqual(v._classify_eqy(self.root, result)[:2], ("eqy_tool_error", False))
        self.put("check/PASS", "")
        self.assertEqual(v._classify_eqy(self.root, result)[:2], ("pass", True))

    def test_timeout_is_not_counterexample(self):
        self.put("check/PASS", "")
        self.assertEqual(v._classify_eqy(self.root, v.StageResult("eqy", timed_out=True))[:2],
                         ("eqy_timeout", True))

    def test_induction_failure_is_unknown_even_with_eqy_error_footer(self):
        self.put("check/strategies/top.y/sby/model/engine_0/logfile_induction.txt", "Assert failed\n")
        self.put("check/strategies/top.y/sby/status", "UNKNOWN")
        self.put("check/logfile.txt", "ERROR: A problem occurred during equivalence check.")
        self.assertEqual(v._classify_eqy(self.root, v.StageResult("eqy", returncode=2))[:2],
                         ("eqy_unknown", True))

    def test_basecase_is_partition_counterexample(self):
        self.put("check/strategies/top.y/sby/model/engine_0/logfile_basecase.txt", "Assert failed\n")
        self.assertEqual(v._classify_eqy(self.root, v.StageResult("eqy", returncode=2))[:2],
                         ("eqy_counterexample", True))

    def test_crash_invalid(self):
        self.assertEqual(v._classify_eqy(self.root, v.StageResult("eqy", returncode=-6))[:2],
                         ("eqy_tool_error", False))

    def test_strategy_error_invalid(self):
        self.put("check/strategies/top.y/sby/status", "ERROR")
        self.assertEqual(v._classify_eqy(self.root, v.StageResult("eqy", returncode=2))[:2],
                         ("eqy_tool_error", False))

    def test_pdr_counterexample(self):
        self.put("check/strategies/top.y/pdr/model/logfile.txt", "Status returned by engine: FAIL\n")
        self.assertEqual(v._classify_eqy(self.root, v.StageResult("eqy", returncode=2))[:2],
                         ("eqy_counterexample", True))

    def test_port_signature_includes_direction(self):
        path = self.put("ports.json", json.dumps({"modules": {"TOP_EQUIV": {"ports": {
            "a": {"direction": "inout", "bits": [2]}, "y": {"direction": "output", "bits": [3]}}}}}))
        with self.assertRaisesRegex(ValueError, "inout"):
            v._design_ports(path)

    def test_answer_wrapper_without_fence(self):
        self.assertEqual(v._extract_solution("<answer>module top; endmodule</answer>"), "module top; endmodule")

    def test_proof_uses_remaining_preparation_budget(self):
        calls = []
        ports = {"modules": {"TOP_EQUIV": {"ports": {"y": {"direction": "output", "bits": [2]}}}}}

        def fake_stage(name, cmd, cwd, timeout_s, env):
            calls.append((name, timeout_s))
            if name.startswith("prepare_"):
                for stem in ("solution", "ground_truth"):
                    (cwd / (stem + ".json")).write_text(json.dumps(ports))
                    (cwd / (stem + ".il")).write_text("prepared")
            if name == "eqy":
                (cwd / "check").mkdir()
                (cwd / "check" / "PASS").touch()
            return v.StageResult(name, returncode=0)

        # Start=0, deadline starts at 1, gold at 2, gate at 5, proof at 11.
        with patch.object(v, "_run_stage", side_effect=fake_stage), patch.object(
                v.time, "monotonic", side_effect=[0, 1, 2, 5, 11, 12]):
            result = v.verify_rtl_sample("module top(output y); assign y=0; endmodule",
                                         "module top(output y); assign y=0; endmodule",
                                         str(self.root), "budget", config=v.VerifierConfig(timeout_s=180))
        self.assertTrue(result.is_pass)
        self.assertEqual(calls, [("iverilog", v.IVERILOG_TIMEOUT_S), ("prepare_gold", 179),
                                 ("prepare_gate", 176), ("eqy", 170)])

    def test_successful_fallback_overrides_earlier_error(self):
        self.put("check/strategies/top.y/sby/status", "ERROR")
        self.put("check/strategies/top.y/pdr/status", "PASS")
        self.put("check/PASS", "")
        self.assertEqual(v._classify_eqy(self.root, v.StageResult("eqy", returncode=0))[:2], ("pass", True))

    def test_optional_backend_error_preserves_primary_unknown(self):
        self.put("check/strategies/top.y/sby/status", "UNKNOWN")
        self.put("check/strategies/top.y/pdr/status", "ERROR")
        result = v._classify_eqy(self.root, v.StageResult("eqy", returncode=2))
        self.assertEqual(result[:2], ("eqy_unknown", True))
        self.assertIn("fallback failed", result[2])
        self.put("check/strategies/top.z/sby/status", "ERROR")
        self.assertEqual(v._classify_eqy(self.root, v.StageResult("eqy", returncode=2))[:2],
                         ("eqy_tool_error", False))

    def test_missing_tool_is_not_candidate_syntax_error(self):
        with patch.object(v, "DEFAULT_OSS_CAD_BIN", "/nonexistent/eda"):
            result = v.verify_rtl_sample("module top; endmodule", "module top; endmodule",
                                         str(self.root), "missing")
        self.assertEqual(result.stage, "syntax_tool_error")
        self.assertFalse(result.reward_valid)

    def test_workspace_id_is_not_a_path(self):
        result = v.verify_rtl_sample("", "not verilog", str(self.root), "../../escape", True)
        self.assertEqual(Path(result.workspace).parent, self.root.resolve())
        self.assertFalse(result.reward_valid)

    def test_bad_reference_cleanup(self):
        result = v.verify_rtl_sample("", "not verilog", str(self.root), "bad")
        self.assertEqual(result.stage, "header_extract_fail")
        self.assertFalse(Path(result.workspace).exists())

    def test_subprocess_stdout_and_timeout(self):
        result = v._run_stage("ok", [sys.executable, "-c", "print('hello')"], self.root, 3, v._tool_env())
        self.assertEqual(result.returncode, 0)
        self.assertIn("hello", result.stdout_tail)
        result = v._run_stage("slow", [sys.executable, "-c", "import time; time.sleep(10)"],
                              self.root, .1, v._tool_env())
        self.assertTrue(result.timed_out)
        self.assertLess(result.duration_s, 5)


if __name__ == "__main__":
    unittest.main()
