"""The verification controller must never touch an audit-lane group: _group_views flags it and the loop only logs a
shadow decision for it (torch-free: calls _group_views unbound)."""
import sys
import types
from types import SimpleNamespace

for name in ("roll", "roll.utils", "roll.utils.logging", "roll.utils.event_log"):
    if name not in sys.modules:
        sys.modules[name] = types.ModuleType(name)
import logging
sys.modules["roll.utils.logging"].get_logger = lambda: logging.getLogger("test")
sys.modules["roll.utils.event_log"].sched_event = lambda **kw: None

from applications.rtl import verify_controller as vc  # noqa: E402
from applications.rtl.verify_governor import VerifyQueueGovernor  # noqa: E402


def _job(state, audit, t_dispatch=90.0):
    return SimpleNamespace(state=state, t_dispatch=t_dispatch, req=SimpleNamespace(meta_info={"member_index": 0, "audit": audit}))


def test_group_views_flag_audit_groups(monkeypatch):
    import time
    monkeypatch.setattr(time, "time", lambda: 100.0)
    gov = SimpleNamespace(_vc=vc, group_size=4, group_rewards={1: [0.0], 2: [0.0]}, group_pass={1: [False], 2: [False]},
                          active_jobs={1: [_job("running", False), _job("queued", False, None)],
                                       2: [_job("running", True), _job("running", True)],
                                       3: [_job("done", False)]})
    views = list(VerifyQueueGovernor._group_views(gov))
    assert [(v.prompt_id, audit) for v, audit in views] == [(1, False), (2, True)]   # 3 has no active checks
    assert views[0][0].active_ages == [10.0, 0.0]


def test_cancel_cost_reaches_the_selector(monkeypatch):
    """_cancel_job charges the selector the running seconds of a cancelled (not released) check."""
    import asyncio, time
    monkeypatch.setattr(time, "time", lambda: 100.0)
    noted = []
    sel = SimpleNamespace(note_cancel_cost=lambda d, s: noted.append((d, s)))
    loop = asyncio.new_event_loop()
    fut = loop.create_future()
    job = SimpleNamespace(state="running", domain="rtl", prompt_id=7, dataset_id="d7", member_index=0, rollout_id="r",
                          t_submit=50.0, t_dispatch=70.0, worker=SimpleNamespace(), future=fut, seq=1, req=SimpleNamespace(meta_info={}))
    gov = SimpleNamespace(scheduler=SimpleNamespace(admission_policy=sel), pending={"rtl": []}, _log=lambda **kw: None,
                          _forget=lambda j: None)
    VerifyQueueGovernor._cancel_job(gov, job, reason="controller_abandon")
    assert noted == [("d7", 30.0)] and fut.cancelled()
    loop.close()
