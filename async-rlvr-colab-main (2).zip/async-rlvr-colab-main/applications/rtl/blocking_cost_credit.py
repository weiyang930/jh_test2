"""Driver-side D_local credit: turn the observed rollout events into ``cost_advantages``.

Runs in the pipeline driver after a learner batch is received and before any
learner-side forward pass.  It reads the scheduler's ``events.jsonl`` (all
verification jobs, not only those in this batch, so worker chains are complete),
rebuilds the fixed max-plus timeline, computes D_local per batch sample, and
writes within-class cost advantages into the batch.  Every step is logged to
``cost_credit_events.jsonl`` (per sample) and ``learner_events.jsonl`` (driver
timestamps) so the same computation can be replayed offline.
"""
from __future__ import annotations

import json
import os
import time
from typing import Dict, List, Optional

import numpy as np
import torch

from applications.rtl.blocking_cost import (
    Group, Job, Timeline, compute_batch_credit, within_class_weights,
)


class BlockingCostCredit:
    """Incremental event reader + per-batch D_local annotator."""

    def __init__(self, output_dir: str, epsilon: float, eta: float, cost_scale: float,
                 classes: List[str], group_size: int, window_s: float = 3600.0):
        self.output_dir = output_dir
        self.epsilon, self.eta, self.cost_scale = epsilon, eta, cost_scale
        self.classes, self.group_size, self.window_s = list(classes), group_size, window_s
        os.makedirs(output_dir, exist_ok=True)
        self.events_path = os.path.join(output_dir, 'events.jsonl')
        self._events_fh = None
        self._jobs: Dict[tuple, Job] = {}
        self._groups: Dict[int, Group] = {}
        self._credit_fh = open(os.path.join(output_dir, 'cost_credit_events.jsonl'), 'a', encoding='utf-8')
        self._learner_fh = open(os.path.join(output_dir, 'learner_events.jsonl'), 'a', encoding='utf-8')
        self.t_request: Optional[float] = None
        self.t_receive: Optional[float] = None
        self.current_step: int = -1

    # ---------------------------------------------------------------- driver marks
    def mark(self, event: str, **fields) -> float:
        now = time.time()
        rec = dict(event=event, step=self.current_step, ts=now, **fields)
        self._learner_fh.write(json.dumps(rec) + '\n')
        self._learner_fh.flush()
        if event == 'learner_request':
            self.t_request = now
        elif event == 'batch_received':
            self.t_receive = now
        return now

    # ---------------------------------------------------------------- event ingest
    def _ingest(self) -> None:
        if self._events_fh is None:
            if not os.path.exists(self.events_path):
                return
            self._events_fh = open(self.events_path, 'r', encoding='utf-8')
        while True:
            line = self._events_fh.readline()
            if not line:
                break
            if not line.endswith('\n'):
                # partial line: rewind and retry next time
                self._events_fh.seek(self._events_fh.tell() - len(line))
                break
            try:
                ev = json.loads(line)
            except json.JSONDecodeError:
                continue
            kind = ev.get('event')
            if kind == 'sample_done' and ev.get('verify_worker') not in (None, '?'):
                key = (int(ev['prompt_id']), int(ev['member_index']))
                self._jobs[key] = Job(
                    key=key, worker=str(ev['verify_worker']), release=float(ev['t_reward_submit']),
                    start=float(ev['t_worker_start']), end=float(ev['t_worker_end']),
                    ret=float(ev['t_reward_return']), reward=float(ev.get('reward', float('nan'))),
                    stage=str(ev.get('verifier_stage', '?')), valid=bool(ev.get('reward_valid', True)))
            elif kind == 'prompt_commit':
                pid = int(ev['prompt_id'])
                n = int(ev.get('group_size', self.group_size))
                self._groups[pid] = Group(pid, [(pid, i) for i in range(n)], float(ev['t_commit']))

    def _prune(self, before: float) -> None:
        self._jobs = {k: j for k, j in self._jobs.items() if j.start >= before}
        self._groups = {p: g for p, g in self._groups.items() if g.t_commit >= before}

    # ---------------------------------------------------------------- annotate
    def annotate(self, batch, global_step: int) -> Dict[str, float]:
        """Attach ``cost_advantages`` (B, L-1) and per-sample credit columns; return metrics."""
        self.current_step = global_step
        t0 = time.time()
        self._ingest()
        ntb = batch.non_tensor_batch
        n = batch.batch.batch_size[0]
        prompt_ids = [int(x) for x in np.asarray(ntb['group_id']).flatten()]
        members = [int(x) for x in np.asarray(ntb['group_member_index']).flatten()]
        rewards = batch.batch['scores'].detach().cpu().float().numpy().reshape(-1)
        stages = [str(x) for x in np.asarray(ntb.get('verifier_stage', ['?'] * n)).flatten()]
        valids = [bool(x) for x in np.asarray(ntb.get('reward_valid', [True] * n)).flatten()]
        keys = list(zip(prompt_ids, members))

        unmatched = [k for k in keys if k not in self._jobs]
        for key, pid, m in zip(keys, prompt_ids, members):
            # fall back to the batch's own timing columns when the event is missing
            if key in self._jobs:
                continue
            idx = keys.index(key)
            self._jobs[key] = Job(
                key=key, worker=str(np.asarray(ntb.get('verify_worker', ['?'] * n)).flatten()[idx]),
                release=float(np.asarray(ntb['t_reward_submit']).flatten()[idx]),
                start=float(np.asarray(ntb['t_worker_start']).flatten()[idx]),
                end=float(np.asarray(ntb['t_worker_end']).flatten()[idx]),
                ret=float(np.asarray(ntb['t_reward_return']).flatten()[idx]),
                reward=float(rewards[idx]), stage=stages[idx], valid=valids[idx])
        batch_groups: Dict[int, Group] = {}
        for pid in dict.fromkeys(prompt_ids):
            member_keys = sorted(k for k in keys if k[0] == pid)
            if pid in self._groups:
                grp = self._groups[pid]
                grp = Group(pid, member_keys, grp.t_commit)
            else:
                grp = Group(pid, member_keys, max(self._jobs[k].ret for k in member_keys))
            batch_groups[pid] = grp

        t_request = self.t_request if self.t_request is not None else min(self._jobs[k].release for k in keys)
        t_receive = self.t_receive if self.t_receive is not None else time.time()
        window_start = min(self._jobs[k].release for k in keys) - 120.0
        timeline_jobs = [j for j in self._jobs.values() if window_start <= j.start <= t_receive]
        timeline = Timeline.build(timeline_jobs)
        credit = compute_batch_credit(timeline, list(batch_groups.values()), t_request, self.epsilon)

        samples = [dict(key=k, group_id=k[0], reward=float(r), stage=s, valid=v,
                        effective_cost=credit.effective_cost.get(k, 0.0))
                   for k, r, s, v in zip(keys, rewards, stages, valids)]
        weights = within_class_weights(samples, self.eta, self.cost_scale, self.classes)

        seq_len = batch.batch['response_mask'].shape[1]
        adv_rows = torch.tensor([weights.advantage[k] for k in keys], dtype=torch.float32)
        batch.batch['cost_advantages'] = adv_rows.unsqueeze(1).expand(n, seq_len - 1).contiguous()
        for name, values in [
            ('d_local', [credit.d_local.get(k, 0.0) for k in keys]),
            ('effective_cost', [credit.effective_cost.get(k, 0.0) for k in keys]),
            ('raw_verifier_cost', [credit.raw_cost.get(k, self._jobs[k].service) for k in keys]),
            ('cost_weight', [weights.weight[k] for k in keys]),
            ('cost_class_size', [weights.class_size[k] for k in keys]),
        ]:
            ntb[name] = np.array(values, dtype=object)

        eligible_groups = {k[0] for k in keys if weights.class_size[k] >= 2}
        nonzero_d = sum(1 for k in keys if credit.d_local.get(k, 0.0) > 0)
        nonzero_adv = sum(1 for k in keys if abs(weights.advantage[k]) > 1e-9)
        elapsed = time.time() - t0
        metrics = {
            'cost/learner_wait_s': credit.learner_wait_s,
            'cost/verification_attributable_s': credit.verification_attributable_s,
            'cost/t_receive_minus_t_b_s': t_receive - credit.t_b,
            'cost/replay_calibration_err_s': credit.calibration_max_abs_err_s,
            'cost/negative_slack_jobs': float(credit.negative_slack_jobs),
            'cost/timeline_jobs': float(len(timeline_jobs)),
            'cost/unmatched_batch_jobs': float(len(unmatched)),
            'cost/d_nonzero_samples': float(nonzero_d),
            'cost/d_nonzero_frac': nonzero_d / max(n, 1),
            'cost/d_sum_s': float(sum(credit.d_local.values())),
            'cost/weighted_samples': float(weights.n_weighted),
            'cost/weighted_classes': float(weights.n_classes),
            'cost/adv_nonzero_samples': float(nonzero_adv),
            'cost/eligible_group_frac': len(eligible_groups) / max(len(batch_groups), 1),
            'cost/annotate_cpu_s': elapsed,
        }
        summary = dict(event='batch_credit', step=global_step, t_request=t_request, t_receive=t_receive,
                       t_b=credit.t_b, t_b_all_half=credit.t_b_all_half, n_samples=n,
                       n_groups=len(batch_groups), unmatched=[list(k) for k in unmatched], **metrics)
        self._credit_fh.write(json.dumps(summary) + '\n')
        for k, s in zip(keys, samples):
            job = self._jobs[k]
            self._credit_fh.write(json.dumps(dict(
                event='sample_credit', step=global_step, prompt_id=k[0], member_index=k[1], worker=job.worker,
                reward=s['reward'], stage=s['stage'], valid=s['valid'], release=job.release, start=job.start,
                end=job.end, ret=job.ret, raw_cost=job.service, d_local=credit.d_local.get(k, 0.0),
                effective_cost=credit.effective_cost.get(k, 0.0), on_critical=bool(credit.on_critical.get(k, False)),
                weight=weights.weight[k], advantage=weights.advantage[k], class_size=weights.class_size[k])) + '\n')
        self._credit_fh.flush()
        self._prune(window_start - self.window_s)
        return metrics
