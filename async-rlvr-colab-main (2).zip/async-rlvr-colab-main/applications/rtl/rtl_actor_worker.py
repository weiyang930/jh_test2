"""Actor worker for the RTL baseline: adds the reference "80/20" entropy mask.

The historical RTL runs (archer-LLM verl, ``use_entropy_mask=True``,
``token_entropy_quantile=0.8``) restrict the policy-gradient AND kl losses to
the top-(1-q) highest-entropy response tokens per sequence
(``dp_actor.py:420``: ``low_entropy_mask = (masked_entropy > q80) & response_mask``,
then ``response_mask = low_entropy_mask``).

This subclass reproduces that inside ROLL via the ``actor_train.worker_cls``
extension point: entropy of the current forward pass is computed per microbatch
(same as verl, which recomputes it each PPO epoch/minibatch), the per-sequence
0.8-quantile is taken over ``final_response_mask`` tokens, and
``final_response_mask`` is replaced by the top-entropy mask before delegating to
the stock ROLL loss.  Denominators for token-mean aggregation are switched to
the local masked token count (``batch_num_tokens=None``), matching verl's
per-microbatch token-mean aggregation.

No other loss semantics are changed.
"""
import torch

from roll.distributed.scheduler.protocol import DataProto
from roll.pipeline.rlvr.actor_worker import ActorWorker

RTL_TOKEN_ENTROPY_QUANTILE = 0.8


class RTLActorWorker(ActorWorker):

    def loss_func(self, data: DataProto, output_tensor: torch.Tensor):
        response_mask = data.batch["response_mask"][:, 1:].long()
        final_response_mask = data.batch.get("final_response_mask", response_mask).long()

        with torch.no_grad():
            entropy = self.strategy.op_compute_entropy(
                logits=output_tensor, attention_mask=data.batch["response_mask"]
            ).detach()
            masked_entropy = torch.where(
                final_response_mask.bool(), entropy.float(), torch.nan
            )
            q = torch.nanquantile(
                masked_entropy, q=RTL_TOKEN_ENTROPY_QUANTILE, dim=-1, keepdim=True
            )
            # top-(1-q) highest-entropy tokens; rows with empty mask (all-nan) -> all False
            high_entropy_mask = (masked_entropy > q) & final_response_mask.bool()

        data.batch["final_response_mask"] = high_entropy_mask.long()
        # token-mean over the entropy-restricted mask uses local token counts
        # (verl aggregates per microbatch); keep other keys' global counts.
        # clamp(min=1) guards microbatches whose rows are all difficulty-masked
        # (verl physically dropped such rows; here they must contribute 0, not 0/0).
        batch_num_tokens = dict(data.meta_info["batch_num_tokens"])
        batch_num_tokens["final_response_mask"] = high_entropy_mask.long().sum().clamp(min=1)
        data.meta_info["batch_num_tokens"] = batch_num_tokens
        global_valid_samples = dict(data.meta_info["global_valid_samples"])
        global_valid_samples.setdefault("final_response_mask", global_valid_samples["response_mask"])
        data.meta_info["global_valid_samples"] = global_valid_samples

        return super().loss_func(data, output_tensor)
