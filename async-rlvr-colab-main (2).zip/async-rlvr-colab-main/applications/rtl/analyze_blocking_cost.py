"""Summarise a blocking-cost run: gate B, step timing, C-vs-D_local ranking, aux signal."""
import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path

import numpy as np


def load_jsonl(path: Path) -> list:
    if not path.exists():
        return []
    return [json.loads(l) for l in path.open() if l.strip()]


def spearman(x, y) -> float:
    if len(x) < 3:
        return float('nan')
    rx, ry = np.argsort(np.argsort(x)), np.argsort(np.argsort(y))
    return float(np.corrcoef(rx, ry)[0, 1])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('output_dir', type=Path)
    ap.add_argument('--steady-from', type=int, default=2, help='first step counted as steady state')
    ap.add_argument('--out', type=Path, default=None)
    args = ap.parse_args()
    out = args.output_dir
    credits = load_jsonl(out / 'cost_credit_events.jsonl')
    learner = load_jsonl(out / 'learner_events.jsonl')
    batches = [c for c in credits if c['event'] == 'batch_credit']
    samples = [c for c in credits if c['event'] == 'sample_credit']

    step_end = {e['step']: e for e in learner if e['event'] == 'step_end'}
    requests = {e['step']: e['ts'] for e in learner if e['event'] == 'learner_request'}
    received = {e['step']: e['ts'] for e in learner if e['event'] == 'batch_received'}
    train_start = {e['step']: e['ts'] for e in learner if e['event'] == 'train_start'}
    steps = sorted(step_end)
    per_step = []
    for s in steps:
        b = next((x for x in batches if x['step'] == s), None)
        prev_end = step_end[s - 1]['ts'] if s - 1 in step_end else None
        per_step.append(dict(
            step=s, step_wall_s=(step_end[s]['ts'] - prev_end) if prev_end else None,
            wait_s=(received[s] - requests[s]) if s in requests and s in received else None,
            train_s=(step_end[s]['ts'] - train_start[s]) if s in train_start else None,
            learner_wait_s=b['cost/learner_wait_s'] if b else None,
            verif_attr_s=b['cost/verification_attributable_s'] if b else None,
            calib_err_s=b['cost/replay_calibration_err_s'] if b else None,
            t_receive_minus_t_b=b['cost/t_receive_minus_t_b_s'] if b else None,
            d_nonzero=b['cost/d_nonzero_samples'] if b else None,
            weighted=b['cost/weighted_samples'] if b else None,
            adv_nonzero=b['cost/adv_nonzero_samples'] if b else None,
            unmatched=b['cost/unmatched_batch_jobs'] if b else None,
            annotate_s=b['cost/annotate_cpu_s'] if b else None,
        ))
    steady = [p for p in per_step if p['step'] >= args.steady_from and p['learner_wait_s'] is not None]
    n_steady = len(steady)
    gate_b = dict(
        steady_steps=n_steady,
        frac_steps_with_wait=sum(p['learner_wait_s'] > 0 for p in steady) / max(n_steady, 1),
        frac_wait_steps_verif_attr_ge_20pct=(sum(p['verif_attr_s'] >= 0.2 * p['learner_wait_s'] for p in steady if p['learner_wait_s'] > 0)
                                             / max(sum(p['learner_wait_s'] > 0 for p in steady), 1)),
        median_d_nonzero_in_class=float(np.median([p['adv_nonzero'] for p in steady])) if steady else None,
        frac_steps_adv_nonzero_ge_8=sum(p['adv_nonzero'] >= 8 for p in steady) / max(n_steady, 1),
        max_calibration_err_s=max((p['calib_err_s'] for p in steady), default=None),
        max_t_receive_minus_t_b=max((p['t_receive_minus_t_b'] for p in steady), default=None),
        mean_step_wall_s=float(np.mean([p['step_wall_s'] for p in steady if p['step_wall_s']])) if steady else None,
        mean_wait_s=float(np.mean([p['wait_s'] for p in steady if p['wait_s'] is not None])) if steady else None,
        mean_train_s=float(np.mean([p['train_s'] for p in steady if p['train_s'] is not None])) if steady else None,
    )
    gate_b['passes'] = bool(n_steady and gate_b['frac_steps_with_wait'] >= 0.5
                            and gate_b['frac_wait_steps_verif_attr_ge_20pct'] >= 0.2
                            and gate_b['frac_steps_adv_nonzero_ge_8'] >= 0.5)

    crit = [s for s in samples if s['d_local'] > 0]
    by_stage = defaultdict(list)
    for s in samples:
        by_stage[s['stage']].append(s)
    ranking = dict(
        n_samples=len(samples), n_critical=len(crit), critical_frac=len(crit) / max(len(samples), 1),
        spearman_raw_vs_effective_all=spearman([s['raw_cost'] for s in samples], [s['effective_cost'] for s in samples]),
        spearman_raw_vs_effective_critical=spearman([s['raw_cost'] for s in crit], [s['effective_cost'] for s in crit]),
        critical_by_stage={st: sum(x['d_local'] > 0 for x in v) / len(v) for st, v in by_stage.items()},
        raw_cost_p50_by_stage={st: float(np.median([x['raw_cost'] for x in v])) for st, v in by_stage.items()},
        adv_abs_mean_weighted=float(np.mean([abs(s['advantage']) for s in samples if s['class_size'] >= 2])) if any(s['class_size'] >= 2 for s in samples) else 0.0,
        adv_abs_max=max((abs(s['advantage']) for s in samples), default=0.0),
        weighted_frac=sum(s['class_size'] >= 2 for s in samples) / max(len(samples), 1),
        weighted_by_stage={st: sum(x['class_size'] >= 2 for x in v) / len(v) for st, v in by_stage.items()},
    )
    report = dict(output_dir=str(out), per_step=per_step, gate_b=gate_b, ranking=ranking)
    text = json.dumps(report, indent=2, default=float)
    if args.out:
        args.out.write_text(text + '\n')
    print(json.dumps(dict(gate_b=gate_b, ranking=ranking), indent=2, default=float))
    for p in per_step:
        print({k: (round(v, 2) if isinstance(v, float) else v) for k, v in p.items()})


if __name__ == '__main__':
    main()
