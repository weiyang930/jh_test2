"""Central verification-queue governor (E2 allocator, semantics-preserving arms).

Today ROLL round-robins each sample's reward request straight onto a worker
actor's own Ray queue: assignment is blind, per-worker FIFO suffers head-of-line
blocking, and nothing can be re-prioritized once submitted (64.1% of groups have
all four verifications submitted before the first reward returns).

The governor interposes a single pending queue per domain: jobs wait centrally,
one job runs per worker, and every dispatch decision re-reads the group's
partial state (rewards observed so far), the predictor's utility and the
predicted verification cost. Every job eventually runs - reordering only, so
n=4 GRPO group semantics are untouched (cancellation is a separate variant).

Dispatch policies:
  fifo   submit order (control arm - still through the governor so latency
         accounting and logs are identical across arms)
  joint  c-mu-rule index: value / (lam + cost_hat), where value = 1.0 once the
         group is already determined informative (finish it fast: it will be
         consumed) and otherwise the admission-style utility U(x); cost_hat
         from the pretrained cost head.

Audit (per the design spec): decisions carry a known exploration probability -
with prob epsilon the dispatched job is drawn uniformly from the pending set,
and every decision logs its action probability, so completion propensities are
randomized-and-logged rather than deterministic.

Cancellation (decoupled consumption): ``cancel(prompt_id)`` drops that prompt's
queued jobs and kills its running ones through the worker's
``cancel_verification`` (see CodeVRewardWorker); a job whose awaiting rollout
task is cancelled (ReplayBuffer.gc -> task.cancel) takes the same path from
``submit``. Cancelled jobs never enter ``group_rewards`` and their futures are
resolved as cancelled, so the rollout task can never commit them.

Partial release (controller ``ctrl_release`` slow | index): ``release(prompt_id)`` cancels the remaining checks of an
already informative group like ``cancel`` but resolves their futures with a placeholder verdict (``released_verdict``:
reward_valid False, verifier_stage "released"), so the rollout task commits the group with its verified members and
the learner masks the released rows (rtl_rollout_loop.fill_released_members, functionals member_filler).
"""
import asyncio
import json
import math
import os
import pickle
import random
import time
from types import SimpleNamespace
from typing import Dict, List, Optional

import numpy as np

from roll.utils.event_log import sched_event
from roll.utils.logging import get_logger

logger = get_logger()


class ScoreBundle:
    """Pretrained TF-IDF + difficulty heads + cost head (built from E1 logs)."""

    def __init__(self, path: str):
        with open(path, "rb") as fh:
            b = pickle.load(fh)
        self.tfidf = b["tfidf"]
        self.clf_easy, self.clf_hard = b["clf_easy"], b["clf_hard"]
        self.cost_reg = b["cost_reg"]
        self.cost_mean, self.cost_std = b["cost_norm"]

    def score(self, text: str):
        X = self.tfidf.transform([text])
        p_easy = float(self.clf_easy.predict_proba(X)[0, 1])
        p_hard = float(self.clf_hard.predict_proba(X)[0, 1])
        cost_hat = float(np.expm1(self.cost_reg.predict(X)[0]))
        return {"utility": 1.0 - p_easy - p_hard, "p_easy": p_easy, "p_hard": p_hard,
                "cost_hat": max(cost_hat, 0.01),
                "cost_norm": (cost_hat - self.cost_mean) / (self.cost_std + 1e-9)}


def _req_text(req) -> str:
    ntb = req.non_tensor_batch
    msg = str(np.asarray(ntb.get("messages", ["?"])).flatten()[0])
    if msg.startswith("["):
        try:
            msg = json.loads(msg)[-1]["content"]
        except Exception:
            pass
    gt = str(np.asarray(ntb.get("ground_truth", [""])).flatten()[0])
    return msg + "\n" + gt


RELEASED_STAGE = "released"


def released_verdict(req, elapsed_s: float):
    """Placeholder verdict for a member whose check was released (never trained on: reward_valid=False)."""
    now = time.time()
    non_tensors = dict(verifier_stage=np.array([RELEASED_STAGE], dtype=object), reward_valid=np.array([False], dtype=object),
                       verifier_cpu_core_seconds=np.array([float(elapsed_s)], dtype=object),
                       t_worker_start=np.array([now - elapsed_s], dtype=object), t_worker_end=np.array([now], dtype=object),
                       verify_worker=np.array([RELEASED_STAGE], dtype=object))
    responses = req.batch.get("responses") if hasattr(req.batch, "get") else None
    try:
        import torch
        from roll.distributed.scheduler.protocol import DataProto
    except ImportError:  # unit tests without torch
        torch = DataProto = None
    if torch is not None and isinstance(responses, torch.Tensor):
        scores = torch.zeros(responses.shape[0], dtype=torch.float32)
        return DataProto.from_dict(tensors=dict(token_level_rewards=torch.zeros_like(responses, dtype=torch.float32),
                                                response_level_rewards=scores, scores=scores.clone()), non_tensors=non_tensors)
    return SimpleNamespace(batch={"response_level_rewards": [0.0], "scores": [0.0]}, non_tensor_batch=non_tensors)


def _req_field(req, key: str, default):
    """First element of a non_tensor_batch column, or ``default`` when absent (test fakes carry few columns)."""
    values = req.non_tensor_batch.get(key)
    return default if values is None else np.asarray(values).flatten()[0]


class _Job:
    __slots__ = ("seq", "req", "domain", "prompt_id", "dataset_id", "future", "t_submit", "scores",
                 "state", "worker", "t_dispatch", "rollout_id", "member_index")

    def __init__(self, seq, req, domain, prompt_id, dataset_id, scores):
        self.seq, self.req, self.domain = seq, req, domain
        self.prompt_id, self.dataset_id = prompt_id, dataset_id
        self.future = asyncio.get_running_loop().create_future()
        self.t_submit = time.time()
        self.scores = scores
        self.state = "queued"  # queued | running | done | cancelled | released
        self.worker = None
        self.t_dispatch = None
        self.rollout_id = str(_req_field(req, "rollout_id", f"seq{seq}"))
        self.member_index = getattr(req, "meta_info", {}).get("member_index")


class VerifyQueueGovernor:
    """One pending queue + one-in-flight-per-worker dispatch, per domain."""

    def __init__(self, scheduler, pipeline_config, policy: str = "fifo", epsilon: float = 0.1,
                 lam: float = 1.0, bundle_path: Optional[str] = None, seed: Optional[int] = None,
                 group_size: int = 4, controller: str = "none", ctrl_lambda: float = 1e-3, ctrl_kappa: float = 1e-3,
                 ctrl_theta: float = 0.1, ctrl_tables: Optional[str] = None, ctrl_interval_s: float = 2.0,
                 ctrl_min_age_s: float = 2.0, ctrl_min_obs: int = 0, ctrl_release: str = "none",
                 ctrl_release_frac: float = 0.75, ctrl_release_slow_s: float = 30.0, price_tracker: bool = False):
        """price_tracker: with controller="none", still run the price loop (kappa * EMA(queued / workers)) so a
        selector with price="shared" reads the same dynamic price as it would under the full arm (selector-only ablation)."""
        assert policy in ("fifo", "joint"), policy
        from applications.rtl import verify_controller as vc
        assert controller in vc.MODES, controller
        assert ctrl_release in vc.RELEASE_MODES, ctrl_release
        self.controller = controller
        self.price_tracker = bool(price_tracker)
        self.ctrl_release, self.ctrl_release_frac, self.ctrl_release_slow_s = ctrl_release, float(ctrl_release_frac), float(ctrl_release_slow_s)
        self.ctrl_lambda, self.ctrl_kappa, self.ctrl_theta = float(ctrl_lambda), float(ctrl_kappa), float(ctrl_theta)
        self.ctrl_interval_s, self.ctrl_min_age_s, self.ctrl_min_obs = float(ctrl_interval_s), float(ctrl_min_age_s), int(ctrl_min_obs)
        self.ctrl_tables = vc.Tables.load(ctrl_tables) if (controller != "none" and ctrl_tables) else None
        if controller != "none":
            assert self.ctrl_tables is not None, "controller needs ctrl_tables (fit_controller_tables.py output)"
        self._vc = vc
        self._price = vc.PriceTracker(self.ctrl_kappa)
        self._ctrl_task = None
        self._ctrl_stats = {"decisions": 0, "abandoned": 0, "continued": 0, "released": 0, "shadow_abandoned": 0}
        self._shadow_flagged: set = set()   # audit groups whose shadow abandon was already logged
        # the price the controller is using right now (const: lambda; dynamic: the backlog price), read by the
        # admission policy when it runs with price="shared" (one price for admission and stopping)
        self.current_price = (0.0 if price_tracker else None) if controller == "none" else (self.ctrl_lambda if controller in ("const", "posterior") else 0.0)
        self.policy = policy
        self.epsilon = epsilon
        self.lam = lam
        self.group_size = group_size
        self.rng = random.Random(int(seed if seed is not None else getattr(pipeline_config, "seed", 42)))
        self.bundle = ScoreBundle(bundle_path) if bundle_path else None
        if policy == "joint":
            assert self.bundle is not None, "joint policy needs a pretrained score bundle"

        self.pending: Dict[str, List[_Job]] = {}
        self.free_workers: Dict[str, List] = {}
        self.active_jobs: Dict[int, List[_Job]] = {}  # prompt_id -> queued + running jobs
        self.group_rewards: Dict[int, List[float]] = {}
        self.group_pass: Dict[int, List[bool]] = {}     # verifier verdicts, parallel to group_rewards
        self._score_cache: Dict[int, dict] = {}
        self._seq = 0

        self.scheduler = scheduler
        for domain, cluster in scheduler.reward_clusters.items():
            self.pending[domain] = []
            self.free_workers[domain] = list(cluster.workers)

        out_dir = getattr(pipeline_config, "output_dir", None) or "."
        os.makedirs(out_dir, exist_ok=True)
        self._fh = open(os.path.join(out_dir, "verify_queue_events.jsonl"), "a", encoding="utf-8")
        self._log(event="governor_init", policy=policy, epsilon=epsilon, lam=lam, controller=controller,
                  ctrl_release=ctrl_release, ctrl_release_frac=self.ctrl_release_frac, ctrl_release_slow_s=self.ctrl_release_slow_s,
                  ctrl_lambda=self.ctrl_lambda, ctrl_kappa=self.ctrl_kappa, ctrl_theta=self.ctrl_theta,
                  ctrl_tables=getattr(self.ctrl_tables, "source", None), ctrl_interval_s=self.ctrl_interval_s,
                  workers={d: len(w) for d, w in self.free_workers.items()},
                  bundle=bool(self.bundle))
        logger.info(f"VerifyQueueGovernor: policy={policy} eps={epsilon} "
                    f"workers={ {d: len(w) for d, w in self.free_workers.items()} }")

    def _log(self, **event):
        event["ts"] = time.time()
        self._fh.write(json.dumps(event, ensure_ascii=False) + "\n")
        self._fh.flush()

    # ------------------------------------------------------------------ scoring
    def _job_scores(self, prompt_id: int, req) -> dict:
        if prompt_id not in self._score_cache:
            if self.bundle is None:
                self._score_cache[prompt_id] = {"utility": 0.0, "cost_hat": 1.0, "cost_norm": 0.0,
                                                "p_easy": None, "p_hard": None}
            else:
                self._score_cache[prompt_id] = self.bundle.score(_req_text(req))
        return self._score_cache[prompt_id]

    def _priority(self, job: _Job) -> float:
        if self.policy == "fifo":
            return -job.seq
        obs = self.group_rewards.get(job.prompt_id, [])
        determined = len(set(obs)) > 1
        value = 1.0 if determined else max(job.scores["utility"], 0.05)
        return value / (self.lam + job.scores["cost_hat"])

    # ------------------------------------------------------------------ dispatch
    def _pump(self, domain: str):
        while self.free_workers[domain]:
            self._drop_dead_pending(domain)
            pend = self.pending[domain]
            if not pend:
                return
            prios = [self._priority(j) for j in pend]
            best = int(np.argmax(prios))
            explored = self.rng.random() < self.epsilon and len(pend) > 1
            idx = self.rng.randrange(len(pend)) if explored else best
            action_prob = (0.0 if explored and idx != best else (1 - self.epsilon)) + self.epsilon / len(pend)
            job = pend.pop(idx)
            worker = self.free_workers[domain].pop()
            job.state, job.worker, job.t_dispatch = "running", worker, time.time()
            self._log(event="dispatch", policy=self.policy, domain=domain, seq=job.seq,
                      prompt_id=job.prompt_id, dataset_id=job.dataset_id,
                      n_pending=len(pend) + 1, explored=explored, action_prob=action_prob,
                      priority=self._priority(job), utility=job.scores["utility"],
                      cost_hat=job.scores["cost_hat"],
                      group_observed=list(self.group_rewards.get(job.prompt_id, [])),
                      queue_wait_s=time.time() - job.t_submit)
            asyncio.ensure_future(self._run(job, worker, domain))

    def _drop_dead_pending(self, domain: str):
        """Queued jobs whose awaiter already went away (future cancelled) must never reach a worker."""
        for job in list(self.pending[domain]):
            if job.future.done():
                self._cancel_job(job, reason="awaiter_gone")

    async def _run(self, job: _Job, worker, domain: str):
        try:
            result = await worker.compute_rewards.remote(job.req)
            if job.state in ("cancelled", "released"):
                return  # killed child's placeholder verdict: never observed, never delivered
            reward = float(result.batch["response_level_rewards"][0])
            self.group_rewards.setdefault(job.prompt_id, []).append(reward)
            stage = str(result.non_tensor_batch.get("verifier_stage", ["?"])[0]) if hasattr(result, "non_tensor_batch") else "?"
            self.group_pass.setdefault(job.prompt_id, []).append(stage == "pass" if stage != "?" else reward >= 1.0)
            job.state = "done"
            if not job.future.done():
                job.future.set_result(result)
        except Exception as exc:  # surface to the awaiting rollout task
            if job.state not in ("cancelled", "released") and not job.future.done():
                job.future.set_exception(exc)
        finally:
            self.free_workers[domain].append(worker)
            self._forget(job)
            self._pump(domain)

    def _forget(self, job: _Job):
        """Drop a finished/cancelled job from the per-prompt registry; free group state once it cannot grow."""
        jobs = self.active_jobs.get(job.prompt_id, [])
        if job in jobs:
            jobs.remove(job)
        complete = len(self.group_rewards.get(job.prompt_id, [])) >= self.group_size
        if not jobs and (complete or job.state in ("cancelled", "released")):
            self.active_jobs.pop(job.prompt_id, None)
            self.group_rewards.pop(job.prompt_id, None)
            self.group_pass.pop(job.prompt_id, None)
            self._score_cache.pop(job.prompt_id, None)

    # ------------------------------------------------------------------ cancellation
    def _cancel_job(self, job: _Job, reason: str, release: bool = False):
        if job.state in ("done", "cancelled", "released"):
            return
        previous_state = job.state
        job.state = "released" if release else "cancelled"
        if previous_state == "queued":
            self.pending[job.domain].remove(job)
            self._forget(job)
        else:
            # running: kill the worker's child; its placeholder verdict is dropped by _run, which then
            # frees the worker and forgets the job
            cancel = getattr(job.worker, "cancel_verification", None)
            if cancel is not None:
                cancel.remote(job.rollout_id)
        running_s = None if job.t_dispatch is None else time.time() - job.t_dispatch
        if not release and running_s:
            note = getattr(getattr(self, "scheduler", None), "admission_policy", None)
            note = getattr(note, "note_cancel_cost", None)
            if note is not None:
                note(job.dataset_id, running_s)   # the selector charges the cancelled group its verifier-seconds
        if not job.future.done():
            if release:
                job.future.set_result(released_verdict(job.req, running_s or 0.0))
            else:
                job.future.cancel()
        record = dict(seq=job.seq, domain=job.domain, prompt_id=job.prompt_id, dataset_id=job.dataset_id,
                      member_index=job.member_index, rollout_id=job.rollout_id, state=previous_state,
                      elapsed_s=time.time() - job.t_submit, running_s=running_s, reason=reason)
        self._log(event="release" if release else "cancel", **record)
        sched_event(event="verify_release" if release else "verify_cancel", **record)  # no-op unless ROLL_SCHED_EVENT_FILE is set

    def cancel(self, prompt_id: int, reason: str = "stale_gc") -> int:
        """Cancel every queued/running verification job of ``prompt_id``; return how many were cancelled."""
        jobs = list(self.active_jobs.get(prompt_id, []))
        for job in jobs:
            self._cancel_job(job, reason=reason)
        return len(jobs)

    def release(self, prompt_id: int, reason: str = "controller_release") -> int:
        """Partial release: cancel ``prompt_id``'s remaining checks but hand their awaiters a placeholder verdict."""
        jobs = list(self.active_jobs.get(prompt_id, []))
        for job in jobs:
            self._cancel_job(job, reason=reason, release=True)
        return len(jobs)

    # ------------------------------------------------------------------ controller (group-level abandonment)
    def _ensure_controller(self):
        if (self.controller == "none" and not self.price_tracker) or self._ctrl_task is not None:
            return
        self._ctrl_task = asyncio.ensure_future(self._controller_loop())

    def _group_views(self):
        """(view, audit) for every group with active checks. Audit-lane groups are never abandoned or released (so
        the tables' tail stays observed); the loop only records the decision the controller WOULD have taken on them
        (``controller_shadow_abandon``), a model-free online estimate of the label loss."""
        now = time.time()
        rb = getattr(getattr(self, "scheduler", None), "replay_buffer", None)
        current_step = getattr(rb, "current_step", None)
        expiry_steps = math.ceil(float(getattr(rb, "async_generation_ratio", 0) or 0)) or None
        for prompt_id, jobs in list(self.active_jobs.items()):
            active = [j for j in jobs if j.state in ("queued", "running")]
            if not active:
                continue
            audit = any(bool(getattr(j.req, "meta_info", {}).get("audit")) for j in jobs)
            ages = [(now - j.t_dispatch) if (j.state == "running" and j.t_dispatch) else 0.0 for j in active]
            start = next((getattr(j.req, "meta_info", {}).get("sampling_start_step") for j in jobs
                          if getattr(j.req, "meta_info", {}).get("sampling_start_step") is not None), None)
            age_steps = (current_step - int(start)) if (current_step is not None and start is not None) else None
            yield self._vc.GroupView(prompt_id=prompt_id, observed=list(self.group_rewards.get(prompt_id, [])),
                                     active_ages=ages, group_size=self.group_size, age_steps=age_steps,
                                     expiry_steps=expiry_steps), audit

    async def _controller_loop(self):
        while True:
            try:
                await asyncio.sleep(self.ctrl_interval_s)
                now = time.time()
                queued = sum(len(p) for p in self.pending.values())
                workers = sum(len(c.workers) for c in self.scheduler.reward_clusters.values()) if hasattr(self, "scheduler") else 1
                price = self._price.update(now, queued, max(1, workers))
                if self.controller == "none":          # price-only mode (selector ablation): publish the price, decide nothing
                    self.current_price = price
                    continue
                self.current_price = self.ctrl_lambda if self.controller in ("const", "posterior") else price
                self._shadow_flagged &= set(self.active_jobs)
                for g, audit in self._group_views():
                    d = self._vc.decide(g, self.ctrl_tables, self.controller, self.ctrl_lambda, self.ctrl_theta, price,
                                        self.ctrl_min_age_s, self.ctrl_min_obs, self.ctrl_release, self.ctrl_release_frac,
                                        self.ctrl_release_slow_s)
                    if d.action == "skip":
                        continue
                    if audit:   # shadow decision only: log the first would-be abandon, never act
                        if d.action == "abandon" and g.prompt_id not in self._shadow_flagged:
                            self._shadow_flagged.add(g.prompt_id)
                            self._ctrl_stats["shadow_abandoned"] += 1
                            self._log(event="controller_shadow_abandon", prompt_id=g.prompt_id, p_inform=d.p_inform,
                                      r_sum=d.r_sum, price=d.price, n_obs=d.n_obs, s_obs=d.s_obs, n_active=d.n_active,
                                      ages=[round(a, 1) for a in g.active_ages], queued=queued, mode=self.controller)
                        continue
                    self._ctrl_stats["decisions"] += 1
                    if d.action == "release":
                        self._ctrl_stats["released"] += 1
                        n = self.release(g.prompt_id)
                        self._log(event="controller_release", prompt_id=g.prompt_id, n_released=n, r_sum=d.r_sum, price=d.price,
                                  n_obs=d.n_obs, s_obs=d.s_obs, n_active=d.n_active, ages=[round(a, 1) for a in g.active_ages],
                                  queued=queued, mode=self.controller, release=self.ctrl_release, reason=d.reason)
                    elif d.action == "abandon":
                        self._ctrl_stats["abandoned"] += 1
                        n = self.cancel(g.prompt_id, reason="controller_abandon")
                        self._log(event="controller_abandon", prompt_id=g.prompt_id, n_cancelled=n, p_inform=d.p_inform,
                                  r_sum=d.r_sum, price=d.price, n_obs=d.n_obs, s_obs=d.s_obs, n_active=d.n_active,
                                  ages=[round(a, 1) for a in g.active_ages], queued=queued, mode=self.controller, reason=d.reason)
                    else:
                        self._ctrl_stats["continued"] += 1
                        if self._ctrl_stats["continued"] % 50 == 0:
                            self._log(event="controller_continue_sample", prompt_id=g.prompt_id, p_inform=d.p_inform,
                                      r_sum=d.r_sum, price=d.price, n_obs=d.n_obs, s_obs=d.s_obs, n_active=d.n_active,
                                      queued=queued, mode=self.controller)
            except asyncio.CancelledError:
                return
            except Exception as exc:  # never let the controller kill the pipeline
                logger.warning(f"verify controller loop error: {exc!r}")

    async def submit(self, req, domain: str, prompt_id: int, dataset_id: str = "?"):
        self._ensure_controller()
        self._seq += 1
        job = _Job(self._seq, req, domain, prompt_id, dataset_id, self._job_scores(prompt_id, req))
        self.pending[domain].append(job)
        self.active_jobs.setdefault(prompt_id, []).append(job)
        self._log(event="submit", domain=domain, seq=job.seq, prompt_id=prompt_id,
                  dataset_id=dataset_id, n_pending=len(self.pending[domain]))
        self._pump(domain)
        try:
            return await job.future
        except asyncio.CancelledError:
            self._cancel_job(job, reason="awaiter_cancelled")
            raise
