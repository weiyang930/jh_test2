"""RTL analogue of applications/lean/probe_and_eval.py: sample n Verilog completions per prompt with vLLM (chat template),
check them with a pool of EQY verifier processes (applications.rtl.verifier.verify_rtl_sample, same budgets as training),
and report pass rates, group informativeness at G and the verification-time distribution. Used to compare candidate
models (SALV, CodeV-R1-Distill, EARL-SFT, ...) on the CodeV-R1 RL prompts before committing a training run.

Usage: probe_rtl.py --model PATH --data train.jsonl --out DIR [--n 8] [--limit 500] [--workers 48] [--gpu 0]
       env: RTL_OSS_CAD_BIN (oss-cad-suite/bin), RTL_EQY_TIMEOUT_S (180), RTL_WORKSPACE_ROOT
"""
from __future__ import annotations

import argparse
import collections
import json
import re
import multiprocessing as mp
import os
import random
import time
from pathlib import Path


def _verify(task):
    idx, response, ground_truth, workspace_root, sample_id = task
    from applications.rtl.verifier import verify_rtl_sample
    r = verify_rtl_sample(solution_str=response, ground_truth=ground_truth, workspace_root=workspace_root, sample_id=sample_id)
    return idx, r.stage, r.total_duration_s, r.reward_valid, (r.reason or "")[:200], float(r.reward)


def with_gt_header(response: str, ground_truth: str) -> str:
    """Prepend the ground truth's module header (up to the first `);`) when the response is a body-only completion."""
    body = response.strip()
    if body.startswith("```"):
        body = body.split("\n", 1)[1] if "\n" in body else ""
    if body.lstrip().startswith("module") or "module " in body[:200]:
        return response
    m = re.search(r"module\b.*?\);", ground_truth, flags=re.DOTALL)
    return response if m is None else m.group(0) + "\n" + response


def quantiles(xs, qs=(0.5, 0.9, 0.95, 0.99)):
    xs = sorted(xs)
    return {f"p{int(q * 100)}": (xs[min(len(xs) - 1, int(q * (len(xs) - 1)))] if xs else None) for q in qs}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--data", type=Path, required=True, help="jsonl with messages (json string) + ground_truth + id")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--n", type=int, default=8)
    ap.add_argument("--limit", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--workers", type=int, default=48)
    ap.add_argument("--max-tokens", type=int, default=2048)
    ap.add_argument("--temperature", type=float, default=1.0)
    ap.add_argument("--top-p", type=float, default=1.0)
    ap.add_argument("--gpu", default="0")
    ap.add_argument("--gpu-mem", type=float, default=0.85)
    ap.add_argument("--max-model-len", type=int, default=4096)
    ap.add_argument("--regen", action="store_true")
    ap.add_argument("--prepend-gt-header", action="store_true",
                    help="EARL reward convention: if a response does not start with `module`, prepend the ground truth's "
                         "first module header (prompts that already contain the header get body-only completions)")
    ap.add_argument("--groups", default="4,8")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    rows = [json.loads(l) for l in open(args.data, encoding="utf-8")]
    if args.limit and len(rows) > args.limit:
        random.Random(args.seed).shuffle(rows)
        rows = rows[: args.limit]
    gen_path = args.out / "generations.jsonl"
    if gen_path.exists() and not args.regen:
        gens = [json.loads(l) for l in open(gen_path)]
    else:
        os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
        from transformers import AutoTokenizer
        from vllm import LLM, SamplingParams
        tok = AutoTokenizer.from_pretrained(args.model)
        prompts = []
        for r in rows:
            msgs = json.loads(r["messages"]) if isinstance(r["messages"], str) else r["messages"]
            prompts.append(tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True))
        llm = LLM(model=args.model, tensor_parallel_size=1, gpu_memory_utilization=args.gpu_mem, max_model_len=args.max_model_len,
                  seed=args.seed, dtype="bfloat16")
        sp = SamplingParams(n=args.n, temperature=args.temperature, top_p=args.top_p, max_tokens=args.max_tokens, seed=args.seed)
        t0 = time.time()
        outs = llm.generate(prompts, sp)
        gen_s = time.time() - t0
        gens = []
        for r, o in zip(rows, outs):
            for j, c in enumerate(o.outputs):
                gens.append(dict(id=r["id"], j=j, response=c.text, tokens=len(c.token_ids), finish=c.finish_reason))
        with open(gen_path, "w", encoding="utf-8") as fh:
            for g in gens:
                fh.write(json.dumps(g, ensure_ascii=False) + "\n")
        json.dump(dict(generation_s=gen_s, prompts=len(rows), n=args.n, model=args.model), open(args.out / "generation_meta.json", "w"))
        del llm
    gt = {r["id"]: r["ground_truth"] for r in rows}
    ws = os.environ.get("RTL_WORKSPACE_ROOT", "/tmp/rtl_probe")
    os.makedirs(ws, exist_ok=True)
    if args.prepend_gt_header:
        for g in gens:
            g["response"] = with_gt_header(g["response"], gt[g["id"]])
    tasks = [(i, g["response"], gt[g["id"]], ws, f"probe_{g['id']}_{g['j']}") for i, g in enumerate(gens)]
    t0 = time.time()
    results = [None] * len(tasks)
    with mp.get_context("spawn").Pool(args.workers) as pool:
        done = 0
        for idx, stage, elapsed, valid, reason, reward in pool.imap_unordered(_verify, tasks, chunksize=1):
            results[idx] = (stage, elapsed, valid, reason, reward)
            done += 1
            if done % 200 == 0:
                print(f"verified {done}/{len(tasks)} in {time.time() - t0:.0f}s", flush=True)
    verify_wall = time.time() - t0
    with open(args.out / "attempts.jsonl", "w", encoding="utf-8") as fh:
        for g, (stage, elapsed, valid, reason, reward) in zip(gens, results):
            fh.write(json.dumps(dict(id=g["id"], j=g["j"], stage=stage, reward=reward, verify_time_s=round(elapsed, 3), reward_valid=valid,
                                     tokens=g["tokens"], finish=g["finish"], reason=reason), ensure_ascii=False) + "\n")
    per = collections.defaultdict(lambda: dict(passes=0, n=0, invalid=0, levels=collections.Counter()))
    stages = collections.Counter()
    times = []
    for g, (stage, elapsed, valid, _, reward) in zip(gens, results):
        p = per[g["id"]]
        p["n"] += 1
        p["passes"] += int(stage == "pass")
        p["levels"][round(reward, 3)] += 1   # cascaded reward level (0.5 syntax / 0.75 header / 0.9 EQY-level failure / 1.0 pass)
        p["invalid"] += int(not valid)
        stages[stage] += 1
        times.append(elapsed)
    rates = [p["passes"] / p["n"] for p in per.values()]
    # informative = the group's rewards are not all equal (what GRPO and the selector use). RTL rewards are cascaded, so a group
    # mixing two failure stages is informative too: P(informative) = 1 - sum_k f_k^G over the reward levels k (plug-in estimate);
    # the binary pass/fail version 1 - r^G - (1-r)^G is kept as pass_mixed_share_G.
    groups = [int(x) for x in args.groups.split(",")]
    inf = {f"informative_share_G{G}": sum(1 - sum((c / p["n"]) ** G for c in p["levels"].values()) for p in per.values()) / len(per) for G in groups}
    inf.update({f"pass_mixed_share_G{G}": sum(1 - r ** G - (1 - r) ** G for r in rates) / len(rates) for G in groups})
    inf["constant_level_share"] = sum(1 for p in per.values() if len(p["levels"]) == 1) / len(per)
    total = sum(times)
    tail = sorted(times, reverse=True)
    summary = dict(model=args.model, data=str(args.data), prompts=len(per), n=args.n,
                   attempt_pass_rate=stages["pass"] / len(gens), stage_counts=dict(stages),
                   **{f"pass@{args.n}": sum(1 for p in per.values() if p["passes"] > 0) / len(per)}, **inf,
                   mixed_at_probe=sum(1 for p in per.values() if 0 < p["passes"] < p["n"]) / len(per),
                   all_fail=sum(1 for p in per.values() if p["passes"] == 0) / len(per), all_pass=sum(1 for p in per.values() if p["passes"] == p["n"]) / len(per),
                   groups_with_invalid=sum(1 for p in per.values() if p["invalid"]) / len(per),
                   mean_response_tokens=sum(g["tokens"] for g in gens) / len(gens),
                   finish_length_share=sum(1 for g in gens if g["finish"] == "length") / len(gens),
                   verify_time=dict(mean=total / len(times), **quantiles(times), max=max(times),
                                    share_time_top1pct=sum(tail[: max(1, len(tail) // 100)]) / total,
                                    share_time_over_60s=sum(t for t in times if t > 60) / total, frac_over_60s=sum(1 for t in times if t > 60) / len(times),
                                    timeout_share=stages.get("eqy_timeout", 0) / len(times)),
                   verify_wall_s=verify_wall, workers=args.workers, eqy_timeout_s=os.environ.get("RTL_EQY_TIMEOUT_S", "180"),
                   problems={pid: dict(passes=p["passes"], n=p["n"], invalid=p["invalid"], levels={str(k): v for k, v in p["levels"].items()}) for pid, p in per.items()})
    json.dump(summary, open(args.out / "summary.json", "w"), indent=1)
    print(json.dumps({k: v for k, v in summary.items() if k != "problems"}, indent=1))


if __name__ == "__main__":
    main()
