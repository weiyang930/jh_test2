"""RTL reward adapter, protocol ``eqy-v2``.

The scalar ladder remains .5 (syntax), .9 (not certified in budget), 1 (proof).
UNKNOWN/TIMEOUT are *not* claims of functional incorrectness. Bad references
and infrastructure errors have reward_valid=False and must not enter training.
See EQY_PROTOCOL.md for clock semantics, preprocessing and migration details.
"""
import json
import math
import os
import re
import shutil
import signal
import subprocess
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Optional


DEFAULT_OSS_CAD_BIN = os.environ.get("RTL_OSS_CAD_BIN", "/opt/oss-cad-suite/bin")
IVERILOG_TIMEOUT_S = int(os.environ.get("RTL_IVERILOG_TIMEOUT_S", "30"))
EQY_TIMEOUT_S = float(os.environ.get("RTL_EQY_TIMEOUT_S", "180"))
_TAIL = 2000  # chars of stdout/stderr retained per stage


@dataclass(frozen=True)
class VerifierConfig:
    """One shared deadline covers preparation and every proof strategy."""

    timeout_s: float = EQY_TIMEOUT_S
    depth: int = 10
    jobs: int = 1
    clock_mode: str = "clk2fflogic"
    induction_timeout_s: int = 30

    def __post_init__(self):
        if (not math.isfinite(self.timeout_s) or self.timeout_s <= 0
                or self.depth < 1 or self.jobs < 1 or self.induction_timeout_s < 1):
            raise ValueError("verifier budgets, depth and jobs must be positive")
        if self.clock_mode not in {"clk2fflogic", "async2sync", "none"}:
            raise ValueError("clock_mode must be clk2fflogic, async2sync or none")

    @classmethod
    def from_env(cls):
        return cls(
            timeout_s=float(os.environ.get("RTL_EQY_TIMEOUT_S", EQY_TIMEOUT_S)),
            depth=int(os.environ.get("RTL_EQY_DEPTH", "10")),
            jobs=int(os.environ.get("RTL_EQY_JOBS", "1")),
            clock_mode=os.environ.get("RTL_EQY_CLOCK_MODE", "clk2fflogic"),
            induction_timeout_s=int(os.environ.get("RTL_EQY_INDUCTION_TIMEOUT_S", "30")),
        )


# ---------------------------------------------------------------------------
# header / module-name extraction (ported verbatim from dapo/reward_helper.py)
# ---------------------------------------------------------------------------

def extract_first_module_header(vtext: str) -> str:
    """Extract the first module header (from 'module' to the closing ';')."""
    text = re.sub(r"//.*?$", "", vtext, flags=re.MULTILINE)
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    text = re.sub(r"\(\*.*?\*\)", "", text, flags=re.DOTALL)

    m = re.search(r"\bmodule\b", text)
    if not m:
        raise ValueError("no 'module' keyword found")
    i = m.start()

    paren_depth = 0
    in_string = False
    escape_next = False
    j = i
    n = len(text)
    while j < n:
        ch = text[j]
        if escape_next:
            escape_next = False
        elif ch == "\\":
            escape_next = True
        elif ch == '"':
            in_string = not in_string
        elif not in_string:
            if ch in "(":
                paren_depth += 1
            elif ch == ")":
                paren_depth -= 1
            elif ch == ";" and paren_depth == 0:
                return text[i : j + 1]
        j += 1
    raise ValueError("module header not terminated with ';'")


def extract_first_module_name(vtext: str) -> str:
    """Extract the first declared module name."""
    no_line_comments = re.sub(r"//.*?$", "", vtext, flags=re.MULTILINE)
    no_block_comments = re.sub(r"/\*.*?\*/", "", no_line_comments, flags=re.DOTALL)
    m = re.search(r"^\s*module\s+([a-zA-Z_]\w*)\b", no_block_comments, flags=re.MULTILINE)
    if not m:
        raise ValueError("no module declaration found")
    return m.group(1)


def _quoted_path(path: Path) -> str:
    return json.dumps(str(Path(path).resolve()))


def _prepare_commands(path: Path, top: Optional[str], config: VerifierConfig) -> str:
    if top is not None and not re.fullmatch(r"[a-zA-Z_]\w*", top):
        raise ValueError("unsupported top-module identifier")
    hierarchy = f"-top {top}" if top else "-auto-top"
    clock = "" if config.clock_mode == "none" else config.clock_mode
    return f"""read_verilog -sv {_quoted_path(path)}
hierarchy -check {hierarchy}
rename -top TOP_EQUIV
prep -top TOP_EQUIV -flatten
write_json {_quoted_path(path.with_suffix('.json'))}
check -assert
memory_map
{clock}
opt_clean
write_rtlil {_quoted_path(path.with_suffix('.il'))}
"""


def generate_eqy_content(
    gold_top: Optional[str], gate_top: Optional[str], gt_path: Path, sol_path: Path,
    config: Optional[VerifierConfig] = None, prepared: bool = False, join_vectors: bool = True,
) -> str:
    """Normalize both sides identically; try induction then PDR, within one cap."""
    config = config or VerifierConfig.from_env()
    gold = (f"read_rtlil {_quoted_path(gt_path)}" if prepared else
            _prepare_commands(gt_path, gold_top, config))
    gate = (f"read_rtlil {_quoted_path(sol_path)}" if prepared else
            _prepare_commands(sol_path, gate_top, config))
    return f"""[gold]
{gold}
[gate]
{gate}

[collect *]
{'join *' if join_vectors else ''}

[strategy sby]
use sby
depth {config.depth}
engine smtbmc
timeout {config.induction_timeout_s}

[strategy pdr]
use sby
engine abc pdr
"""


# ---------------------------------------------------------------------------
# subprocess execution with process-group kill
# ---------------------------------------------------------------------------

@dataclass
class StageResult:
    name: str
    cmd: List[str] = field(default_factory=list)
    returncode: Optional[int] = None
    timed_out: bool = False
    duration_s: float = 0.0
    stdout_tail: str = ""
    stderr_tail: str = ""
    launch_error: bool = False


def _safe_sample_id(sample_id: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]", "_", str(sample_id))[:80]


def _kill_workspace_orphans(workspace: str) -> None:
    """SIGKILL any process whose cmdline or cwd references ``workspace``.

    Workspace paths embed a per-sample uuid, so matching processes can only be
    leftovers of this sample's own (timed-out) verification tree."""
    _kill_processes_referencing(os.path.basename(workspace.rstrip("/")))


def kill_sample_orphans(sample_id: str) -> None:
    """SIGKILL every process still referencing ``sample_id``'s workspace (``rtl_<sample_id>_<uuid>``).

    Used when a verification is cancelled from outside the verifier process: the per-sample
    subreaper is killed by process group, but sby detaches its SMT engines into new sessions."""
    _kill_processes_referencing(f"rtl_{_safe_sample_id(sample_id)}_")


def remove_sample_workspaces(workspace_root: str, sample_id: str) -> None:
    """Delete ``sample_id``'s workspaces (``rtl_<sample_id>_<uuid>``) under ``workspace_root``.

    A verifier child killed by a cancel (or crashing) never reaches ``_finish``, so its EQY workspace
    would otherwise stay on disk; decoupled runs cancel hundreds of samples and filled /tmp (2026-10-23)."""
    root = Path(workspace_root)
    if not root.is_dir():
        return
    for workspace in root.glob(f"rtl_{_safe_sample_id(sample_id)}_*"):
        shutil.rmtree(workspace, ignore_errors=True)


def kill_process_group(pid: int) -> None:
    """SIGKILL the process group led by ``pid`` (children started with ``start_new_session=True``)."""
    try:
        os.killpg(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def _kill_processes_referencing(token: str) -> None:
    if not token.startswith("rtl_") or len(token) < 12:  # only per-sample uuid dirs
        return
    if not os.path.isdir("/proc"):
        return
    for pid in os.listdir("/proc"):
        if not pid.isdigit() or int(pid) == os.getpid():
            continue
        try:
            with open(f"/proc/{pid}/cmdline", "rb") as fh:
                cmdline = fh.read().decode("utf-8", "ignore")
            if token not in cmdline:
                try:
                    if token not in os.readlink(f"/proc/{pid}/cwd"):
                        continue
                except OSError:
                    continue
            os.kill(int(pid), signal.SIGKILL)
        except (OSError, ValueError):
            continue


def _run_stage(name: str, cmd: List[str], cwd: Path, timeout_s: float, env: Dict[str, str]) -> StageResult:
    t0 = time.monotonic()
    result = StageResult(name=name, cmd=list(cmd))
    try:
        proc = subprocess.Popen(
            cmd, cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace", start_new_session=True, env=env,
        )
    except OSError as exc:
        result.launch_error = True
        result.stderr_tail = str(exc)
        result.duration_s = time.monotonic() - t0
        return result
    try:
        stdout, stderr = proc.communicate(timeout=timeout_s)
        result.returncode = proc.returncode
    except subprocess.TimeoutExpired:
        result.timed_out = True
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except ProcessLookupError:
            pass
        _kill_workspace_orphans(str(cwd))
        try:
            stdout, stderr = proc.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            stdout, stderr = "", "output pipe did not close after timeout cleanup"
        result.returncode = proc.returncode
        stderr = (stderr or "") + f"\ntimeout after {timeout_s}s, process group killed"
        # sby detaches its SMT engines into new sessions, so killpg misses them;
        # orphans keep burning CPU and hold (deleted) logfiles open, filling the
        # disk. Sweep any process still referencing this sample's workspace.
        _kill_workspace_orphans(str(cwd))
    result.duration_s = time.monotonic() - t0
    (cwd / f"{name}.stdout.log").write_text(stdout or "", encoding="utf-8")
    (cwd / f"{name}.stderr.log").write_text(stderr or "", encoding="utf-8")
    result.stdout_tail = (stdout or "")[-_TAIL:]
    result.stderr_tail = (stderr or "")[-_TAIL:]
    return result


# ---------------------------------------------------------------------------
# verifier
# ---------------------------------------------------------------------------

@dataclass
class VerifyResult:
    reward: float
    stage: str
    is_pass: bool
    total_duration_s: float
    workspace: str
    stages: List[dict] = field(default_factory=list)
    reward_valid: bool = True
    reason: str = ""
    protocol: str = "eqy-v2"
    config: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def _tool_env() -> Dict[str, str]:
    """Environment with oss-cad-suite first on PATH (matches reference cluster)."""
    env = dict(os.environ)
    env["PATH"] = f"{DEFAULT_OSS_CAD_BIN}:{env.get('PATH', '/usr/local/bin:/usr/bin:/bin')}"
    return env


def _extract_solution(text: str) -> str:
    """Use the final fenced answer, not modules quoted inside a reasoning trace."""
    if "</think>" in text:
        text = text.rsplit("</think>", 1)[1]
    answers = re.findall(r"<answer>(.*?)</answer>", text, re.S | re.I)
    if answers:
        text = answers[-1]
    blocks = re.findall(r"```(?:verilog|systemverilog|sv)?\s*\n(.*?)```", text, re.S | re.I)
    return (blocks[-1] if blocks else text).strip()


def _design_ports(path: Path) -> dict:
    modules = json.loads(path.read_text())["modules"]
    top = modules["TOP_EQUIV"]
    if any(int(str(m.get("attributes", {}).get("blackbox", "0")), 2) for m in modules.values()):
        raise ValueError("black-box module has no digital reference behavior")
    ports = top.get("ports", {})
    if not any(p["direction"] == "output" and p["bits"] for p in ports.values()):
        raise ValueError("no observable output ports")
    if all(bit in {"x", "z"} for p in ports.values() if p["direction"] == "output" for bit in p["bits"]):
        raise ValueError("all output bits are unconstrained")
    if any(p["direction"] == "inout" for p in ports.values()):
        raise ValueError("inout ports require an explicit environment model")
    return {name: (p["direction"], len(p["bits"])) for name, p in ports.items()}


def _join_vectors_for_designs(*paths: Path) -> bool:
    """Join only combinational bitwise/wiring designs.

    Preserve arithmetic cutpoints and clock-lowered feedback boundaries. Broad
    joins on the pinned 2024 EQY release can also crash its sequential partitioner.
    """
    expensive = {"$div", "$mod", "$divfloor", "$modfloor", "$mul", "$pow"}
    for path in paths:
        modules = json.loads(path.read_text())["modules"]
        for module in modules.values():
            for cell in module.get("cells", {}).values():
                kind = cell["type"]
                if kind in expensive or kind == "$ff" or "dff" in kind or "latch" in kind:
                    return False
                if kind.startswith("$mem") and any(
                    "1" in str(value) for name, value in cell.get("parameters", {}).items()
                    if name.endswith("CLK_ENABLE")
                ):
                    return False
    return True


def _classify_eqy(workspace: Path, result: StageResult):
    """A partition induction failure is UNKNOWN, never a counterexample."""
    root = workspace / "check"
    if result.timed_out:
        return "eqy_timeout", True, "not certified within the shared EQY deadline"
    if result.launch_error:
        return "eqy_tool_error", False, result.stderr_tail
    if result.returncode == 0 and (root / "PASS").is_file():
        # No partitions can be legitimate for constant/trivial outputs, but not
        # for the no-output references rejected by _design_ports above.
        return "pass", True, "EQY completed all proof obligations"
    for path in root.glob("strategies/**/logfile_basecase.txt"):
        if "Assert failed" in path.read_text(errors="replace"):
            return "eqy_counterexample", True, "base-case counterexample in an EQY partition"
    for path in root.glob("strategies/*/*/*/logfile.txt"):
        contents = path.read_text(errors="replace")
        if "Status returned by engine: FAIL" in contents:
            return "eqy_counterexample", True, "PDR counterexample in an EQY partition"
    log = (root / "logfile.txt")
    contents = result.stderr_tail + result.stdout_tail
    if log.exists():
        contents += log.read_text(errors="replace")
    # EQY prints 'ERROR: A problem occurred during equivalence check' even for
    # an ordinary UNKNOWN. Inspect strategy statuses, not that generic footer.
    errored_partition = False
    fallback_error = False
    for partition in (root / "strategies").glob("*"):
        statuses = [p.read_text().strip().split()[0] for p in partition.glob("*/status")
                    if p.read_text().strip()]
        if "PASS" not in statuses and "ERROR" in statuses:
            if any(status in {"UNKNOWN", "UNPROVEN", "TIMEOUT"} for status in statuses):
                fallback_error = True
            else:
                errored_partition = True
    if fallback_error and not errored_partition and result.returncode == 2:
        # An optional backend failure does not invalidate a sound UNKNOWN
        # already returned by another strategy. Keep the non-success reward,
        # not a correctness claim, and retain the backend failure in the reason.
        return "eqy_unknown", True, "primary strategy inconclusive; optional fallback failed (see proof logs)"
    error_markers = ("std::out_of_range", "Unhandled cell", "not found", "Traceback")
    specific_errors = [line for line in contents.splitlines() if "ERROR:" in line
                       and "A problem occurred during equivalence check" not in line]
    if ((result.returncode is not None and result.returncode < 0) or errored_partition
            or specific_errors or any(x in contents for x in error_markers)):
        return "eqy_tool_error", False, contents[-_TAIL:]
    if result.returncode == 0:
        return "eqy_tool_error", False, "exit code zero without EQY PASS artifact"
    return "eqy_unknown", True, "proof not completed; no confirmed base-case counterexample"


def verify_rtl_sample(
    solution_str: str,
    ground_truth: str,
    workspace_root: str,
    sample_id: str,
    keep_artifacts: bool = False,
    config: Optional[VerifierConfig] = None,
    gold_top: Optional[str] = None,
    gate_top: Optional[str] = None,
) -> VerifyResult:
    """Check a candidate without mutating the reference or guessing its reset.

    Default clock lowering uses a global-step model (including multiple clocks).
    Explicit async2sync mode is only for datasets with synchronized inputs.
    """
    config = config or VerifierConfig.from_env()
    t_start = time.monotonic()
    workspace = Path(workspace_root).resolve() / f"rtl_{_safe_sample_id(sample_id)}_{uuid.uuid4().hex}"
    workspace.mkdir(parents=True, exist_ok=False)
    env = _tool_env()
    stages: List[dict] = []

    def _finish(reward: float, stage: str, valid: bool = True, reason: str = "") -> VerifyResult:
        if not keep_artifacts:
            shutil.rmtree(workspace, ignore_errors=True)
        return VerifyResult(
            reward=reward,
            stage=stage,
            is_pass=(stage == "pass"),
            total_duration_s=time.monotonic() - t_start,
            workspace=str(workspace),
            stages=stages,
            reward_valid=valid,
            reason=reason,
            config=asdict(config),
        )

    # === (1) preprocess: extract header/name from ground truth ===
    try:
        gt_header = extract_first_module_header(ground_truth)
        extract_first_module_name(ground_truth)
    except ValueError as exc:
        return _finish(0.75, "header_extract_fail", False, str(exc))

    answer = _extract_solution(solution_str)
    try:
        extract_first_module_name(answer)
        processed_solution = answer
    except ValueError:
        processed_solution = gt_header + "\n" + answer
    sol_file = workspace / "solution.v"
    gt_file = workspace / "ground_truth.v"
    out_file = workspace / "temp_output"
    sol_file.write_text(processed_solution, encoding="utf-8")
    gt_file.write_text(ground_truth, encoding="utf-8")

    # === (2) iverilog -g2012 syntax check ===
    syn = _run_stage(
        "iverilog",
        [f"{DEFAULT_OSS_CAD_BIN}/iverilog", "-g2012", "-o", str(out_file), str(sol_file)],
        cwd=workspace,
        timeout_s=IVERILOG_TIMEOUT_S,
        env=env,
    )
    stages.append(asdict(syn))
    if syn.launch_error or (syn.returncode is not None and syn.returncode < 0 and not syn.timed_out):
        return _finish(0.5, "syntax_tool_error", False, syn.stderr_tail)
    if syn.timed_out:
        return _finish(0.5, "syntax_timeout")
    if syn.returncode != 0:
        return _finish(0.5, "syntax_fail")

    # === (3) Prepare actual hierarchy, reject invalid references/interfaces ===
    deadline = time.monotonic() + config.timeout_s
    ports = {}
    # Separate processes avoid leaking Yosys's global auto-ID counter across
    # sides; design -reset does not reset that counter.
    for role, source, top in (("gold", gt_file, gold_top), ("gate", sol_file, gate_top)):
        is_gold = role == "gold"
        prepare_file = workspace / f"prepare_{role}.ys"
        try:
            prepare_file.write_text(_prepare_commands(source, top, config), encoding="utf-8")
        except ValueError as exc:
            return _finish(.75, "top_config_error", False, str(exc))
        prep = _run_stage(
            f"prepare_{role}", [f"{DEFAULT_OSS_CAD_BIN}/yosys", "-s", str(prepare_file)],
            cwd=workspace, timeout_s=max(.001, deadline - time.monotonic()), env=env,
        )
        stages.append(asdict(prep))
        if prep.launch_error or (prep.returncode is not None and prep.returncode < 0 and not prep.timed_out):
            return _finish(.9, "eqy_tool_error", False, prep.stderr_tail)
        if prep.timed_out:
            return _finish(.9, "eqy_timeout", True, "preparation exhausted the shared EQY deadline")
        if prep.returncode != 0:
            return _finish(.75 if is_gold else .9,
                           "gold_prepare_fail" if is_gold else "candidate_prepare_fail",
                           not is_gold, prep.stderr_tail + "\n" + prep.stdout_tail)
        try:
            ports[role] = _design_ports(source.with_suffix(".json"))
        except (ValueError, KeyError, OSError) as exc:
            return _finish(.75 if is_gold else .9, "gold_invalid" if is_gold else "candidate_invalid",
                           not is_gold, str(exc))
    if ports["gold"] != ports["gate"]:
        return _finish(.9, "interface_mismatch", True, "port names, directions or widths differ")

    # === (4) EQY induction + PDR, using already prepared netlists ===
    eqy_file = workspace / "check.eqy"
    join_vectors = _join_vectors_for_designs(gt_file.with_suffix(".json"), sol_file.with_suffix(".json"))
    eqy_file.write_text(
        generate_eqy_content(gold_top, gate_top, gt_file.with_suffix(".il"),
                             sol_file.with_suffix(".il"), config, prepared=True,
                             join_vectors=join_vectors),
        encoding="utf-8",
    )
    eqy = _run_stage(
        "eqy",
        [f"{DEFAULT_OSS_CAD_BIN}/eqy", "-j", str(config.jobs), str(eqy_file)],
        cwd=workspace,
        timeout_s=max(.001, deadline - time.monotonic()),
        env=env,
    )
    stages.append(asdict(eqy))
    stage, valid, reason = _classify_eqy(workspace, eqy)
    # The pinned 2024 partitioner also segfaults on some hierarchical
    # combinational joins (CodeV 64235 reproduces even against itself). Retry
    # only this specific tool crash, with the same netlists and shared budget.
    # Preserve the first attempt and charge both attempts to this sample.
    if (join_vectors and stage == "eqy_tool_error"
            and re.search(r"partition: finished \(returncode=-\d+\)", reason)
            and time.monotonic() < deadline):
        (workspace / "check").rename(workspace / "check_join_failed")
        eqy_file.rename(workspace / "check_join_failed.eqy")
        eqy_file.write_text(
            generate_eqy_content(gold_top, gate_top, gt_file.with_suffix(".il"),
                                 sol_file.with_suffix(".il"), config, prepared=True,
                                 join_vectors=False), encoding="utf-8")
        retry = _run_stage(
            "eqy_nojoin_retry", [f"{DEFAULT_OSS_CAD_BIN}/eqy", "-j", str(config.jobs), str(eqy_file)],
            cwd=workspace, timeout_s=max(.001, deadline - time.monotonic()), env=env)
        stages.append(asdict(retry))
        stage, valid, reason = _classify_eqy(workspace, retry)
        reason = "retried partition crash without vector joins; " + reason
    return _finish(1.0 if stage == "pass" else .9, stage, valid, reason)
