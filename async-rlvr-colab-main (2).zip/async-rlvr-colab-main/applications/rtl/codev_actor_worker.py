"""CodeV actor: full-token GRPO with bounded softmax temporaries and pad trimming.

The optimizer minibatch boundaries are unchanged. Trimming is per forward, not
ROLL's dynamic minibatch regrouping (which changes effective optimizer batches).
"""
from types import MethodType
from typing import Callable

import torch
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint

from roll.distributed.scheduler.decorator import Dispatch, register
from roll.pipeline.rlvr.actor_worker import ActorWorker


def selected_log_probs(logits: torch.Tensor, labels: torch.Tensor, chunk_size: int = 128) -> torch.Tensor:
    """Match FP32 dense log-softmax/gather, checkpointing token chunks in training."""
    flat = logits.reshape(-1, logits.shape[-1])
    targets = labels.reshape(-1)

    def selected(chunk: torch.Tensor, ids: torch.Tensor) -> torch.Tensor:
        return F.log_softmax(chunk.float(), dim=-1).gather(-1, ids[:, None]).squeeze(-1)

    pieces = []
    for start in range(0, len(flat), chunk_size):
        x, y = flat[start:start + chunk_size], targets[start:start + chunk_size]
        if torch.is_grad_enabled() and x.requires_grad:
            pieces.append(checkpoint(selected, x, y, use_reentrant=False))
        else:
            pieces.append(selected(x, y))
    return torch.cat(pieces).reshape(labels.shape)


def chunked_entropy(logits: torch.Tensor, chunk_size: int = 128) -> torch.Tensor:
    """Compute old-policy entropy without full-sequence FP32 vocabulary buffers."""
    flat = logits.reshape(-1, logits.shape[-1])
    pieces = []
    for start in range(0, len(flat), chunk_size):
        x = flat[start:start + chunk_size].float()
        pieces.append(torch.logsumexp(x, -1) - (x.softmax(-1) * x).sum(-1))
    return torch.cat(pieces).reshape(logits.shape[:-1])


def install_bounded_forward(strategy: object) -> None:
    """Install the CP=1 CodeV operations on this actor's FSDP strategy only."""
    if strategy.worker.rank_info.cp_size != 1:
        raise ValueError('CodeV smoke pad trimming requires cp_size=1')
    original_forward: Callable = strategy._fsdp2_forward

    def forward(self, input_ids, attention_mask, position_ids, forward_args):
        occupied = attention_mask.bool().any(dim=0).nonzero()
        if occupied.numel() == 0:
            raise ValueError('Empty attention mask in CodeV actor')
        end = int(occupied[-1].item()) + 1
        return original_forward(
            input_ids=input_ids[:, :end], attention_mask=attention_mask[:, :end],
            position_ids=position_ids[..., :end], forward_args=forward_args,
        )

    def log_probs(self, logits, input_ids, attention_mask):
        length = logits.shape[1]
        labels = input_ids[:, 1:length].clone()
        labels[attention_mask[:, 1:length] == 0] = 0
        labels = torch.cat([labels, torch.zeros_like(input_ids[:, :1])], dim=1)
        result = selected_log_probs(logits, labels)[:, :-1] * attention_mask[:, 1:length]
        return F.pad(result, (0, input_ids.shape[1] - length))

    def entropy(self, logits, attention_mask):
        length = logits.shape[1]
        result = chunked_entropy(logits)[:, :-1] * attention_mask[:, 1:length]
        return F.pad(result, (0, attention_mask.shape[1] - length))

    strategy._fsdp2_forward = MethodType(forward, strategy)
    strategy.op_compute_log_probs = MethodType(log_probs, strategy)
    strategy.op_compute_entropy = MethodType(entropy, strategy)


class CodeVActorWorker(ActorWorker):
    """Use the normal all-token actor loss, with CodeV long-context memory fixes."""

    @register(dispatch_mode=Dispatch.ONE_TO_ALL)
    def initialize(self, pipeline_config):
        super().initialize(pipeline_config)
        dtypes = {p.dtype for p in self.strategy.model.parameters() if p.requires_grad}
        if dtypes != {torch.float32}:
            raise RuntimeError(f'CodeV requires FP32 stored actor parameters, found {dtypes}')
        install_bounded_forward(self.strategy)
        self.logger.info('CodeV FP32 stored actor parameters verified; BF16 compute, bounded logprob/entropy, padding trim enabled')

    @register(dispatch_mode=Dispatch.DP_MP_DISPATCH_FIRST, trace=True, prefetch=False, to_remote=False)
    def train_step(self, data):
        """Record actual training peaks on each learner GPU for batch selection."""
        probe_name = next(name for name, p in self.strategy.model.named_parameters() if 'q_proj.weight' in name)

        def probe():
            p = dict(self.strategy.model.named_parameters())[probe_name].detach()
            if hasattr(p, 'to_local'):
                p = p.to_local()
            return p.flatten()[:1024].float().cpu().clone()

        before = probe()
        torch.cuda.reset_peak_memory_stats()
        result = super().train_step(data)
        difference = (probe() - before).abs()
        result.meta_info['metrics']['codev/probe_changed_elements@sum'] = int((difference > 0).sum())
        result.meta_info['metrics']['codev/probe_max_abs_update@max'] = float(difference.max())
        state_dtypes = {value.dtype for state in self.strategy.optimizer.state.values()
                        for key, value in state.items() if key in {'exp_avg', 'exp_avg_sq'}}
        if state_dtypes != {torch.float32}:
            raise RuntimeError(f'CodeV requires initialized FP32 Adam states, found {state_dtypes}')
        result.meta_info['metrics']['codev/train_peak_allocated_gib@max'] = torch.cuda.max_memory_allocated() / 2**30
        result.meta_info['metrics']['codev/train_peak_reserved_gib@max'] = torch.cuda.max_memory_reserved() / 2**30
        return result
