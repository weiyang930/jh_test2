"""Convert the reference RTL parquet dataset to ROLL RLVR jsonl format.

Source: reference_code/archer_llm/data/filtered_dataset-{train,val}.parquet
  columns: score, data_source, prompt (chat message list), ability,
           reward_model{ground_truth}, extra_info{index, question}

Target jsonl columns (mirrors data/math_deepmath_deal.jsonl schema so all
fields survive into non_tensor_batch):
  id, data_source, messages (json string), ground_truth, question, tag, difficulty

Prompt content is passed through unmodified; chat formatting happens in ROLL via
the 'native' template (= tokenizer.apply_chat_template, identical to verl).
"""
import argparse
import json

import pandas as pd


def convert(src: str, dst: str, tag: str = "rtl") -> int:
    df = pd.read_parquet(src)
    n = 0
    with open(dst, "w", encoding="utf-8") as f:
        for _, row in df.iterrows():
            prompt_msgs = [
                {"role": m["role"], "content": m["content"]} for m in row["prompt"]
            ]
            extra = row["extra_info"]
            record = {
                "id": str(extra.get("index", n)),
                "data_source": str(row["data_source"]),
                "messages": json.dumps(prompt_msgs, ensure_ascii=False),
                "ground_truth": str(row["reward_model"]["ground_truth"]),
                "question": str(extra.get("question", "")),
                "tag": tag,
                "difficulty": "",
            }
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
            n += 1
    return n


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--src", required=True)
    parser.add_argument("--dst", required=True)
    parser.add_argument("--tag", default="rtl")
    args = parser.parse_args()
    count = convert(args.src, args.dst, args.tag)
    print(f"wrote {count} records to {args.dst}")
