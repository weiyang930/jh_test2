"""Synthetic reward for orchestration regression only, NEVER an RTL experiment."""
import hashlib
import numpy as np
import torch

from applications.rtl.rtl_reward_worker import RTLRewardWorker
from roll.distributed.scheduler.decorator import Dispatch, register
from roll.distributed.scheduler.protocol import DataProto


class ControlRewardWorker(RTLRewardWorker):
    @register(dispatch_mode=Dispatch.DP_MP_COMPUTE, clear_cache=False)
    def compute_rewards(self, data):
        # Deterministic per generated request, solely to exercise GRPO routing.
        ids = data.non_tensor_batch['rollout_id']
        scores = torch.tensor([hashlib.sha256(str(x).encode()).digest()[0] % 2 for x in ids], dtype=torch.float32)
        return DataProto.from_dict(
            tensors={'token_level_rewards': torch.zeros_like(data.batch['responses'], dtype=torch.float32),
                     'response_level_rewards': scores, 'scores': scores.clone()},
            non_tensors={'verifier_stage': np.array(['CONTROL_TEST_ONLY'] * len(ids), dtype=object)},
        )
