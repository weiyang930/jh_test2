# 怎么跑（2026-10-31 版）：DAPO 基线，RTL，50 步（约 5 小时，有空再跑）

和 `RERUN_1030.md` 的 Lean 一样的臂，换成 RTL。代码不用再 pull。每 25 步存一个 checkpoint，评第 0、25、50 步。

```bash
cd $ROOT/code
export ROOT VENV OSS_CAD_DIR RTL_NUM_GPUS=8 RTL_TRAIN_GPUS=4 RTL_TRACK_WITH=tensorboard WANDB_MODE=disabled
nohup bash -c "RTL_SAVE_STEPS=25 bash experiments/h100_20261019/run_arm.sh rtl barrier_dapo 50; echo STAGE2D_RTL_EXIT=\$?" > $ROOT/logs/stage2d_rtl.log 2>&1 &
```

第一小时检查（约第 15 步）：`summarize_run.py` 的 step_s 应在 150 到 300 秒；`events.jsonl` 里每步 `prompt_begin` 约为 32 加 `prompt_filtered` 数。
超过 400 秒或每步 prompt 超过 200 就告诉我。

跑完贴三样：

```bash
$VENV/bin/python experiments/h100_20261019/summarize_run.py $ROOT/runs/h100_rtl_barrier_dapo
$VENV/bin/python experiments/h100_20261019/stage2_summary.py $ROOT/runs/h100_rtl_barrier_dapo
cat $ROOT/runs/h100_rtl_barrier_dapo/eval/eval_curve.json
```

tgz `$ROOT/outbox/h100_rtl_barrier_dapo.tgz` 最后和 Lean 的一起发；盘上保留 `train/output/`、`eval/`、最后一个 checkpoint。
