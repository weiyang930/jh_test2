# 给 Wei 的消息（2026-10-27）：Stage-2 第一轮崩溃后的诊断材料

两件事：

1. 把这两个现成文件直接发我（超过 95 MB 的切一下：`split -b 90m 文件名 文件名.part_`）：

```
/opt/dlami/nvme/weicyang_ec/outbox/h100_rtl_decoupled_eta2_full2.tgz
/opt/dlami/nvme/weicyang_ec/outbox/h100_lean_decoupled_eta2_sel.tgz
```

2. 先 `cd /opt/dlami/nvme/weicyang_ec/code && git pull`，然后让你的 agent 跑下面这段，把全部打印贴给我：

```bash
export ROOT=/opt/dlami/nvme/weicyang_ec VENV=$ROOT/env/venv; cd $ROOT/code
for r in h100_rtl_decoupled_eta2_full2 h100_lean_decoupled_eta2_sel h100_lean_decoupled_eta2_full2 h100_rtl_decoupled_eta2_sel; do
  echo "##### $r"; $VENV/bin/python experiments/h100_20261019/stage2_summary.py $ROOT/runs/$r
  $VENV/bin/python experiments/h100_20261019/summarize_run.py $ROOT/runs/$r
  echo "----- stdout tail"; tail -n 60 $ROOT/runs/$r/train/stdout.log
done
git diff roll/utils/tracking.py
```

重跑先等我，代码改好会告诉你。
