# Verification-bound asynchronous RLVR — collaboration package

RL post-training of a 7B Verilog model (SALV-7B on CodeV-R1 prompts) where the reward is a **formal equivalence check
(Yosys EQY)** running on CPU. Each prompt gets G=8 samples (GRPO group; the first-round numbers below were taken at G=4). Verification has a 200x tail: ~3.5% of samples
hit the 180 s timeout and consume ~75% of all verifier CPU time. We study training-pipeline designs in the regime where
this verifier, not generation, is the bottleneck. The stack is a fork of Alibaba ROLL (Ray + vLLM 0.8.4 + FSDP2).

## What has been measured so far (6xA100-80GB, 48 verifier workers, B=64 prompts x G=4, 30 learner steps per arm, 2026-10-01)

| arm | step time | informative groups / h | staleness | verifier busy |
|---|---|---|---|---|
| ROLL cohort barrier, ratio 1 | 117 s | 3,344 | 1.0 | 40% |
| ROLL cohort barrier, ratio 2 | 81 s | 4,895 | 2.0 | 61% |
| ROLL cohort barrier, ratio 4 | 53 s | 7,143 | 4.0 | 92% |
| decoupled consumption (AReaL-style), eta 2 | 41.8 s | 10,418 | 1.84 | 88% |

Decoupled consumption at matched staleness is 2.13x the barrier pipeline (ratio 2). At 48 workers the decoupled arm
is already bounded by the learner (42 s of GPU compute per step), so the next experiments run with fewer verifier
workers, where verification is the binding stage.

## Hardware

- One node, 6–8 GPUs with 80 GB each (A100/H100/H200). Default split: GPUs 0..3 train, the rest serve vLLM.
  For 8 GPUs: `export RTL_NUM_GPUS=8 RTL_TRAIN_GPUS=4`.
- **CPU matters**: the verifier is CPU-bound; 48+ cores recommended. Report `nproc` and any cgroup/Slurm CPU limit.
- Disk: ~60 GB for environment + model + per-run logs; a final checkpoint is 29 GB if enabled (off by default).
- Network: HuggingFace (model 15 GB + dataset), GitHub (EDA tools 0.6 GB), PyPI.

## Setup (three scripts, ~20 min; validated from a clean Ubuntu 24.04 image)

```bash
export ROOT=/path/with/space/ec            # everything lives here
export VENV=$ROOT/env/venv                 # Python 3.11 venv created by uv
export OSS_CAD_DIR=$ROOT/env/oss-cad-suite # EDA tools (yosys/eqy/sby/iverilog)
git clone <this repo> $ROOT/code
bash $ROOT/code/experiments/ec/pod_setup.sh   > $ROOT/logs/setup.log 2>&1   # needs `uv` on PATH
bash $ROOT/code/experiments/ec/pod_assets.sh  > $ROOT/logs/assets.log 2>&1  # SALV-7B + CodeV-R1 parquet -> train.jsonl
```

Expected: `SETUP_DONE`, `ASSETS_DONE`, `SALV_SHA_OK`, `DATA_SHA_OK` in the logs.

## Run

```bash
cd $ROOT/code
# 2-step smoke (~8 min): verifies the stack and prints verification-time percentiles + leftover-process check
RTL_SAVE_LAST=false bash experiments/ec/run_ec_arm.sh decoupled_eta2 2 _smoke
$VENV/bin/python experiments/ec/smoke_check.py $ROOT/runs/ec_decoupled_eta2_smoke
# one arm, 30 steps (arms: barrier_r1 barrier_r2 barrier_r4 decoupled_eta2 decoupled_eta8 decoupled_eta2_sel)
RTL_VERIFY_WORKERS=24 bash experiments/ec/run_ec_arm.sh barrier_r2 30
# several arms back to back, results copied to $VOL_RUNS as each arm ends
VOL_RUNS=/shared/persistent/path RTL_VERIFY_WORKERS=24 bash experiments/ec/ec_pod_sequence.sh 30 barrier_r2 decoupled_eta2
$VENV/bin/python experiments/ec/analyze_ec.py $ROOT/runs/ec_barrier_r2 $ROOT/runs/ec_decoupled_eta2
```

Every arm writes `$ROOT/runs/<run_id>/output/{events,scheduler_events,verify_queue_events,learner_events}.jsonl`
(tens of MB) plus `manifest.json`. **Results must leave the node as soon as an arm finishes** (the sequencer does this
to `VOL_RUNS`); nodes and scratch disks have vanished on us before.

## Knobs (environment variables)

| variable | meaning | default |
|---|---|---|
| `RTL_VERIFY_WORKERS` | number of CPU verifier workers N | 48 in `run_ec_arm.sh` |
| `RTL_GROUP_G`, `RTL_ROLLOUT_B` | GRPO group size G and prompts per step B | 8 / 32 in `run_ec_arm.sh` (yaml defaults 4 / 64 = old runs) |
| `RTL_ASYNC_GENERATION_RATIO` | barrier ratio r, or staleness bound eta in decoupled mode | per arm |
| `RTL_CONSUMPTION_MODE` | `barrier` (ROLL) or `decoupled` (AReaL-style group buffer) | per arm |
| EQY timeout tau | `experiments/configs/salv_blocking_cost.yaml` (180 s) | fixed |
| `RTL_NUM_GPUS`, `RTL_TRAIN_GPUS` | GPU count and train/vLLM split | 6 / 4 |
| `RTL_SAVE_LAST` | write the final HF checkpoint (29 GB) | false in the sequencer |

## Planned experiments on the shared machine

Setting is fixed at one verifier-bound point: G = 8, B = 32, tau = 180 s, N chosen from a smoke so that
`verifier work per step / (N x learner step time) ≈ 2` (on A100 that is N ≈ 20; recalibrate on H200).

1. Throughput, 30 steps each (~0.5–2 h per arm): barrier r1 / r2 / r4, decoupled eta 2, decoupled eta 2 + controller
   (controller code lands in ~1 week).
2. Learning curves, 600 steps each with evaluation every 100 steps: barrier r2, decoupled eta 2, decoupled + controller.

Contact: Caroline (Jiahe) Shi, MIT.
