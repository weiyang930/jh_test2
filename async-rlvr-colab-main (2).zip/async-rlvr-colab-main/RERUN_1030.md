# 怎么跑（2026-10-30 版）：DAPO 基线，Lean，50 步（约 3 小时）

承接 `RERUN_1029.md`（那批已收到）。代码：`git pull`，新增 `barrier_dapo` 臂，其余不变。
DAPO 是同步算法（ROLL 原生 dynamic sampling：生成到 32 个有梯度的组为止，暂停，训练），每步比我们所有 arm 都慢，
按墙钟比较是公平的。每 25 步存一个 checkpoint，评第 0、25、50 步。RTL 那段单独在 `RERUN_1031.md`，有空再跑。

```bash
cd $ROOT/code && git pull --no-rebase && git log --oneline -1
export ROOT VENV OSS_CAD_DIR RTL_NUM_GPUS=8 RTL_TRAIN_GPUS=4 RTL_TRACK_WITH=tensorboard WANDB_MODE=disabled
# 冒烟 2 步（约 15 分钟）
SMOKE=1 bash experiments/h100_20261019/run_arm.sh lean barrier_dapo 2 _smoke > $ROOT/logs/smoke_lean_dapo.log 2>&1
grep -c '"prompt_filtered"' $ROOT/runs/lean_barrier_dapo_smoke/output/events.jsonl      # 应当 > 0
grep -c "Traceback" $ROOT/runs/h100_lean_barrier_dapo_smoke/train/stdout.log           # 应当 0
# 正式 50 步（约 2.3 小时 + 0.5 小时评测）
nohup bash -c "RTL_SAVE_STEPS=25 bash experiments/h100_20261019/run_arm.sh lean barrier_dapo 50; echo STAGE2D_LEAN_EXIT=\$?" > $ROOT/logs/stage2d_lean.log 2>&1 &
```

跑完在对话里贴三样，不用等 tgz：

```bash
$VENV/bin/python experiments/h100_20261019/summarize_run.py $ROOT/runs/h100_lean_barrier_dapo
$VENV/bin/python experiments/h100_20261019/stage2_summary.py $ROOT/runs/h100_lean_barrier_dapo
cat $ROOT/runs/h100_lean_barrier_dapo/eval/eval_curve.json
```

说明（pod 冒烟得出）：Lean 生成快，每步会先把 32 个额外 prompt 起满再在暂停时取消，所以每步 `prompt_begin` 约为 64 加过滤数，是正常的；
`barrier_dapo` 不用控制器表；`RTL_OFFLOAD` 不要设。tgz `$ROOT/outbox/h100_lean_barrier_dapo.tgz` 最后发；盘上保留 `train/output/`、`eval/`、最后一个 checkpoint。
