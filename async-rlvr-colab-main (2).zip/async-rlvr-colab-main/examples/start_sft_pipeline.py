import argparse
import os

from dacite import from_dict, Config
from hydra.experimental import compose, initialize
from omegaconf import OmegaConf

from roll.distributed.scheduler.initialize import init
from roll.pipeline.sft.sft_config import SFTConfig

from roll.pipeline.sft.sft_pipeline import SFTPipeline


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config_path", help="The path of the main configuration file", default="config")
    parser.add_argument(
        "--config_name", help="The name of the main configuration file (without extension).", default="sppo_config"
    )
    args = parser.parse_args()

    initialize(config_path=args.config_path, job_name="app")
    cfg = compose(config_name=args.config_name)

    print(OmegaConf.to_yaml(cfg, resolve=True))

    sft_config: SFTConfig = from_dict(data_class=SFTConfig, data=OmegaConf.to_container(cfg, resolve=True))

    init()
    pipeline = SFTPipeline(pipeline_config=sft_config)

    pipeline.run()


if __name__ == "__main__":
    main()
