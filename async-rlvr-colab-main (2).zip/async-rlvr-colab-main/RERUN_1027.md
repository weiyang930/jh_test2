# 怎么跑（2026-10-27 版）：Stage 2 重跑三个 arm，各 400 步（rtl full2 的 419 步保留，不重跑）

10-26 那批的结论：`rtl decoupled_eta2_full2` 跑到 419 步才崩，这 419 步的训练日志、100/200/300/400 四个 checkpoint 的评测都是完整的，
**保留，不重跑**。另外三个 run 重跑：`lean full2` 和 `rtl sel` 当时根本没起来（起步就 OOM / 崩），`lean sel` 跑了 241 步但用的是
旧的选题器定义（常数价、没有文本特征），和这次的定义不一致，所以也重跑。

这次改了什么（都已经在仓库里，`git pull` 就有；你 10-25 的本地 patch 已经合进去了，这次 pull 应当没有冲突）：

| 问题 | 修法 |
|---|---|
| 419 步崩：一批 32 个组全是零方差，压缩后 0 行 → `view(0,-1)` 报错 | 空批直接原样返回（优势全零，等于空走一步），记一个 `compaction/empty_step` |
| `lean full2` 起步 OOM：上一个 run 的评测 vLLM 还占着 GPU 0 的 74 GB | `run_arm.sh` 开跑前等所有 GPU 低于 2 GB（最多 20 分钟，然后 kill 残留进程） |
| Ray socket 路径过长 | 用你 10-26 的 6 位 hash 方案；`RTL_RAY_TMP_ROOT` 只在 `$ROOT` 短于 25 字符时才设 |
| tensorboard 不认 wandb 的参数 | 已修 |
| wandb 没装 / 版本冲突 | `setup_h100.sh` 装固定版本（wandb 0.28.0 + protobuf 4.25.9 + opentelemetry 1.26.0）；import 失败自动退回 tensorboard，不会因此崩 |
| 选题器后期全是零方差的组（审计组 informative 比例 0.50 → 0.08） | 后验只看每题最近 50 步的结果（`window=50`），加 TF-IDF + 结构特征的文本先验（每 50 步在线重拟一次） |
| `sel` 臂之前用的是常数价 | `sel` 和 `full2` 现在都用动态价（κ×验证队列长度的滑动平均） |

参数都是脚本默认值，不用设任何环境变量。

## 一、更新代码和环境（约 10 分钟）

```bash
export ROOT=/opt/dlami/nvme/weicyang_ec VENV=$ROOT/env/venv OSS_CAD_DIR=$ROOT/env/oss-cad-suite
cd $ROOT/code
git status --short                        # 应当是空的；有 M 的文件就先 git stash push -m wei_local_1027
git pull --no-rebase
git log --oneline -3                      # 顶上应当是 2026-10-27 的提交
bash experiments/h100_20261019/setup_h100.sh > $ROOT/logs/setup_1027.log 2>&1
tail -n 8 $ROOT/logs/setup_1027.log       # 结尾应有 WANDB_OK（WANDB_IMPORT_FAIL 也能跑，只是曲线落到 tensorboard）、CTRL_TABLES_OK rtl.json lean.json、H100_SETUP_DONE
nvidia-smi --query-gpu=memory.used --format=csv   # 8 张卡都应低于 2000 MiB；不是的话 pkill -9 -f "vllm|ray::|roll\." 再看一次
```

## 二、把 10-26 的旧目录挪开（必须做：事件日志是追加写的，不挪开会和新 run 混在一起）

```bash
cd $ROOT/runs
mv h100_lean_decoupled_eta2_sel  h100_lean_decoupled_eta2_sel_1026      # 旧定义的 241 步，留着
mv lean_decoupled_eta2_sel       lean_decoupled_eta2_sel_1026
mv $ROOT/outbox/h100_lean_decoupled_eta2_sel.tgz $ROOT/outbox/h100_lean_decoupled_eta2_sel_1026.tgz
rm -rf h100_lean_decoupled_eta2_full2 lean_decoupled_eta2_full2 h100_rtl_decoupled_eta2_sel ec_decoupled_eta2_sel   # 都是没跑起来的空壳
ls $ROOT/runs                              # h100_rtl_decoupled_eta2_full2 和 ec_decoupled_eta2_full2 不要动
```

## 三、冒烟（约 15 分钟）：lean full2 跑 2 步，gate 自动判定

```bash
cd $ROOT/code
export ROOT VENV OSS_CAD_DIR RTL_NUM_GPUS=8 RTL_TRAIN_GPUS=4
SMOKE=1 bash experiments/h100_20261019/run_arm.sh lean decoupled_eta2_full2 2 _smoke > $ROOT/logs/smoke_lean_full2_1027.log 2>&1
$VENV/bin/python experiments/h100_20261019/smoke_gate.py $ROOT --runs h100_lean_decoupled_eta2_full2_smoke --setup-log logs/setup_1027.log
```

`SMOKE_GATE_PASS` 就直接进第四节。`SMOKE_GATE_FAIL` 的话把 gate 的打印和 `$ROOT/runs/h100_lean_decoupled_eta2_full2_smoke/train/stdout.log`
的最后 200 行贴给我。

## 四、正式跑（3 个 run，各 400 步；顺序约 12 小时训练 + 2.5 小时评测）

步数从 500 改成 400：保留的 `rtl full2` 到 400 步的评测点已经有了，三个新 run 也跑到 400 就能逐点对齐；
而且 10-26 的日志显示 400 步后题库基本学完（审计组里还有区分度的组只剩 8%），再往后跑没有信息量。

```bash
cd $ROOT/code
export ROOT VENV OSS_CAD_DIR RTL_NUM_GPUS=8 RTL_TRAIN_GPUS=4
nohup bash -c '
  bash experiments/h100_20261019/run_arm.sh lean decoupled_eta2_full2 400 &&
  bash experiments/h100_20261019/run_arm.sh rtl  decoupled_eta2_sel   400 &&
  bash experiments/h100_20261019/run_arm.sh lean decoupled_eta2_sel   400
  BENCH_ONLY=proofnet_test bash experiments/h100_20261019/eval_ckpt.sh lean h100_lean_barrier_r2     > $ROOT/logs/proofnet_barrier.log   2>&1
  BENCH_ONLY=proofnet_test bash experiments/h100_20261019/eval_ckpt.sh lean h100_lean_decoupled_eta2 > $ROOT/logs/proofnet_decoupled.log 2>&1
' > $ROOT/logs/stage2b.log 2>&1 &
```

最后两行是 10-25 第二节欠下的：给 10-18 的两个 Lean 基线补评 ProofNet（零训练，约 30 分钟，只评第 0 步和盘上还在的
checkpoint，miniF2F 已有结果会跳过）。挂在三个 run 后面自动跑，不用单独操作；前面某个 run 失败了它们也照样跑。
结果在 `$ROOT/runs/h100_lean_barrier_r2/eval/eval_curve.json` 和 `$ROOT/runs/h100_lean_decoupled_eta2/eval/eval_curve.json`，回传时一起贴。

| run | 做什么 | 预计训练 | 预计评测 |
|---|---|---|---|
| lean decoupled_eta2_full2 | 选题器 + 验证控制器 + 部分释放，动态价格 | 约 3 小时 | 约 0.5 小时 |
| rtl decoupled_eta2_sel | 只有选题器，动态价格（没有控制器） | 约 6 小时（每步按 50 s 估；10-26 的 full2 是 42 s） | 约 1.5 小时 |
| lean decoupled_eta2_sel | 同上 | 约 3.5 小时（10-26 实测 31 s/步） | 约 0.5 小时 |

`&&` 串起来的：前一个 run 的评测没结束，下一个不会开始，而且开跑前会等 GPU 清空，不会再出现 10-26 那种 OOM。
看进度：`tail -f $ROOT/logs/stage2b.log`，每个 run 结束打印 `H100_ARM_DONE` 和 `SYNC_READY`。
Weights & Biases 上的 run 名字和 10-26 的一样，按日期区分即可；连不上 wandb 会自动转离线模式，不影响训练。

**第一个 run 开跑约 1 小时后检查一次（重要）**：

```bash
$VENV/bin/python experiments/h100_20261019/stage2_summary.py $ROOT/runs/h100_lean_decoupled_eta2_full2
grep -c '"text_refit"' $ROOT/runs/h100_lean_decoupled_eta2_full2/train/output/admission_events.jsonl
```

看 `50-99` 那一行的 `price mean`：Lean 应在 1.5e-3 到 6e-3 之间；后面 `rtl sel` 开跑一小时后同样看一次，RTL 应在 5e-4 到 2e-3 之间。
在范围内就不用管；不在范围内把打印贴给我，我给新的 κ，你 `kill` 掉当前 run、带 `RTL_CTRL_KAPPA=<新值>` 重起这一条。
`grep -c` 应当 ≥ 1（第 50 步起每 50 步重拟一次文本先验）；是 0 的话把 `admission_events.jsonl` 里含 `text_refit` 的行贴给我，训练不用停。

## 五、checkpoint 怎么评（自动）

每 100 步存一个 checkpoint，run 结束后自动评第 0 步和 100/200/300/400 步共 5 个模型。RTL 评 VerilogEval-v2、CVDP cid003、cid002；
Lean 评 miniF2F-test 和 ProofNet-test。结果在 `$ROOT/runs/<run>/eval/eval_curve.json`。评完只留最后一个 checkpoint。

## 六、结果怎么回传（和上次一样：对话里贴摘要，文件发给我，我来归档）

每个 run 结束后先在对话里贴三样，不用等全部跑完：

```bash
$VENV/bin/python experiments/h100_20261019/summarize_run.py $ROOT/runs/h100_lean_decoupled_eta2_full2
$VENV/bin/python experiments/h100_20261019/stage2_summary.py $ROOT/runs/h100_lean_decoupled_eta2_full2
cat $ROOT/runs/h100_lean_decoupled_eta2_full2/eval/eval_curve.json
cat $ROOT/runs/h100_lean_barrier_r2/eval/eval_curve.json $ROOT/runs/h100_lean_decoupled_eta2/eval/eval_curve.json   # 补评的 ProofNet，最后贴一次
```

全部跑完后把每个 run 的 `$ROOT/outbox/<run>.tgz`（`sync_back.sh` 自动打的，分析全靠里面的 `verify_queue_events.jsonl` 和
`admission_events.jsonl`）和一份过程记录 MD（环境、冒烟、中止和修复、每个 run 两个汇总脚本的完整打印）发给我。

**请保留在磁盘上**：`$ROOT/runs/*/train/output/`、`$ROOT/runs/*/eval/`、最后一个 checkpoint、`$ROOT/outbox/*.tgz`、第二节挪开的 `*_1026` 目录。

## 七、什么情况找我

`git pull` 有冲突；setup 结尾缺 `CTRL_TABLES_OK`；gate 不通过；第一小时的 price 不在范围内；任何 run 的 manifest 不是 `completed`
（`$ROOT/logs/<run>.launch.log` 和 `stdout.log` 的最后 200 行贴给我）。其余情况按顺序跑完即可，不用等我。
